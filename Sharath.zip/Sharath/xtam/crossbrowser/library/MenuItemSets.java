package crossbrowser.library;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.List;

import org.json.JSONObject;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MenuItemSets {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();
	private lib_MCD mcd;
	private lib_RFM2 rfm;
         
    public MenuItemSets (WebDriver driver, Keywords actions, UIValidations uiActions, Map inputData, lib_MCD mcd, lib_RFM2 rfm){
    	this.driver = driver;
		this.actions = actions;
		this.uiActions = uiActions;
		this.input = inputData;
		this.mcd = mcd;
		this.rfm = rfm;      
    	
       }
       
       @Test
     /*****************************************************************************
   	 * Function Name: MMIS_VerifyUI ()
   	 * Date Created:21-Mar-2016
   	 * Author : Archana Savanji
   	 * Arguments: 
   	 * Description: This functions is verify the objects on Manage Menu set page. 
   	 * Pre-Rq. is Mange Menu set page should be open.
   	 * Used in script : 
   	
   	 ******************************************************************************/
      public boolean MMIS_VerifyUI(){
   		
   		System.out.println("*********************************** Start Test-Steps executions: MMIS_VerifyUI");
   			/** Verify below objects are displayed by default
   			"MenuItemSets.SearchSetName"
   			"MenuItemSets.SearchBtn"
   			"MenuItemSets.ViewFullList"
   			"MenuItemSets.NewMenuItemSet"
   			"MenuItemSets.FilterBtn"
   			"MenuItemSets.Market"
   			"MenuItemSets.Region"
   			"MenuItemSets.Coop"
   			"MenuItemSets.MenuSetTable"
   			"MenuItemSets.MenuSetTableCol1"
   			"MenuItemSets.MenuSetTableCol2"
   			"MenuItemSets.NextPage"
   			"MenuItemSets.Page2"
   			"MenuItemSets.Page3"
   			"MenuItemSets.PreviousPage"
   			"MenuItemSets.lblSearchList"
   			"MenuItemSets.lblSearchFullList"
   			"MenuItemSets.lblFilterList"
   			"MenuItemSets.lblRegion"
   			"MenuItemSets.lblMarket"
   			"MenuItemSets.lblCoop"
   		 */
   		boolean bflag = true;
   		try{
   			
   			// Verify default page controls
   			boolean b1 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.SearchSetName"); 
   			if (b1 == true)
   				{ System.out.println ("MenuItemSets.SearchSetName is found : "+b1);
   				}
   			else
   				{ System.out.println ("MenuItemSets.SearchSetName is not found :"+b1);
   				bflag = false;
				}
   			
   			boolean b2 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.SearchBtn");
   			
   			if (b2 == true)
				{ System.out.println ("MenuItemSets.SearchBtn is found : "+b2);
				}
			else
				{ System.out.println ("MenuItemSets.SearchBtn is not found :"+b2);
				bflag = false;
				}
   			
   			boolean b3 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.ViewFullList");
   			if (b3 == true)
   				{ System.out.println ("MenuItemSets.ViewFullList is found : "+b3);
			}
   			else
   				{ System.out.println ("MenuItemSets.ViewFullList is not found :"+b3);
   				bflag = false;
			}
   			
   			boolean b4 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.NewMenuItemSet");
   			if (b4 == true)
				{ System.out.println ("MenuItemSets.NewMenuItemSet is found : "+b4);
				}
			else
				{ System.out.println ("MenuItemSets.NewMenuItemSet is not found :"+b4);
				bflag = false;
				}
   			
   			boolean b5 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.FilterBtn");
   			if (b5 == true)
			{ System.out.println ("MenuItemSets.FilterBtn is found : "+b5);
			}
   			else
			{ System.out.println ("MenuItemSets.FilterBtn is not found :"+b5);
			bflag = false;
			}
   			
   			boolean b6 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.Market");
   			if (b6 == true)
			{ System.out.println ("MenuItemSets.Market is found : "+b6);
			}
   			else
			{ System.out.println ("MenuItemSets.Market is not found :"+b6);
			bflag = false;
			}
   			
   			boolean b7 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.Region");
   			if (b7 == true)
			{ System.out.println ("MenuItemSets.Region is found : "+b7);
			}
   			else
			{ System.out.println ("MenuItemSets.Region is not found :"+b7);
			bflag = false;
			}
   			
   			boolean b8 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.Coop");
   			if (b8 == true)
			{ System.out.println ("MenuItemSets.Coop is found : "+b8);
			}
   			else
			{ System.out.println ("MenuItemSets.Coop is not found :"+b8);
			bflag = false;
			}
   			
   			boolean b9 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.MenuSetTable");
   			if (b9 == true)
			{ System.out.println ("MenuItemSets.MenuSetTable is found : "+b9);
			}
   			else
			{ System.out.println ("MenuItemSets.MenuSetTable is not found :"+b9);
			bflag = false;
			}
   			
   			boolean b10 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.MenuSetTableCol1");
   			if (b10 == true)
			{ System.out.println ("MenuItemSets.MenuSetTableCol1 is found : "+b10);
			}
   			else
			{ System.out.println ("MenuItemSets.MenuSetTableCol1 is not found :"+b10);
			bflag = false;
			}
   			
   			boolean b11 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.MenuSetTableCol2");
   			if (b11 == true)
			{ System.out.println ("MenuItemSets.MenuSetTableCol2 is found : "+b11);
			}
   			else
			{ System.out.println ("MenuItemSets.MenuSetTableCol2 is not found :"+b11);
			bflag = false;
			}
   			
   			boolean b12 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.NextPage");
   			if (b12 == true)
			{ System.out.println ("MenuItemSets.NextPage is found : "+b12);
			}
   			else
			{ System.out.println ("MenuItemSets.NextPage is not found :"+b12);
			bflag = false;
			}
   			
   			boolean b13 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.Page2");
   			if (b13 == true)
			{ System.out.println ("MenuItemSets.Page2 is found : "+b13);
			}
   			else
			{ System.out.println ("MenuItemSets.Page2 is not found :"+b13);
			bflag = false;
			}
   			
   			boolean b14 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.Page3");
   			if (b14 == true)
			{ System.out.println ("MenuItemSets.Page3 is found : "+b14);
			}
   			else
			{ System.out.println ("MenuItemSets.Page3 is not found :"+b14);
			bflag = false;
			}
   			//boolean b15 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.PreviousPage");
   			
   			// Verify labels
   			boolean b16 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.lblSearchList");
   	   		boolean b19 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.lblRegion");
   			boolean b20 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.lblMarket");
   			boolean b21 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.lblCoop");
   			
   			if (b16 == true  && b19 == true && b20 == true && b21 == true)
			{ 
   				System.out.println ("MenuItemSets.lblSearchList is found : "+b16);
   				System.out.println ("MenuItemSets.lblRegion is found : "+b19);
   				System.out.println ("MenuItemSets.lblMarket is found : "+b20);
   				System.out.println ("MenuItemSets.lblCoop is found : "+b21);
			}
   			else
			{ 
   				System.out.println ("MenuItemSets.lblSearchList is found :  "+b16);
   			   	System.out.println ("MenuItemSets.lblRegion is found : "+b19);
   				System.out.println ("MenuItemSets.lblMarket is found : "+b20);
   				System.out.println ("MenuItemSets.lblCoop is found : "+b21);
   				bflag = false;
			}
   			
   			  
   		 }
   	   catch (Exception err1){
   		   System.out.println("Error:" +err1);
   	   }
   		System.out.println("*********************************** End of MMIS_VerifyUI function ");
   		return bflag;
   }
       
           
       
       /*****************************************************************************
      	 * Function Name: MMIS_CreateNewMenuItemSet ()
      	 * Date Created:22-Mar-2016
      	 * Author : Archana Savanji
      	 * Arguments: strNodeName - String. Node name to create Menu Item Set.
      	 * strPreRqMenu - List of Menu to add
      	 * Description: This functions is used to create New Menu Item set.
      	 * Pre-Rq. is Mange Menu set page should be open.
      	 * Used in script : 
      	
      	 ******************************************************************************/
         public String MMIS_CreateNewMenuItemSet(String strNodeName){
      		
      		System.out.println("*********************************** Start Test-Steps executions: MMIS_CreateNewMenuItemSet");
      		String strSetName="";
      		      		
      		boolean bflag = true;
      		try{
      			actions.click("MenuItemSets.NewMenuItemSet");
                Thread.sleep(2000);
                
                //switch to new menu item set window
                mcd.SwitchToWindow("Add New Menu Item Set");
                
                //menu item set name
                strSetName= mcd.fn_GetRndName("Auto");
                actions.setValue("NewMenuItemSet.SetName", strSetName);
                actions.keyboardEnter("NewMenuItemSet.SelectBtn");
                Thread.sleep(2000);
         
                
                mcd.SwitchToWindow("Select Node"); 
                                            
                mcd.Selectrestnode("SelectNode.Tree", strNodeName); 
                Thread.sleep(3000);
     
               
                mcd.SwitchToWindow("Add New Menu Item Set");                         
                //Thread.sleep(3000);
                
                actions.keyboardEnter("NewMenuItemSet.NextBtn");

                // Switch to Manage Menu Item Set : Common Menu Item Selector 
                mcd.SwitchToWindow("@Manage Menu Item Set : Common Menu Item Selector");
                //mcd.SwitchToWindow("#Title");
                Thread.sleep(2000);             
                System.out.println("--------------End of MMIS_CreateNewMenuItemSet function -------------");
                /*
                actions.smartWait(180);
                List<WebElement> Add_Chkbox = driver.findElements(By.xpath(".//input[@type = 'checkbox'][contains(@onclick, 'addMenuItem')]"));
                int Item_Counts = Add_Chkbox.size();
                int i_temp = 0;
                for (int n=0; n< Item_Counts; n++){
                                //Check whether enabled for Add or not
                                if((Add_Chkbox.get(n).isEnabled())){
                                                //Check box enabled - Add Item
                                                Add_Chkbox.get(n).sendKeys(Keys.SPACE);
                                                i_temp++;
                                }else{
                                                System.out.println("This MI is already added");                                                 
                                }
                                
                                if (i_temp==2){
                                                System.out.println("Selected 3 items for Add MI");
                                                break;
                                }
                                Thread.sleep(1000);
                }
                            
                actions.keyboardEnter("AddRemoveMenu.Savebtn");
                actions.smartWait(120);                
                actions.verifyTextPresence("Your changes have been saved.", true);
                Thread.sleep(2000);
                actions.keyboardEnter("MenuItemSets.ReturnToSet");
                actions.smartWait(120);
                
                mcd.SwitchToWindow("#Title");
                
                */
                
                }
         	
      			catch(Exception e){
//                e.printStackTrace();
//                Reporter.log("Failed Test : "+e.getMessage());
      				actions.catchException(e);
    			}
      			return strSetName;
         	}
      
         
         /*****************************************************************************
        	 * Function Name: MMIS_Search ()
        	 * Date Created:22-Mar-2016
        	 * Author : Archana Savanji
        	 * Arguments: strSetName - String. Set name to search. 
        	 * Description: This functions is used to search Menu Item set.
        	 * Pre-Rq. is Mange Menu set page should be open.
        	 * Used in script : 
        	
        	 ******************************************************************************/
           public void MMIS_Search(String strSetName){
        		
        		System.out.println("*********************************** Start Test-Steps executions: MMIS_Search");
        		
        		try{
        			
        			// Verify default page controls
        			boolean b1 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.SearchSetName"); 
        			        			
        			if (b1 == true)
        				{ 
        				actions.setValue("MenuItemSets.SearchSetName", strSetName);
        				actions.smartWait(10);
        				actions.keyboardEnter("ManageDimensionGroup.SearchButton");
        				Thread.sleep(4000); 
        				boolean b2 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.SearchedMenuLink");
        				if(b2 == true){
            				actions.reportCreatePASS("Verify Search", strSetName+ " - Menu Item Set should be displayed", strSetName+ " - Menu Item Set is displayed", "Pass");
            				}
            				else
            				{
            				actions.reportCreateFAIL("Verify Search", strSetName+ " - Menu Item Set should be displayed", strSetName+ " - Menu Item Set is not displayed", "Fail");
            				}
        				}
        			else
        				{ 
        				System.out.println ("MenuItemSets.SearchSetName object is not found :"+b1);
        			     }        			
        			}
        	   catch (Exception err1){
        		   System.out.println("Error:" + err1);
        	   }
        		System.out.println("*********************************** End of MMIS_Search function ");
        		
        }
         
           
         /*****************************************************************************
       	 * Function Name: MMIS_ViewFullList ()
       	 * Date Created:22-Mar-2016
       	 * Author : Archana Savanji
       	 * Arguments: 
       	 * Description: This functions is used to view full list of Menu Item set.
       	 * Pre-Rq. is Mange Menu set page should be open.
       	 * Used in script : 
       	
       	 ******************************************************************************/
          public void MMIS_ViewFullList(){
       		
       		System.out.println("*********************************** Start Test-Steps executions: MMIS_ViewFullList");
       		
       		try{
       			
       				actions.keyboardEnter("MenuItemSets.ViewFullList");
//       				Thread.sleep(4000); 
       				actions.smartWait(180);
       				
       				boolean b2 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.NextPage");
       				boolean b1 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.SearchedMenuLink");
       				
       				if(b2 == true && b2 == true){
           					actions.reportCreatePASS("Click View Full List button on Menu Item Set page", "Menu Item Set list should be displayed", "Menu Item Set list is displayed", "Pass");
           				}
           			else
           				{
           					actions.reportCreateFAIL("Click View Full List button on Menu Item Set page", "Menu Item Set list should be displayed", "Menu Item Set list is displayed", "Fail");
           				}
       						
       			}
       	   catch (Exception err1){
       		   System.out.println("Error:" + err1);
       	   }
       		System.out.println("*********************************** End of MMIS_ViewFullList function ");
       		
       }
          
          /*****************************************************************************
         	 * Function Name: VerifyGUIObjects ()
         	 * Date Created:28-Mar-2016
         	 * Author : Archana Savanji
         	 * Arguments: strWebElementList - List of string with #
         	 * Description: This functions is used to verify that GUI Object exists or not
         	 * For example: strWebElementList ="CopyComponents.MergeBtn#CopyComponents.SearchBeginswith#CopyComponents.SearchBeginswith#CopyComponents.SearchEndswith#CopyComponents.SearchContains#CopyComponents.SearchText#CopyComponents.Status#CopyComponents.Move>#CopyComponents.Move>>#CopyComponents.Move<#CopyComponents.Move<<";
         	 ******************************************************************************/    
          public void VerifyGUIObjects(String strWebElementList) {
      		
      		int i;
      		String[] strWebElement = strWebElementList.split("#");
      		System.out.println("Object count:" +strWebElement.length);
      		
      		for (i=0;i<strWebElement.length;i++)
      			
      		{
      			try {
      				System.out.println("Verifying Object: "+strWebElement[i]);
      				
      				WebElement eleWebEdit = actions.getwebDriverLocator(actions.getLocator(strWebElement[i]));
      				
      				if (eleWebEdit != null) {
      					actions.reportCreatePASS("Verify object ","'"+ strWebElement[i]+ "' Should be displayed", strWebElement[i]+ " is displayed", "Pass");
      					} 
      				else {
      					actions.reportCreateFAIL("Verify object ","'"+ strWebElement[i]+ "' Should be displayed", strWebElement[i]+ " is not displayed", "Fail");
      			       	}
      				} 
      			catch (Exception e) {
      						e.printStackTrace();
      					}
      		}
      		
      	}
        
          
          /*****************************************************************************
       	 * Function Name: VerifyPromotionalTab (String sPromotionFlag)
       	 * Date Created:04-Apr-2016
       	 * Author : Archana Savanji
       	 * Arguments: String sPromotionFlag - Set it TRUE if you want to verify Protional Tab is enabled
       	 * Description: This functions is used to verify that Promotional Tab Default Settings
       	 
       	 ******************************************************************************/    
        public void VerifyPromotionalTab(String sPromotionFlag) {
    		// Assume that user has performed steps: Open Menu Item Set and clicks a menu Item link to invoke Manage Menu Item page
    	
        	switch(sPromotionFlag)
    				{
    				case "true":
    					// Click Promotion Range tab 	
    					actions.keyboardEnter("ManageMenuItem.PromotionRangeTab");
    					actions.smartWait(10);
    					
    					boolean bflag = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.PRStDate"))).isDisplayed();
        			
    					if (bflag == true){
        				actions.reportCreatePASS("Verify that promotional Tab is enabled and open", "Promotional Tab should be enabled and open.", "Promotional Tab is enabled and open.", "Pass");
    					}
    					else{
        				actions.reportCreatePASS("Verify that promotional Tab is enabled and open", "Promotional Tab should be open.", "Promotional Tab is not open.", "Fail");
    					}
        			
    				case "false":
    					String bflag1 = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.PromotionRangeTab"))).getAttribute("disabled");
    				
    					if (bflag1 == "true"){
    						actions.reportCreatePASS("Verify that promotional Tab is disabled", "Promotional Tab should be disabled.", "Promotional Tab is disabled.", "Pass");
    					}
    					else{
    						actions.reportCreatePASS("Verify that promotional Tab is disabled", "Promotional Tab should be disabled.", "Promotional Tab is not disabled.", "Fail");
    					}
    				
    				}
    		}
        
        /*****************************************************************************
       	 * Function Name: SetPromotionalTabDates ()
       	 * Date Created:04-Apr-2016
       	 * Author : Archana Savanji
       	 * Arguments: 
       	 * Description: This functions is used to verify that Promotional Tab Start Date and End Date
                	 
       	 ******************************************************************************/    
        public void SetPromotionalTabDates(int iSDNum, int iEDNum, String strApplicationDate, String sMsg) throws Exception {
    		// Assume that user has performed steps: Open Menu Item Set and clicks a menu Item link to invoke Manage Menu Item page
    	    // Click Promotion Range tab 	
    		//actions.keyboardEnter("ManageMenuItem.PromotionRangeTab");
    		//actions.smartWait(10);
        	int i;
      		String[] strMessages = sMsg.split("#");
      		System.out.println("Verification message count:" +strMessages.length);
      		
    		// Set Start Date
    		 driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.PRStDatebtn"))).click();
    		// mcd.Get_future_date(x, Calender_Type, app_date);
             mcd.Get_future_date(iSDNum, "Close",strApplicationDate);
             actions.smartWait(3);
    		
             
             driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.PREndDatebtn"))).click();
     		// mcd.Get_future_date(x, Calender_Type, app_date);
              mcd.Get_future_date(iEDNum, "Close",strApplicationDate);
              actions.smartWait(3);              
              
              actions.keyboardEnter("ManageMenuItem.ApplySavebtn");
              Thread.sleep(3000);
              
              mcd.SwitchToWindow("Apply Changes Details");
              actions.smartWait(10);
              
              actions.keyboardEnter("ApplyChangesDetails.SaveBtn");             
              
              mcd.SwitchToWindow("Manage Menu Items");
              actions.smartWait(10);
              // Verify message:Your changes have been saved
              actions.verifyTextPresence(strMessages[0], true);
              
              actions.click("ManageMenuItem.StartDateEraser");
              actions.keyboardEnter("ManageMenuItem.StartDateEraser");
              
              actions.click("ManageMenuItem.EndDateEraser");
              actions.keyboardEnter("ManageMenuItem.EndDateEraser");
              
              actions.keyboardEnter("ManageMenuItem.ApplySavebtn");
              
              
              actions.smartWait(10);
             
           // Verify message:Your changes have been saved
              actions.verifyTextPresence(strMessages[0], true);
              
              driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.PRStDatebtn"))).click();
      		
               mcd.Get_future_date(iSDNum, "Close",strApplicationDate);
               actions.smartWait(3);
               
               actions.keyboardEnter("ManageMenuItem.ApplySavebtn");
               actions.smartWait(10);
              
            // Verify message:Your changes have been saved
               actions.verifyTextPresence(strMessages[0], true);
               
               actions.click("ManageMenuItem.StartDateEraser");
               actions.keyboardEnter("ManageMenuItem.StartDateEraser");
               
               driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.PREndDatebtn"))).click();
  
                 mcd.Get_future_date(iEDNum, "Close",strApplicationDate);
                 actions.smartWait(3);  
                  
                  actions.keyboardEnter("ManageMenuItem.ApplySavebtn");
                 
               // Verify message:Your changes have been saved
             
                  System.out.println("Verify Message: "+strMessages[1]);
                  mcd.VerifyAlertMessageDisplayed("warning", strMessages[1], true,AlertPopupButton.OK_BUTTON);
                  actions.smartWait(10);
                  		
    		}
         
         
}
