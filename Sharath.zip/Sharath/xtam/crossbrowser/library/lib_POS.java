package crossbrowser.library;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.openqa.selenium.support.ui.Select;

//import com.sun.org.apache.bcel.internal.generic.Select;
//import com.sun.xml.internal.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class lib_POS {
	private static final String Value = null;
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();
	private lib_MCD mcd;
	private lib_RFM2 rfm;

	public lib_POS(WebDriver nodeDriver, Keywords actions, UIValidations uiActions, Map inputData, lib_MCD mcd,
			lib_RFM2 rfm) {
		this.driver = nodeDriver;
		this.actions = actions;
		this.uiActions = uiActions;
		this.input = inputData;
		this.mcd = mcd;
		this.rfm = rfm;
	}

	@Test

	// ----------------------------------
	/*
	 * Feature Name : Production Routing Set Functionality :GUI Validation of
	 * Production Routing Set Scenario ID : POS_0071 Author : Sonam
	 */
	// -----------------------------------

	public void RFM_POS_GUIValidationProductionRoutingSet() {

		// Verify Search Label is displayed
		boolean flag1 = driver.findElement(By.xpath(actions.getLocator("RFMProductionRoutingPage.SearchLabel")))
				.isDisplayed();
		// System.out.println(flag1);
		if (flag1 == true) {
			System.out.println("Search label is Displayed as expected - PASS");
			actions.reportCreatePASS("Validating the Production Routing Set - Search label is displayed",
					"Production Routing Set - Search label should be displayed",
					"Production Routing Set - Search label is displayed", "Pass");
		} else {
			System.out.println("Search label is Not Displayed - FAIL");
			actions.reportCreateFAIL("Validating the Production Routing Set - Search label is displayed",
					"Production Routing Set - Search label should be displayed",
					"Production Routing Set - Search label is not displayed", "Fail");
		}
		// Verify Search text box is displayed and enabled
		boolean flag2 = driver.findElement(By.xpath(actions.getLocator("RFMProductionRoutingPage.SearchTextBox")))
				.isDisplayed();
		// System.out.println(flag2);
		if (flag2 == true) {
			System.out.println("Search Textbox is Displayed as expected - PASS");
			actions.reportCreatePASS("Validating the Production Routing Set - Search text box is displayed",
					"Production Routing Set - Search text box should be displayed",
					"Production Routing Set - Search text box is displayed", "Pass");
			boolean flag = driver.findElement(By.xpath(actions.getLocator("RFMProductionRoutingPage.SearchTextBox")))
					.isEnabled();
			if (flag == true) {
				System.out.println("Search textbox is Enabled as expected - PASS");
				actions.reportCreatePASS("Validating the Production Routing Set - Search text box is enabled",
						"Production Routing Set - Search text box should be enabled",
						"Production Routing Set - Search text box is enabled", "Pass");
			} else {
				System.out.println("Search textbox is Not Enabled - FAIL");
				actions.reportCreateFAIL("Validating the Production Routing Set - Search text box is enabled",
						"Production Routing Set - Search text box should be enabled",
						"Production Routing Set - Search text box is not enabled", "Fail");
			}
		} else {
			System.out.println("Search Textbox is Not Displayed - FAIL");
			actions.reportCreateFAIL("Validating the Production Routing Set - Search text box is displayed",
					"Production Routing Set - Search text box should be displayed",
					"Production Routing Set - Search text box is not displayed", "Fail");
		}
		// Verify SearchwithinStatus Filter DDL is displayed and enabled
		boolean flag3 = driver
				.findElement(By.xpath(actions.getLocator("RFMProductionRoutingPage.FilterSearchwithinStatus")))
				.isDisplayed();
		// System.out.println(flag3);
		if (flag3 == true) {
			System.out.println("SearchwithinStatus Filter DDL is Displayed as expected - PASS");
			actions.reportCreatePASS(
					"Validating the Production Routing Set -  SearchwithinStatus Filter DDL is displayed",
					"Production Routing Set - SearchwithinStatus Filter DDL should be displayed",
					"Production Routing Set - SearchwithinStatus Filter DDL is displayed", "Pass");
			boolean flag = driver
					.findElement(By.xpath(actions.getLocator("RFMProductionRoutingPage.FilterSearchwithinStatus")))
					.isEnabled();
			if (flag == true) {
				System.out.println("SearchwithinStatus Filter DDL is Enabled as expected - PASS");
				actions.reportCreatePASS(
						"Validating the Production Routing Set -  SearchwithinStatus Filter DDL is enabled",
						"Production Routing Set - SearchwithinStatus Filter DDL should be enabled",
						"Production Routing Set - SearchwithinStatus Filter DDL is enabled", "Pass");
			} else {
				System.out.println("SearchwithinStatus Filter DDL is Not Enabled - FAIL");
				actions.reportCreateFAIL(
						"Validating the Production Routing Set -  SearchwithinStatus Filter DDL is enabled",
						"Production Routing Set - SearchwithinStatus Filter DDL should be enabled",
						"Production Routing Set - SearchwithinStatus Filter DDL is not enabled", "Fail");
			}
		} else {
			System.out.println("SearchwithinStatus Filter DDL is Not Displayed - FAIL");
			actions.reportCreateFAIL(
					"Validating the Production Routing Set -  SearchwithinStatus Filter DDL is displayed",
					"Production Routing Set - SearchwithinStatus Filter DDL should be displayed",
					"Production Routing Set - SearchwithinStatus Filter DDL is not displayed", "Fail");
		}
		// Verify View Full List button is displayed and enabled
		boolean flag4 = driver.findElement(By.xpath(actions.getLocator("RFMProductionRoutingPage.ViewFullListButton")))
				.isDisplayed();
		// System.out.println(flag4);
		if (flag4 == true) {
			System.out.println("View Full List button is Displayed as expected - PASS");
			actions.reportCreatePASS("Validating the Production Routing Set -  View Full List button is displayed",
					"Production Routing Set - View Full List button should be displayed",
					"Production Routing Set - View Full List button is displayed", "Pass");
			boolean flag = driver
					.findElement(By.xpath(actions.getLocator("RFMProductionRoutingPage.ViewFullListButton")))
					.isEnabled();
			if (flag == true) {
				System.out.println("View Full List button is Enabled as expected - PASS");
				actions.reportCreatePASS("Validating the Production Routing Set -  View Full List button is enabled",
						"Production Routing Set - View Full List button should be enabled",
						"Production Routing Set - View Full List button is enabled", "Pass");
			} else {
				System.out.println("View Full List button is Not Enabled - FAIL");
				actions.reportCreateFAIL("Validating the Production Routing Set -  View Full List button is enabled",
						"Production Routing Set - View Full List button should be enabled",
						"Production Routing Set - View Full List button is not enabled", "Fail");
			}
		} else {
			System.out.println("View Full List button is Not Displayed - FAIL");
			actions.reportCreateFAIL("Validating the Production Routing Set -  View Full List button is displayed",
					"Production Routing Set - View Full List button should be displayed",
					"Production Routing Set - View Full List button is not displayed", "Fail");
		}
		// Verify Search button is displayed and enabled
		boolean flag5 = driver.findElement(By.xpath(actions.getLocator("RFMProductionRoutingPage.SearchButton")))
				.isDisplayed();
		// System.out.println(flag5);
		if (flag5 == true) {
			System.out.println("Search button is Displayed as expected - PASS");
			actions.reportCreatePASS("Validating the Production Routing Set -  Search button is displayed",
					"Production Routing Set - Search button should be displayed",
					"Production Routing Set - Search button is displayed", "Pass");
			boolean flag = driver.findElement(By.xpath(actions.getLocator("RFMProductionRoutingPage.SearchButton")))
					.isEnabled();
			if (flag == true) {
				System.out.println("Search button is Enabled as expected - PASS");
				actions.reportCreatePASS("Validating the Production Routing Set -  Search button is enabled",
						"Production Routing Set - Search button should be enabled",
						"Production Routing Set - Search button is enabled", "Pass");
			} else {
				System.out.println("Search button is Not Enabled - FAIL");
				actions.reportCreateFAIL("Validating the Production Routing Set -  Search button is enabled",
						"Production Routing Set - Search button should be enabled",
						"Production Routing Set - Search button is not enabled", "Fail");
			}
		} else {
			System.out.println("Search button is Not Displayed - FAIL");
			actions.reportCreateFAIL("Validating the Production Routing Set -  Search button is displayed",
					"Production Routing Set - Search button should be displayed",
					"Production Routing Set - Search button is not displayed", "Fail");
		}
		// Verify PostSearch Filter Status DDL is displayed and enabled
		boolean flag6 = driver
				.findElement(By.xpath(actions.getLocator("RFMProductionRoutingPage.PostSearchFilterStatus")))
				.isDisplayed();
		// System.out.println(flag6);
		if (flag6 == true) {
			System.out.println("PostSearch Filter Status DDL is Displayed as expected - PASS");
			// Reporter.log("PostSearch Filter Status DDL is Displayed as
			// expected - PASS");
			actions.reportCreatePASS("Verify PostSearch Filter Status DDL",
					"PostSearch Filter Status DDL should be Displayed",
					"PostSearch Filter Status DDL is Displayed as expected", "PASS");

			boolean flag = driver
					.findElement(By.xpath(actions.getLocator("RFMProductionRoutingPage.PostSearchFilterStatus")))
					.isEnabled();
			if (flag == false) {
				System.out.println("PostSearch Filter Status DDL is Disabled as expected - PASS");
				// Reporter.log("PostSearch Filter Status DDL is Disabled as
				// expected - PASS");
				actions.reportCreatePASS("Verify PostSearch Filter Status DDL",
						"PostSearch Filter Status DDL should be Disabled",
						"PostSearch Filter Status DDL is Disabled as expected", "PASS");
			} else {
				System.out.println("PostSearch Filter Status DDL is Not Disabled - FAIL");
				// Reporter.log("PostSearch Filter Status DDL is Not Disabled -
				// FAIL");
				actions.reportCreateFAIL("Verify PostSearch Filter Status DDL",
						"PostSearch Filter Status DDL should be Disabled",
						"PostSearch Filter Status DDL is not Disabled", "FAIL");
			}
		} else {
			// System.out.println("PostSearch Filter Status DDL is Not Displayed
			// - FAIL");
			// Reporter.log("PostSearch Filter Status DDL is Not Displayed -
			// FAIL");
			actions.reportCreateFAIL("Verify PostSearch Filter Status DDL",
					"PostSearch Filter Status DDL should be Displayed", "PostSearch Filter Status DDL is not Displayed",
					"FAIL");
		}
		// Verify New button is displayed and enabled
		boolean flag7 = driver.findElement(By.xpath(actions.getLocator("RFMProductionRoutingPage.NewButton")))
				.isDisplayed();
		// System.out.println(flag7);
		if (flag7 == true) {
			System.out.println("New button is Displayed as expected - PASS");
			// Reporter.log("New button is Displayed as expected - PASS");
			Report_Element_Displayed("New button", "displayed", "PASS");
			boolean flag = driver.findElement(By.xpath(actions.getLocator("RFMProductionRoutingPage.NewButton")))
					.isEnabled();
			if (flag == true) {
				System.out.println("New button is Enabled as expected - PASS");
				// Reporter.log("New button is Enabled as expected - PASS");
				Report_Element_Displayed("New button", "enabled", "PASS");
			} else {
				System.out.println("New button is Not Enabled - FAIL");
				// Reporter.log("New button is Not Enabled - FAIL");
				Report_Element_Displayed("New button", "enabled", "FAIL");
			}
		} else {
			System.out.println("New button is Not Displayed - FAIL");
			Report_Element_Displayed("New button", "displayed", "FAIL");
			// Reporter.log("New button is Not Displayed - FAIL");
		}
		// Verify Grid is displayed
		boolean flag8 = driver.findElement(By.xpath(actions.getLocator("RFMProductionRoutingPage.Table")))
				.isDisplayed();
		// System.out.println(flag8);
		if (flag8 == true) {
			System.out.println("Grid is Displayed as expected - PASS");
			// Reporter.log("Grid is Displayed as expected - PASS");
			Report_Element_Displayed("Grid", "displayed", "PASS");
		} else {
			System.out.println("Grid is Not Displayed - FAIL");
			// Reporter.log("Grid is Not Displayed - FAIL");
			Report_Element_Displayed("Grid", "displayed", "FAIL");
		}
		// Verify Name Column is displayed
		boolean flag9 = driver.findElement(By.xpath(actions.getLocator("RFMProductionRoutingPage.NameColumn")))
				.isDisplayed();
		// System.out.println(flag9);
		if (flag9 == true) {
			System.out.println("Name Column is Displayed as expected - PASS");
			// Reporter.log("Name Column is Displayed as expected - PASS");
			Report_Element_Displayed("Name Column", "displayed", "PASS");
		} else {
			System.out.println("Name Column is Not Displayed - FAIL");
			// Reporter.log("Name Column is Not Displayed - FAIL");
			Report_Element_Displayed("Name Column", "displayed", "FAIL");
		}
		// Verify Description Column is displayed
		boolean flag10 = driver.findElement(By.xpath(actions.getLocator("RFMProductionRoutingPage.DescriptionColumn")))
				.isDisplayed();
		// System.out.println(flag10);
		if (flag10 == true) {
			System.out.println("Description Column is Displayed as expected - PASS");
			// Reporter.log("Description Column is Displayed as expected -
			// PASS");
			Report_Element_Displayed("Description Column", "displayed", "PASS");
		} else {
			System.out.println("Description Column is Not Displayed - FAIL");
			// Reporter.log("Description Column is Not Displayed - FAIL");
			Report_Element_Displayed("Description Column", "displayed", "FAIL");
		}
		// Verify Status Column is displayed
		boolean flag11 = driver.findElement(By.xpath(actions.getLocator("RFMProductionRoutingPage.StatusColumn")))
				.isDisplayed();
		// System.out.println(flag11);
		if (flag11 == true) {
			System.out.println("Status Column is Displayed as expected - PASS");
			// Reporter.log("Status Column is Displayed as expected - PASS");
			Report_Element_Displayed("Status Column", "displayed", "PASS");
		} else {
			System.out.println("Status Column is Not Displayed - FAIL");
			// Reporter.log("Status Column is Not Displayed - FAIL");
			Report_Element_Displayed("Status Column", "displayed", "FAIL");
		}
		// Verify Delete Column is displayed
		boolean flag12 = driver.findElement(By.xpath(actions.getLocator("RFMProductionRoutingPage.DeleteColumn")))
				.isDisplayed();
		// System.out.println(flag12);
		if (flag12 == true) {
			System.out.println("Delete Column is Displayed as expected - PASS");
			// Reporter.log("Delete Column is Displayed as expected - PASS");
			Report_Element_Displayed("Delete Column", "displayed", "PASS");
		} else {
			System.out.println("Delete Column is Not Displayed - FAIL");
			// Reporter.log("Delete Column is Not Displayed - FAIL");
			Report_Element_Displayed("Delete Column", "displayed", "FAIL");
		}
	}

	// ----------------------------------
	/*
	 * Feature Name : Production Routing Set Functionality :Search Validation
	 * Production Routing Set - Select Node Author : Sonam
	 */
	// -----------------------------------

	public void RFM_POS_SearchProductionRoutingSet(String strSearchValue, String strNoRecordMsg)
			throws InterruptedException {

		// Variable Declaration
		int iTemp = 0;
		int row_cnt = 0;

		// Clear the text box value
		actions.clear("RFMPresentationRoutingSetSelectNodePage.SearchTextbox");
		Thread.sleep(1000);
		// Enter Search value

		driver.findElement(By.xpath(actions.getLocator("RFMPresentationRoutingSetSelectNodePage.SearchTextbox")))
				.sendKeys(strSearchValue);
		// actions.setValue("RFMPresentationRoutingSetSelectNodePage.SearchTextbox",
		// strSearchValue);
		Thread.sleep(500);
		// Click on Search button
		actions.click("RFMPresentationRoutingSetSelectNodePage.SearchButton");
		Thread.sleep(5000);
		// actions.smartWait(100);
		System.out.println(strSearchValue);

		if (strSearchValue == null) {
			System.out.println("> Click on OK button of Message Box");
			mcd.VerifyAlertMessageDisplayed("Expected Message", "Please enter a search criteria.", true,
					AlertPopupButton.OK_BUTTON);
		} else {
			// Get row count of number of Presentation Routing sets fetched
			row_cnt = mcd.GetTableRowCount("RFMPresentationRoutingSetSelectNodePage.SelectNodeTable");
			// Verify the name containing search value
			if (row_cnt == 0) {
				WebElement msg_element = driver.findElement(By.xpath("//*[@id='_infoCode']/li/span"));
				String temp_msg = msg_element.getText();
				if (temp_msg.equals(strNoRecordMsg)) {
					// Reporter.log( strNoRecordMsg + " message is displayed as
					// expected " + "- PASS");
					System.out.println("No records available with the search text - " + strSearchValue);
					System.out.println(strNoRecordMsg + " message is displayed as expected " + "- PASS");
				}
			} else {
				List<WebElement> PrdRSet_List = driver.findElements(By.xpath("//*[@id='userRoleData']/tr"));
				// Get row count of number of Production Routing sets fetched
				row_cnt = PrdRSet_List.size();
				for (int i = 1; i <= row_cnt && i < 10; i++) {
					try {
						String xpath = "//*[@id='userRoleData']/tr[" + i + "]/td[1]/a";
						String PreRSet_Name = driver.findElement(By.xpath(xpath)).getText();
						System.out.println(PreRSet_Name);

						if (PreRSet_Name.contains(strSearchValue.toLowerCase())
								|| PreRSet_Name.contains(strSearchValue.toUpperCase())
								|| PreRSet_Name.contains(strSearchValue)) {
							iTemp = iTemp + 1;
						} else {
							System.out.println(
									PreRSet_Name + " doesnot contain the search value - " + strSearchValue + " - FAIL");
							actions.reportCreateFAIL("Validation of Search Criteria",
									"All the fetched records should contain the search value as " + strSearchValue,
									PreRSet_Name + " doesnot contain the search value - " + strSearchValue, "FAIL");
							iTemp = 0;
							break;
						}
						if (iTemp == row_cnt) {
							System.out.println("All the fetched Production Routing Sets contains the search value - "
									+ strSearchValue + " - PASS");
							actions.reportCreatePASS("Validation of Search Criteria",
									"All the fetched records should contain the search value as " + strSearchValue,
									"All the fetched Production Routing Sets contains the search value - "
											+ strSearchValue,
									"PASS");
						}
					} catch (Exception e) {
						System.out.println("No records available with the search text -  " + strSearchValue);
					}

				}
			}
		}
	}

	// ----------------------------------
	/*
	 * Feature Name : Production Routing Set Functionality : Search with Filter
	 * Validation Production Routing Set Author : Sonam
	 */
	// -----------------------------------

	public void RFM_POS_SearchwithFilterProductionRoutingSet(String strSearchValue, String strStatus,
			String strNoRecordMsg) throws InterruptedException {

		// Variable Declaration
		int iTemp = 0;
		int row_cnt = 0;

		// Clear the text box value
		actions.clear("RFMPresentationRoutingSetSelectNodePage.SearchTextbox");
		Thread.sleep(1000);
		// Enter Search value
		actions.setValue("RFMPresentationRoutingSetSelectNodePage.SearchTextbox", strSearchValue);
		Thread.sleep(500);
		// Select Status
		actions.setValue("RFMPresentationRoutingSetSelectNodePage.SearchStatusDDL", strStatus);
		// Click on Search button
		actions.click("RFMPresentationRoutingSetSelectNodePage.SearchButton");
		Thread.sleep(5000);
		// Verify the PostSearch Filter Status is selected same as selected
		// status
		boolean flag = driver
				.findElement(By.xpath(actions.getLocator("RFMPresentationRoutingSetSelectNodePage.filterStatusDDL")))
				.isEnabled();
		if (flag == false && (strStatus == "Active" || strStatus == "Inactive")) {
			System.out.println("PostSearch Filter is Disabled");
		} else {
			System.out.println("PostSearch Filter is Not Disbaled");
		}

		if (strSearchValue == null) {
			System.out.println("> Click on OK button of Message Box");
			mcd.VerifyAlertMessageDisplayed("Expected Message", "Please enter a search criteria.", true,
					AlertPopupButton.OK_BUTTON);
		} else {

			// Get row count of number of Production Routing sets fetched
			row_cnt = mcd.GetTableRowCount("RFMPresentationRoutingSetSelectNodePage.SelectNodeTable");

			// Verify the name containing search value
			if (row_cnt == 0) {
				WebElement msg_element = driver.findElement(By.xpath("//*[@id='_infoCode']/li/span"));
				String temp_msg = msg_element.getText();

				if (temp_msg.equals(strNoRecordMsg)) {
					System.out.println("No records available with the search text - " + strSearchValue);
					System.out.println(strNoRecordMsg + " message is displayed as expected " + "- PASS");
				}
			} else {

				List<WebElement> PrdRSet_List = driver.findElements(By.xpath("//*[@id='userRoleData']/tr"));
				// Get row count of number of Production Routing sets fetched
				row_cnt = PrdRSet_List.size();
				for (int i = 1; i <= row_cnt && i == 10; i++) {
					try {
						String xpath1 = "//*[@id='userRoleData']/tr[" + i + "]/td[1]/a";
						String xpath2 = "//*[@id='userRoleData']/tr[" + i + "]/td[3]";
						String PreRSet_Name = driver.findElement(By.xpath(xpath1)).getText();
						System.out.println(PreRSet_Name);
						String PreRSet_Status = driver.findElement(By.xpath(xpath2)).getText();
						System.out.println(PreRSet_Status);

						if (strStatus == "Active/Inactive") {
							if (PreRSet_Status.equals("Active") || PreRSet_Status.equals("Inactive")) {
								iTemp = iTemp + 1;
							} else {
								System.out.println(
										PreRSet_Name + " doesnot have the status value " + strStatus + " - FAIL");
								actions.reportCreateFAIL("Validation of Post Status Filter",
										"All the fetched records should have status as " + strStatus,
										PreRSet_Name + " doesnot have the status value " + strStatus, "FAIL");
								iTemp = 0;
								break;
							}
						} else {
							if (PreRSet_Status.equals(strStatus)) {
								iTemp = iTemp + 1;
							} else {
								System.out.println(
										PreRSet_Name + " doesnot have the status value " + strStatus + " - FAIL");
								actions.reportCreateFAIL("Validation of Post Status Filter",
										"All the fetched records should have status as " + strStatus,
										PreRSet_Name + " doesnot have the status value " + strStatus, "FAIL");
								iTemp = 0;
								break;
							}

						}

						if (iTemp == row_cnt) {
							System.out.println("All the fetched Production Routing Sets are having status value - "
									+ strStatus + " - PASS");
							actions.reportCreatePASS("Validation of Post Status Filter",
									"All the fetched records should have status as " + strStatus,
									"All the fetched Production Routing Sets are having status value - " + strStatus,
									"PASS");
						}

					} catch (Exception e) {
						System.out.println("No records available with the search text - " + strSearchValue);
					}

				}
			}
		}
	}

	// --------------------------------------
	/*
	 * Feature Name : Production Routing Set Functionality : Verify Post Status
	 * Filter functionality in Production Routing Set - Select Node Author :
	 * Sonam
	 */
	// ---------------------------------------

	public void RFM_POS_FilterStatusProductionRoutingSet(String strStatus, String strNoRecordMsg)
			throws InterruptedException {

		// Variable Declaration
		int iTemp = 0;
		int row_cnt = 0;

		// Clear the text box value
		actions.clear("RFMPresentationRoutingSetSelectNodePage.SearchTextbox");
		Thread.sleep(1000);
		// Click on View Full List button
		actions.click("RFMPresentationRoutingSetSelectNodePage.ViewFullListButton");
		actions.smartWait(100);
		// Select Status
		actions.setValue("RFMPresentationRoutingSetSelectNodePage.filterStatusDDL", strStatus);
		// Get row count of number of Production Routing sets fetched
		row_cnt = mcd.GetTableRowCount("RFMPresentationRoutingSetSelectNodePage.SelectNodeTable");
		// Verify the name containing search value
		if (row_cnt == 0) {
			WebElement msg_element = driver.findElement(By.xpath("//*[@id='_infoCode']/li/span"));
			String temp_msg = msg_element.getText();
			if (temp_msg.equals(strNoRecordMsg)) {
				System.out.println("No records available");
				System.out.println(strNoRecordMsg + " message is displayed as expected " + "- PASS");
			}
		} else {
			List<WebElement> PreRSet_List = driver.findElements(By.xpath("//*[@id='userRoleData']/tr"));
			// Get row count of number of Production Routing sets fetched
			row_cnt = PreRSet_List.size();
			for (int i = 1; i <= row_cnt; i++) {
				try {
					String xpath1 = "//*[@id='userRoleData']/tr[" + i + "]/td[1]/a";
					String xpath2 = "//*[@id='userRoleData']/tr[" + i + "]/td[3]";
					String PreRSet_Name = driver.findElement(By.xpath(xpath1)).getText();
					System.out.println(PreRSet_Name);
					String PreRSet_Status = driver.findElement(By.xpath(xpath2)).getText();
					System.out.println(PreRSet_Status);
					if (strStatus == "Active/Inactive") {
						if (PreRSet_Status.equals("Active") || PreRSet_Status.equals("Inactive")) {
							iTemp = iTemp + 1;
						} else {
							System.out
									.println(PreRSet_Name + " doesnot have the status value " + strStatus + " - FAIL");
							actions.reportCreateFAIL("Validation of Post Status Filter",
									"All the fetched records should have status as " + strStatus,
									PreRSet_Name + " doesnot have the status value " + strStatus, "FAIL");
							iTemp = 0;
							break;
						}
					} else {
						if (PreRSet_Status.equals(strStatus)) {
							iTemp = iTemp + 1;
						} else {
							System.out
									.println(PreRSet_Name + " doesnot have the status value " + strStatus + " - FAIL");
							actions.reportCreateFAIL("Validation of Post Status Filter",
									"All the fetched records should have status as " + strStatus,
									PreRSet_Name + " doesnot have the status value " + strStatus, "FAIL");
							iTemp = 0;
							break;
						}
					}
					if (iTemp == row_cnt) {
						System.out.println("All the fetched Production Routing Sets are having status value - "
								+ strStatus + " - PASS");
						actions.reportCreatePASS("Validation of Post Status Filter",
								"All the fetched records should have status as " + strStatus,
								"All the fetched Production Routing Sets are having status value - " + strStatus,
								"PASS");
					}
				} catch (Exception e) {
					System.out.println("No records available");
				}
			}
		}
	}

	// ----------------------------------
	/*
	 * Feature Name : Queue Management Functionality :GUI Validation of Queue
	 * Management Scenario ID : POS_1149 Author : Sonam
	 */
	// -----------------------------------

	public void RFM_POS_GUIValidationQueueManagement(String strRoutingAreaType) {

		// Verify Queue Management Header is displayed
		boolean flag1 = driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.PageHeader")))
				.isDisplayed();
		// System.out.println(flag1);
		if (flag1 == true) {
			System.out.println("Queue Management Header is Displayed as expected - PASS");
			// Reporter.log("Queue Management Header is Displayed as expected -
			// PASS");
			actions.reportCreatePASS("Queue Management Header is Displayed", "Queue Management Header should Displayed",
					"Queue Management Header is Displayed", "Pass");
		} else {
			System.out.println("Queue Management Header is Not Displayed - FAIL");
			// Reporter.log("Queue Management Header is Not Displayed - FAIL");
			actions.reportCreateFAIL("Queue Management Header is Displayed", "Queue Management Header should Displayed",
					"Queue Management Header is not Displayed", "Fail");
		}
		// Verify Search Label is displayed
		boolean flag2 = driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.SearchLabel")))
				.isDisplayed();
		// System.out.println(flag2);
		if (flag2 == true) {
			System.out.println("Search label is Displayed as expected - PASS");
			// Reporter.log("Search label is Displayed as expected - PASS");
			actions.reportCreatePASS("Search label is Displayed", "Search label should Displayed",
					"Search label is Displayed", "Pass");
		} else {
			System.out.println("Search label is Not Displayed - FAIL");
			// Reporter.log("Search label is Not Displayed - FAIL");
			actions.reportCreateFAIL("Search label is Displayed", "Search label should Displayed",
					"Search label is not Displayed", "Fail");
		}
		// Verify Search textbox is displayed and enabled
		boolean flag3 = driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.SearchTextBox")))
				.isDisplayed();
		// System.out.println(flag3);
		if (flag3 == true) {
			System.out.println("Search Textbox is Displayed as expected - PASS");
			// Reporter.log("Search Textbox is Displayed as expected - PASS");
			actions.reportCreatePASS("Search Textbox is Displayed", "Search Textbox should Displayed",
					"Search Textbox is Displayed", "Pass");
			boolean flag = driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.SearchTextBox")))
					.isEnabled();
			if (flag == true) {
				System.out.println("Search textbox is Enabled as expected - PASS");
				// Reporter.log("Search textbox is Enabled as expected - PASS");
				actions.reportCreatePASS("Search Textbox is Enabled", "Search Textbox should Enabled",
						"Search Textbox is Enabled", "Pass");
			} else {
				System.out.println("Search textbox is Not Enabled - FAIL");
				// Reporter.log("Search textbox is Not Enabled - FAIL");
				actions.reportCreateFAIL("Search Textbox is Enabled", "Search Textbox should Enabled",
						"Search Textbox is not Enabled", "Fail");
			}
		} else {
			System.out.println("Search Textbox is Not Displayed - FAIL");
			// Reporter.log("Search Textbox is Not Displayed - FAIL");
			actions.reportCreateFAIL("Search Textbox is Displayed", "Search Textbox should Displayed",
					"Search Textbox is not Displayed", "Fail");
		}
		// Verify Routing Area Type DDL is displayed and enabled and Values are
		// displayed as expected
		boolean flag4 = driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.RoutingAreaTypeDDL")))
				.isDisplayed();
		// System.out.println(flag3);
		if (flag4 == true) {
			System.out.println("Routing Area Type DDL is Displayed as expected - PASS");
			// Reporter.log("Routing Area Type DDL is Displayed as expected -
			// PASS");
			actions.reportCreatePASS("Routing Area Type DDL is Displayed", "Routing Area Type DDL should Displayed",
					"Routing Area Type DDL is Displayed", "Pass");
			boolean flag = driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.RoutingAreaTypeDDL")))
					.isEnabled();
			if (flag == true) {
				System.out.println("Routing Area Type DDL is Enabled as expected - PASS");
				// Reporter.log("Routing Area Type DDL is Enabled as expected -
				// PASS");
				actions.reportCreatePASS("Routing Area Type DDL is Enabled", "Routing Area Type DDL should Enabled",
						"Routing Area Type DDL is Enabled", "Pass");
				String RoutingAreaList = driver
						.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.RoutingAreaTypeDDL")))
						.getText();
				String[] RoutingAreaTypeList = new String[5];
				RoutingAreaTypeList = strRoutingAreaType.split("\\|");
				for (int i = 0; i < RoutingAreaTypeList.length; i++) {
					if (RoutingAreaList.contains(RoutingAreaTypeList[i].trim())) {
						System.out.println(RoutingAreaTypeList[i]
								+ " - Routing Area Type is available in the dropdown list as expected - PASS");
						actions.reportCreatePASS(
								RoutingAreaTypeList[i] + " - Routing Area Type is available in the dropdown list",
								RoutingAreaTypeList[i] + " - Routing Area Type should available in the dropdown list",
								RoutingAreaTypeList[i] + "- Routing Area Type is available in the dropdown list",
								"Pass");
						// Reporter.log(RoutingAreaTypeList[i] + " - Routing
						// Area Type is available in the dropdown list as
						// expected - PASS");
					} else {
						System.out.println(RoutingAreaTypeList[i]
								+ " - Routing Area Type is NOT available in the dropdown list - FAIL");
						// Reporter.log(RoutingAreaTypeList[i] + " - Routing
						// Area Type is NOT available in the dropdown list -
						// FAIL");
						actions.reportCreateFAIL(
								RoutingAreaTypeList[i] + " - Routing Area Type is available in the dropdown list",
								RoutingAreaTypeList[i] + " - Routing Area Type should available in the dropdown list",
								RoutingAreaTypeList[i] + "- Routing Area Type is not available in the dropdown list",
								"Fail");
					}
				}
			} else {
				System.out.println("Routing Area Type DDL is Not Enabled - FAIL");
				// Reporter.log("Routing Area Type DDL is Not Enabled - FAIL");
				actions.reportCreatePASS("Routing Area Type DDL is Enabled", "Routing Area Type DDL should Enabled",
						"Routing Area Type DDL is Enabled", "Pass");
			}
		} else {
			System.out.println("Routing Area Type DDL is Not Displayed - FAIL");
			// Reporter.log("Routing Area Type DDL is Not Displayed - FAIL");
			actions.reportCreatePASS("Routing Area Type DDL is Displayed", "Routing Area Type DDL should Displayed",
					"Routing Area Type DDL is Displayed", "Pass");
		}
		// Verify View Full List button is displayed and enabled
		boolean flag5 = driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.ViewFullListButton")))
				.isDisplayed();
		// System.out.println(flag4);
		if (flag5 == true) {
			System.out.println("View Full List button is Displayed as expected - PASS");
			// Reporter.log("View Full List button is Displayed as expected -
			// PASS");
			actions.reportCreatePASS("View Full List button is Displayed", "View Full List button should Displayed",
					"View Full List button is Displayed", "Pass");
			boolean flag = driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.ViewFullListButton")))
					.isEnabled();
			if (flag == true) {
				System.out.println("View Full List button is Enabled as expected - PASS");
				// Reporter.log("View Full List button is Enabled as expected -
				// PASS");
				actions.reportCreatePASS("View Full List button is Enabled", "View Full List button should Enabled",
						"View Full List button is Enabled", "Pass");
			} else {
				System.out.println("View Full List button is Not Enabled - FAIL");
				// Reporter.log("View Full List button is Not Enabled - FAIL");
				actions.reportCreateFAIL("View Full List button is Enabled", "View Full List button should Enabled",
						"View Full List button is not Enabled", "Fail");
			}
		} else {
			System.out.println("View Full List button is Not Displayed - FAIL");
			// Reporter.log("View Full List button is Not Displayed - FAIL");
			actions.reportCreateFAIL("View Full List button is Displayed", "View Full List button should Displayed",
					"View Full List button is not Displayed", "Fail");
		}
		// Verify Search button is displayed and enabled
		boolean flag6 = driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.SearchButton")))
				.isDisplayed();
		// System.out.println(flag6);
		if (flag6 == true) {
			System.out.println("Search button is Displayed as expected - PASS");
			// Reporter.log("Search button is Displayed as expected - PASS");
			actions.reportCreatePASS("Search button is Displayed", "Search button should Displayed",
					"Search button is Displayed", "Pass");
			boolean flag = driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.SearchButton")))
					.isEnabled();
			if (flag == true) {
				System.out.println("Search button is Enabled as expected - PASS");
				// Reporter.log("Search button is Enabled as expected - PASS");
				actions.reportCreatePASS("Search button is Enabled", "Search button should Enabled",
						"Search button is Enabled", "Pass");
			} else {
				System.out.println("Search button is Not Enabled - FAIL");
				// Reporter.log("Search button is Not Enabled - FAIL");
				actions.reportCreateFAIL("Search button is Enabled", "Search button should Enabled",
						"Search button is not Enabled", "Fail");
			}
		} else {
			System.out.println("Search button is Not Displayed - FAIL");
			// Reporter.log("Search button is Not Displayed - FAIL");
			actions.reportCreateFAIL("Search button is Displayed", "Search button should Displayed",
					"Search button is not Displayed", "Fail");
		}
		// Verify Add New Queue button is displayed and enabled
		boolean flag7 = driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.AddNewQueueButton")))
				.isDisplayed();
		// System.out.println(flag7);
		if (flag7 == true) {
			System.out.println("Add New Queue button is Displayed as expected - PASS");
			// Reporter.log("Add New Queue button is Displayed as expected -
			// PASS");
			actions.reportCreatePASS("Add New Queue button is Displayed", "Add New Queue button should Displayed",
					"Add New Queue button is Displayed", "Pass");
			boolean flag = driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.AddNewQueueButton")))
					.isEnabled();
			if (flag == true) {
				System.out.println("Add New Queue button is Enabled as expected - PASS");
				// Reporter.log("Add New Queue button is Enabled as expected -
				// PASS");
				actions.reportCreatePASS("Add New Queue button is Enabled", "Add New Queue button should Enabled",
						"Add New Queue button is Displayed", "Pass");
			} else {
				System.out.println("Add New Queue button is Not Enabled - FAIL");
				// Reporter.log("Add New Queue button is Not Enabled - FAIL");
				actions.reportCreateFAIL("Add New Queue button is Enabled", "Add New Queue button should Enabled",
						"Add New Queue button is not Enabled", "Fail");
			}
		} else {
			System.out.println("Add New Queue button is Not Displayed - FAIL");
			// Reporter.log("Add New Queue button is Not Displayed - FAIL");
			actions.reportCreateFAIL("Add New Queue button is Displayed", "Add New Queue button should Displayed",
					"Add New Queue button is not Enabled", "Fail");
		}
		// Verify Save As CSV button is displayed and enabled
		boolean flag8 = driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.SaveAsCSVButton")))
				.isDisplayed();
		// System.out.println(flag8);
		if (flag8 == true) {
			System.out.println("Save As CSV button is Displayed as expected - PASS");
			// Reporter.log("Save As CSV button is Displayed as expected -
			// PASS");
			actions.reportCreatePASS("Add New Queue button is Displayed", "Add New Queue button should Displayed",
					"Add New Queue button is Displayed", "Pass");
			boolean flag = driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.SaveAsCSVButton")))
					.isEnabled();
			if (flag == true) {
				System.out.println("Save As CSV button is Enabled as expected - PASS");
				// Reporter.log("Save As CSV button is Enabled as expected -
				// PASS");
				actions.reportCreatePASS("Save As CSV button is Enabled", "Save As CSV button should Enabled",
						"Save As CSV button is Enabled", "Pass");
			} else {
				System.out.println("Save As CSV button is Not Enabled - FAIL");
				// Reporter.log("Save As CSV button is Not Enabled - FAIL");
				actions.reportCreateFAIL("Save As CSV button is Enabled", "Save As CSV button should Enabled",
						"Save As CSV button is not Enabled", "Fail");
			}
		} else {
			System.out.println("Save As CSV button is Not Displayed - FAIL");
			// Reporter.log("Save As CSV button is Not Displayed - FAIL");
			actions.reportCreateFAIL("Save As CSV button is Displayed", "Save As CSV button should Displayed",
					"Save As CSV button is not Displayed", "Fail");
		}
		// Verify Grid is displayed
		boolean flag9 = driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.Table"))).isDisplayed();
		// System.out.println(flag9);
		if (flag9 == true) {
			System.out.println("Grid is Displayed as expected - PASS");
			// Reporter.log("Grid is Displayed as expected - PASS");
			actions.reportCreatePASS("Grid is Displayed", "Grid should Displayed", "Grid is Displayed", "Pass");
		} else {
			System.out.println("Grid is Not Displayed - FAIL");
			// Reporter.log("Grid is Not Displayed - FAIL");
			actions.reportCreateFAIL("Grid is Displayed", "Grid should Displayed", "Grid is not Displayed", "Fail");
		}
		// Verify Save button is displayed and enabled
		boolean flag10 = driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.SaveButton")))
				.isDisplayed();
		// System.out.println(flag10);
		if (flag10 == true) {
			System.out.println("Save button is Displayed as expected - PASS");
			// Reporter.log("Save button is Displayed as expected - PASS");
			actions.reportCreatePASS("Save is Displayed", "Save should Displayed", "Save is Displayed", "Pass");
			boolean flag = driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.SaveButton")))
					.isEnabled();
			if (flag == true) {
				System.out.println("Save button is Enabled as expected - PASS");
				// Reporter.log("Save button is Enabled as expected - PASS");
				actions.reportCreatePASS("Save is Enabled", "Save should Enabled", "Save is Enabled", "Pass");
			} else {
				System.out.println("Save button is Not Enabled - FAIL");
				// Reporter.log("Save button is Not Enabled - FAIL");
				actions.reportCreateFAIL("Save is Enabled", "Save should Enabled", "Save is not Enabled", "Fail");
			}
		} else {
			System.out.println("Save button is Not Displayed - FAIL");
			// Reporter.log("Save button is Not Displayed - FAIL");
			actions.reportCreateFAIL("Save is Displayed", "Save should Displayed", "Save is not Displayed", "Fail");
		}
		// Verify Cancel button is displayed and enabled
		boolean flag11 = driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.CancelButton")))
				.isDisplayed();
		// System.out.println(flag11);
		if (flag11 == true) {
			System.out.println("Cancel button is Displayed as expected - PASS");
			// Reporter.log("Cancel button is Displayed as expected - PASS");
			actions.reportCreatePASS("Cancel is Displayed", "Cancel should Displayed", "Cancel is Displayed", "Pass");
			boolean flag = driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.CancelButton")))
					.isEnabled();
			if (flag == true) {
				System.out.println("Cancel button is Enabled as expected - PASS");
				// Reporter.log("Cancel button is Enabled as expected - PASS");
				actions.reportCreatePASS("Cancel is Enabled", "Cancel should Enabled", "Cancel is Enabled", "Pass");
			} else {
				System.out.println("Cancel button is Not Enabled - FAIL");
				// Reporter.log("Cancel button is Not Enabled - FAIL");
				actions.reportCreateFAIL("Cancel is Enabled", "Cancel should Enabled", "Cancel is not Enabled", "Fail");
			}
		} else {
			System.out.println("Cancel button is Not Displayed - FAIL");
			// Reporter.log("Cancel button is Not Displayed - FAIL");
			actions.reportCreateFAIL("Cancel is Displayed", "Cancel should Displayed", "Cancel is not Displayed",
					"Fail");
		}
	}

	// ----------------------------------
	/*
	 * Feature Name : Queue Management Functionality :Search Validation with
	 * Queue Name - Queue Management Scenario ID : POS_1149 Author : Sonam
	 */
	// -----------------------------------

	public void RFM_POS_SearchName_QueueManagement(String strSearchValue, String strNoRecordMsg)
			throws InterruptedException {

		// Variable Declaration
		int iTemp = 0;
		int row_cnt = 0;

		// Clear the text box value
		actions.clear("RFMQueueManagementPage.SearchTextBox");
		Thread.sleep(1000);
		// Enter Search value
		// actions.setValue("RFMQueueManagementPage.SearchTextBox",
		// strSearchValue);
		driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.SearchTextBox")))
				.sendKeys(strSearchValue);
		Thread.sleep(500);

		// Click on Search button
		actions.keyboardEnter("RFMQueueManagementPage.SearchButton");
		Thread.sleep(5000);
		// actions.smartWait(100);
		System.out.println(strSearchValue);

		if (strSearchValue == null) {
			System.out.println("> Click on OK button of Message Box");
			mcd.VerifyAlertMessageDisplayed("Expected Message", "Please enter a search criteria.", true,
					AlertPopupButton.OK_BUTTON);
		} else {

			// Get row count of number of Production Routing sets fetched
			row_cnt = mcd.GetTableRowCount("RFMQueueManagementPage.Table");

			// Verify the name containing search value
			if (row_cnt < 2) {
				WebElement msg_element = driver
						.findElement(By.xpath("//*[@id='queueManagementForm_infoCode']/li/span"));
				String temp_msg = msg_element.getText();

				if (temp_msg.equals(strNoRecordMsg)) {
					// Reporter.log( strNoRecordMsg + " message is displayed as
					// expected " + "- PASS");
					System.out.println("No records available with the search text - " + strSearchValue);
					System.out.println(strNoRecordMsg + " message is displayed as expected " + "- PASS");
					actions.reportCreatePASS(strNoRecordMsg + " message is displayed",
							strNoRecordMsg + " message should displayed", strNoRecordMsg + " message is displayed",
							"Pass");
				}
			} else {

				// List<WebElement> Queue_List =
				// driver.findElements(By.xpath(actions.getLocator("RFMQueueManagementPage.Table")));
				// Get row count of number of Queues fetched
				// row_cnt = Queue_List.size();

				for (int i = 0; i < row_cnt - 1; i++) {
					try {
						String xpath = ".//*[@id='name_" + i + "']";
						String Queue_Name = driver.findElement(By.xpath(xpath)).getAttribute("value");
						System.out.println(Queue_Name);
						if (Queue_Name.contains(strSearchValue.toLowerCase())
								|| Queue_Name.contains(strSearchValue.toUpperCase())) {
							iTemp = iTemp + 1;
						} else {
							// Reporter.log(Queue_Name + " doesnot contain the
							// search value - " + strSearchValue + " - FAIL");
							System.out.println(
									Queue_Name + " doesnot contain the search value - " + strSearchValue + " - FAIL");
							actions.reportCreateFAIL(Queue_Name + " contain the search value - " + strSearchValue,
									Queue_Name + " should contain the search value - " + strSearchValue,
									Queue_Name + " doesnot contain the search value - " + strSearchValue, "Fail");
							iTemp = 0;
							break;
						}

						if (iTemp == row_cnt - 1) {
							System.out.println(
									"All the fetched Queues contains the search value - " + strSearchValue + " - PASS");
							// Reporter.log("All the fetched Queues contains the
							// search value - " + strSearchValue + " - PASS");
							actions.reportCreatePASS(
									"All the fetched Queues contains the search value - " + strSearchValue,
									"All the fetched Queues should contains the search value - " + strSearchValue,
									"All the fetched Queues contains the search value - " + strSearchValue, "Pass");
						}

					} catch (Exception e) {
						System.out.println("No records available with the search text -  " + strSearchValue);
					}

				}
			}
		}
	}

	// ----------------------------------
	/*
	 * Feature Name : Queue Management Functionality :Search Validation with
	 * Queue Number - Queue Management Scenario ID : POS_1149 Author : Sonam
	 */
	// -----------------------------------

	public void RFM_POS_SearchNumber_QueueManagement(String strSearchValue, String strNoRecordMsg)
			throws InterruptedException {

		// Variable Declaration
		int iTemp = 0;
		int row_cnt = 0;

		// Clear the text box value
		actions.clear("RFMQueueManagementPage.SearchTextBox");
		Thread.sleep(1000);
		// Enter Search value
		actions.setValue("RFMQueueManagementPage.SearchTextBox", strSearchValue);
		Thread.sleep(500);
		// Click on Search button
		actions.keyboardEnter("RFMQueueManagementPage.SearchButton");
		// Thread.sleep(5000);
		actions.smartWait(100);
		System.out.println(strSearchValue);

		if (strSearchValue == null) {
			System.out.println("> Click on OK button of Message Box");
			mcd.VerifyAlertMessageDisplayed("Expected Message", "Please enter a search criteria.", true,
					AlertPopupButton.OK_BUTTON);
		} else {

			// Get row count of number of Production Routing sets fetched
			row_cnt = mcd.GetTableRowCount("RFMQueueManagementPage.Table");

			// Verify the name containing search value
			if (row_cnt < 2) {
				WebElement msg_element = driver
						.findElement(By.xpath("//*[@id='queueManagementForm_infoCode']/li/span"));
				String temp_msg = msg_element.getText();

				if (temp_msg.equals(strNoRecordMsg)) {
					// Reporter.log( strNoRecordMsg + " message is displayed as
					// expected " + "- PASS");
					System.out.println("No records available with the search text - " + strSearchValue);
					System.out.println(strNoRecordMsg + " message is displayed as expected " + "- PASS");
					actions.reportCreatePASS(strNoRecordMsg + " message is displayed",
							strNoRecordMsg + " message should displayed", strNoRecordMsg + " message is displayed",
							"Pass");
				}
			} else {

				// List<WebElement> Queue_List =
				// driver.findElements(By.xpath(actions.getLocator("RFMQueueManagementPage.Table")));
				// Get row count of number of Queues fetched
				// row_cnt = Queue_List.size();

				for (int i = 0; i < row_cnt - 1; i++) {
					try {

						String xpath1 = ".//*[@id='queueDetails_" + i + "']/td[1]";
						String xpath2 = ".//*[@id='name_" + i + "']";

						String Queue_Number = driver.findElement(By.xpath(xpath1)).getText();
						String Queue_Name = driver.findElement(By.xpath(xpath2)).getAttribute("value");
						System.out.println(Queue_Number);

						if (Queue_Number.contains(strSearchValue) || Queue_Name.contains(strSearchValue)) {
							iTemp = iTemp + 1;
						} else {
							// Reporter.log(Queue_Number+","+Queue_Name + "
							// doesnot contain the search value - " +
							// strSearchValue + " - FAIL");
							System.out.println(Queue_Number + "," + Queue_Name + " doesnot contain the search value - "
									+ strSearchValue + " - FAIL");
							actions.reportCreateFAIL(
									Queue_Number + "," + Queue_Name + " contain the search value - " + strSearchValue,
									Queue_Number + "," + Queue_Name + " should contain the search value - "
											+ strSearchValue,
									Queue_Number + "," + Queue_Name + " doesnot contain the search value - "
											+ strSearchValue,
									"Fail");
							iTemp = 0;
							break;
						}

						if (iTemp == row_cnt - 1) {
							System.out.println(
									"All the fetched Queues contains the search value - " + strSearchValue + " - PASS");
							// Reporter.log("All the fetched Queues contains the
							// search value - " + strSearchValue + " - PASS");
							actions.reportCreatePASS(
									"All the fetched Queues contains the search value - " + strSearchValue,
									"All the fetched Queues should contains the search value - " + strSearchValue,
									"All the fetched Queues contains the search value - " + strSearchValue, "Pass");
						}

					} catch (Exception e) {
						System.out.println("No records available with the search text -  " + strSearchValue);
						// Reporter.log("No records available with the search
						// text - " + strSearchValue);
					}

				}
			}
		}
	}

	// ----------------------------------
	/*
	 * Feature Name : Queue Management Functionality :Search with Routing Area
	 * Type Filter Validation - Queue Management Scenario ID : POS_1149 Author :
	 * Sonam
	 */
	// -----------------------------------

	public void RFM_POS_SearchNamewithRoutingAreaType_QueueManagement(String strSearchValue, String strRoutingType,
			String strNoRecordMsg) throws InterruptedException {

		// Variable Declaration
		int iTemp = 0;
		int row_cnt = 0;

		// Clear the text box value
		actions.clear("RFMQueueManagementPage.SearchTextBox");
		Thread.sleep(1000);
		// Enter Search value
		actions.setValue("RFMQueueManagementPage.SearchTextBox", strSearchValue);
		Thread.sleep(500);
		// Select Routing Area TYpe
		actions.setValue("RFMQueueManagementPage.RoutingAreaTypeDDL", strRoutingType);
		// Click on Search button
		actions.keyboardEnter("RFMQueueManagementPage.SearchButton");
		// Thread.sleep(5000);
		actions.smartWait(100);
		if (strSearchValue == null) {
			System.out.println("> Click on OK button of Message Box");
			mcd.VerifyAlertMessageDisplayed("Expected Message", "Please enter a search criteria.", true,
					AlertPopupButton.OK_BUTTON);
		} else {
			// Get row count of number of Production Routing sets fetched
			row_cnt = mcd.GetTableRowCount("RFMQueueManagementPage.Table");

			// Verify the name containing search value
			if (row_cnt < 2) {
				WebElement msg_element = driver
						.findElement(By.xpath("//*[@id='queueManagementForm_infoCode']/li/span"));
				String temp_msg = msg_element.getText();

				if (temp_msg.equals(strNoRecordMsg)) {
					// Reporter.log( strNoRecordMsg + " message is displayed as
					// expected " + "- PASS");
					System.out.println("No records available with the search text - " + strSearchValue);
					System.out.println(strNoRecordMsg + " message is displayed as expected " + "- PASS");
					actions.reportCreatePASS(strNoRecordMsg + " message is displayed",
							strNoRecordMsg + " message should displayed", strNoRecordMsg + " message is displayed",
							"Pass");
				}
			} else {

				// List<WebElement> Queue_List =
				// driver.findElements(By.xpath(actions.getLocator("RFMQueueManagementPage.Table")));
				// Get row count of number of Production Routing sets fetched
				// row_cnt = Queue_List.size();
				for (int i = 0; i < row_cnt - 1; i++) {
					try {
						String xpath1 = ".//*[@id='name_" + i + "']";
						String xpath2 = ".//*[@id='routingAreaType_" + i + "']";
						String Queue_Name = driver.findElement(By.xpath(xpath1)).getAttribute("value");
						System.out.println(Queue_Name);
						Select select = new Select(driver.findElement(By.xpath(xpath2)));
						String RoutingArea_Type = select.getFirstSelectedOption().getText();
						System.out.println(RoutingArea_Type);
						if (RoutingArea_Type.equals(strRoutingType)) {
							iTemp = iTemp + 1;
						} else {
							// Reporter.log(Queue_Name + " doesnot have the
							// Routing Area Type value " + strRoutingType + " -
							// FAIL");
							System.out.println(Queue_Name + " doesnot contain the Routing Area Type value - "
									+ strRoutingType + " - FAIL");
							actions.reportCreateFAIL(
									Queue_Name + " contain the Routing Area Type value - " + strRoutingType,
									Queue_Name + " doesnot should contain the Routing Area Type value - "
											+ strRoutingType,
									Queue_Name + " doesnot contain the Routing Area Type value - " + strRoutingType,
									"Fail");
							iTemp = 0;
							break;
						}
						if (iTemp == row_cnt - 1) {
							System.out.println("All the fetched Queues are having Routing Area Type value - "
									+ strRoutingType + " - PASS");
							actions.reportCreatePASS(
									"All the fetched Queues are having Routing Area Type value - " + strRoutingType,
									"All the fetched Queues should have Routing Area Type value - " + strRoutingType,
									"All the fetched Queues are having Routing Area Type value - " + strRoutingType,
									"Pass");
						}

					} catch (Exception e) {
						System.out.println("No records available with the search text - " + strSearchValue);
					}

				}
			}
		}
	}

	// ----------------------------------
	/*
	 * Feature Name : Queue Management Functionality : Functionality of Cancel
	 * button on Queue Management screen Scenario ID : POS_1153 Author : Sonam
	 */
	// -----------------------------------

	public void RFM_POS_CancelFunctionality_QueueManagement() throws InterruptedException {

		// Variable Declaration
		Boolean VerifyPopUpMsg;

		// Click on Add New Queue button
		actions.click("RFMQueueManagementPage.AddNewQueueButton");
		// Click on cancel button
		actions.click("RFMQueueManagementPage.CancelButton");
		Thread.sleep(1000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error",
				"Unsaved data will be lost. Are you sure you want to proceed?", true, AlertPopupButton.CANCEL_BUTTON);
		if (VerifyPopUpMsg == true) {
			// Reporter.log("Unsaved record message displayed as expected -
			// PASS");
			actions.reportCreatePASS("Unsaved data will be lost. Are you sure you want to proceed?-- is Dispalyed",
					"Unsaved data will be lost. Are you sure you want to proceed?-- should Dispalyed",
					"Unsaved data will be lost. Are you sure you want to proceed?-- is Dispalyed", "Pass");
		} else {
			// Reporter.log("Unsaved record message Not displayed - FAIL");
			actions.reportCreateFAIL("Unsaved data will be lost. Are you sure you want to proceed?-- is Dispalyed",
					"Unsaved data will be lost. Are you sure you want to proceed?-- should Dispalyed",
					"Unsaved data will be lost. Are you sure you want to proceed?-- is not Dispalyed", "Fail");
		}
		// Again click on cancel button
		actions.click("RFMQueueManagementPage.CancelButton");
		Thread.sleep(1000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error",
				"Unsaved data will be lost. Are you sure you want to proceed?", true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg == true) {
			// Reporter.log("Unsaved record message displayed as expected -
			// PASS");
			actions.reportCreatePASS("Unsaved data will be lost. Are you sure you want to proceed?-- is Dispalyed",
					"Unsaved data will be lost. Are you sure you want to proceed?-- should Dispalyed",
					"Unsaved data will be lost. Are you sure you want to proceed?-- is Dispalyed", "Pass");
		} else {
			// Reporter.log("Unsaved record message Not displayed - FAIL");
			actions.reportCreateFAIL("Unsaved data will be lost. Are you sure you want to proceed?-- is Dispalyed",
					"Unsaved data will be lost. Are you sure you want to proceed?-- should Dispalyed",
					"Unsaved data will be lost. Are you sure you want to proceed?-- is not Dispalyed", "Fail");
		}
		Thread.sleep(5000);
		actions.clear("RFMQueueManagementPage.FirstNameTextbox");
		// Generating random number to enter.
		Random rand_num = new Random();
		String strValue = "Auto_" + rand_num.nextInt(9999);
		// Update the Queue Name value
		actions.clear("RFMQueueManagementPage.FirstNameTextbox");
		actions.setValue("RFMQueueManagementPage.FirstNameTextbox", strValue);
		// Click on cancel button
		actions.click("RFMQueueManagementPage.CancelButton");
		Thread.sleep(1000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error",
				"Unsaved data will be lost. Are you sure you want to proceed?", true, AlertPopupButton.CANCEL_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log("Unsaved record message displayed as expected -
			// PASS");
			actions.reportCreatePASS("Unsaved data will be lost. Are you sure you want to proceed?-- is Dispalyed",
					"Unsaved data will be lost. Are you sure you want to proceed?-- should Dispalyed",
					"Unsaved data will be lost. Are you sure you want to proceed?-- is Dispalyed", "Pass");
		} else {
			// Reporter.log("Unsaved record message Not displayed - FAIL");
			actions.reportCreateFAIL("Unsaved data will be lost. Are you sure you want to proceed?-- is Dispalyed",
					"Unsaved data will be lost. Are you sure you want to proceed?-- should Dispalyed",
					"Unsaved data will be lost. Are you sure you want to proceed?-- is not Dispalyed", "Fail");
		}
		// Again click on cancel button
		actions.click("RFMQueueManagementPage.CancelButton");
		Thread.sleep(1000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error",
				"Unsaved data will be lost. Are you sure you want to proceed?", true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log("Unsaved record message displayed as expected -
			// PASS");
			actions.reportCreatePASS("Unsaved data will be lost. Are you sure you want to proceed?-- is Dispalyed",
					"Unsaved data will be lost. Are you sure you want to proceed?-- should Dispalyed",
					"Unsaved data will be lost. Are you sure you want to proceed?-- is Dispalyed", "Pass");
		} else {
			// Reporter.log("Unsaved record message Not displayed - FAIL");
			actions.reportCreateFAIL("Unsaved data will be lost. Are you sure you want to proceed?-- is Dispalyed",
					"Unsaved data will be lost. Are you sure you want to proceed?-- should Dispalyed",
					"Unsaved data will be lost. Are you sure you want to proceed?-- is not Dispalyed", "Fail");
		}
		Thread.sleep(5000);

	}

	// ----------------------------------
	/*
	 * Feature Name : Queue Management Functionality : Functionality of Save
	 * button on Queue Management screen Scenario ID : POS_1152 Author : Sonam
	 */
	// -----------------------------------

	public void RFM_POS_SaveFunctionality_QueueManagement(String strNoQueueMsg, String strInvalidQueueMsg,
			String strNoNameMsg, String strNoShortNameMsg, String strNoDescMsg, String strNoTypeMsg,
			String strNoAreaMsg, String strNoServiceMsg, String strDupQueueMsg, String strDupNameMsg,
			String strSuccessMsg) throws InterruptedException {

		// Variable Declaration
		Boolean VerifyPopUpMsg;

		// Click on Add New Queue button
		actions.click("RFMQueueManagementPage.AddNewQueueButton");
		// Click on Save button
		actions.click("RFMQueueManagementPage.SaveButton");
		Thread.sleep(1000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Expected Message", strNoQueueMsg, true,
				AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log(strNoQueueMsg + " message displayed as expected -
			// PASS");
			actions.reportCreatePASS(strNoQueueMsg + " message displayed", strNoQueueMsg + " message should displayed",
					strNoQueueMsg + " message displayed", "Pass");
		} else {
			// Reporter.log(strNoQueueMsg + " message Not displayed - FAIL");
			actions.reportCreateFAIL(strNoQueueMsg + " message displayed", strNoQueueMsg + " message should displayed",
					strNoQueueMsg + " message not displayed", "Fail");
		}

		String strQueue_Number = "123!@#$%7890";
		// Enter the special characters as Queue Number
		// actions.setValue("RFMQueueManagementPage.NewQueueTextbox",
		// strQueue_Number);
		driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.NewQueueTextbox")))
				.sendKeys(strQueue_Number);
		// Again click on Save button
		actions.click("RFMQueueManagementPage.SaveButton");
		Thread.sleep(1000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strInvalidQueueMsg, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log(strInvalidQueueMsg + " message displayed as expected
			// - PASS");
			actions.reportCreatePASS(strInvalidQueueMsg + " message displayed",
					strInvalidQueueMsg + " message should displayed", strInvalidQueueMsg + " message displayed",
					"Pass");
		} else {
			// Reporter.log(strInvalidQueueMsg + " message Not displayed -
			// FAIL");
			actions.reportCreateFAIL(strInvalidQueueMsg + " message displayed",
					strInvalidQueueMsg + " message should displayed", strInvalidQueueMsg + " message not displayed",
					"Fail");
		}

		// Generate Unique Random number
		Random rand_num = new Random();
		String rand_number = Integer.toString(rand_num.nextInt(9999));

		// Read the existing Queue number
		strQueue_Number = driver.findElement(By.xpath(".//*[@id='queueDetails_0']/td[1]")).getText();
		// Clear the Queue text value
		actions.clear("RFMQueueManagementPage.NewQueueTextbox");
		// Enter the existing Queue number
		// actions.setValue("RFMQueueManagementPage.NewQueueTextbox",
		// strQueue_Number);
		driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.NewQueueTextbox")))
				.sendKeys(strQueue_Number);
		// Click on Save button
		actions.click("RFMQueueManagementPage.SaveButton");
		Thread.sleep(1000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strNoNameMsg, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log(strNoNameMsg + " message displayed as expected -
			// PASS");
			actions.reportCreatePASS(strNoNameMsg + " message displayed", strNoNameMsg + " message should displayed",
					strNoNameMsg + " message displayed", "Pass");
		} else {
			// Reporter.log(strNoNameMsg + " message Not displayed - FAIL");
			actions.reportCreateFAIL(strNoNameMsg + " message displayed", strNoNameMsg + " message should displayed",
					strNoNameMsg + " message not displayed", "Fail");
		}
		// Generate Unique Queue Name
		String strQueue_Name = "Auto_" + rand_number;
		// Enter unique Queue Name
		actions.setValue("RFMQueueManagementPage.NewNameTextbox", strQueue_Name);
		// Click on Save button
		actions.click("RFMQueueManagementPage.SaveButton");
		Thread.sleep(1000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strNoShortNameMsg, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log(strNoShortNameMsg + " message displayed as expected
			// - PASS");
			actions.reportCreatePASS(strNoShortNameMsg + " message displayed",
					strNoShortNameMsg + " message should displayed", strNoShortNameMsg + " message displayed", "Pass");
		} else {
			// Reporter.log(strNoShortNameMsg + " message Not displayed -
			// FAIL");
			actions.reportCreateFAIL(strNoShortNameMsg + " message displayed",
					strNoShortNameMsg + " message should displayed", strNoShortNameMsg + " message not displayed",
					"Fail");
		}
		// Generate Unique Short Name
		String strQueue_ShortName = "Short_" + rand_number;
		// Enter unique Short Name
		actions.setValue("RFMQueueManagementPage.NewShortNameTextbox", strQueue_ShortName);
		// Click on Save button
		actions.click("RFMQueueManagementPage.SaveButton");
		Thread.sleep(1000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strNoDescMsg, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log(strNoDescMsg + " message displayed as expected -
			// PASS");
			actions.reportCreatePASS(strNoDescMsg + " message displayed", strNoDescMsg + " message should displayed",
					strNoDescMsg + " message displayed", "Pass");
		} else {
			// Reporter.log(strNoDescMsg + " message Not displayed - FAIL");
			actions.reportCreateFAIL(strNoDescMsg + " message displayed", strNoDescMsg + " message should displayed",
					strNoDescMsg + " message not displayed", "Fail");
		}
		// Generate Unique Description
		String strQueue_Desc = "Desc_" + rand_number;
		// Enter unique Description
		actions.setValue("RFMQueueManagementPage.NewDescriptionTextbox", strQueue_Desc);
		// Click on Save button
		actions.click("RFMQueueManagementPage.SaveButton");
		Thread.sleep(1000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strNoTypeMsg, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log(strNoTypeMsg + " message displayed as expected -
			// PASS");
			actions.reportCreatePASS(strNoTypeMsg + " message displayed", strNoTypeMsg + " message should displayed",
					strNoTypeMsg + " message displayed", "Pass");
		} else {
			// Reporter.log(strNoTypeMsg + " message Not displayed - FAIL");
			actions.reportCreateFAIL(strNoTypeMsg + " message displayed", strNoTypeMsg + " message should displayed",
					strNoTypeMsg + " message not displayed", "Fail");
		}
		// Generate Unique Queue Type
		String strQueue_Type = "Type_" + rand_number;
		// Enter unique Queue Type
		actions.setValue("RFMQueueManagementPage.NewQueueTypeTextbox", strQueue_Type);

		// Click on Save button
		actions.click("RFMQueueManagementPage.SaveButton");
		Thread.sleep(1000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strNoAreaMsg, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log(strNoAreaMsg + " message displayed as expected -
			// PASS");
			actions.reportCreatePASS(strNoAreaMsg + " message displayed", strNoAreaMsg + " message should displayed",
					strNoAreaMsg + " message displayed", "Pass");
		} else {
			// Reporter.log(strNoAreaMsg + " message Not displayed - FAIL");
			actions.reportCreateFAIL(strNoAreaMsg + " message displayed", strNoAreaMsg + " message should displayed",
					strNoAreaMsg + " message not displayed", "Fail");
		}
		// Select Routing Area Type
		Select select = new Select(
				driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.NewRoutingAreaTypeDDL"))));
		select.selectByIndex(1);
		// Click on Save button
		actions.click("RFMQueueManagementPage.SaveButton");
		Thread.sleep(1000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strNoServiceMsg, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log(strNoServiceMsg + " message displayed as expected -
			// PASS");
			actions.reportCreatePASS(strNoServiceMsg + " message displayed",
					strNoServiceMsg + " message should displayed", strNoServiceMsg + " message displayed", "Pass");
		} else {
			// Reporter.log(strNoServiceMsg + " message Not displayed - FAIL");
			actions.reportCreateFAIL(strNoServiceMsg + " message displayed",
					strNoServiceMsg + " message should displayed", strNoServiceMsg + " message not displayed", "Fail");
		}
		// Select Routing Service Type
		Select select1 = new Select(
				driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.NewRoutingServiceTypeDDL"))));
		select1.selectByIndex(1);

		// Click on Save button
		actions.click("RFMQueueManagementPage.SaveButton");
		Thread.sleep(5000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strDupQueueMsg, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log(strDupQueueMsg + " message displayed as expected -
			// PASS");
			actions.reportCreatePASS(strDupQueueMsg + " message displayed",
					strDupQueueMsg + " message should displayed", strDupQueueMsg + " message displayed", "Pass");
		} else {
			// Reporter.log(strDupQueueMsg + " message Not displayed - FAIL");
			actions.reportCreateFAIL(strDupQueueMsg + " message displayed",
					strDupQueueMsg + " message should displayed", strDupQueueMsg + " message not displayed", "Fail");
		}
		strQueue_Number = rand_number;
		// Clear the Queue text value
		actions.clear("RFMQueueManagementPage.NewQueueTextbox");
		// Enter the unique Queue number
		// actions.setValue("RFMQueueManagementPage.NewQueueTextbox",
		// strQueue_Number);
		driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.NewQueueTextbox")))
				.sendKeys(strQueue_Number);
		// Read the existing Queue Name
		strQueue_Name = driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.FirstNameTextbox")))
				.getAttribute("value");
		// Clear the Queue Name value
		actions.clear("RFMQueueManagementPage.NewNameTextbox");
		// Enter the existing Queue number
		actions.setValue("RFMQueueManagementPage.NewNameTextbox", strQueue_Name);
		// Click on Save button
		actions.click("RFMQueueManagementPage.SaveButton");
		Thread.sleep(1000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strDupNameMsg, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log(strDupNameMsg + " message displayed as expected -
			// PASS");
			actions.reportCreatePASS(strDupNameMsg + " message displayed", strDupNameMsg + " message should displayed",
					strDupNameMsg + " message displayed", "Pass");
		} else {
			// Reporter.log(strDupNameMsg + " message Not displayed - FAIL");
			actions.reportCreateFAIL(strDupNameMsg + " message displayed", strDupNameMsg + " message should displayed",
					strDupNameMsg + " message not displayed", "Fail");
		}
		// Generate Unique Random Name
		strQueue_Name = "Auto_" + rand_number;
		// Clear the Queue Name value
		actions.clear("RFMQueueManagementPage.NewNameTextbox");
		// Enter unique Queue Name
		actions.setValue("RFMQueueManagementPage.NewNameTextbox", strQueue_Name);
		// Click on Save button
		actions.click("RFMQueueManagementPage.SaveButton");
		Thread.sleep(5000);
		WebElement msg_element = driver.findElement(By.xpath("//*[@id='queueManagementForm_infoCode']/li/span"));
		String temp_msg = msg_element.getText();
		if (temp_msg.equals(strSuccessMsg)) {
			// Reporter.log( strSuccessMsg + " message is displayed as expected
			// " + "- PASS");
			System.out.println(strSuccessMsg + " message is displayed as expected " + "- PASS");
			actions.reportCreatePASS(strSuccessMsg + " message displayed", strSuccessMsg + " message should displayed",
					strSuccessMsg + " message displayed", "Pass");
		} else {
			// Reporter.log( strSuccessMsg + " message is Not displayed" + "-
			// FAIL");
			System.out.println(strSuccessMsg + " message is Not displayed" + "- FAIL");
			actions.reportCreateFAIL(strSuccessMsg + " message displayed", strSuccessMsg + " message should displayed",
					strSuccessMsg + " message not displayed", "Fail");
		}

	}

	// ----------------------------------
	/*
	 * Feature Name : Queue Management Functionality : Create New Queue on Queue
	 * Management screen Scenario ID : POS_1151 Author : Sonam
	 */
	// -----------------------------------

	public String RFM_POS_CreateQueueManagement(String strQueue_Number, String strQueue_Name, String strQueue_ShortName,
			String strQueue_Desc, String strQueue_Type, String strRoutingArea_Type, String strRoutingService_Type,
			String strSuccessMsg) throws InterruptedException {

		// Click on Add New Queue button
		actions.click("RFMQueueManagementPage.AddNewQueueButton");

		// Generate Unique Random number
		Random rand_num = new Random();
		String strRand_Num = Integer.toString(rand_num.nextInt(7000));

		// Enter unique Queue Name
		if (strQueue_Name.trim().equalsIgnoreCase("Runtime data")) {
			strQueue_Name = "Auto_" + strRand_Num;
		}
		actions.setValue("RFMQueueManagementPage.NewNameTextbox", strQueue_Name);

		// Enter unique Short Name
		if (strQueue_ShortName.trim().equalsIgnoreCase("Runtime data")) {
			strQueue_ShortName = "Short_" + strRand_Num;
		}
		actions.setValue("RFMQueueManagementPage.NewShortNameTextbox", strQueue_ShortName);

		// Enter unique Description
		if (strQueue_Desc.trim().equalsIgnoreCase("Runtime data")) {
			strQueue_Desc = "Desc_" + strRand_Num;
		}
		actions.setValue("RFMQueueManagementPage.NewDescriptionTextbox", strQueue_Desc);

		// Enter unique Queue Type
		if (strQueue_Type.trim().equalsIgnoreCase("Runtime data")) {
			strQueue_Type = "Type_" + strRand_Num;
		}
		actions.setValue("RFMQueueManagementPage.NewQueueTypeTextbox", strQueue_Type);

		// Select Routing Area Type
		if (strRoutingArea_Type.trim().equalsIgnoreCase("Runtime data")) {
			Select select = new Select(
					driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.NewRoutingAreaTypeDDL"))));
			select.selectByIndex(1);
			strRoutingArea_Type = select.getFirstSelectedOption().getText();

		} else {
			actions.setValue("RFMQueueManagementPage.NewRoutingAreaTypeDDL", strRoutingArea_Type);
		}
		System.out.println("Selected value '" + strRoutingArea_Type
				+ "' in the input element 'RFMQueueManagementPage.NewRoutingAreaTypeDDL'");

		// Select Routing Service Type
		if (strRoutingService_Type.trim().equalsIgnoreCase("Runtime data")) {
			Select select = new Select(driver
					.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.NewRoutingServiceTypeDDL"))));
			select.selectByIndex(1);
			strRoutingService_Type = select.getFirstSelectedOption().getText();
		} else {
			actions.setValue("RFMQueueManagementPage.NewRoutingServiceTypeDDL", strRoutingService_Type);
		}
		System.out.println("Selected value '" + strRoutingArea_Type
				+ "' in the input element 'RFMQueueManagementPage.NewRoutingServiceTypeDDL'");
		boolean blnQueueNumberExists = false;
		do {
			// Enter the unique Queue number
			if (strQueue_Number.trim().equalsIgnoreCase("Runtime data")) {
				strQueue_Number = strRand_Num;
			}
			// actions.setValue("RFMQueueManagementPage.NewQueueTextbox",
			// strQueue_Number);
			driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.NewQueueTextbox"))).clear();
			driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.NewQueueTextbox")))
					.sendKeys(strQueue_Number);

			// Click on Save button
			actions.click("RFMQueueManagementPage.SaveButton");
			Thread.sleep(2000);
			try {
				mcd.VerifyAlertMessageDisplayed("Warning Message",
						"Queue Number already exists, Please enter another Queue Number.", true,
						AlertPopupButton.OK_BUTTON);
				blnQueueNumberExists = true;
				strRand_Num = Integer.toString(rand_num.nextInt(7000));
				System.out.println("> > > > > > >  " + strRand_Num);
			} catch (Exception e) {
				actions.smartWait(180);
				blnQueueNumberExists = false;
			}
		} while (blnQueueNumberExists);
		// Thread.sleep(5000);

		WebElement msg_element = driver.findElement(By.xpath("//*[@id='queueManagementForm_infoCode']/li/span"));
		String temp_msg = msg_element.getText();
		if (temp_msg.equals(strSuccessMsg)) {
			// Reporter.log( strSuccessMsg + " message is displayed as expected
			// " + "- PASS");
			System.out.println(strSuccessMsg + " message is displayed as expected " + "- PASS");
			System.out.println("Queue with queue name - " + strQueue_Name + " is created successfully");
			actions.reportCreatePASS("Create a new Queue", "Queue should be created successfully",
					"Queue with queue name - '" + strQueue_Name + "' is created successfully", "Pass");
		} else {
			// Reporter.log( strSuccessMsg + " message is Not displayed" + "-
			// FAIL");
			System.out.println(strSuccessMsg + " message is Not displayed" + "- FAIL");
			System.out.println("Queue is not created");
			actions.reportCreateFAIL("Create a new Queue", "Queue should be created successfully",
					"Queue is not created", "Fail");
		}
		// Verify Routing Area Type DDL becomes disabled
		boolean flag1 = driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.NewRoutingAreaTypeDDL")))
				.isEnabled();
		// System.out.println(flag1);
		if (flag1 == false) {
			System.out.println("Routing Area Type DDL is Disabled as expected - PASS");
			// Reporter.log("Routing Area Type DDL is Disabled as expected -
			// PASS");
			actions.reportCreatePASS("Routing Area Type DDL is Disabled", "Routing Area Type DDL should Disabled",
					"Routing Area Type DDL is Disabled", "Pass");
		} else {
			System.out.println("Routing Area Type DDL is Not Disabled - FAIL");
			// Reporter.log("Routing Area Type DDL is Not Disabled - FAIL");
			actions.reportCreateFAIL("Routing Area Type DDL is Disabled", "Routing Area Type DDL should Disabled",
					"Routing Area Type DDL is not Disabled", "Fail");
		}
		// Verify Routing Service Type DDL becomes disabled
		boolean flag2 = driver
				.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.NewRoutingServiceTypeDDL")))
				.isEnabled();
		// System.out.println(flag1);
		if (flag2 == false) {
			System.out.println("Routing Service Type DDL is Disabled as expected - PASS");
			// Reporter.log("Routing Service Type DDL is Disabled as expected -
			// PASS");
			actions.reportCreatePASS("Routing Service Type DDL is Disabled", "Routing Service Type DDL should Disabled",
					"Routing Service Type DDL is Disabled", "Pass");
		} else {
			System.out.println("Routing Service Type DDL is Not Disabled - FAIL");
			// Reporter.log("Routing Service Type DDL is Not Disabled - FAIL");
			actions.reportCreateFAIL("Routing Service Type DDL is Disabled", "Routing Service Type DDL should Disabled",
					"Routing Service Type DDL is not Disabled", "Fail");
		}

		return strQueue_Name;
	}

	// ----------------------------------
	/*
	 * Feature Name : Queue Management Functionality : Delete Queue on Queue
	 * Management screen Scenario ID : POS_1157 Author : Sonam
	 */
	// -----------------------------------

	public void RFM_POS_DeleteQueueManagement(String strQueue_Name, String strDeletePopupMsg,
			String strDeleteSuccessMsg) throws InterruptedException {

		// Variable Declarations
		Boolean VerifyPopUpMsg;

		// Enter Queue name in the search text box
		actions.setValue("RFMQueueManagementPage.SearchTextBox", strQueue_Name);

		// Click on Search button
		actions.click("RFMQueueManagementPage.SearchButton");
		Thread.sleep(5000);

		// Click on Delete icon
		// actions.click("RFMQueueManagementPage.Deleteicon");
		driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.Deleteicon"))).click();
		Thread.sleep(1000);

		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Confirmation message ", strDeletePopupMsg, true,
				AlertPopupButton.CANCEL_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log(strDeletePopupMsg + " message displayed as expected
			// - PASS");
			System.out.println(strDeletePopupMsg + " message displayed as expected - PASS");
		} else {
			// Reporter.log(strDeletePopupMsg + " message Not displayed -
			// FAIL");
			System.out.println(strDeletePopupMsg + " message Not displayed - FAIL");
		}

		// Again Click on Delete icon
		// actions.click("RFMQueueManagementPage.Deleteicon");
		driver.findElement(By.xpath(actions.getLocator("RFMQueueManagementPage.Deleteicon"))).click();
		Thread.sleep(1000);

		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Confirmation message", strDeletePopupMsg, true,
				AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log(strDeletePopupMsg + " message displayed as expected
			// - PASS");
			System.out.println(strDeletePopupMsg + " message displayed as expected - PASS");
		} else {
			// Reporter.log(strDeletePopupMsg + " message Not displayed -
			// FAIL");
			System.out.println(strDeletePopupMsg + " message Not displayed - FAIL");
		}
		Thread.sleep(5000);

		try {
			mcd.SwitchToWindow("Routing");
			String strTitle = driver.getTitle();
			if (strTitle.equalsIgnoreCase("Routing")) {
				actions.click("RFMRoutingPopupPage.OkButton");
				Thread.sleep(5000);
				System.out.println("Popup is displayed as expected - PASS");
				mcd.SwitchToWindow("QUEUE Management");
			} else {
				WebElement msg_element = driver
						.findElement(By.xpath("//*[@id='queueManagementForm_infoCode']/li/span"));
				String temp_msg = msg_element.getText();
				if (temp_msg.equals(strDeleteSuccessMsg)) {
					// Reporter.log( strDeleteSuccessMsg + " message is
					// displayed as expected " + "- PASS");
					System.out.println(strDeleteSuccessMsg + " message is displayed as expected " + "- PASS");
				} else {
					// Reporter.log( strDeleteSuccessMsg + " message is Not
					// displayed" + "- FAIL");
					System.out.println(strDeleteSuccessMsg + " message is Not displayed" + "- FAIL");
				}
			}
		} catch (Exception e) {
			System.out.println("No action performed");
		}

	}

	// ----------------------------------
	/*
	 * Feature Name : Queue Management Functionality : Update Queue on Queue
	 * Management screen Scenario ID : POS_1155 Author : Sonam
	 */
	// -----------------------------------

	public void RFM_POS_UpdateQueueManagement(String strFieldName, String strFieldValue, String strSuccessMsg)
			throws InterruptedException {

		switch (strFieldName) {
		case "Name":
			// Generate Unique Random number
			Random rand_num = new Random();
			String rand_number = Integer.toString(rand_num.nextInt(9999));
			actions.clear("RFMQueueManagementPage.NameTextbox");
			actions.setValue("RFMQueueManagementPage.NameTextbox", strFieldValue + rand_number);
			break;
		case "Short Name":
			actions.clear("RFMQueueManagementPage.ShortNameTextbox");
			actions.setValue("RFMQueueManagementPage.ShortNameTextbox", strFieldValue);
			break;
		case "Description":
			actions.clear("RFMQueueManagementPage.DescriptionTextbox");
			actions.setValue("RFMQueueManagementPage.DescriptionTextbox", strFieldValue);
			break;
		case "Queue Type":
			actions.clear("RFMQueueManagementPage.QueueTypeTextbox");
			actions.setValue("RFMQueueManagementPage.QueueTypeTextbox", strFieldValue);
			break;
		default:
			System.out.println("No updation done");
		}

		// Click on Save button
		actions.click("RFMQueueManagementPage.SaveButton");
		Thread.sleep(5000);
		try {
			mcd.SwitchToWindow("Routing");
			String strTitle = driver.getTitle();
			if (strTitle.equalsIgnoreCase("Routing")) {
				actions.click("RFMQueueRoutingPopupPage.SaveButton");
				Thread.sleep(5000);
				System.out.println("Popup is displayed as expected - PASS");
				mcd.SwitchToWindow("QUEUE Management");
				WebElement msg_element = driver
						.findElement(By.xpath(".//*[@id='queueManagementForm_infoCode']/li/span"));
				String temp_msg = msg_element.getText();
				if (temp_msg.equals(strSuccessMsg)) {
					// Reporter.log( strSuccessMsg + " message is displayed as
					// expected " + "- PASS");
					System.out.println(strSuccessMsg + " message is displayed as expected " + "- PASS");
					actions.reportCreatePASS(strSuccessMsg + " message is displayed",
							strSuccessMsg + " message should displayed", strSuccessMsg + " message is displayed",
							"Pass");
				} else {
					// Reporter.log( strSuccessMsg + " message is Not displayed"
					// + "- FAIL");
					System.out.println(strSuccessMsg + " message is Not displayed" + "- FAIL");
					actions.reportCreateFAIL(strSuccessMsg + " message is displayed",
							strSuccessMsg + " message should displayed", strSuccessMsg + " message is not displayed",
							"Fail");
				}
			} else {
				WebElement msg_element = driver
						.findElement(By.xpath(".//*[@id='queueManagementForm_infoCode']/li/span"));
				String temp_msg = msg_element.getText();
				if (temp_msg.equals(strSuccessMsg)) {
					// Reporter.log( strSuccessMsg + " message is displayed as
					// expected " + "- PASS");
					System.out.println(strSuccessMsg + " message is displayed as expected " + "- PASS");
					actions.reportCreatePASS(strSuccessMsg + " message is displayed",
							strSuccessMsg + " message should displayed", strSuccessMsg + " message is displayed",
							"Pass");
				} else {
					// Reporter.log( strSuccessMsg + " message is Not displayed"
					// + "- FAIL");
					System.out.println(strSuccessMsg + " message is Not displayed" + "- FAIL");
					actions.reportCreateFAIL(strSuccessMsg + " message is displayed",
							strSuccessMsg + " message should displayed", strSuccessMsg + " message is not displayed",
							"Fail");
				}
			}
		} catch (Exception e) {
			System.out.println("No action performed");
		}

	}

	// ----------------------------------
	/*
	 * Feature Name : Routing Group Management Functionality :GUI Validation of
	 * Routing Group Management Scenario ID : POS_1181 Author : Sonam
	 */
	// -----------------------------------

	public void RFM_POS_GUIValidationRoutingGroupManagement() {

		// Verify header is displayed
		boolean flag1 = driver.findElement(By.xpath(actions.getLocator("RFMRoutingGroupManagementPage.PageHeader")))
				.isDisplayed();
		// System.out.println(flag1);
		if (flag1 == true) {
			System.out.println("Header is Displayed as expected - PASS");
			// Reporter.log("Header is Displayed as expected - PASS");
			actions.reportCreatePASS("Header is Displayed", "Header should Displayed", "Header is Displayed", "Pass");
		} else {
			System.out.println("Header is Not Displayed - FAIL");
			// Reporter.log("Header is Not Displayed - FAIL");
			actions.reportCreateFAIL("Header is Displayed", "Header should Displayed", "Header is not Displayed",
					"Fail");
		}
		// Verify New button is displayed and enabled
		boolean flag2 = driver.findElement(By.xpath(actions.getLocator("RFMRoutingGroupManagementPage.AddNewButton")))
				.isDisplayed();
		// System.out.println(flag2);
		if (flag2 == true) {
			System.out.println("New button is Displayed as expected - PASS");
			// Reporter.log("New button is Displayed as expected - PASS");
			actions.reportCreatePASS("New button is Displayed", "New button should Displayed",
					"New button is Displayed", "Pass");
			boolean flag = driver
					.findElement(By.xpath(actions.getLocator("RFMRoutingGroupManagementPage.AddNewButton")))
					.isEnabled();
			if (flag == true) {
				System.out.println("New button is Enabled as expected - PASS");
				// Reporter.log("New button is Enabled as expected - PASS");
				actions.reportCreatePASS("New button is Enabled", "New button should Enabled", "New button is Enabled",
						"Pass");
			} else {
				System.out.println("New button is Not Enabled - FAIL");
				// Reporter.log("New button is Not Enabled - FAIL");
				actions.reportCreateFAIL("New button is Enabled", "New button should Enabled",
						"New button is not Enabled", "Fail");
			}
		} else {
			System.out.println("New button is Not Displayed - FAIL");
			// Reporter.log("New button is Not Displayed - FAIL");
			actions.reportCreateFAIL("New button is Displayed", "New button should Displayed",
					"New button is not Displayed", "Fail");
		}
		// Verify Grid is displayed
		boolean flag3 = driver.findElement(By.xpath(actions.getLocator("RFMRoutingGroupManagementPage.Table")))
				.isDisplayed();
		// System.out.println(flag3);
		if (flag3 == true) {
			System.out.println("Grid is Displayed as expected - PASS");
			// Reporter.log("Grid is Displayed as expected - PASS");
			actions.reportCreatePASS("Grid is Displayed", "Grid should Displayed", "Grid is Displayed", "Pass");
		} else {
			System.out.println("Grid is Not Displayed - FAIL");
			// Reporter.log("Grid is Not Displayed - FAIL");
			actions.reportCreateFAIL("Grid is Displayed", "Grid should Displayed", "Grid is not Displayed", "Fail");
		}
		// Verify Routing Group Name Column is displayed
		boolean flag4 = driver.findElement(By.xpath(actions.getLocator("RFMRoutingGroupManagementPage.NameColumn")))
				.isDisplayed();
		// System.out.println(flag4);
		if (flag4 == true) {
			System.out.println("Routing Group Name Column is Displayed as expected - PASS");
			// Reporter.log("Routing Group Name Column is Displayed as expected
			// - PASS");
			actions.reportCreatePASS("Routing Group Name Column is Displayed",
					"Routing Group Name Column should Displayed", "Routing Group Name Column is Displayed", "Pass");
		} else {
			System.out.println("Routing Group Name Column is Not Displayed - FAIL");
			// Reporter.log("Routing Group Name Column is Not Displayed -
			// FAIL");
			actions.reportCreateFAIL("Routing Group Name Column is Displayed",
					"Routing Group Name Column should Displayed", "Routing Group Name Column is not Displayed", "Fail");
		}
		// Verify Description Column is displayed
		boolean flag5 = driver
				.findElement(By.xpath(actions.getLocator("RFMRoutingGroupManagementPage.DescriptionColumn")))
				.isDisplayed();
		// System.out.println(flag5);
		if (flag5 == true) {
			System.out.println("Description Column is Displayed as expected - PASS");
			// Reporter.log("Description Column is Displayed as expected -
			// PASS");
			actions.reportCreatePASS("Description Column is Displayed", "Description Column should Displayed",
					"Description Column is Displayed", "Pass");
		} else {
			System.out.println("Description Column is Not Displayed - FAIL");
			// Reporter.log("Description Column is Not Displayed - FAIL");
			actions.reportCreateFAIL("Description Column is Displayed", "Description Column should Displayed",
					"Description Column is not Displayed", "Fail");
		}
		// Verify Area Column is displayed
		boolean flag6 = driver.findElement(By.xpath(actions.getLocator("RFMRoutingGroupManagementPage.AreaColumn")))
				.isDisplayed();
		// System.out.println(flag6);
		if (flag6 == true) {
			System.out.println("Area Column is Displayed as expected - PASS");
			// Reporter.log("Area Column is Displayed as expected - PASS");
			actions.reportCreatePASS("Area Column is Displayed", "Area Column should Displayed",
					"Area Column is Displayed", "Pass");
		} else {
			System.out.println("Area Column is Not Displayed - FAIL");
			// Reporter.log("Area Column is Not Displayed - FAIL");
			actions.reportCreateFAIL("Area Column is Displayed", "Area Column should Displayed",
					"Area Column is not Displayed", "Fail");
		}
		// Verify Queue ID Column is displayed
		boolean flag7 = driver.findElement(By.xpath(actions.getLocator("RFMRoutingGroupManagementPage.QueueIDColumn")))
				.isDisplayed();
		// System.out.println(flag7);
		if (flag7 == true) {
			System.out.println("Queue ID Column is Displayed as expected - PASS");
			// Reporter.log("Queue ID Column is Displayed as expected - PASS");
			actions.reportCreatePASS("Queue ID Column is Displayed", "Queue ID Column should Displayed",
					"Queue ID Column is Displayed", "Pass");
		} else {
			System.out.println("Queue ID Column is Not Displayed - FAIL");
			// Reporter.log("Queue ID Column is Not Displayed - FAIL");
			actions.reportCreateFAIL("Queue ID Column is Displayed", "Queue ID Column should Displayed",
					"Queue ID Column is not Displayed", "Fail");
		}
		// Verify Save button is displayed and enabled
		boolean flag8 = driver.findElement(By.xpath(actions.getLocator("RFMRoutingGroupManagementPage.SaveButton")))
				.isDisplayed();
		// System.out.println(flag8);
		if (flag8 == true) {
			System.out.println("Save button is Displayed as expected - PASS");
			// Reporter.log("Save button is Displayed as expected - PASS");
			actions.reportCreatePASS("Save button is Displayed", "Save button should Displayed",
					"Save button is Displayed", "Pass");
			boolean flag = driver.findElement(By.xpath(actions.getLocator("RFMRoutingGroupManagementPage.SaveButton")))
					.isEnabled();
			if (flag == true) {
				System.out.println("Save button is Enabled as expected - PASS");
				// Reporter.log("Save button is Enabled as expected - PASS");
				actions.reportCreatePASS("Save button is Enabled", "Save button should Enabled",
						"Save button is Enabled", "Pass");
			} else {
				System.out.println("Save button is Not Enabled - FAIL");
				// Reporter.log("Save button is Not Enabled - FAIL");
				actions.reportCreateFAIL("Save button is Enabled", "Save button should Enabled",
						"Save button is not Enabled", "Fail");
			}
		} else {
			System.out.println("Save button is Not Displayed - FAIL");
			// Reporter.log("Save button is Not Displayed - FAIL");
			actions.reportCreateFAIL("Save button is Displayed", "Save button should Displayed",
					"Save button is not Displayed", "Fail");
		}
		// Verify Cancel button is displayed and enabled
		boolean flag9 = driver.findElement(By.xpath(actions.getLocator("RFMRoutingGroupManagementPage.CancelButton")))
				.isDisplayed();
		// System.out.println(flag9);
		if (flag9 == true) {
			System.out.println("Cancel button is Displayed as expected - PASS");
			// Reporter.log("Cancel button is Displayed as expected - PASS");
			actions.reportCreatePASS("Cancel button is Displayed", "Cancel button should Displayed",
					"Cancel button is Displayed", "Pass");
			boolean flag = driver
					.findElement(By.xpath(actions.getLocator("RFMRoutingGroupManagementPage.CancelButton")))
					.isEnabled();
			if (flag == true) {
				System.out.println("Cancel button is Enabled as expected - PASS");
				// Reporter.log("Cancel button is Enabled as expected - PASS");
				actions.reportCreatePASS("Cancel button is Enabled", "Cancel button should Enabled",
						"Cancel button is Enabled", "Pass");
			} else {
				System.out.println("Cancel button is Not Enabled - FAIL");
				// Reporter.log("Cancel button is Not Enabled - FAIL");
				actions.reportCreateFAIL("Cancel button is Enabled", "Cancel button should Enabled",
						"Cancel button is not Enabled", "Fail");
			}
		} else {
			System.out.println("Cancel button is Not Displayed - FAIL");
			// Reporter.log("Cancel button is Not Displayed - FAIL");
			actions.reportCreateFAIL("Cancel button is Displayed", "Cancel button should Displayed",
					"Cancel button is not Displayed", "Fail");
		}
	}

	// ----------------------------------
	/*
	 * Feature Name : Routing Group Management Functionality : Functionality of
	 * Cancel button on Routing Group Management screen Scenario ID : POS_1182
	 * Author : Sonam
	 */
	// -----------------------------------

	public void RFM_POS_CancelFunctionality_RoutingGroup() throws InterruptedException {

		// Variable Declaration
		Boolean VerifyPopUpMsg;

		// Click on Add New button
		actions.click("RFMRoutingGroupManagementPage.AddNewButton");
		// Click on cancel button
		actions.click("RFMRoutingGroupManagementPage.CancelButton");
		Thread.sleep(1000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error",
				"Unsaved data will be lost. Are you sure you want to proceed?", true, AlertPopupButton.CANCEL_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log("Unsaved record message displayed as expected -
			// PASS");
		} else {
			// Reporter.log("Unsaved record message Not displayed - FAIL");
		}
		// Again click on cancel button
		actions.click("RFMRoutingGroupManagementPage.CancelButton");
		Thread.sleep(1000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error",
				"Unsaved data will be lost. Are you sure you want to proceed?", true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log("Unsaved record message displayed as expected -
			// PASS");
		} else {
			// Reporter.log("Unsaved record message Not displayed - FAIL");
		}
		Thread.sleep(5000);
		actions.clear("RFMRoutingGroupManagementPage.FirstName");
		// Generating random number to enter.
		Random rand_num = new Random();
		String strValue = "Auto_" + rand_num.nextInt(9999);
		// Update the Queue Name value
		actions.setValue("RFMRoutingGroupManagementPage.FirstName", strValue);
		// Click on cancel button
		actions.click("RFMRoutingGroupManagementPage.CancelButton");
		Thread.sleep(1000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error",
				"Unsaved data will be lost. Are you sure you want to proceed?", true, AlertPopupButton.CANCEL_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log("Unsaved record message displayed as expected -
			// PASS");
		} else {
			// Reporter.log("Unsaved record message Not displayed - FAIL");
		}
		// Again click on cancel button
		actions.click("RFMRoutingGroupManagementPage.CancelButton");
		Thread.sleep(1000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error",
				"Unsaved data will be lost. Are you sure you want to proceed?", true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log("Unsaved record message displayed as expected -
			// PASS");
		} else {
			// Reporter.log("Unsaved record message Not displayed - FAIL");
		}
		Thread.sleep(5000);

	}

	// ----------------------------------
	/*
	 * Feature Name : Routing Group Management Functionality : Functionality of
	 * Save button on Routing Group Management screen Scenario ID : POS_1074
	 * Author : Sonam
	 */
	// -----------------------------------

	public void RFM_POS_SaveFunctionality_RoutingGroup(String strNoNameMsg, String strNoQueueMsg,
			String strInvalidQueueMsg, String strNoAreaMsg, String strDupQueueMsg, String strDupNameMsg,
			String strSuccessMsg) throws InterruptedException {

		// Variable Declaration
		Boolean VerifyPopUpMsg;

		// Click on Add New Queue button
		actions.click("RFMRoutingGroupManagementPage.AddNewButton");
		// Click on Save button
		actions.click("RFMRoutingGroupManagementPage.SaveButton");
		Thread.sleep(1000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Expected Message", strNoNameMsg, true,
				AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log(strNoNameMsg + " message displayed as expected -
			// PASS");
		} else {
			// Reporter.log(strNoNameMsg + " message Not displayed - FAIL");
		}

		// Generate Unique Random number
		Random rand_num = new Random();
		String rand_number = Integer.toString(rand_num.nextInt(9999));

		// Generate Unique Routing Group Name
		String strRouting_Name = "Auto_RG_" + rand_number;
		// Enter unique Queue Name
		actions.setValue("RFMRoutingGroupManagementPage.NewNameTextbox", strRouting_Name);
		// Click on Save button
		actions.click("RFMRoutingGroupManagementPage.SaveButton");
		Thread.sleep(1000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strNoAreaMsg, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log(strNoAreaMsg + " message displayed as expected -
			// PASS");
		} else {
			// Reporter.log(strNoAreaMsg + " message Not displayed - FAIL");
		}
		// Generate Unique Description
		String strRouting_Desc = "Desc_" + rand_number;
		// Enter unique Description
		actions.setValue("RFMRoutingGroupManagementPage.NewDescTextbox", strRouting_Desc);
		// Click on Save button
		actions.click("RFMRoutingGroupManagementPage.SaveButton");
		Thread.sleep(1000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strNoAreaMsg, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log(strNoAreaMsg + " message displayed as expected -
			// PASS");
		} else {
			// Reporter.log(strNoAreaMsg + " message Not displayed - FAIL");
		}
		// Select Routing Area Type
		Select select = new Select(
				driver.findElement(By.xpath(actions.getLocator("RFMRoutingGroupManagementPage.NewAreaDDL"))));
		select.selectByIndex(1);
		// Click on Save button
		actions.click("RFMRoutingGroupManagementPage.SaveButton");
		Thread.sleep(1000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strNoQueueMsg, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log(strNoQueueMsg + " message displayed as expected -
			// PASS");
		} else {
			// Reporter.log(strNoQueueMsg + " message Not displayed - FAIL");
		}

		String strQueue_Number = "123!@#$%7890";
		// Enter the special characters as Queue Number
		actions.setValue("RFMRoutingGroupManagementPage.NewQueueTextbox", strQueue_Number);
		// Again click on Save button
		actions.click("RFMRoutingGroupManagementPage.SaveButton");
		Thread.sleep(1000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strInvalidQueueMsg, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log(strInvalidQueueMsg + " message displayed as expected
			// - PASS");
		} else {
			// Reporter.log(strInvalidQueueMsg + " message Not displayed -
			// FAIL");
		}

		// Read the existing Queue number
		strQueue_Number = driver.findElement(By.xpath(".//*[@id='queueId_0']")).getAttribute("value");
		// Clear the Queue text value
		actions.clear("RFMRoutingGroupManagementPage.NewQueueTextbox");
		// Enter the existing Queue number
		actions.setValue("RFMRoutingGroupManagementPage.NewQueueTextbox", strQueue_Number);
		// Click on Save button
		actions.click("RFMRoutingGroupManagementPage.SaveButton");
		Thread.sleep(1000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strDupQueueMsg, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log(strDupQueueMsg + " message displayed as expected -
			// PASS");
		} else {
			// Reporter.log(strDupQueueMsg + " message Not displayed - FAIL");
		}

		strQueue_Number = rand_number;
		// Clear the Queue text value
		actions.clear("RFMRoutingGroupManagementPage.NewQueueTextbox");
		// Enter the unique Queue number
		actions.setValue("RFMRoutingGroupManagementPage.NewQueueTextbox", strQueue_Number);
		// Read the existing Routing Group Name
		strRouting_Name = driver.findElement(By.xpath(actions.getLocator("RFMRoutingGroupManagementPage.FirstName")))
				.getAttribute("value");
		// Clear the Routing Group Name value
		actions.clear("RFMRoutingGroupManagementPage.NewNameTextbox");
		// Enter the existing Routing Group name
		actions.setValue("RFMRoutingGroupManagementPage.NewNameTextbox", strRouting_Name);
		// Click on Save button
		actions.click("RFMRoutingGroupManagementPage.SaveButton");
		Thread.sleep(1000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strDupNameMsg, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log(strDupNameMsg + " message displayed as expected -
			// PASS");
		} else {
			// Reporter.log(strDupNameMsg + " message Not displayed - FAIL");
		}
		// Generate Unique Random Name
		strRouting_Name = "Auto_RG_" + rand_number;
		// Clear the Queue Name value
		actions.clear("RFMRoutingGroupManagementPage.NewNameTextbox");
		// Enter unique Queue Name
		actions.setValue("RFMRoutingGroupManagementPage.NewNameTextbox", strRouting_Name);
		// Click on Save button
		actions.click("RFMRoutingGroupManagementPage.SaveButton");
		Thread.sleep(5000);
		WebElement msg_element = driver.findElement(By.xpath("//*[@id='routingGroupManagementForm_infoCode']/li/span"));
		String temp_msg = msg_element.getText();
		if (temp_msg.equals(strSuccessMsg)) {
			// Reporter.log( strSuccessMsg + " message is displayed as expected
			// " + "- PASS");
			System.out.println(strSuccessMsg + " message is displayed as expected " + "- PASS");
		} else {
			// Reporter.log( strSuccessMsg + " message is Not displayed" + "-
			// FAIL");
			System.out.println(strSuccessMsg + " message is Not displayed" + "- FAIL");
		}

	}

	// ----------------------------------
	/*
	 * Feature Name : Routing Group Management Functionality : Create New
	 * Routing Group on Routing Group Management screen Scenario ID : POS_1073
	 * Author : Sonam
	 */
	// -----------------------------------

	public String RFM_POS_CreateRoutingGroup(String strRouting_Name, String strDesc, String strArea, String strQueue_ID,
			String strSuccessMsg) throws InterruptedException {

		// Click on Add New Queue button
		actions.click("RFMRoutingGroupManagementPage.AddNewButton");

		// Generate Unique Random number
		Random rand_num = new Random();
		String strRand_Num = Integer.toString(rand_num.nextInt(9999));

		// Enter the unique Routing Group Name
		if (strRouting_Name.trim().equalsIgnoreCase("Runtime data")) {
			strRouting_Name = "Auto_RG_" + strRand_Num;
		}
		actions.setValue("RFMRoutingGroupManagementPage.NewNameTextbox", strRouting_Name);
		Thread.sleep(1000);
		// Enter unique Description
		if (strDesc.trim().equalsIgnoreCase("Runtime data")) {
			strDesc = "Desc_" + strRand_Num;
		}
		actions.setValue("RFMRoutingGroupManagementPage.NewDescTextbox", strDesc);
		Thread.sleep(1000);
		// Select Routing Area Type
		if (strArea.trim().equalsIgnoreCase("Runtime data")) {
			Select select = new Select(
					driver.findElement(By.xpath(actions.getLocator("RFMRoutingGroupManagementPage.NewAreaDDL"))));
			select.selectByIndex(1);
			strArea = select.getFirstSelectedOption().getText();
		} else {
			actions.setValue("RFMRoutingGroupManagementPage.NewAreaDDL", strArea);
		}
		Thread.sleep(1000);
		System.out.println(
				"Selected value '" + strArea + "' in the input element 'RFMRoutingGroupManagementPage.NewAreaDDL'");

		// Enter unique Queue ID
		if (strQueue_ID.trim().equalsIgnoreCase("Runtime data")) {
			strQueue_ID = strRand_Num;
		}
		actions.setValue("RFMRoutingGroupManagementPage.NewQueueTextbox", strQueue_ID);
		Thread.sleep(1000);
		// Click on Save button
		actions.click("RFMRoutingGroupManagementPage.SaveButton");
		Thread.sleep(5000);
		WebElement msg_element = driver.findElement(By.xpath("//*[@id='routingGroupManagementForm_infoCode']/li/span"));
		String temp_msg = msg_element.getText();
		if (temp_msg.equals(strSuccessMsg)) {
			// Reporter.log( strSuccessMsg + " message is displayed as expected
			// " + "- PASS");
			System.out.println(strSuccessMsg + " message is displayed as expected " + "- PASS");
			System.out.println("User is able to create new Routing group - " + strRouting_Name);
			actions.reportCreatePASS("Validating the Role Permission 'Full Access'",
					"User should be able to create new Routing Group",
					"User is able to create new Routing group - " + strRouting_Name, "Pass");
		} else {
			// Reporter.log( strSuccessMsg + " message is Not displayed" + "-
			// FAIL");
			System.out.println(strSuccessMsg + " message is Not displayed" + "- FAIL");
			System.out.println("User is Not able to create new Routing group");
			actions.reportCreateFAIL("Validating the Role Permission 'Full Access'",
					"User should be able to create new Routing Group", "User is Not able to create new Routing group",
					"Fail");
		}
		// Verify Routing Area DDL becomes disabled
		boolean flag1 = driver.findElement(By.xpath(actions.getLocator("RFMRoutingGroupManagementPage.NewAreaDDL")))
				.isEnabled();
		// System.out.println(flag1);
		if (flag1 == false) {
			System.out.println("Routing Area DDL is Disabled as expected - PASS");
			actions.reportCreatePASS("Validating the Routing Area DDL as disabled",
					"Routing Area DDL should be disbaled", "Routing Area DDL is disbaled as expected", "Pass");

		} else {
			System.out.println("Routing Area DDL is Not Disabled - FAIL");
			actions.reportCreateFAIL("Validating the Routing Area DDL as disabled",
					"Routing Area DDL should be disbaled", "Routing Area DDL is not disbaled", "Fail");
		}
		return strRouting_Name;
	}

	// ------------------------------------------
	/*
	 * Feature Name : Routing Group Management Functionality : Update any Field
	 * on Routing Group Management screen Scenario ID : POS_1183 Author : Sonam
	 */
	// -------------------------------------------

	public String RFM_POS_UpdateRoutingGroup(String strFieldName, String strFieldValue, String strSuccessMsg)
			throws InterruptedException {

		String strValue = null;
		String strRouting_Name = null;
		switch (strFieldName.trim()) {
		case "Name":
			// Generate Unique Random number
			Random rand_num = new Random();
			String rand_number = Integer.toString(rand_num.nextInt(9999));
			actions.clear("RFMRoutingGroupManagementPage.FirstName");
			strValue = strFieldValue + rand_number;
			strRouting_Name = strValue;
			actions.setValue("RFMRoutingGroupManagementPage.FirstName", strFieldValue + rand_number);
			break;
		case "Description":
			actions.clear("RFMRoutingGroupManagementPage.DescriptionTextbox");
			strValue = strFieldValue;
			actions.setValue("RFMRoutingGroupManagementPage.DescriptionTextbox", strFieldValue);
			break;
		case "Queue ID":
			Random rand_num1 = new Random();
			String rand_number1 = Integer.toString(rand_num1.nextInt(99));
			actions.clear("RFMRoutingGroupManagementPage.QueueIDTextbox");
			strValue = rand_number1 + strFieldValue;
			actions.setValue("RFMRoutingGroupManagementPage.QueueIDTextbox", rand_number1 + strFieldValue);
			break;
		default:
			System.out.println("No updation done");
		}

		// Click on Save button
		actions.click("RFMRoutingGroupManagementPage.SaveButton");
		Thread.sleep(5000);
		WebElement msg_element = driver
				.findElement(By.xpath(".//*[@id='routingGroupManagementForm_infoCode']/li/span"));
		String temp_msg = msg_element.getText();
		if (temp_msg.equals(strSuccessMsg)) {
			System.out.println(strSuccessMsg + " message is displayed as expected " + "- PASS");
			System.out.println(" '" + strFieldName + "' field is updated with '" + strValue + "' value");
			actions.reportCreatePASS("Updation of '" + strFieldName + "' field with '" + strValue + "' value",
					"User should be able to update '" + strFieldName + "' field with '" + strValue + "' value",
					strSuccessMsg + " message is displayed as expected and '" + strFieldName
							+ "' field is updated with '" + strValue + "' value",
					"Pass");
		} else {
			// Reporter.log( strSuccessMsg + " message is Not displayed" + "-
			// FAIL");
			System.out.println(strSuccessMsg + " message is Not displayed" + "- FAIL");
			System.out.println(" '" + strFieldName + "' field is not updated with '" + strValue + "' value");
			actions.reportCreateFAIL("Updation of '" + strFieldName + "' field with '" + strValue + "' value",
					"User should be able to update '" + strFieldName + "' field with '" + strValue + "' value",
					strSuccessMsg + " message is Not displayed and '" + strFieldName + "' field is not updated with '"
							+ strValue + "' value",
					"Fail");
		}

		return strRouting_Name;
	}

	// ----------------------------------
	/*
	 * Feature Name : Routing Group Management Functionality : Delete Routing
	 * Group on Routing Group Management screen Scenario ID : POS_1185 Author :
	 * Sonam
	 */
	// -----------------------------------

	public void RFM_POS_DeleteRoutingGroup(String strRouting_Name, String strDeletePopupMsg, String strDeleteSuccessMsg)
			throws InterruptedException {

		// Variable Declarations
		Boolean VerifyPopUpMsg;
		String xpath1 = null;
		int row_cnt = mcd.GetTableRowCount("RFMRoutingGroupManagementPage.Table");
		for (int i = 0; i < row_cnt - 2; i++) {
			WebElement name = driver.findElement(By.xpath("//*[@id='routingGroupName_" + i + "']"));
			String routing_name = name.getAttribute("value");
			if (routing_name.trim().equalsIgnoreCase(strRouting_Name)) {
				int j = i + 2;
				xpath1 = "//*[@id='Sess1']/tbody/tr[" + j + "]/td[5]/a";
				// Click on Delete icon
				driver.findElement(By.xpath(xpath1)).click();
				Thread.sleep(2000);
				break;
			}
		}
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Confirmation message ", strDeletePopupMsg, true,
				AlertPopupButton.CANCEL_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log(strDeletePopupMsg + " message displayed as expected
			// - PASS");
			System.out.println(strDeletePopupMsg + " message displayed as expected - PASS");
			actions.reportCreatePASS(strDeletePopupMsg + " message is displayed",
					strDeletePopupMsg + " message should displayed", strDeletePopupMsg + " message is displayed",
					"Pass");
		} else {
			// Reporter.log(strDeletePopupMsg + " message Not displayed -
			// FAIL");
			System.out.println(strDeletePopupMsg + " message Not displayed - FAIL");
			actions.reportCreateFAIL(strDeletePopupMsg + " message is displayed",
					strDeletePopupMsg + " message should displayed", strDeletePopupMsg + " message is not displayed",
					"Fail");
		}
		// Again Click on Delete icon
		driver.findElement(By.xpath(xpath1)).click();
		Thread.sleep(2000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Confirmation message", strDeletePopupMsg, true,
				AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg = true) {
			// Reporter.log(strDeletePopupMsg + " message displayed as expected
			// - PASS");
			System.out.println(strDeletePopupMsg + " message displayed as expected - PASS");
			actions.reportCreatePASS(strDeletePopupMsg + " message is displayed",
					strDeletePopupMsg + " message should displayed", strDeletePopupMsg + " message is displayed",
					"Pass");
		} else {
			// Reporter.log(strDeletePopupMsg + " message Not displayed -
			// FAIL");
			System.out.println(strDeletePopupMsg + " message Not displayed - FAIL");
			actions.reportCreateFAIL(strDeletePopupMsg + " message is displayed",
					strDeletePopupMsg + " message should displayed", strDeletePopupMsg + " message is not displayed",
					"Fail");
		}
		Thread.sleep(5000);
		try {
			mcd.SwitchToWindow("Cannot Delete Routing Group");
			String strTitle = driver.getTitle();
			if (strTitle.equalsIgnoreCase("Cannot Delete Routing Group")) {
				actions.click("RFMCannotDeleteRoutingPopupPage.OkButton");
				Thread.sleep(5000);
				System.out.println("Popup is displayed as expected - PASS");
				mcd.SwitchToWindow("Routing Group Management");
			} else {
				WebElement msg_element = driver
						.findElement(By.xpath("//*[@id='routingGroupManagementForm_infoCode']/li/span"));
				String temp_msg = msg_element.getText();
				if (temp_msg.equals(strDeleteSuccessMsg)) {
					// Reporter.log( strDeleteSuccessMsg + " message is
					// displayed as expected " + "- PASS");
					System.out.println(strDeleteSuccessMsg + " message is displayed as expected " + "- PASS");
					actions.reportCreatePASS(strDeleteSuccessMsg + " message is displayed",
							strDeleteSuccessMsg + " message should displayed",
							strDeleteSuccessMsg + " message is displayed", "Pass");
				} else {
					// Reporter.log( strDeleteSuccessMsg + " message is Not
					// displayed" + "- FAIL");
					System.out.println(strDeleteSuccessMsg + " message is Not displayed" + "- FAIL");
					actions.reportCreateFAIL(strDeleteSuccessMsg + " message is displayed",
							strDeleteSuccessMsg + " message should displayed",
							strDeleteSuccessMsg + " message is not displayed", "Fail");
				}
			}
		} catch (Exception e) {
			System.out.println("No action performed");
		}

	}

	// ----------------------------------
	/*
	 * Feature Name : Presentation Routing Set Functionality :Search Validation
	 * Presentation Routing Set Scenario ID : POS_1131 Author : Sonam
	 */
	// -----------------------------------

	public void RFM_POS_SearchPresentationRoutingSetSelectNode(String strSearchValue, String strNoRecordMsg,
			String strNoSearchMsg) throws InterruptedException {

		// Variable Declaration
		int iTemp = 0;
		int row_cnt = 0;

		// Clear the text box value
		actions.clear("RFMPresentationRoutingSetSelectNodePage.SearchTextbox");
		Thread.sleep(1000);
		// Enter Search value
		actions.setValue("RFMPresentationRoutingSetSelectNodePage.SearchTextbox", strSearchValue);
		Thread.sleep(500);
		// Click on Search button
		actions.click("RFMPresentationRoutingSetSelectNodePage.SearchButton");
		Thread.sleep(5000);
		System.out.println(strSearchValue);

		if (strSearchValue == null) {
			System.out.println("> Click on OK button of Message Box");
			mcd.VerifyAlertMessageDisplayed("Expected Message", strNoSearchMsg, true, AlertPopupButton.OK_BUTTON);
		} else {
			// Get row count of number of Presentation Routing sets fetched
			row_cnt = mcd.GetTableRowCount("RFMPresentationRoutingSetSelectNodePage.SelectNodeTable");
			// Verify the name containing search value
			if (row_cnt == 0) {
				WebElement msg_element = driver.findElement(By.xpath("//*[@id=' _infoCode']/li/span"));
				String temp_msg = msg_element.getText();
				if (temp_msg.equals(strNoRecordMsg)) {
					// Reporter.log( strNoRecordMsg + " message is displayed as
					// expected " + "- PASS");
					System.out.println("No records available with the search text - " + strSearchValue);
					System.out.println(strNoRecordMsg + " message is displayed as expected " + "- PASS");
				}
			} else {
				List<WebElement> PrdRSet_List = driver.findElements(By.xpath("//*[@id='userRoleData']/tr"));
				// Get row count of number of Production Routing sets fetched
				row_cnt = PrdRSet_List.size();
				for (int i = 1; i <= row_cnt; i++) {
					try {
						String xpath = "//*[@id='userRoleData']/tr[" + i + "]/td[1]/a/pre";
						String PreRSet_Name = driver.findElement(By.xpath(xpath)).getText();
						System.out.println(PreRSet_Name);

						if (PreRSet_Name.contains(strSearchValue.toLowerCase())
								|| PreRSet_Name.contains(strSearchValue.toUpperCase())) {
							iTemp = iTemp + 1;
						} else {
							System.out.println(
									PreRSet_Name + " doesnot contain the search value - " + strSearchValue + " - FAIL");
							actions.reportCreateFAIL("Validation of Search Criteria",
									"All the fetched records should contain the search value as " + strSearchValue,
									PreRSet_Name + " doesnot contain the search value - " + strSearchValue, "FAIL");
							iTemp = 0;
							break;
						}
						if (iTemp == row_cnt) {
							System.out.println("All the fetched Presentation Routing Sets contains the search value - "
									+ strSearchValue + " - PASS");
							actions.reportCreatePASS("Validation of Search Criteria",
									"All the fetched records should contain the search value as " + strSearchValue,
									"All the fetched Presentation Routing Sets contains the search value - "
											+ strSearchValue,
									"PASS");
						}
					} catch (Exception e) {
						System.out.println("No records available with the search text -  " + strSearchValue);
					}

				}
			}
		}
	}

	// ----------------------------------
	/*
	 * Feature Name : Presentation Routing Set Functionality : Search with
	 * Status Presentation Production Routing Set Scenario ID : POS_1131 Author
	 * : Sonam
	 */
	// -----------------------------------

	public void RFM_POS_SearchwithFilterPresentationRoutingSet_SelectNode(String strSearchValue, String strStatus,
			String strNoRecordMsg, String strNoSearchMsg) throws InterruptedException {

		// Variable Declaration
		int iTemp = 0;
		int row_cnt = 0;

		// Clear the text box value
		actions.clear("RFMPresentationRoutingSetSelectNodePage.SearchTextbox");
		Thread.sleep(1000);
		// Enter Search value
		actions.setValue("RFMPresentationRoutingSetSelectNodePage.SearchTextbox", strSearchValue);
		Thread.sleep(500);
		// Select Status
		actions.setValue("RFMPresentationRoutingSetSelectNodePage.SearchStatusDDL", strStatus);
		// Click on Search button
		actions.click("RFMPresentationRoutingSetSelectNodePage.SearchButton");
		Thread.sleep(5000);
		// Verify the PostSearch Filter Status is selected same as selected
		// status
		boolean flag = driver
				.findElement(By.xpath(actions.getLocator("RFMPresentationRoutingSetSelectNodePage.filterStatusDDL")))
				.isEnabled();
		if (flag == false && (strStatus == "Active" || strStatus == "Inactive")) {
			System.out.println("PostSearch Filter is Disabled");
		} else {
			System.out.println("PostSearch Filter is Not Disbaled");
		}

		if (strSearchValue == null) {
			System.out.println("> Click on OK button of Message Box");
			mcd.VerifyAlertMessageDisplayed("Expected Message", strNoSearchMsg, true, AlertPopupButton.OK_BUTTON);
		} else {

			// Get row count of number of Production Routing sets fetched
			row_cnt = mcd.GetTableRowCount("RFMPresentationRoutingSetSelectNodePage.SelectNodeTable");

			// Verify the name containing search value
			if (row_cnt == 0) {
				WebElement msg_element = driver.findElement(By.xpath("//*[@id='_infoCode']/li/span"));
				String temp_msg = msg_element.getText();

				if (temp_msg.equals(strNoRecordMsg)) {
					System.out.println("No records available with the search text - " + strSearchValue);
					System.out.println(strNoRecordMsg + " message is displayed as expected " + "- PASS");
				}
			} else {

				List<WebElement> PrdRSet_List = driver.findElements(By.xpath("//*[@id='userRoleData']/tr"));
				// Get row count of number of Production Routing sets fetched
				row_cnt = PrdRSet_List.size();
				for (int i = 1; i <= row_cnt; i++) {
					try {
						String xpath1 = "//*[@id='userRoleData']/tr[" + i + "]/td[1]/a/pre";
						String xpath2 = "//*[@id='userRoleData']/tr[" + i + "]/td[3]";
						String PreRSet_Name = driver.findElement(By.xpath(xpath1)).getText();
						System.out.println(PreRSet_Name);
						String PreRSet_Status = driver.findElement(By.xpath(xpath2)).getText();
						System.out.println(PreRSet_Status);

						if (strStatus == "Active/Inactive") {
							if (PreRSet_Status.equals("Active") || PreRSet_Status.equals("Inactive")) {
								iTemp = iTemp + 1;
							} else {
								System.out.println(
										PreRSet_Name + " doesnot have the status value " + strStatus + " - FAIL");
								actions.reportCreateFAIL("Validation of Post Status Filter",
										"All the fetched records should have status as " + strStatus,
										PreRSet_Name + " doesnot have the status value " + strStatus, "FAIL");
								iTemp = 0;
								break;
							}
						} else {
							if (PreRSet_Status.equals(strStatus)) {
								iTemp = iTemp + 1;
							} else {
								System.out.println(
										PreRSet_Name + " doesnot have the status value " + strStatus + " - FAIL");
								actions.reportCreateFAIL("Validation of Post Status Filter",
										"All the fetched records should have status as " + strStatus,
										PreRSet_Name + " doesnot have the status value " + strStatus, "FAIL");
								iTemp = 0;
								break;
							}

						}

						if (iTemp == row_cnt) {
							System.out.println("All the fetched Presentation Routing Sets are having status value - "
									+ strStatus + " - PASS");
							actions.reportCreatePASS("Validation of Post Status Filter",
									"All the fetched records should have status as " + strStatus,
									"All the fetched Presentation Routing Sets are having status value - " + strStatus,
									"PASS");
						}

					} catch (Exception e) {
						System.out.println("No records available with the search text - " + strSearchValue);
					}

				}
			}
		}
	}

	// --------------------------------------
	/*
	 * Feature Name : Presentation Routing Set Functionality : Verify Post
	 * Status Filter functionality in Presentation Routing Set - Select Node
	 * Scenario ID : POS_1131 Author : Sonam
	 */
	// ---------------------------------------

	public void RFM_POS_FilterStatusPresentationRoutingSet_SelectNode(String strStatus, String strNoRecordMsg)
			throws InterruptedException {

		// Variable Declaration
		int iTemp = 0;
		int row_cnt = 0;

		// Clear the text box value
		actions.clear("RFMPresentationRoutingSetSelectNodePage.SearchTextbox");
		Thread.sleep(1000);
		// Click on View Full List button
		actions.click("RFMPresentationRoutingSetSelectNodePage.ViewFullListButton");
		actions.smartWait(100);
		// Select Status
		actions.setValue("RFMPresentationRoutingSetSelectNodePage.filterStatusDDL", strStatus);
		// Get row count of number of Production Routing sets fetched
		row_cnt = mcd.GetTableRowCount("RFMPresentationRoutingSetSelectNodePage.SelectNodeTable");
		// Verify the name containing search value
		if (row_cnt == 0) {
			WebElement msg_element = driver.findElement(By.xpath("//*[@id='_infoCode']/li/span"));
			String temp_msg = msg_element.getText();
			if (temp_msg.equals(strNoRecordMsg)) {
				System.out.println("No records available");
				System.out.println(strNoRecordMsg + " message is displayed as expected " + "- PASS");
			}
		} else {
			List<WebElement> PreRSet_List = driver.findElements(By.xpath("//*[@id='userRoleData']/tr"));
			// Get row count of number of Production Routing sets fetched
			row_cnt = PreRSet_List.size();
			for (int i = 1; i <= row_cnt; i++) {
				try {
					String xpath1 = "//*[@id='userRoleData']/tr[" + i + "]/td[1]/a/pre";
					String xpath2 = "//*[@id='userRoleData']/tr[" + i + "]/td[3]";
					String PreRSet_Name = driver.findElement(By.xpath(xpath1)).getText();
					System.out.println(PreRSet_Name);
					String PreRSet_Status = driver.findElement(By.xpath(xpath2)).getText();
					System.out.println(PreRSet_Status);
					if (strStatus == "Active/Inactive") {
						if (PreRSet_Status.equals("Active") || PreRSet_Status.equals("Inactive")) {
							iTemp = iTemp + 1;
						} else {
							System.out
									.println(PreRSet_Name + " doesnot have the status value " + strStatus + " - FAIL");
							actions.reportCreateFAIL("Validation of Post Status Filter",
									"All the fetched records should have status as " + strStatus,
									PreRSet_Name + " doesnot have the status value " + strStatus, "FAIL");
							iTemp = 0;
							break;
						}
					} else {
						if (PreRSet_Status.equals(strStatus)) {
							iTemp = iTemp + 1;
						} else {
							System.out
									.println(PreRSet_Name + " doesnot have the status value " + strStatus + " - FAIL");
							actions.reportCreateFAIL("Validation of Post Status Filter",
									"All the fetched records should have status as " + strStatus,
									PreRSet_Name + " doesnot have the status value " + strStatus, "FAIL");
							iTemp = 0;
							break;
						}
					}
					if (iTemp == row_cnt) {
						System.out.println("All the fetched Presentation Routing Sets are having status value - "
								+ strStatus + " - PASS");
						actions.reportCreatePASS("Validation of Post Status Filter",
								"All the fetched records should have status as " + strStatus,
								"All the fetched Presentation Routing Sets are having status value - " + strStatus,
								"PASS");
					}
				} catch (Exception e) {
					System.out.println("No records available");
				}
			}
		}
	}

	// --------------------------------------
	/*
	 * Feature Name : Create Route Functionality : Create Route for
	 * Presentation/Production Routing Set Author : Sonam
	 */
	// ---------------------------------------

	public void fn_RFM_POS_Create_Route(String strRouteID, String strPMIG, String strSource, String strDestination)
			throws InterruptedException {

		// Generate Unique Random number
		Random rand_num = new Random();
		String strRand_Num = Integer.toString(rand_num.nextInt(9999));
		// Enter Route ID
		if (strRouteID.trim().equalsIgnoreCase("Runtime Data")) {
			strRouteID = strRand_Num;
		}
		actions.setValue("RFMRoutingPage.NewRouteIDTextbox", strRouteID);
		Thread.sleep(1000);

		// Select PMIG
		if (strPMIG.trim().equalsIgnoreCase("Runtime data")) {
			Select select = new Select(driver.findElement(By.xpath(actions.getLocator("RFMRoutingPage.NewPMIGDDL"))));
			select.selectByIndex(2);
			strPMIG = select.getFirstSelectedOption().getText();
			System.out.println("Selected value '" + strPMIG + "' in the input element 'RFMRoutingPage.NewPMIGDDL'");
		} else {
			actions.setValue("RFMRoutingPage.NewPMIGDDL", strPMIG);
		}
		Thread.sleep(1000);

		// Select Source
		if (strSource.trim().equalsIgnoreCase("Runtime data")) {
			Select select = new Select(driver.findElement(By.xpath(actions.getLocator("RFMRoutingPage.NewSourceDDL"))));
			select.selectByIndex(2);
			strSource = select.getFirstSelectedOption().getText();
			System.out.println("Selected value '" + strSource + "' in the input element 'RFMRoutingPage.NewSourceDDL'");
		} else {
			actions.setValue("RFMRoutingPage.NewSourceDDL", strSource);
		}
		Thread.sleep(1000);

		// Select Destination
		if (strDestination.trim().equalsIgnoreCase("Runtime data")) {
			Select select = new Select(driver.findElement(By.xpath(actions.getLocator("RFMRoutingPage.NewDestDDL"))));
			select.selectByIndex(2);
			strDestination = select.getFirstSelectedOption().getText();
			System.out.println(
					"Selected value '" + strDestination + "' in the input element 'RFMRoutingPage.NewDestDDL'");
		} else {
			actions.setValue("RFMRoutingPage.NewDestDDL", strDestination);
		}
		Thread.sleep(1000);

	}

	// --------------------------------------
	/*
	 * Feature Name : Create Volume Functionality : Create Volume for Production
	 * Routing Set Author : Sonam
	 */
	// ---------------------------------------

	public void fn_RFM_POS_Create_Volume() throws InterruptedException {

		// Generate Unique Random number
		Random rand_num = new Random();
		String strRand_Num = Integer.toString(rand_num.nextInt(9999));
		// Enter Volume Name
		String strVolName = "Vol_" + strRand_Num;
		actions.setValue("RFMProductionRoutingSetPage.VolumeName", strVolName);
		Thread.sleep(1000);

		// Enter Volume Description
		String strVolDesc = "Vol_Desc_" + strRand_Num;
		actions.setValue("RFMProductionRoutingSetPage.VolumeDesc", strVolDesc);
		Thread.sleep(1000);

		int row_cnt = mcd.GetTableRowCount("RFMProductionRoutingSetPage.VolumeTable");

		for (int i = 3; i <= row_cnt; i++) {
			WebElement eleQueue_Number = driver
					.findElement(By.xpath("//*[@class='rowbgAltWhite']/table//tbody/tr[" + i + "]/td[2]/input"));
			eleQueue_Number.sendKeys((Integer.toString(i - 2)));
		}

		actions.click("PromotionReport.OkBtn");
		Thread.sleep(2000);
	}

	// ----------------------------------
	/*
	 * Feature Name : Presentation Routing Set Functionality : Create New
	 * Presentation Routing Set Scenario ID : POS_1129 Author : Sonam
	 */
	// -----------------------------------

	public String RFM_POS_CreatePresentationRouting(String strName, String strDesc, String strCopyExisting,
			String strSuccessMsg, String strRouteID, String strPMIG, String strSource, String strDestination,
			String strStatus) throws Exception {

		// Generate Unique Random number
		Random rand_num = new Random();
		String strRand_Num = Integer.toString(rand_num.nextInt(9999));

		// Enter the unique Routing Group Name
		if (strName.trim().equalsIgnoreCase("Runtime data")) {
			strName = "Auto_PreR_" + strRand_Num;
		}
		actions.setValue("RFMPresentationRoutingSetPage.NameTextbox", strName);
		Thread.sleep(1000);

		// Enter unique Description
		if (strDesc.trim().equalsIgnoreCase("Runtime data")) {
			strDesc = "Desc_PreR_" + strRand_Num;
		}
		actions.setValue("RFMPresentationRoutingSetPage.DescTextbox", strDesc);
		Thread.sleep(1000);

		if (strCopyExisting.equalsIgnoreCase("YES")) {

			// Select copy from existing radio button as Yes
			actions.click("RFMPresentationRoutingSetPage.YesRadioButton");

			// Click on Select button
			actions.click("RFMPresentationRoutingSetPage.SelectButton");
			Thread.sleep(5000);
			// mcd.SwitchToWindow("#Manage Presentation Routing Set");
			mcd.SwitchToWindow("Manage Presentation Routing Set");

			// Click on View Full List
			actions.click("RFMPresentationRoutingSetSelectNodePage.ViewFullListButton");
			actions.smartWait(100);

			// Select existing Presentation Routing Set
			driver.findElement(By.xpath("//*[@id='userRoleData']/tr[1]/td[1]/a/pre")).click();
			Thread.sleep(2000);
			// mcd.SwitchToWindow("#Add New Routing Set");
			mcd.SwitchToWindow("Add New Routing Set");

			// Click on next button
			actions.click("RFMPresentationRoutingSetPage.NextButton");
			Thread.sleep(4000);
			mcd.SwitchToWindow("@Manage Presentation Routing Sets");

			WebElement msg_element = driver
					.findElement(By.xpath(actions.getLocator("RFMPresentationRoutingSetPage.SuccessMsg")));
			String temp_msg = msg_element.getText();
			if (temp_msg.equals(strSuccessMsg)) {
				System.out.println(strSuccessMsg + " message is displayed as expected " + "- PASS");
				System.out.println("User is able to create new Presentation Routing Set - '" + strName
						+ "' with copy existing option");
				actions.reportCreatePASS("Create Presentation Routing Set with copy existing option",
						"User should be able to create new Presentation Routing Set with copy existing option",
						"User is able to create new Presentation Routing Set - '" + strName
								+ "' with copy existing option",
						"Pass");
			} else {
				System.out.println(strSuccessMsg + " message is Not displayed" + "- FAIL");
				System.out.println("User is Not able to create new Presentation Routing Set with copy existing option");
				actions.reportCreateFAIL("Create Presentation Routing Set with copy existing option",
						"User should be able to create new Presentation Routing Set with copy existing option",
						"User is not able to create new Presentation Routing Set with copy existing option", "Fail");
			}

		} else {

			// Click on next button
			actions.click("RFMPresentationRoutingSetPage.NextButton");
			Thread.sleep(4000);
			mcd.SwitchToWindow("@Manage Presentation Routing Sets");

			// Click on Add Route button
			actions.keyboardEnter("RFMPresentationRoutingSetPage.AddRoute");
			Thread.sleep(1000);

			// Enter Route Details
			fn_RFM_POS_Create_Route(strRouteID, strPMIG, strSource, strDestination);

			// Select the status value
			actions.setValue("RFMPresentationRoutingSetPage.StatusDDL", strStatus);

			// Click on save button
			actions.click("RFMPresentationRoutingSetPage.Save");
			Thread.sleep(5000);

			WebElement msg_element = driver
					.findElement(By.xpath(actions.getLocator("RFMPresentationRoutingSetPage.SuccessMsg")));
			String temp_msg = msg_element.getText();
			if (temp_msg.equals(strSuccessMsg)) {
				System.out.println(strSuccessMsg + " message is displayed as expected " + "- PASS");
				System.out.println("User is able to create new Presentation Routing Set - '" + strName
						+ "' without using copy existing option");
				actions.reportCreatePASS("Create Presentation Routing Set without using copy existing option",
						"User should be able to create new Presentation Routing Set without using copy existing option",
						"User is able to create new Presentation Routing Set - '" + strName
								+ "' without using copy existing option",
						"Pass");
			} else {
				System.out.println(strSuccessMsg + " message is Not displayed" + "- FAIL");
				System.out.println(
						"User is Not able to create new Presentation Routing Set without using copy existing option");
				actions.reportCreateFAIL("Create Presentation Routing Set without using copy existing option",
						"User should be able to create new Presentation Routing Set without using copy existing option",
						"User is not able to create new Presentation Routing Set without using copy existing option",
						"Fail");
			}
		}

		return strName;
	}

	// ----------------------------------
	/*
	 * Feature Name : Production Routing Set Functionality : Create New
	 * Production Routing Set Author : Sonam
	 */
	// -----------------------------------

	public String RFM_POS_CreateProductionRouting(String strName, String strDesc, String strCopyExisting,
			String strSuccessMsg, String strRouteID, String strPMIG, String strSource, String strDestination,
			String strStatus) throws Exception {

		// Generate Unique Random number
		Random rand_num = new Random();
		String strRand_Num = Integer.toString(rand_num.nextInt(9999));

		// Enter the unique Routing Group Name
		if (strName.trim().equalsIgnoreCase("Runtime data")) {
			strName = "Auto_PrdR_" + strRand_Num;
		}
		actions.setValue("RFMPresentationRoutingSetPage.NameTextbox", strName);
		Thread.sleep(1000);

		// Enter unique Description
		if (strDesc.trim().equalsIgnoreCase("Runtime data")) {
			strDesc = "Desc_PrdR_" + strRand_Num;
		}
		actions.setValue("RFMPresentationRoutingSetPage.DescTextbox", strDesc);
		Thread.sleep(1000);

		if (strCopyExisting.equalsIgnoreCase("YES")) {

			// Select copy from existing radio button as Yes
			actions.click("RFMPresentationRoutingSetPage.YesRadioButton");

			// Click on Select button
			actions.click("RFMPresentationRoutingSetPage.SelectButton");
			Thread.sleep(5000);
			mcd.SwitchToWindow("Manage Production Routing Set");

			// Click on View Full List
			actions.click("RFMPresentationRoutingSetSelectNodePage.ViewFullListButton");
			actions.smartWait(100);

			// Select existing Production Routing Set
			driver.findElement(By.xpath("//*[@id='userRoleData']/tr[1]/td[1]/a")).click();
			Thread.sleep(2000);
			mcd.SwitchToWindow("Add New Routing Set");

			// Click on next button
			actions.click("RFMPresentationRoutingSetPage.NextButton");
			Thread.sleep(4000);
			mcd.SwitchToWindow("@Manage Production Routing Sets");

			WebElement msg_element = driver
					.findElement(By.xpath(actions.getLocator("RFMProductionRoutingSetPage.SuccessMsg")));
			String temp_msg = msg_element.getText();
			if (temp_msg.equals(strSuccessMsg)) {
				System.out.println(strSuccessMsg + " message is displayed as expected " + "- PASS");
				System.out.println("User is able to create new Production Routing Set - '" + strName
						+ "' with copy existing option");
				actions.reportCreatePASS("Create Production Routing Set with copy existing option",
						"User should be able to create new Production Routing Set with copy existing option",
						"User is able to create new Production Routing Set - '" + strName
								+ "' with copy existing option",
						"Pass");
			} else {
				System.out.println(strSuccessMsg + " message is Not displayed" + "- FAIL");
				System.out.println("User is Not able to create new Production Routing Set with copy existing option");
				actions.reportCreateFAIL("Create Production Routing Set with copy existing option",
						"User should be able to create new Production Routing Set with copy existing option",
						"User is not able to create new Production Routing Set with copy existing option", "Fail");
			}

		} else {

			// Click on next button
			actions.click("RFMPresentationRoutingSetPage.NextButton");
			Thread.sleep(4000);
			mcd.SwitchToWindow("@Manage Production Routing Sets");

			// Click on Add Volume button
			actions.click("RFMProductionRoutingSetPage.AddVolume");
			mcd.SwitchToWindow("Router Queues");

			// Enter Volume Details
			fn_RFM_POS_Create_Volume();

			// Switch back to Update window
			mcd.SwitchToWindow("$Manage Production Routing Sets");

			// Click on Add Route button
			actions.keyboardEnter("RFMProductionRoutingSetPage.AddRoute");
			Thread.sleep(1000);

			// Enter Route Details
			fn_RFM_POS_Create_Route(strRouteID, strPMIG, strSource, strDestination);

			// Select the status value
			actions.setValue("RFMPresentationRoutingSetPage.StatusDDL", strStatus);

			// Click on save button
			actions.click("RFMProductionRoutingSetPage.Save");
			Thread.sleep(5000);

			WebElement msg_element = driver
					.findElement(By.xpath(actions.getLocator("RFMProductionRoutingSetPage.SuccessMsg")));
			String temp_msg = msg_element.getText();
			if (temp_msg.equals(strSuccessMsg)) {
				System.out.println(strSuccessMsg + " message is displayed as expected " + "- PASS");
				System.out.println("User is able to create new Production Routing Set - '" + strName
						+ "' without using copy existing option");
				actions.reportCreatePASS("Create Production Routing Set without using copy existing option",
						"User should be able to create new Production Routing Set without using copy existing option",
						"User is able to create new Production Routing Set - '" + strName
								+ "' without using copy existing option",
						"Pass");
			} else {
				System.out.println(strSuccessMsg + " message is Not displayed" + "- FAIL");
				System.out.println(
						"User is Not able to create new Production Routing Set without using copy existing option");
				actions.reportCreateFAIL("Create Production Routing Set without using copy existing option",
						"User should be able to create new Production Routing Set without using copy existing option",
						"User is not able to create new Production Routing Set without using copy existing option",
						"Fail");
			}
		}

		return strName;
	}

	// ----------------------------------
	/*
	 * Feature Name : Side Management Functionality : Create New Side on Side
	 * Management screen Scenario ID : POS_1160 Author : Ritika
	 */
	// -----------------------------------

	public String RFM_POS_CreateSideManagement(String strSide_Number, String strSide_Name, String strSide_ShortName,
			String strSide_Desc, String strSide_SideNo) throws InterruptedException {

		// Generate Unique Random number
		Random rand_num = new Random();
		String strRand_Num = Integer.toString(rand_num.nextInt(9999));

		// Enter the unique Queue number
		if (strSide_Number == "") {
			strSide_Number = strRand_Num;
		}
		actions.clear("SideManagement.NewQueueNumber");
		driver.findElement(By.xpath(actions.getLocator("SideManagement.NewQueueNumber"))).sendKeys(strSide_Number);
		// actions.setValue("RFMQueueManagementPage.NewQueueTextbox",
		// strQueue_Number);

		// Enter unique Queue Name
		if (strSide_Name == "") {
			strSide_Name = "Name_" + strRand_Num;
		}
		actions.clear("SideManagement.NewSideName");
		actions.setValue("SideManagement.NewSideName", strSide_Name);

		// Enter unique Short Name
		if (strSide_ShortName == "") {
			strSide_ShortName = "ShortName_" + strRand_Num;
		}
		actions.clear("SideManagement.NewShortName");
		actions.setValue("SideManagement.NewShortName", strSide_ShortName);

		// Enter unique Description
		if (strSide_Desc == "") {
			strSide_Desc = "Desc_" + strRand_Num;
		}
		actions.clear("SideManagement.NewDescription");
		actions.setValue("SideManagement.NewDescription", strSide_Desc);

		// Enter unique Queue Type
		if (strSide_SideNo == "") {
			strSide_SideNo = strRand_Num;
		}
		actions.clear("SideManagement.NewSideNumber");
		actions.setValue("SideManagement.NewSideNumber", strSide_SideNo);
		// actions.reportCreatePASS("Entered 'Selected Queue' displayed on 'Side
		// Management' screen","'Selected Queue' displayed should be displayed
		// on 'Side Management' screen as expected", "'Selected Queue' displayed
		// is displayed on 'Side Management' screen as expected", "Pass");
		/*
		 * Thread.sleep(5000); WebElement msg_element =
		 * driver.findElement(By.xpath(
		 * "//*[@id='sideManagementForm_infoCode']/li/span")); String temp_msg =
		 * msg_element.getText(); if(temp_msg.equals(strSuccessMsg)){
		 * //Reporter.log( strSuccessMsg + " message is displayed as expected "
		 * + "- PASS"); System.out.println(strSuccessMsg +
		 * " message is displayed as expected " + "- PASS"); }else{
		 * //Reporter.log( strSuccessMsg + " message is Not displayed" +
		 * "- FAIL"); System.out.println(strSuccessMsg +
		 * " message is Not displayed" + "- FAIL"); }
		 */
		return strSide_Number;

	}

	// Function for UI validation reporting.
	// Date created : 19-June-2016
	// Created By : Pooja Panse

	public void Report_Element_Displayed(String strElementName, String strExpectedResult, String strResult) {
		if (strResult.equalsIgnoreCase("Pass")) {
			actions.reportCreatePASS("Verify " + strElementName, strElementName + " should be " + strExpectedResult,
					strElementName + " is " + strExpectedResult, "PASS");
		} else if (strResult.equalsIgnoreCase("Fail")) {
			actions.reportCreateFAIL("Verify " + strElementName, strElementName + " should be " + strExpectedResult,
					strElementName + " is not " + strExpectedResult, "FAIL");
		}
	}

	
	
	
	// Date created : 20-Dec-2016
	// Created By : Smita Kolate

	public void uploadMediaFileThroughBatchUpload(String mediaFilePath, String zipFilePath, String expMessage) {

		try {

			mcd.smartsync(30);

			actions.setValue("POS.ManageMediaAssets.BatchUpload.UploadTextBox", mediaFilePath);

			actions.javaScriptClick("POS.ManageMediaAssets.BatchUpload.SaveButton");

			// Please upload ZIP file for English pop up should displayed

			mcd.VerifyAlertMessageDisplayed("Information", "Please upload ZIP file for English", true,
					AlertPopupButton.OK_BUTTON);

			mcd.SwitchToWindow("massMediaZipUploadPopUp");

			actions.setValue("POS.ManageMediaAssets.BatchUpload.UploadZipTextBox", zipFilePath);

			actions.javaScriptClick("POS.ManageMediaAssets.BatchUpload.SaveButton");

			// On successful completion of Batch Upload, display message
			// Media batch upload completed successfully.
			// to handle alert message
			Thread.sleep(3000);
			LinkedList<String> handle = new LinkedList<String>(driver.getWindowHandles());
			String isSuccessMsg = driver.switchTo().window(handle.get(0)).switchTo().alert().getText();

			try {
				driver.switchTo().window(handle.get(0)).switchTo().alert().accept();
			} catch (Exception e) {
			}

			if (isSuccessMsg.equalsIgnoreCase(expMessage)) {

				actions.reportCreatePASS("Verify An Success message: 'Mass Media batch upload completed successfully.'",
						"An success message: 'Mass Media batch upload completed successfully.' should be present",
						"An success message: 'Mass Media batch upload completed successfully.' is present as expected",
						"Pass");
			} else {
				actions.reportCreateFAIL("Verify An success message: 'Mass Media batch upload completed successfully.'",
						"An success message: 'Mass Media batch upload completed successfully.' should be present",
						"An success message: 'Mass Media batch upload completed successfully.' is NOT present", "Fail");
			}

		} catch (Exception e) {
		}

	}

	// Date created : 20-Dec-2016
	// Created By : Smita Kolate
	public void verifyErrorMessagesWhileuploadingMediaFileThroughBatchUpload(String mediaFilePath, String zipFilePath) {

		try {
			mcd.smartsync(40);
			actions.setValue("POS.ManageMediaAssets.BatchUpload.UploadTextBox", mediaFilePath);

			actions.javaScriptClick("POS.ManageMediaAssets.BatchUpload.SaveButton");

			// Please upload ZIP file for English pop up should displayed

			mcd.VerifyAlertMessageDisplayed("Information", "Please upload ZIP file for English", true,
					AlertPopupButton.OK_BUTTON);

			mcd.SwitchToWindow("massMediaZipUploadPopUp");

			actions.setValue("POS.ManageMediaAssets.BatchUpload.UploadZipTextBox", zipFilePath);

			actions.keyboardEnter("POS.ManageMediaAssets.BatchUpload.SaveButton");

		} catch (Exception e) {
		}
	}

	// Date created : 20-Dec-2016
	// Created By : Smita Kolate
	// edit excel file
	public void editExcelFile(String mediaFilePath, int colNum, String updatedValue) {
		try {
			FileInputStream fsIP = new FileInputStream(new File(mediaFilePath));
			// Read the spreadsheet that needs to be updated
			XSSFWorkbook wb = new XSSFWorkbook(fsIP);
			// Access the workbook
			XSSFSheet worksheet = wb.getSheetAt(0);
			// Access the worksheet, so that we can update / modify it.
			XSSFCell cell = null;
			// declare a Cell object
			cell = worksheet.getRow(1).getCell(colNum);
			// Access the second cell in second row to update the value
			cell.setCellValue(updatedValue);
			// Get current cell value value and overwrite the value
			fsIP.close();
			// Close the InputStream File
			OutputStream output_file = new FileOutputStream(new File(mediaFilePath));
			// Open FileOutputStream to write updates
			wb.write(output_file);
			// write changes
			output_file.close();
			// close the stream

		} catch (Exception e) {
		}
	}

	// Created by: Smita Kolate
	// Date:21 Dec 2016
	// Function is used in pos scripts
	public void verifyGUIElementsOnMediaTypePage() {

		rfm.GUI_ObjectDisplayedValidation("MenuItems.PresentationTab.SearchImageTextBox", "Aearch Media File TextBox");
		rfm.GUI_ObjectDisplayedValidation("ApproveRestaurant.SearchButton", "Search Button");
		rfm.GUI_ObjectDisplayedValidation("ApproveRestaurant.ViewFullListBtn", "View Full List Button");
		rfm.GUI_ObjectDisplayedValidation("POS.ManageMediaAssets.MediaFile.MediaTypeDDL", "Media Type DDL");
		rfm.GUI_ObjectDisplayedValidation("POS.ManageMediaAssets.MediaFile.LanguageDDL", "Language DDL");
		rfm.GUI_ObjectDisplayedValidation("POS.ManageMediaAssets.MediaFile.StatusDDL", "Status DDL");

		verifyGUIElementIsEnabledorDisabled("POS.ManageMediaAssets.MediaFile.MediaTypeDDL", "Media Type DDL",
				"enabled");
		verifyGUIElementIsEnabledorDisabled("POS.ManageMediaAssets.MediaFile.LanguageDDL", "Language DDL", "enabled");
		verifyGUIElementIsEnabledorDisabled("POS.ManageMediaAssets.MediaFile.StatusDDL", "Status DDL", "enabled");

		verifyByDefaultSelectedDDLValue("POS.ManageMediaAssets.MediaFile.MediaTypeDDL", "Media Type DDL", "All");
		verifyByDefaultSelectedDDLValue("POS.ManageMediaAssets.MediaFile.LanguageDDL", "Language DDL", "All");
		verifyByDefaultSelectedDDLValue("POS.ManageMediaAssets.MediaFile.StatusDDL", "Status DDL", "active/inactive");

		verifyGUIElementIsEnabledorDisabled("POS.ManageMediaAssets.MediaFile.MediaTypeFilter", "Media Type Filter",
				"disabled");
		verifyGUIElementIsEnabledorDisabled("POS.ManageMediaAssets.MediaFile.LanguageFilter", "Language Filter",
				"disabled");
		verifyGUIElementIsEnabledorDisabled("POS.ManageMediaAssets.MediaFile.StatusFilter", "Status Filter",
				"disabled");
		verifyGUIElementIsEnabledorDisabled("POS.ManageMediaAssets.MediaFile.DisplayFilter", "Status Filter",
				"disabled");

		verifyByDefaultSelectedDDLValue("POS.ManageMediaAssets.MediaFile.MediaTypeFilter", "Media Type Filter", "All");
		verifyByDefaultSelectedDDLValue("POS.ManageMediaAssets.MediaFile.LanguageFilter", "Language Filter", "All");
		verifyByDefaultSelectedDDLValue("POS.ManageMediaAssets.MediaFile.StatusFilter", "Status Filter",
				"active/inactive");
		verifyByDefaultSelectedDDLValue("POS.ManageMediaAssets.MediaFile.DisplayFilter", "Status Filter", "details");

		rfm.GUI_ObjectDisplayedValidation("POS.ManageMediaAssets.MediaFile.NewMediaFileBtn", "New Media File Button");

		verifyTablecolumnsPresent("RFM.WebTable", "Logical Name");
		verifyTablecolumnsPresent("RFM.WebTable", "Description");
		verifyTablecolumnsPresent("RFM.WebTable", "Name");
		verifyTablecolumnsPresent("RFM.WebTable", "ID");
		verifyTablecolumnsPresent("RFM.WebTable", "Media Type");
		verifyTablecolumnsPresent("RFM.WebTable", "Language");
		verifyTablecolumnsPresent("RFM.WebTable", "Status");
		verifyTablecolumnsPresent("RFM.WebTable", "Delete");

	}

	// Created by: Smita Kolate
	// Date:02 jan 2017
	// Function is used in pos scripts
	public void verifyByDefaultSelectedDDLValue(String eleLocator, String eleName, String expValue) {

		Select dropDownList = new Select(driver.findElement(By.xpath(actions.getLocator(eleLocator))));

		String defaultSelectedValue = dropDownList.getFirstSelectedOption().getText();
		if (defaultSelectedValue.equalsIgnoreCase(expValue)) {
			actions.reportCreatePASS("Verify default selected value in " + eleName + '"',
					expValue + "' should be selected by default in DDL", expValue + "' is selected by default in DDL",
					"Pass");
		} else {
			actions.reportCreateFAIL("Verify default selected value in " + eleName + '"',
					expValue + "' should be selected by default " + eleName + '"',
					expValue + "' is NOT selected by default in DDL", "Fail");
		}
	}

	// Created by: Smita Kolate
	// Date:02 Jan 2017
	// Function is used in pos scripts
	public void verifyGUIElementIsEnabledorDisabled(String eleLocator, String eleName,
			String checkForEnabledorDisabled) {

		if (checkForEnabledorDisabled.equalsIgnoreCase("enabled")) {

			boolean isEleEnabled = driver.findElement(By.xpath(actions.getLocator(eleLocator))).isEnabled();

			if (isEleEnabled) {

				actions.reportCreatePASS("Verify " + eleName + " is Enabled'", eleName + " should be Enabled",
						eleName + " is Enabled as expected", "Pass");
			} else {
				actions.reportCreateFAIL("Verify " + eleName + " is Enabled'", eleName + " should be Enabled",
						eleName + " is NOT Enabled ", "Fail");
			}
		}
		if (checkForEnabledorDisabled.equalsIgnoreCase("disabled")) {
			boolean isEleEnabled = driver.findElement(By.xpath(actions.getLocator(eleLocator))).isEnabled();

			if (!(isEleEnabled)) {

				actions.reportCreatePASS("Verify " + eleName + " is Disabled'", eleName + " should be Disabled",
						eleName + " is Disabled as expected", "Pass");
			} else {
				actions.reportCreateFAIL("Verify " + eleName + " is Disabled'", eleName + " should be Disabled",
						eleName + " is NOT Disabled ", "Fail");
			}
		}
	}

	// Created by: Smita Kolate
	// Date:2 Jan 2017
	// Function is used in pos scripts
	public void verifyTablecolumnsPresent(String tableLocator, String colName) {

		boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

		if (iscolPresent) {
			actions.reportCreatePASS("Verify " + colName + " Column is present in Media Assets Table",
					colName + " Column should be present in Media Assets Table",
					colName + " Column is present in Media Assets Table", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + colName + " Column is present in Media Assets Table",
					colName + " Column should be present in Media Assets Table",
					colName + " Column is NOT present in Media Assets Table", "Fail");
		}
	}

}