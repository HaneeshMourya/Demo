/*
 * Copyright 2012 iGATE GROUP OF COMPANIES. All rights reserved
 * (Subject to Limited Distribution and Restricted Disclosure Only.)
 * THIS SOURCE FILE MAY CONTAIN INFORMATION WHICH IS THE PROPRIETARY
 * information of IGATE GROUP OF COMPANIES AND IS INTENDED FOR USE
 * ONLY BY THE ENTITY WHO IS ENTITLED TO AND MAY CONTAIN
 * INFORMATION THAT IS PRIVILEGED, CONFIDENTIAL, OR EXEMPT FROM
 * DISCLOSURE UNDER APPLICABLE LAW.
 * YOUR ACCESS TO THIS SOURCE FILE IS GOVERNED BY THE TERMS AND
 * CONDITIONS OF AN AGREEMENT BETWEEN YOU AND IGATE GROUP OF COMPANIES.
 * The USE, DISCLOSURE REPRODUCTION OR TRANSFER OF THIS PROGRAM IS
 * RESTRICTED AS SET FORTH THEREIN
 */

package crossbrowser.library;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Driver;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.io.FileUtils;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHttpEntityEnclosingRequest;
import org.json.simple.JSONObject;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.HasInputDevices;
import org.openqa.selenium.interactions.Mouse;
import org.openqa.selenium.internal.Locatable;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.SessionId;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.Assertion;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import crossbrowser.harness.Serializer;
import crossbrowser.helper.DateFormatter;
import crossbrowser.helper.JsonFormatter;
import crossbrowser.helper.PropertyReader;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.helper.Helper;
import crossbrowser.logger.FrameworkLogger;
import crossbrowser.logger.FrameworkLogger.LEVEL;
import crossbrowser.logger.TestReportLogger;
import crossbrowser.utils.FileUtil;
import crossbrowser.utils.JsonReader;
import io.netty.util.internal.chmv8.ConcurrentHashMapV8.Action;

public class Keywords extends Helper {

	String pastUrl = null;

	List<Map<?, ?>> uiMap = new ArrayList<Map<?, ?>>();
	private List<String> foundUrls = new ArrayList<String>();
	private List<String> visitedUrls = new ArrayList<String>();
	private WebDriver webDriver;
	private Assertion assertTest = new Assertion();
	private List<Boolean> flags;
	UIValidations validations = new UIValidations();
	private String screenShotLevel = "FAIL";
	private HashMap<String, String> gblTestData; // Global test-data values from
	// 'GlobalConfigurations.txt'
	// file

	public Keywords(WebDriver webDriver, Object uiMapFile) {
		this.webDriver = webDriver;
		flags = new ArrayList<Boolean>();
		screenShotLevel = PropertyReader.getProperty("Screenshot", "FAIL");
		if (uiMapFile != null) {
			try {

				Serializer tcSerializer = new Serializer();
				this.uiMap = tcSerializer.readObjectRepository(uiMapFile.toString());

			} catch (Exception e) {
				FrameworkLogger.log("Error in initializing Object Repository. Exception: " + e.getMessage(),
						LEVEL.debug, this.getClass());
				FrameworkLogger.log("Error in initializing Object Repository. Please check the Object Repository file.",
						LEVEL.fatal, this.getClass());
			}
		} else {
			FrameworkLogger.log("Error in initializing Object Repository. Please check the Object Repository file.",
					LEVEL.fatal, this.getClass());
		}
		// Read global Test-Data
		gblTestData = new HashMap<String, String>();
		File gblFile = new File("crossbrowser.properties");
		if (gblFile.exists() && !gblFile.isDirectory()) {
			// try {
			//// Scanner gblFileScnr = new Scanner(gblFile);
			//// while (gblFileScnr.hasNext()) {
			//// String strGblTDLine = gblFileScnr.nextLine();
			//// if (! strGblTDLine.trim().startsWith("'")) {
			//// String strTDName = strGblTDLine.substring(0,
			// strGblTDLine.indexOf(":")).trim().toUpperCase();
			//// String strTDValue =
			// strGblTDLine.substring(strGblTDLine.indexOf(":") +1).trim();
			////
			//// gblTestData.put(strTDName, strTDValue);
			//// }
			//// }
			//// gblFileScnr.close();
			////
			gblTestData = PropertyReader.getAllProperty();
			// } catch (FileNotFoundException e) {
			// System.out.println("Error reading global test-data file
			// 'assets/TestData/GlobalConfigurations.txt'");
			// e.printStackTrace();
			// }
		} else {
			System.out.println("Global test-data file ('assets/TestData/GlobalConfigurations.txt') is missng");
		}
		System.out.println("Global Test-Data : " + gblTestData);

	}

	/**
	 * @Function Retrieves the UI Map of the specified UI element
	 * @param UI
	 *            Element
	 * @return UI Map of the specified UI element
	 */
	public Map<?, ?> getElementMap(String sElementName) {
		Map<?, ?> locatorMap = null;
		if (this.uiMap == null) {
			Exception e = new Exception();
			try {
				throw e;
			} catch (Exception e1) {
				FrameworkLogger.log("Error while finding the Element. Exception: " + e.getMessage(), LEVEL.debug,
						this.getClass());
				FrameworkLogger.log("Error while finding the Element.", LEVEL.error, this.getClass());

			}
		} else {
			try {
				for (Map<?, ?> map : this.uiMap) {
					String sTemp = (String) map.get("elementName");
					if (sElementName.matches(sTemp)) {
						locatorMap = map;
						break;
					}
				}
				if (locatorMap == null) {
					fail("Get element locator '" + sElementName + "'", "Get element locator '" + sElementName + "'",
							"Error : Element " + sElementName + "not found in Object Repository");

				}
			} catch (Exception e) {
				FrameworkLogger.log("Error : Caused while trying to retrieve the map for Unknown Element '"
						+ sElementName + "'. Exception: " + e.getMessage(), LEVEL.debug, this.getClass());
				FrameworkLogger.log(
						"Error : Caused while trying to retrieve the map for Unknown Element '" + sElementName + "'.",
						LEVEL.error, this.getClass());
			}
		}
		return locatorMap;
	}

	/**
	 * @Function Returns the Locator for the given ElementName
	 * @param sElementName
	 * @return Locator String
	 */
	public String getLocator(String sElementName) {
		String reportEleName = formatElementName(sElementName);
		Map<?, ?> result = null;
		String sLocator = "";
		try {
			for (Map<?, ?> map : this.uiMap) {
				String temp = (String) map.get("elementName");
				if (sElementName.matches(temp) || sElementName.equalsIgnoreCase(temp)) {
					result = map;
					break;
				}
			}
			if (result != null){
			sLocator = (String) result.get("locator");
			}else {
				
				fail("Click on Element'" + reportEleName + "'", "Should click the Element '" + reportEleName + "'",
						"Element '" + reportEleName + "' not found in Object Repository");
				
			}

		} catch (RuntimeException e) {
			fail("Retrive element'" + reportEleName + "'", "Should Retrive element '" + reportEleName + "' from  OR",
					"Error: Exception occured while retriving the element '" + reportEleName + "' from OR");
			/*fail("Get Locator of '" + reportEleName + "'", "Element '" + reportEleName + "'",
					"Error: Trying to retrieve the Locator of Unknown Element \" " + reportEleName + " \"");*/
		}
		return sLocator;
	}

	public String getLocator(String sElementName, String strMsg) {
		String reportEleName = formatElementName(sElementName);
		Map<?, ?> result = null;
		String sLocator = "";
		try {
			for (Map<?, ?> map : this.uiMap) {
				String temp = (String) map.get("elementName");
				if (sElementName.matches(temp) || sElementName.equalsIgnoreCase(temp)) {
					result = map;
					break;
				}
			}
			if (result != null){
					
				sLocator = (String) result.get("locator");
			}else {
				strMsg = "Tiemout Error: Unknown Element '" + reportEleName + "'.";				
				return strMsg;
				
				/*fail("Click on Element'" + reportEleName + "'", "Should click the Element '" + reportEleName + "'",
						"Element '" + reportEleName + "' not found in Object Repository");*/
				/*fail("Get Locator of '" + reportEleName + "'", "Element '" + reportEleName + "'",
						"TiemOut Error: Unknown Element '" + reportEleName + "'.");*/
			}

		} catch (RuntimeException e) {
			
			fail("Retrive element'" + reportEleName + "'", "Should Retrive element '" + reportEleName + "' from  OR",
					"Error: Exception occured while retriving the element '" + reportEleName + "' from OR");
			/*fail("Get Locator of '" + reportEleName + "'", "Element '" + reportEleName + "'",
					"Error: Trying to retrieve the Locator of Unknown Element \" " + reportEleName + " \"");*/
		}
		return sLocator;
	}
	
	
	public WebElement getWebElement(String sElement) {
		return getwebDriverLocator(getLocator(sElement));
	}

	private String formatElementName(String sElement) {
		String formatedEleName = "";
		if (PropertyReader.getProperty("ReportElementName", "PG.EL").equals("EL")) {
			if (sElement.contains(".")) {
				formatedEleName = sElement.replaceAll("^[^.]*.", "");
			} else {
				formatedEleName = sElement;
			}
		} else if (PropertyReader.getProperty("ReportElementName", "PG.EL").equals("PG.EL")) {
			formatedEleName = sElement;
		}
		return formatedEleName;
	}

	// public void fail(String step, String expected, String actual) {
	// failstep();
	// Date date = new Date();
	// String screenShotPath="";
	// if(!screenShotLevel.equals("NONE")){
	// screenShotPath=takeTestStepScreenShot();
	// }
	// String testStepJson=JsonFormatter.format(date, step, expected, actual,
	// "Fail", screenShotPath);
	// TestReportLogger.log(testStepJson);
	// FrameworkLogger.log("Test step JSON: "+testStepJson, LEVEL.debug,
	// this.getClass());
	// FrameworkLogger.log("Test Failed: {Expected : '"+ expected + "', Actual :
	// '" + actual + "'}", LEVEL.error, this.getClass());
	// }

	public void fail(String step, String expected, String actual, boolean flag) {
		failstep();
		Date date = new Date();
		String screenShotPath = "";
		String testStepJson = JsonFormatter.format(date, step, expected, actual, "Fail", screenShotPath);
		TestReportLogger.log(testStepJson);
		FrameworkLogger.log("Test step JSON: " + testStepJson, LEVEL.debug, this.getClass());
		FrameworkLogger.log("Test Failed: {Expected : '" + expected + "', Actual : '" + actual + "'}", LEVEL.error,
				this.getClass());
	}

	// public void pass(String step, String expected, String actual) {
	// Date date = new Date();
	// String screenShotPath="";
	// if(!screenShotLevel.equals("FAIL") && !screenShotLevel.equals("NONE")){
	// screenShotPath=takeTestStepScreenShot();
	// }
	// String testStepJson=JsonFormatter.format(date, step, expected, actual,
	// "Pass", screenShotPath);
	// TestReportLogger.log(testStepJson);
	// FrameworkLogger.log("Test step JSON: "+testStepJson, LEVEL.debug,
	// this.getClass());
	// }
	public void pass(String step, String expected, String actual, boolean flag) {
		Date date = new Date();
		String screenShotPath = "";
		String testStepJson = JsonFormatter.format(date, step, expected, actual, "Pass", screenShotPath);
		TestReportLogger.log(testStepJson);
		FrameworkLogger.log("Test step JSON: " + testStepJson, LEVEL.debug, this.getClass());
	}

	// public void launchApplication(Object url) {
	// String strStep = "Launch Application";
	// String strExpected = "Applcation should launch URL: '"
	// + url + "' successfully.";
	// try {
	// if ((!((RemoteWebDriver) webDriver).getCapabilities().getPlatform()
	// .toString().equalsIgnoreCase("ANDROID"))) {
	// webDriver.manage().window().maximize();
	// }
	// webDriver.get(url.toString());
	//
	// Capabilities cap = ((RemoteWebDriver) webDriver).getCapabilities();
	// String
	// osBrowserInfoStr=JsonFormatter.format(cap.getPlatform().toString(),
	// cap.getBrowserName().toString(), cap.getVersion().toString());
	// TestReportLogger.log(osBrowserInfoStr);
	// pass(strStep, strExpected,
	// "application launched successfully");
	// } catch (Exception e) {
	// FrameworkLogger.log("Error while launching the application. Exception:
	// "+e.getMessage(), LEVEL.debug, this.getClass());
	// fail(strStep, strExpected,
	// "Failed to launch application");
	// }
	// }

	
	public String takeTestStepScreenShot() {
		Date date = new Date();
		String dateStr = DateFormatter.formatDate(date, "ddMMMyyyy-HHmmssS-z");
		String fileName = "StepScreenshot" + dateStr + ".png";
		String filePath = "./test-output/stepScreenShots/" + fileName;
		File screenShotFile = null;
		try {
			// boolean popup = isAlertPresent(2);
			Alert alert = webDriver.switchTo().alert();
			if (alert.getText().isEmpty()) {
				screenShotFile = screenShot(webDriver);
			}
		} catch (Exception e) {
			screenShotFile = screenShot(webDriver);
		}
		// File screenShotFile=screenShot(webDriver);
		if (!crossbrowser.utils.FileUtil.folderExists("./test-output")) {
			crossbrowser.utils.FileUtil.makeFolder("./test-output/stepScreenShots/");
		}
		File destFile = new File(filePath);
		try {
			if (screenShotFile != null) {
				FileUtils.copyFile(screenShotFile, destFile);
			}
		} catch (IOException e) {
			FrameworkLogger.log(
					"Error while coping screenshot file in 'stepScreenShots' folder. Exception: " + e.getMessage(),
					LEVEL.debug, this.getClass());
		}
		return filePath;
	}

	public void pass(String step, String expected, String actual) {
		Date date = new Date();
		String screenShotPath = "";
		if (!screenShotLevel.equals("FAIL") && !screenShotLevel.equals("NONE")) {
			try {
				Alert alert = webDriver.switchTo().alert();
				if (alert.getText().isEmpty()) {
					screenShotPath = takeTestStepScreenShot();
				}
			} catch (Exception e) {
				screenShotPath = takeTestStepScreenShot();
			}
		}
		String testStepJson = JsonFormatter.format(date, step, expected, actual, "Pass", screenShotPath);
		TestReportLogger.log(testStepJson);
		FrameworkLogger.log("Test step JSON: " + testStepJson, LEVEL.debug, this.getClass());
	}

	public void fail(String step, String expected, String actual) {
		failstep();
		Date date = new Date();
		String screenShotPath = "";
		if (!screenShotLevel.equals("NONE")) {
			try {
				Alert alert = webDriver.switchTo().alert();
				if (alert.getText().isEmpty()) {
					screenShotPath = takeTestStepScreenShot();
				}
			} catch (Exception e) {
				screenShotPath = takeTestStepScreenShot();
			}
			// screenShotPath=takeTestStepScreenShot();
		}
		String testStepJson = JsonFormatter.format(date, step, expected, actual, "Fail", screenShotPath);
		TestReportLogger.log(testStepJson);
		FrameworkLogger.log("Test step JSON: " + testStepJson, LEVEL.debug, this.getClass());
		FrameworkLogger.log("Test Failed: {Expected : '" + expected + "', Actual : '" + actual + "'}", LEVEL.error,
				this.getClass());
	}

	// public String takeTestStepScreenShot(){
	// Date date=new Date();
	// String dateStr=DateFormatter.formatDate(date, "ddMMMyyyy-HHmmssS-z");
	// String fileName="StepScreenshot"+dateStr+".png";
	// String filePath="./test-output/stepScreenShots/"+fileName;
	// File screenShotFile=screenShot(webDriver);
	// if (!crossbrowser.utils.FileUtil
	// .folderExists("./test-output")) {
	// crossbrowser.utils.FileUtil
	// .makeFolder("./test-output/stepScreenShots/");
	// }
	// File destFile=new File(filePath);
	// try {
	// FileUtils.copyFile(screenShotFile, destFile);
	// } catch (IOException e) {
	// FrameworkLogger.log("Error while coping screenshot file in
	// 'stepScreenShots' folder. Exception: "+e.getMessage(), LEVEL.debug,
	// this.getClass());
	// }
	// return filePath;
	// }

	public void failstep() {
		this.flags.add(false);
	}

	public void assertTestCase() {
		assertTest.assertTrue(false);
	}

	public void verifyTestCase(Class<?> clazz) {
		String testcaseName = clazz.getName().replace("xtam.test.", "");
		if (this.flags.contains(false)) {
			assertTestCase();
			FrameworkLogger.log("Test case '" + testcaseName + "' Failed", LEVEL.error, this.getClass());
		} else {
			FrameworkLogger.log("Test case '" + testcaseName + "' Passed", LEVEL.info, this.getClass());
		}
	}

	public void setTestcaseDescription(String description) {
		String jsonStr = JsonFormatter.format("description", description);
		TestReportLogger.log(jsonStr);
	}

	public void acceptAlert() {
		webDriver.switchTo().alert().accept();
	}

	// public void catchException(Exception exception) {
	// String errorMsg = exception.getMessage();
	// fail("Test Step", "Test Step to Pass",errorMsg.split("\\r?\\n")[0]);
	// FrameworkLogger.log(exception.getMessage(), LEVEL.debug,
	// this.getClass());
	// }

	public void catchException(Exception exception) {
		try {
			String errorMsg = exception.getMessage();
			fail("Exception", "Exception Occurred", errorMsg.split("\\r?\\n")[0]);
			FrameworkLogger.log(exception.getMessage(), LEVEL.debug, this.getClass());
		} catch (Exception e) {
			fail("Exception", "Exception Occurred", "Null Pointer Exception", true);
			FrameworkLogger.log("Null Pointer Exception", LEVEL.debug, this.getClass());
		}
	}

	/**
	 * @Function Checks the presence of element up-to specified Time
	 * @param Name
	 *            of the element
	 * @param Time
	 * @return Boolean Result
	 */
	public boolean checkElement(String sActualLocator, int timeInSec) {
		WebElement webElement = getwebDriverLocator(sActualLocator);
		String temp = gblTestData.get("StepTimeOut");
		timeInSec = Integer.parseInt(temp);
		boolean result = false;
		try {
			for (int second = 0;; second++) {
				if (second >= timeInSec * 2) {
					fail("Check Element (Actual Locator: \" " + sActualLocator + " \")", "Element should be prsent",
							"TimeOut waiting for Element (Actual Locator: \" " + sActualLocator + " \") " + (second / 2)
									+ " Seconds ");
					break;
				}
				try {
					if (webElement.isDisplayed()) {
						result = true;

						break;
					}
				} catch (Exception e) {
					FrameworkLogger.log("Error : Caused while trying to check presence of Element '" + sActualLocator
							+ "'. Exception: " + e.getMessage(), LEVEL.debug, this.getClass());
					FrameworkLogger.log(
							"Error : Caused while trying to check presence of Element '" + sActualLocator + "'.",
							LEVEL.fatal, this.getClass());

				}
			}
		} catch (Exception e) {
			fail("Check Element (Actual Locator: \" " + sActualLocator + " \")", "Element should be prsent",
					"Error: Caused while Verifying the Presence of Element (Actual Locator: \" " + sActualLocator
							+ " \")");

		}

		return result;
	}

	public void clear(String sElement) {
		String reportEleName = formatElementName(sElement);
		try {
			if (getwebDriverLocator(getLocator(sElement)) != null) {
				getwebDriverLocator(getLocator(sElement)).clear();
				pass("Clear TextBox '" + reportEleName + "'", "Will clear textbox '" + reportEleName + "'",
						"Cleared textbox '" + reportEleName + "'");
			}
		} catch (Exception e2) {
			fail("clear TextBox '" + reportEleName + "'", "Will clear textbox '" + reportEleName + "'",
					"Not able to clear textbox '" + reportEleName + "'");
			FrameworkLogger.log("Error while clearing element: '" + sElement + "'. Exception: " + e2.getMessage(),
					LEVEL.debug, this.getClass());

		}
	}

	/**
	 * @Function clicks the specified element,using web-webDriver object
	 * @param Element
	 */
	public void click(final String sElement) {
 		String strResult = "";
		String reportEleName = formatElementName(sElement);
		try {
			strResult = WaitForElementPresent(sElement);
			if (strResult.equals("")) {
				if (getwebDriverLocator(getLocator(sElement)) != null) {
					if(isSafari()) { 
                        JavascriptExecutor executor = (JavascriptExecutor) webDriver; 
                        executor.executeScript("var elem=arguments[0]; setTimeout(function() {elem.click();}, 100)", getwebDriverLocator(getLocator(sElement)));
	                }else{ 
	                	getwebDriverLocator(getLocator(sElement)).click(); 
	                }
					pass("Click on '" + reportEleName + "'", "Should click the element '" + reportEleName + "'",
							"Clicked on  element '" + reportEleName + "'");
				} else {
					fail("Click on '" + reportEleName + "'", "Should click the element '" + reportEleName + "'",
							"Element '" + reportEleName + "' not found");
				}
			} else {
				fail("Click on element'" + sElement + "'",
						"Should click the element '" + sElement + "'", strResult);
			}
		} catch (Exception e2) {
			fail("Click on element'" + sElement + "'",
					"Should click the element '" + sElement + "'",
					"Error while clicking on element '" + sElement + "'");
			FrameworkLogger.log("Error while clicking on Button '" + sElement + "'. Exception: "+e2.getMessage(),LEVEL.debug, this.getClass());
		}
	}

	/**
	 * @Function clicks the specified element
	 * @param Element
	 */
	public void click(WebElement sElement) {
		String reportEleName = sElement.getText();
		try {

			if (isSafari()) {
				JavascriptExecutor executor = (JavascriptExecutor) webDriver;
				executor.executeScript("var elem=arguments[0]; setTimeout(function() {elem.click();}, 100)", sElement);
			} else {
				sElement.click();
			}
			pass("Click on '" + reportEleName + "'", "Should click the button '" + reportEleName + "'",
					"Clicked on  button '" + reportEleName + "'");
		} catch (Exception e2) {
			fail("Click on '" + sElement + "'", "Should click the button '" + sElement + "'",
					"Error while clicking on Button '" + sElement + "'");
			FrameworkLogger.log("Error while clicking on Button '" + sElement + "'. Exception: " + e2.getMessage(),
					LEVEL.debug, this.getClass());
		}
	}

	public void dismissAlert() {
		webDriver.switchTo().alert().dismiss();
	}

	public void drawHighlight(String ele, WebDriver driver) throws InterruptedException {

		WebElement element = getwebDriverLocator(getLocator(ele));
		if (((RemoteWebDriver) driver).getCapabilities().getBrowserName().equalsIgnoreCase("chrome")
				|| ((RemoteWebDriver) driver).getCapabilities().getBrowserName().equalsIgnoreCase("firefox")) {
			for (int i = 0; i < 2; i++) {
				JavascriptExecutor js = (JavascriptExecutor) webDriver;
				js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element,
						"color: red; border: 5px solid red;");
				Thread.sleep(500);
				js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "");
			}
		}

		if (((RemoteWebDriver) driver).getCapabilities().getBrowserName().equalsIgnoreCase("ie")) {
			JavascriptExecutor js = ((JavascriptExecutor) driver);
			for (int i = 0; i < 2; i++) {
				js.executeScript("arguments[0].style.border='4px solid red'", element);
				Thread.sleep(500);
				js.executeScript("arguments[0].style.border='none'", element);
			}
		}
	}

	public void executeJavaScript(String javaScript) {
		try {
			JavascriptExecutor js = ((JavascriptExecutor) webDriver);
			js.executeScript(javaScript);
		} catch (Exception e2) {
			fail("Execute JavaScript", "Will execute javascript", "Not able to execute javascript");
			FrameworkLogger.log("Not able to execute javascript. Exception: " + e2.getMessage(), LEVEL.debug,
					this.getClass());
		}
	}

	public String getFileData(Object filePath) {
		FileUtil fileUtil = new FileUtil();
		return fileUtil.getFileData(filePath.toString());
	}

	public String getPageTitle() {
		return webDriver.getTitle();
	}

	public List<String> getUrls(String baseUrl, String extURLStr) {
		List<String> links = new ArrayList<String>();
		List<WebElement> list = webDriver.findElements(By.cssSelector("a"));
		for (int i = 0; i < list.size(); i++) {
			String href = list.get(i).getAttribute("href");
			if (href == null) {

			} else {
				boolean urlCheck = urlValidate(baseUrl, extURLStr, href);
				if (urlCheck == true) {
					links.add(href);
				}
			}
		}
		return links;
	}

	/**
	 * @Function gets the value to the specified UI Element
	 * @param ElementName
	 *            of which value has to be found
	 * @return value
	 * 
	 */
	public String getValue(String sElementName) {
		Map<?, ?> result = null;
		try {
			result = getElementMap(sElementName);
			if (result != null) {
				String sLocator = (String) result.get("locator");
				String sType = (String) result.get("type");
				if (sType.equalsIgnoreCase("textBox") || sType.equalsIgnoreCase("textArea")
						|| sType.equalsIgnoreCase("link")) {
					try {
						if (checkElement(sLocator, 10)) {
							return getwebDriverLocator(sLocator).getText();
						}
					} catch (Exception e) {
						FrameworkLogger.log("Error while finding the Element. Exception: " + e.getMessage(),
								LEVEL.debug, this.getClass());
						FrameworkLogger.log("Error while finding the Element.", LEVEL.error, this.getClass());
					}

				} else if (sType.equalsIgnoreCase("dropDown")) {
					try {
						if (checkElement(sLocator, 10)) {
							Select selectOption = new Select(getwebDriverLocator(sLocator));
							return selectOption.getFirstSelectedOption().getText();
						}
					} catch (Exception e) {
						FrameworkLogger.log("Error while finding the Element. Exception: " + e.getMessage(),
								LEVEL.debug, this.getClass());
						FrameworkLogger.log("Error while finding the Element.", LEVEL.error, this.getClass());

					}

				} else if (sType.equalsIgnoreCase("radioButton")) {
					if (checkElement(sLocator, 10)) {

						return Boolean.toString(getwebDriverLocator(sLocator).isSelected());

					}
				} else if (sType.equalsIgnoreCase("checkBox")) {
					if (checkElement(sLocator, 10)) {
						return Boolean.toString(getwebDriverLocator(sLocator).isSelected());
					}
				}
			}
		} catch (NullPointerException e) {
			FrameworkLogger.log("Error while finding the Element. Exception: " + e.getMessage(), LEVEL.debug,
					this.getClass());
			FrameworkLogger.log("Error while finding the Element.", LEVEL.error, this.getClass());

		} catch (Exception e) {
			FrameworkLogger.log("Error while finding the Element. Exception: " + e.getMessage(), LEVEL.debug,
					this.getClass());
			FrameworkLogger.log("Error while finding the Element.", LEVEL.error, this.getClass());

		}
		return null;
	}

	/**
	 * @Function gets the WebElement
	 * @param actualLocator
	 *            Locator string
	 * @return WebElement
	 * 
	 */
	public WebElement getwebDriverLocator(String actualLocator) {
		WebElement element = null;
		try {
			if (actualLocator.startsWith("//")) {
			
				element = webDriver.findElement(By.xpath(actualLocator));
				
			} else {
				try {
					element = webDriver.findElement(By.id(actualLocator));
				} catch (Exception e) {
					try {
						element = webDriver.findElement(By.name(actualLocator));
					} catch (Exception e1) {
						try {
							element = webDriver.findElement(By.className(actualLocator));
						} catch (Exception e2) {
							try {
								element = webDriver.findElement(By.cssSelector(actualLocator));
							} catch (Exception e3) {
								try {
									element = webDriver.findElement(By.linkText(actualLocator));
								} catch (Exception e4) {
									try {
										element = webDriver.findElement(By.partialLinkText(actualLocator));
									} catch (Exception e5) {
										FrameworkLogger.log(
												"Error while finding the Element. Exception: " + e5.getMessage(),
												LEVEL.debug, this.getClass());
										FrameworkLogger.log("Error while finding the Element.", LEVEL.error,
												this.getClass());
									}
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			FrameworkLogger.log("Error while finding the Element. Exception: " + e.getMessage(), LEVEL.debug,
					this.getClass());
			FrameworkLogger.log("Error while finding the Element.", LEVEL.error, this.getClass());

		}
		return element;
	}

	public String hostFind(String url) {
		String host = null;
		try {
			if (!url.startsWith("http://")) {
				url = "http://" + url;
			}
			URL urlWith = new URL(url);
			String fullHost = urlWith.getHost();
			host = fullHost.substring(4);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		return host;
	}

	public boolean isAlertPresent(int timeoutInSeconds) {
		WebDriverWait wait = new WebDriverWait(webDriver,
				timeoutInSeconds /*
									 * timeout in seconds
									 */);
		try {
			if (wait.until(ExpectedConditions.alertIsPresent()) == null) {
				fail("Check alert presence", "Alert should be present", "Alert is not present");
				return false;
			} else {
				return true;
			}
		} catch (Exception e) {
			fail("Check alert presence", "Alert should be present", "Alert is not present");
			FrameworkLogger.log("Error while checking for alert. Exception: " + e.getMessage(), LEVEL.debug,
					this.getClass());
			return false;
		}
	}

	public boolean isTextPresence(Object text, boolean continueExecution) {
		boolean blnflag = false;
		String pageText = webDriver.getPageSource();
		if (pageText.contains(text.toString())) {
			blnflag = true;
			pass("Verify Text Presence '" + text + "'", text.toString(), "Page contains '" + text.toString() + "'");

		} else {
			blnflag = false;
			fail("Verify Text Presence '" + text + "'", text.toString(),
					"Page does not contains '" + text.toString() + "'");
			if (!continueExecution) {
				quitBrowser();
				assertTestCase();
			}
		}
		return blnflag;
	}

	
	public void javaScriptClick(String sElement, LocatorType type) {
		String reportEleName = formatElementName(sElement);
		try {
			if (getLocator(sElement) != null) {
				String locator = getLocator(sElement);
				webDriver.navigate()
						.to("javascript:document.getElementBy" + type.toString() + "('" + locator + "').click()");
				pass("Click on '" + reportEleName + "'", "Should click the button '" + reportEleName + "'",
						"Clicked on  button '" + reportEleName + "'");
			} else {
				fail("Click on '" + reportEleName + "'", "Should click the button '" + reportEleName + "'",
						"Button '" + reportEleName + "' not found in OR");
			}
		} catch (Exception e2) {
			fail("Click on '" + sElement + "'", "Should click the button '" + sElement + "'",
					"Error while clicking on Button '" + sElement + "'");
			FrameworkLogger.log("Error while clicking on Button '" + reportEleName + "'. Exception: " + e2.getMessage(),
					LEVEL.debug, this.getClass());
		}
	}

	public enum LocatorType {
		Id("Id"), ClassName("ClassName"), Name("Name"), TagName("TagName"), TagNameNS("TagNameNS");

		private final String name;

		private LocatorType(String s) {
			name = s;
		}

		public boolean equalsName(String otherName) {
			return (otherName == null) ? false : name.equals(otherName);
		}

		public String toString() {
			return this.name;
		}
	}

	public void javaScriptClick(WebElement elementToClick) {
		try {
			JavascriptExecutor executor = (JavascriptExecutor) webDriver;
			if (isSafari() || isMicrosoftEdge()) {
				executor.executeScript("var elem=arguments[0]; setTimeout(function() {elem.click();}, 100)",
						elementToClick);
			} else {
				executor.executeScript("arguments[0].click();", elementToClick);
			}
		} catch (Exception e2) {
			fail("Click on (Actual locator: '" + elementToClick + "')",
					"Should click the button (Actual locator: '" + elementToClick + "')",
					"Error while clicking on Button (Actual locator: '" + elementToClick + "')");
			FrameworkLogger.log(
					"Error while clicking on Button '" + elementToClick + "'. Exception: " + e2.getMessage(),
					LEVEL.debug, this.getClass());
		}
	}

	public void keyboardEnter(String sElement) {
		String reportEleName = formatElementName(sElement);
		try {
			WaitForElementPresent(sElement);
			if (getwebDriverLocator(getLocator(sElement)) != null) {
				if (isSafari()) {
					JavascriptExecutor executor = (JavascriptExecutor) webDriver;
					executor.executeScript("var elem=arguments[0]; setTimeout(function() {elem.click();}, 100)",
							getwebDriverLocator(getLocator(sElement)));
				} else {
					getwebDriverLocator(getLocator(sElement)).sendKeys(Keys.ENTER);
				}
				pass("Click on '" + reportEleName + "'", "Should click the button '" + reportEleName + "'",
						"Clicked on button '" + reportEleName + "'");
			} else {
				fail("Click on '" + reportEleName + "'", "Should click the button '" + reportEleName + "'",
						"Button '" + reportEleName + "' not found");
			}
		} catch (Exception e2) {
			fail("Click on '" + reportEleName + "'", "Should click the button '" + reportEleName + "'",
					"Error while clicking on Button '" + reportEleName + "'");
			FrameworkLogger.log("Error while clicking on Button '" + sElement + "'. Exception: " + e2.getMessage(),
					LEVEL.debug, this.getClass());

		}
	}

	public void keyboardEnter(WebElement eleElement) {
		String strElementText = "";
		try {
			if (eleElement != null) {

				if (isSafari()) {
					JavascriptExecutor executor = (JavascriptExecutor) webDriver;
					executor.executeScript("var elem=arguments[0]; setTimeout(function() {elem.click();}, 100)",
							eleElement);
				} else {
					eleElement.sendKeys(Keys.ENTER);
				}

				strElementText = eleElement.getText();
				pass("Click on '" + strElementText + "'", "Should click the button '" + strElementText + "'",
						"Clicked on button '" + strElementText + "'");
			} else {
				fail("Click on '" + strElementText + "'", "Should click the button '" + strElementText + "'",
						"Button '" + strElementText + "' not found");
			}
		} catch (Exception e2) {
			fail("Click on '" + strElementText + "'", "Should click the button '" + strElementText + "'",
					"Error while clicking on Button '" + strElementText + "'");
			FrameworkLogger.log(
					"Error while clicking on Button '" + strElementText + "'. Exception: " + e2.getMessage(),
					LEVEL.debug, this.getClass());
		}
	}

	/*
	 * public String readExcelData(String testDataFile, String testCaseName,
	 * String rowId, String columnName) { Serializer serializer = new
	 * Serializer(); try { List<Map> dataMap =
	 * serializer.readSheetData(testCaseName, testDataFile); Map dataRow =
	 * serializer.getRowDataMap(dataMap, rowId); String data = (String)
	 * dataRow.get(columnName); return data;
	 * 
	 * } catch (BiffException e) { reportCreateFAIL("Read excel data from '" +
	 * testDataFile + ">" + testCaseName + ">" + rowId + "'",
	 * "Should read data form '" + testDataFile + ">" + testCaseName + ">" +
	 * rowId + "'", "Failed to read data", "Fail"); return null; //
	 * e.printStackTrace(); } catch (IOException e) { reportCreateFAIL(
	 * "Read excel data from '" + testDataFile + ">" + testCaseName + ">" +
	 * rowId + "'", "Should read data form '" + testDataFile + ">" +
	 * testCaseName + ">" + rowId + "'", "Failed to read data", "Fail"); return
	 * null; // e.printStackTrace(); }
	 * 
	 * }
	 * 
	 */

	public void monkeyTest(Object Url, Object extURL, Class<?> clsName) throws InterruptedException, IOException {

		String extURLStr = extURL.toString();
		String url = Url.toString();
		String baseUrl = url;
		this.foundUrls.add(url);
		// int num = 0;

		while (this.foundUrls.size() > 0) {

			String currentUrl;
			if (this.visitedUrls.isEmpty()) {
				currentUrl = url;
				this.visitedUrls.add(url);
			} else {
				currentUrl = this.nextUrl();
			}

			if (currentUrl == "URL FINISHED") {
				break;
			} else {
				launchApplication(currentUrl);
				validations.takeScreenShot(webDriver, webDriver.getTitle(), this.getClass());
				// num++;
				Thread.sleep(1000);
				this.foundUrls.addAll(getUrls(baseUrl, extURLStr));
			}
		}
		webDriver.quit();
	}

	public String nextUrl() {
		String nextUrl;
		do {
			if (this.foundUrls.size() > 0) {
				nextUrl = this.foundUrls.remove(0);
			} else {
				nextUrl = "URL FINISHED";
			}
		} while (this.visitedUrls.contains(nextUrl));
		this.visitedUrls.add(nextUrl);
		return nextUrl;
	}

	public boolean urlValidate(String baseUrl, String extURLStr, String href) {
		String host = hostFind(baseUrl);
		String exUrl = ".*(" + extURLStr + ").*";
		String base = ".*(" + host + ").*";
		if (Pattern.matches(exUrl, href)) {
			return false;
		} else {
			if (href.startsWith("http://") || href.startsWith("https://")) {
				if (Pattern.matches(base, href)) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		}
	}

	/**
	 * @Function
	 * @param
	 */
	public void mouseOver(String sElementName) {
		try {
			WebElement link = getwebDriverLocator(getLocator(sElementName));
			Locatable hoverItem = (Locatable) link;
			Mouse mouse = ((HasInputDevices) webDriver).getMouse();
			mouse.mouseMove(hoverItem.getCoordinates());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void mouseOver(WebElement element) {
		try {
			Locatable hoverItem = (Locatable) element;
			Mouse mouse = ((HasInputDevices) webDriver).getMouse();
			mouse.mouseMove(hoverItem.getCoordinates());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Mouse overs on the specified menu,and clicks the sub menu.
	 * 
	 * @param menu
	 *            of the elements
	 * @param subMenu
	 *            menu to be clicked
	 */
	public void mouseOverAndClick(String menu, String subMenu) {
		try {
			WebElement link = getwebDriverLocator(getLocator(menu));
			Locatable hoverItem = (Locatable) link;
			Mouse mouse = ((HasInputDevices) webDriver).getMouse();
			mouse.mouseMove(hoverItem.getCoordinates());
			Thread.sleep(5000);
			click(subMenu);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void quitBrowser() {
		try {
			try{
				if(webDriver.getTitle() != null){
					webDriver.quit();
				}
			}catch(Exception e){}
			
			pass("Closing Browser", "Should close the browser.", "Closed the browser.", true);

		} catch (Exception e) {
			fail("Closing Browser", "Should close the browser.", "Failed to close the browser.", true);
			FrameworkLogger.log("Error while closing the browser. Exception: " + e.getMessage(), LEVEL.debug,
					this.getClass());
		}
	} 

	public String readScenarioData(String scenarioName, String key) {
		JsonReader jsonReader = new JsonReader();
		String filepath = "./assets/ScenarioData/" + scenarioName + ".json";
		JSONObject json = new JSONObject();
		if (FileUtil.folderExists(filepath)) {
			json = jsonReader.jsonRead(filepath);
			if (json.containsKey(key)) {
				return json.get(key).toString();
			} else {
				fail("Reading the scenario '" + scenarioName + "' data", "Should read the scenario data",
						"Key '" + key + "' not found in Scenario '" + scenarioName + "'");
				return null;
			}
		} else {
			fail("Reading the scenario '" + scenarioName + "' data", "Should read the scenario data",
					"Scenario '" + scenarioName + "' Not Found");
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	public boolean saveScenarioData(String scenarioName, String key, String value) {
		boolean flag = false;
		JsonReader j63126356r263526 = new JsonReader();
		String filepath = "./assets/ScenarioData/" + scenarioName + ".json";
		JSONObject json = new JSONObject();
		if (!FileUtil.folderExists("./assets/ScenarioData")) {
			FileUtil.makeFolder("./assets/ScenarioData");
			json.put(key, value);
			flag = j63126356r263526.jsonWrite(filepath, json);
		} else {
			if (FileUtil.fileExists(filepath)) {
				json = j63126356r263526.jsonRead(filepath);
				json.put(key, value);
			}
			//added else part so that the value can be entered in json file -6/9/2016
			else{
				json.put(key, value);
			}
			flag = j63126356r263526.jsonWrite(filepath, json);
		}
		if (!flag) {
			fail("Saving the scenario '" + scenarioName + "' data", "Should save the scenario data",
					"Failed to save Scenario '" + scenarioName + "' data. {Key: '" + key + "',Value: '" + value + "'}");
		}
		return flag;
	}

	/**
	 * @Function sets the value to the specified UI Element
	 * @param ElementName
	 *            which has to be set
	 * @param Value
	 *            that is to be set
	 */
	
	/* Updated reporting part by sharath on 21-july-2016*/
	public void setValue(String sElementName, Object sValue) {
		String reportEleName = formatElementName(sElementName);
		Map<?, ?> result = null;
		try {
			result = getElementMap(sElementName);
			if (result != null) {
				String sLocator = (String) result.get("locator");
				String sType = (String) result.get("type");
				if (sType.equalsIgnoreCase("textBox") || sType.equalsIgnoreCase("textArea")) {
					try {
						if (checkElement(sLocator, 10)) {

							getwebDriverLocator(sLocator).sendKeys(sValue.toString().trim());

							pass("Set value of '" + reportEleName + "' ",
									"Should type '" + sValue.toString() + "' in the element'" + reportEleName
											+ "'",
									"Typed text '" + sValue.toString() + "' in the element '" + reportEleName
											+ "'");
						}
					} catch (Exception e) {
						fail("Set value of '" + reportEleName + "' ",
								"Should type '" + sValue.toString() + "' in the element '" + reportEleName + "'",
								"Error while typing text '" + sValue.toString() + "' in the element '"
										+ reportEleName + "'");
						FrameworkLogger.log("Error while typing text. Exception: " + e.getMessage(), LEVEL.debug,
								this.getClass());
					}

				} else if (sType.equalsIgnoreCase("dropDown") && (sValue.toString() != null)
						&& (!sValue.toString().equals(""))) {
					if (checkElement(sLocator, 10)) {
						try {
							if(isSafari()){
								/*webDriver.findElement(By.xpath(getLocator(sElementName))).sendKeys(sValue.toString().trim());
								smartWait(100);
								webDriver.findElement(By.xpath(getLocator(sElementName))).sendKeys(Keys.ENTER);
								smartWait(100);*/
								
								Select selectOption = new Select(webDriver.findElement(By.xpath(getLocator(sElementName))));								
								selectOption.selectByVisibleText(sValue.toString().trim());	
								WebElement select = webDriver.findElement(By.xpath(getLocator(sElementName)));
                                ((JavascriptExecutor)webDriver).executeScript("var select = arguments[0]; for(var i = 0; i < select.options.length; i++){ if(select.options[i].text == arguments[1]){ select.options[i].selected = true; } }", select, sValue.toString().trim());

							}else{	
							Select selectOption = new Select(getwebDriverLocator(sLocator));
							selectOption.selectByVisibleText(sValue.toString().trim());
							}
							pass("Set value of '" + reportEleName + "'",
									"Should select '" + sValue.toString() + "' from the dropdown element '"
											+ reportEleName + "'",
									"Selected '" + sValue.toString() + "' from the dropdown element '" + reportEleName
											+ "'");
						} catch (Exception e) {
							fail("Set value of '" + reportEleName + "'",
									"Should select '" + sValue.toString() + "' from the dropdown element '"
											+ reportEleName + "'",
									"Error while selecting '" + sValue.toString() + "' from the dropdown element '"
											+ reportEleName + "'");
							FrameworkLogger.log("Error while selecting value. Exception: " + e.getMessage(),
									LEVEL.debug, this.getClass());

						}
					}
				} else if (sType.equalsIgnoreCase("radioButton")) {
					if (checkElement(sLocator, 10)) {
						if (sValue.toString().equals("Yes")) {
							getwebDriverLocator(sLocator).click();
							pass("Set value of '" + reportEleName + "'",
									"Should select '" + sValue.toString() + "' from the radio button element '"
											+ reportEleName + "'",
									"Selected '" + sValue.toString() + "' from the radio button element '"
											+ reportEleName + "'");
						} else if (sValue.toString().equals("No")) {
							getwebDriverLocator(sLocator).click();
							fail("Set value of '" + reportEleName + "'",
									"Should select '" + sValue.toString() + "' from the dropdown element '"
											+ reportEleName + "'",
									"Error while selecting '" + sValue.toString() + "' from the radio button element '"
											+ reportEleName + "'");
						}

					}
				} else if (sType.equalsIgnoreCase("checkBox")) {
					if (checkElement(sLocator, 10)) {
						if (sValue.toString().equals("Yes")) {
							getwebDriverLocator(sLocator).click();
							pass("Set value of '" + reportEleName + "'",
									"Should select '" + sValue.toString() + "' from the radio button element '"
											+ reportEleName + "'",
									"Selected '" + sValue.toString() + "' from the checkbox element '" + reportEleName
											+ "'");
						}
					}
				}
			}
		} catch (NullPointerException e) {
			fail("Set value of '" + reportEleName + "'", "Element '" + reportEleName + "'",
					"Error: element '" + reportEleName + "' not found.");
			FrameworkLogger.log("Error element not found. Exception: " + e.getMessage(), LEVEL.debug, this.getClass());
		} catch (Exception e) {
			fail("Set value of '" + reportEleName + "'", "Element '" + reportEleName + "'",
					"Error: element '" + reportEleName + "' not found.");
			FrameworkLogger.log("Error element not found. Exception: " + e.getMessage(), LEVEL.debug, this.getClass());
		}
	}

	/// ========
	public void setValue(WebElement sElementName, String sType, Object sValue) {
		String reportEleName = sElementName.getText();
		try {

			if (sType.equalsIgnoreCase("textBox") || sType.equalsIgnoreCase("textArea")) {
				try {
					sElementName.sendKeys(sValue.toString().trim());

					pass("Set value of '" + reportEleName + "'",
							"Should type '" + sValue.toString() + "' in the input element '" + reportEleName + "'",
							"Typed text '" + sValue.toString() + "' in the input element '" + reportEleName + "'");
				} catch (Exception e) {
					fail("Set value of '" + reportEleName + "'",
							"Should type '" + sValue.toString() + "' in the input element '" + reportEleName + "'",
							"Error while typing text '" + sValue.toString() + "' in the input element '" + reportEleName
									+ "'");
					FrameworkLogger.log("Error while typing text. Exception: " + e.getMessage(), LEVEL.debug,
							this.getClass());
				}

			} else if (sType.equalsIgnoreCase("dropDown") && (sValue.toString() != null)
					&& (!sValue.toString().equals(""))) {
				try {
					Select selectOption = new Select(sElementName);
					selectOption.selectByVisibleText(sValue.toString());
					pass("Set value of '" + reportEleName + "'",
							"Should select '" + sValue.toString() + "' from the dropdown element '" + reportEleName
									+ "'",
							"Selected '" + sValue.toString() + "' from the dropdown element '" + reportEleName + "'");
				} catch (Exception e) {
					fail("Set value of '" + reportEleName + "'",
							"Should select '" + sValue.toString() + "' from the dropdown element '" + reportEleName
									+ "'",
							"Error while selecting '" + sValue.toString() + "' from the dropdown element '"
									+ reportEleName + "'");
					FrameworkLogger.log("Error while selecting value. Exception: " + e.getMessage(), LEVEL.debug,
							this.getClass());

				}
			} else if (sType.equalsIgnoreCase("radioButton")) {
				if (sValue.toString().equals("Yes")) {
					sElementName.click();
					pass("Set value of '" + reportEleName + "'",
							"Should select '" + sValue.toString() + "' from the radio button element '" + reportEleName
									+ "'",
							"Selected '" + sValue.toString() + "' from the radio button element '" + reportEleName
									+ "'");
				} else if (sValue.toString().equals("No")) {
					sElementName.click();
					fail("Set value of '" + reportEleName + "'",
							"Should select '" + sValue.toString() + "' from the dropdown element '" + reportEleName
									+ "'",
							"Error while selecting '" + sValue.toString() + "' from the radio button element '"
									+ reportEleName + "'");
				}

			} else if (sType.equalsIgnoreCase("checkBox")) {
				if (sValue.toString().equals("Yes")) {
					sElementName.click();
					pass("Set value of '" + reportEleName + "'",
							"Should select '" + sValue.toString() + "' from the radio button element '" + reportEleName
									+ "'",
							"Selected '" + sValue.toString() + "' from the checkbox element '" + reportEleName + "'");
				}
			}

		} catch (NullPointerException e) {
			fail("Set value of '" + reportEleName + "'", "Element '" + reportEleName + "'",
					"Error: element '" + reportEleName + "' not found.");
			FrameworkLogger.log("Error element not found. Exception: " + e.getMessage(), LEVEL.debug, this.getClass());
		} catch (Exception e) {
			fail("Set value of '" + reportEleName + "'", "Element '" + reportEleName + "'",
					"Error: element '" + reportEleName + "' not found.");
			FrameworkLogger.log("Error element not found. Exception: " + e.getMessage(), LEVEL.debug, this.getClass());
		}
	}

	/// ==============
	public void setValue(WebElement sElementName, String sType, Object sValue, String Caption) {
		String reportEleName = Caption;
		try {

			if (sType.equalsIgnoreCase("textBox") || sType.equalsIgnoreCase("textArea")) {
				try {
					sElementName.sendKeys(sValue.toString().trim());

					pass("Set value of '" + reportEleName + "'",
							"Should type '" + sValue.toString() + "' in the input element '" + reportEleName + "'",
							"Typed text '" + sValue.toString() + "' in the input element '" + reportEleName + "'");
				} catch (Exception e) {
					fail("Set value of '" + reportEleName + "'",
							"Should type '" + sValue.toString() + "' in the input element '" + reportEleName + "'",
							"Error while typing text '" + sValue.toString() + "' in the input element '" + reportEleName
									+ "'");
					FrameworkLogger.log("Error while typing text. Exception: " + e.getMessage(), LEVEL.debug,
							this.getClass());
				}

			} else if (sType.equalsIgnoreCase("dropDown") && (sValue.toString() != null)
					&& (!sValue.toString().equals(""))) {
				try {
					Select selectOption = new Select(sElementName);
					selectOption.selectByVisibleText(sValue.toString());
					pass("Set value of '" + reportEleName + "'",
							"Should select '" + sValue.toString() + "' from the dropdown element '" + reportEleName
									+ "'",
							"Selected '" + sValue.toString() + "' from the dropdown element '" + reportEleName + "'");
				} catch (Exception e) {
					fail("Set value of '" + reportEleName + "'",
							"Should select '" + sValue.toString() + "' from the dropdown element '" + reportEleName
									+ "'",
							"Error while selecting '" + sValue.toString() + "' from the dropdown element '"
									+ reportEleName + "'");
					FrameworkLogger.log("Error while selecting value. Exception: " + e.getMessage(), LEVEL.debug,
							this.getClass());

				}
			} else if (sType.equalsIgnoreCase("radioButton")) {
				if (sValue.toString().equals("Yes")) {
					sElementName.click();
					pass("Set value of '" + reportEleName + "'",
							"Should select '" + sValue.toString() + "' from the radio button element '" + reportEleName
									+ "'",
							"Selected '" + sValue.toString() + "' from the radio button element '" + reportEleName
									+ "'");
				} else if (sValue.toString().equals("No")) {
					sElementName.click();
					fail("Set value of '" + reportEleName + "'",
							"Should select '" + sValue.toString() + "' from the dropdown element '" + reportEleName
									+ "'",
							"Error while selecting '" + sValue.toString() + "' from the radio button element '"
									+ reportEleName + "'");
				}

			} else if (sType.equalsIgnoreCase("checkBox")) {
				if (sValue.toString().equals("Yes")) {
					sElementName.click();
					pass("Set value of '" + reportEleName + "'",
							"Should select '" + sValue.toString() + "' from the radio button element '" + reportEleName
									+ "'",
							"Selected '" + sValue.toString() + "' from the checkbox element '" + reportEleName + "'");
				}
			}

		} catch (NullPointerException e) {
			fail("Set value of '" + reportEleName + "'", "Element '" + reportEleName + "'",
					"Error: element '" + reportEleName + "' not found.");
			FrameworkLogger.log("Error element not found. Exception: " + e.getMessage(), LEVEL.debug, this.getClass());
		} catch (Exception e) {
			fail("Set value of '" + reportEleName + "'", "Element '" + reportEleName + "'",
					"Error: element '" + reportEleName + "' not found.");
			FrameworkLogger.log("Error element not found. Exception: " + e.getMessage(), LEVEL.debug, this.getClass());
		}
	}
	/// ====

	/**
	 * @Function Submits the form
	 * @param Element
	 */

	public void submit(String sElement) {
		String reportEleName = formatElementName(sElement);
		try {
			if (getwebDriverLocator(getLocator(sElement)) != null) {
				getwebDriverLocator(getLocator(sElement)).submit();
				pass("Click on '" + reportEleName + "'", "Should click on the button '" + reportEleName + "'",
						"Clicked  button '" + reportEleName + "'");
			} else {
				fail("Click on '" + reportEleName + "'", "Should click on the button '" + reportEleName + "'",
						"Failed to click on  button '" + reportEleName + "'");
			}
		} catch (Exception e) {

			try {
				getwebDriverLocator(getLocator(sElement)).click();
			} catch (Exception e2) {
				fail("Click on '" + reportEleName + "'", "Should click on the button '" + reportEleName + "'",
						"Error while clicking on  button '" + reportEleName + "'");
				FrameworkLogger.log("Error while clicking on  button. Exception: " + e.getMessage(), LEVEL.debug,
						this.getClass());
			}
		}
	}

	public void upload(String sElement, String filePath) {
		String reportEleName = formatElementName(sElement);
		try {
			if (getwebDriverLocator(getLocator(sElement)) != null) {
				if (new File(filePath).exists()) {
					File fileUpload = new File(filePath);
					getwebDriverLocator(getLocator(sElement)).sendKeys(fileUpload.getAbsolutePath());
					pass("Upload file", "Will upload '" + filePath + "' file to '" + reportEleName + "'",
							"Upload the file");
				} else {
					fail("Upload file", "Will upload '" + filePath + "' file to '" + reportEleName + "'",
							"file path '" + filePath + "' not found");
				}

			} else {
				fail("Upload file", "Will upload '" + filePath + "' file to '" + reportEleName + "'",
						"Failed to upload file " + filePath + " as element" + sElement + " does not exists");
			}
		} catch (Exception e2) {
			fail("Upload file", "Will upload '" + filePath + "' file to '" + reportEleName + "'",
					"Failed to upload " + e2.getStackTrace() + "");
			FrameworkLogger.log("Failed to upload. Exception: " + e2.getMessage(), LEVEL.debug, this.getClass());
		}
	}

	public void verifyPresence(String sElement, Boolean continueExecution) {
		String reportEleName = formatElementName(sElement);
		try {
			if (getwebDriverLocator(getLocator(sElement)) != null) {
				if (continueExecution) {
					if (!isElementPresent(sElement)) {
						failstep();
					} else {

					}
				} else {
					if (!isElementPresent(sElement)) {
						failstep();
						quitBrowser();
						assertTestCase();
					}
				}
			} else {
				fail("Verify Presence of '" + reportEleName + "'", "Sould find element '" + reportEleName + "'",
						"'" + reportEleName + "' does not exists");
			}
		} catch (Exception e2) {
			fail("Verify Presence of '" + reportEleName + "'", "Should find element '" + reportEleName + "'",
					"Error while tried to find the element");
			FrameworkLogger.log("Error while tried to find the element. Exception: " + e2.getMessage(), LEVEL.debug,
					this.getClass());
		}

	}

	public void verifyTestStep(Object actual, Object expected, Boolean continueExecution) {
		if (continueExecution) {
			if (!actual.equals(expected)) {

				fail("Verify equal", "Expected and Actual value should be same.", "Expected value: " + expected
						+ ". Actual value: " + actual + ". Verification failed. Execution continued.");
			} else {
				pass("Verify equal", "Expected and Actual value should be same.", "Expected value: " + expected
						+ ". Actual value: " + actual + ". Verification passed. Execution continued.");
			}
		} else {
			if (!actual.equals(expected)) {

				fail("Verify equal", "Expected and Actual value should be same.", "Expected value: " + expected
						+ ". Actual value: " + actual + ". Verification failed. Execution stopped.");
				quitBrowser();
				assertTestCase();
			} else {
				pass("Verify equal", "Expected and Actual value should be same.", "Expected value: " + expected
						+ ". Actual value: " + actual + ". Verification passed. Execution continued.");
			}
		}
	}

	public void verifyTextContains(String actual, String expected, Boolean continueExecution) {
		if (continueExecution) {
			if (!actual.contains(expected)) {

				fail("Verify contains", "Actual value should contains Expected value.",
						"Expected value: " + expected + ". Actual value: " + actual
								+ ". Not contains expected value. Verification failed. Execution continued.");
			} else {
				pass("Verify contains", "Actual value should contains Expected value.", "Expected value: " + expected
						+ ". Actual value: " + actual + ". Verification passed. Execution continued.");
			}
		} else {
			if (!actual.contains(expected)) {

				fail("Verify contains", "Actual value should contains Expected value.",
						"Expected value: " + expected + ". Actual value: " + actual
								+ ". Not contains expected value. Verification failed. Execution stopped.");
				quitBrowser();
				assertTestCase();
			} else {
				pass("Verify contains", "Actual value should contains Expected value.", "Expected value: " + expected
						+ ". Actual value: " + actual + ". Verification passed. Execution continued.");
			}
		}
	}

	/**** From old Framework *****/
	public void forceClick(String sElement) {
		String reportEleName = formatElementName(sElement);
		try {
			if (getwebDriverLocator(getLocator(sElement)) != null) {
				getwebDriverLocator(getLocator(sElement)).click();
				// Reporter.log("Clicked on " + sElement + "");
				reportCreatePASS("Click on '" + reportEleName + "'", "Will click on '" + reportEleName + "'",
						"Clicked on '" + reportEleName + "'", "Pass");
			} else {
				// Reporter.log("Failed to click as element " + sElement+ " does
				// not exists");
				reportCreateFAIL("Click on '" + reportEleName + "'", "Will click on '" + reportEleName + "'",
						"Not able to click on '" + reportEleName + "'", "Fail");
			}
		} catch (Exception e2) {
			// Reporter.log("Failed to click" + e2.getStackTrace() + "");
			reportCreateFAIL("Click on '" + reportEleName + "'", "Will click on '" + reportEleName + "'",
					"Not able to click on '" + reportEleName + "'", "Fail");
			e2.printStackTrace();
			// log.error(e2.getMessage());
		}
	}

	public void verifyTextPresence(Object text, boolean continueExecution) {
		String pageText = webDriver.getPageSource();
		if (pageText.contains(text.toString())) {
			pass("Verify Text Presence '" + text + "'", text.toString(), "Page contains '" + text.toString() + "'");
		} else {

			fail("verify Text Presence'" + text + "'", text.toString(),
					"Page does not contains '" + text.toString() + "'");
			if (!continueExecution) {
				quitBrowser();
				assertTestCase();
			}
		}
	}

	public void WaitForElementPresent(final String sElement, int TimeInSeconds) throws Exception {
		String temp = gblTestData.get("StepTimeOut");
		TimeInSeconds = Integer.parseInt(temp);
		String reportEleName = formatElementName(sElement);
		FrameworkLogger.log("Waiting for element: " + sElement, LEVEL.info, this.getClass());
		Map<?, ?> result = null;
		try {
			result = getElementMap(sElement);
			if (result != null) {
				final String sLocatorElem = (String) result.get("locator");
				try {
					ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
						public Boolean apply(WebDriver webDriver) {
							WebElement element = getwebDriverLocator(sLocatorElem);
							if (element != null) {
								return true;

							} else {
								return false;

							}
						}
					};

					Wait<WebDriver> wait = new WebDriverWait(webDriver, TimeInSeconds);
					try {
						wait.until(expectation);
					} catch (Exception e) {
						/*
						 * fail("Wait For Element Present", "Wait for element '"
						 * + reportEleName + "'", "Timeout: element '" +
						 * reportEleName + "' not found after " + TimeInSeconds
						 * + " seconds")
						 */;
						FrameworkLogger.log("Timeout. Exception: " + e.getMessage(), LEVEL.debug, this.getClass());
						throw e;
					}
				} catch (Exception e) {
					fail("Wait For Element", "Wait for element " + reportEleName + "is avaliable",
							"Tiemout Error: Element '" + reportEleName + " not found with in " + TimeInSeconds
									+ " seconds" + "'");
					FrameworkLogger.log("Error while waiting for element. Exception: " + e.getMessage(), LEVEL.debug,
							this.getClass());
				}
			} else {
				/*
				 * fail("Wait For Element Present", "Wait for element '" +
				 * reportEleName + "'", "Element '" + reportEleName +
				 * "' not found in Object Repository");
				 */
			}
		} catch (Exception e) {
			fail("Exception Occured", "Exception Occured",
					"Error: Excetption occured while retriving element '" + reportEleName + "'");
			FrameworkLogger.log("Error while waiting for element. Exception: " + e.getMessage(), LEVEL.debug,
					this.getClass());
		}
	}
	
	
	
    /* Sharath [07-21] Function overloded  to manage error reporting */
    public String WaitForElementPresent(final String sElement) throws Exception {
    	String strReturn = "";
		String temp = gblTestData.get("StepTimeOut");
		int TimeInSeconds = Integer.parseInt(temp);
		
		String reportEleName = formatElementName(sElement);
		FrameworkLogger.log("Waiting for element: " + sElement, LEVEL.info, this.getClass());
		Map<?, ?> result = null;
		try {
			result = getElementMap(sElement);
			if (result != null) {
				final String sLocatorElem = (String) result.get("locator");
				try {
					ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
						public Boolean apply(WebDriver webDriver) {
							WebElement element = getwebDriverLocator(sLocatorElem);
							if (element != null) {
								return true;

							} else {
								return false;

							}
						}
					};

					Wait<WebDriver> wait = new WebDriverWait(webDriver, TimeInSeconds);
					try {
						wait.until(expectation);
					} catch (Exception e) {
						strReturn = "Timeout Error: Element '" + reportEleName + "' not found with in " + TimeInSeconds + " seconds";
					
						/*fail("Wait For Element Present", "Wait for element '"
						  + reportEleName + "'", "Timeout: element '" +
						  reportEleName + "' not found after " + TimeInSeconds
						  + " seconds")*/
						 
						FrameworkLogger.log("Timeout. Exception: " + e.getMessage(), LEVEL.debug, this.getClass());
						throw e;
					}
				} catch (Exception e) {
					strReturn = "Timeout Error: Element '" + reportEleName + "' not found with in " + TimeInSeconds + " seconds";

					/*fail("Wait For Element", "Wait for element " + reportEleName + "is avaliable",
							"Tiemout Error: Element '" + reportEleName + " not found with in " + TimeInSeconds
									+ " seconds" + "'");*/
					FrameworkLogger.log("Error while waiting for element. Exception: " + e.getMessage(), LEVEL.debug,
							this.getClass());
				}
			} else {
				strReturn = "UI Definition Error: Element '" + reportEleName + "' not found in Object Repository";
				/*
				 * fail("Wait For Element Present", "Wait for element '" +
				 * reportEleName + "'", "Element '" + reportEleName +
				 * "' not found in Object Repository");
				 */
			}
		} catch (Exception e) {
			strReturn = "Error: Excetption occured while retriving element '" + reportEleName + "' - " + e.getMessage();
			/*fail("Exception Occured", "Exception Occured",
					"Error: Excetption occured while retriving element '" + reportEleName + "'");*/
			/*fail("Wait For Element Present", "Wait for element '" + reportEleName + "'",
					"Error while waiting for element '" + reportEleName + "'");*/
			FrameworkLogger.log("Error while waiting for element. Exception: " + e.getMessage(), LEVEL.debug,
					this.getClass());
		}
		
		return strReturn;
	}

    
	public void waitForPageToLoad(int timeInSec) {
		String temp = gblTestData.get("StepTimeOut");
		timeInSec = Integer.parseInt(temp);
		webDriver.manage().timeouts().pageLoadTimeout(timeInSec, TimeUnit.SECONDS);
	}

	public void WaitForWindowToBe(final int windows, int TimeInSeconds) {
		String temp = gblTestData.get("StepTimeOut");
		TimeInSeconds = Integer.parseInt(temp);
		WaitForWindowToBeRecognized(windows, TimeInSeconds);
	}

	public void WaitForWindowToBeRecognized(final int windows, int TimeInSeconds) {
		try {
			ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver webDriver) {
					int handles = webDriver.getWindowHandles().size();
					if (windows == handles) {
						return true;
					} else {
						return false;
					}
				}
			};

			Wait<WebDriver> wait = new WebDriverWait(webDriver, TimeInSeconds);
			try {
				wait.until(expectation);
			} catch (Exception e) {
				fail("Wait For Window '" + windows + "' To Be Recognized",
						"Wait for Window '" + windows + "' to be Recognized",
						"Timeout after " + TimeInSeconds + " seconds while waiting for window");
				FrameworkLogger.log("Error while waiting for window. Exception: " + e.getMessage(), LEVEL.debug,
						this.getClass());
				throw e;
			}
		} catch (Exception e) {
			fail("Wait For Window '" + windows + "' To Be Recognized",
					"Wait for Window '" + windows + "' to be Recognized", "Error while waiting for window");
			FrameworkLogger.log("Error while waiting for window. Exception: " + e.getMessage(), LEVEL.debug,
					this.getClass());
		}
	}

	public void WaitForWindowToClose(final int windows, int TimeInSeconds) {
		try {
			ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver webDriver) {
					int handles = webDriver.getWindowHandles().size();
					if (windows == handles) {
						return true;
					} else {
						fail("Wait For Window '" + windows + "' To Close",
								" Should wait for Window '" + windows + "' to close", "Window not found");
						return false;
					}
				}
			};

			Wait<WebDriver> wait = new WebDriverWait(webDriver, TimeInSeconds);
			try {
				wait.until(expectation);
			} catch (Exception e) {
				fail("Wait For Window '" + windows + "' To Close", "Should wait for Window '" + windows + "' to close",
						"Timeout after '" + TimeInSeconds + "' seconds waiting for window");
				FrameworkLogger.log("Timeout waiting for window. Exception: " + e.getMessage(), LEVEL.debug,
						this.getClass());
				closeWindow();
			}
		} catch (Exception e) {
			fail("Wait For Window '" + windows + "' To Close", "Should wait for Window '" + windows + "' to close",
					"Error while waiting for window");
			FrameworkLogger.log("Error while waiting for window to close. Exception: " + e.getMessage(), LEVEL.debug,
					this.getClass());
		}
	}

	public void reportCreatePASS(String step, String expected, String actual, String status) {
		pass(step, expected, actual);

	}

	public void reportCreateFAIL(String step, String expected, String actual, String status) {
		fail(step, expected, actual);
	}

	public void select_menu(String sElement, Object sValue) {
		try {
			String[] arrMenuOptions = (sValue.toString()).split(">");
			WebElement eleMenuOption = getwebDriverLocator(getLocator(sElement));
			String strXpath = null;
			// handling the HOME navigation for Audit Log
			if (arrMenuOptions.length > 1) {

				if (arrMenuOptions.length == 2) {
					strXpath = "//a[normalize-space(translate(text(), '  ', ' '))='"
							+ arrMenuOptions[0].trim().toUpperCase()
							+ "']/following-sibling::ul//a[normalize-space(translate(., '  ', ' '))='"
							+ arrMenuOptions[arrMenuOptions.length - 1].trim() + "']";
				} else {
					strXpath = "//a[normalize-space(translate(text(), '  ', ' '))='"
							+ arrMenuOptions[0].trim().toUpperCase()
							+ "']/..//a[normalize-space(translate(text(), '  ', ' '))='" + arrMenuOptions[1].trim()
							+ "']/following-sibling::ul//a[normalize-space(translate(., '  ', ' '))='"
							+ arrMenuOptions[arrMenuOptions.length - 1].trim() + "']";
				}

				try {
					eleMenuOption = eleMenuOption.findElement(By.xpath(strXpath));
				} catch (Exception e2) {
					strXpath = "//a[normalize-space(translate(text(), '  ', ' '))='"
							+ arrMenuOptions[0].trim().toUpperCase()
							+ "']/following-sibling::ul//a[normalize-space(translate(., '  ', ' '))='"
							+ arrMenuOptions[arrMenuOptions.length - 1].trim() + "']";
					eleMenuOption = eleMenuOption.findElement(By.xpath(strXpath));
				}
				// eleMenuOption = webDriver.findElement(By.xpath(strXpath));
				javaScriptClick(eleMenuOption);
			} else {
				strXpath = "//a[normalize-space(translate(text(), '  ', ' '))='"
						+ arrMenuOptions[0].trim().toUpperCase() + "']";
				eleMenuOption = eleMenuOption.findElement(By.xpath(strXpath));
				javaScriptClick(eleMenuOption);
			}
			reportCreatePASS("Navigate to '" + sValue.toString() + "'",
					"Should navigate to '" + sValue.toString() + "'", "Navigated to '" + sValue.toString() + "'",
					"Pass");
		} catch (Exception e) {
			reportCreateFAIL("Navigate to '" + sValue.toString() + "'",
					"Should navigate to '" + sValue.toString() + "'",
					"Failed to navigate to '" + sValue.toString() + "'", "Fail");
		}
	}

	public boolean select_menu_NoneAccess(String sElement, Object sValue) {
		try {
			String[] arrMenuOptions = (sValue.toString()).split(">");
			WebElement eleMenuOption = getwebDriverLocator(getLocator(sElement));
			// WebElement eleMenuOption =
			// webDriver.findElement(By.id("topNav"));

			for (int mnuOption = 0; mnuOption < arrMenuOptions.length; mnuOption++) {
				// System.out.println(arrMenuOptions[mnuOption].trim());
				eleMenuOption = eleMenuOption
						.findElement(By.xpath("//li/a[contains(text(),'" + arrMenuOptions[mnuOption].trim() + "')]"));
				// System.out.println("******************"+eleMenuOption);
				if (mnuOption == (arrMenuOptions.length - 1)) {
					// eleMenuOption.click();
					javaScriptClick(eleMenuOption);
				}
				Thread.sleep(1000);
				waitForPageToLoad(3000);
			}
			reportCreateFAIL("Navigate to '" + sValue.toString() + "'",
					"Should navigate to '" + sValue.toString() + "'", "Navigated to '" + sValue.toString() + "'",
					"Fail");
			return true;

		} catch (Exception e) {
			reportCreatePASS("Navigate to '" + sValue.toString() + "'",
					"Should not navigate to" + sValue.toString() + "'",
					"Did not get navigated to '" + sValue.toString() + "'", "Pass");
			// e.printStackTrace();
			return false;

		}
	}

	public void smartWait(int TimeInSeconds) {
		// TimeInSeconds = mcd.gblTestData.get("WaitTime");
		// int TimeInSeconds;
		// String temp = mcd.GetKeyValue("StepTimeOut");
		String temp = gblTestData.get("StepTimeOut");
		TimeInSeconds = Integer.parseInt(temp);

		try {
			ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver webDriver) {

					WebElement waitb1 = webDriver.findElement(By.xpath("//*[@id='divId'][@class='resdiv']"));
					WebElement waitb2 = webDriver.findElement(By.xpath("//*[@id='divIdOver'][@class='resdivOver']"));
					JavascriptExecutor js = (JavascriptExecutor) webDriver;
					String val1 = js.executeScript("return $('.resdiv').css('display');").toString();
					String val2 = js.executeScript("return $('.resdivOver').css('display');").toString();
					if (val1.equalsIgnoreCase("none") && val2.equalsIgnoreCase("none"))
						return true;
					return false;
				}
			};

			Wait<WebDriver> wait = new WebDriverWait(webDriver, TimeInSeconds);
			try {
				wait.until(expectation);
			} catch (Exception e) {
				throw e;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void closeWindow() {
		try {
			webDriver.close();
			pass("Closing Window", "Should close the window.", "Closed the window.", true);

		} catch (Exception e) {
			fail("Closing window", "Should close the window.", "Failed to close the window.", true);
			FrameworkLogger.log("Error while closing the window. Exception: " + e.getMessage(), LEVEL.debug,
					this.getClass());
		}
	}

	
	

	public Boolean isElementPresent(String sElement) {
		// String reportElement=formatElementName(sElement);
		if (getwebDriverLocator(getLocator(sElement)) != null) {
			WebElement element = getwebDriverLocator(getLocator(sElement));
			if (element.isDisplayed()) {
				// pass("Checking for element '"+reportElement+"' presence.",
				// "Element should be present.", "Element is present.");
				return true;
			} else {
				// fail("Checking for element '"+reportElement+"' presence.",
				// "Element should be present.", "Element is not present.");
				return false;
			}
		} else {
			// fail("Checking for element '"+reportElement+"' presence.",
			// "Element should be present.", "Not able to find the locator for
			// Element. Check Object Repository.");
			return false;
		}
	}

	public Boolean isElementSelected(String sElement) {
		// String reportElement=formatElementName(sElement);
		if (getwebDriverLocator(getLocator(sElement)) != null) {
			WebElement element = getwebDriverLocator(getLocator(sElement));
			if (element.isSelected()) {
				// pass("Checking for element '"+reportElement+"' is Selected.",
				// "Element should be is Selected.", "Element is is Selected.");
				return true;
			} else {
				// fail("Checking for element '"+reportElement+"' is Selected.",
				// "Element should be is Selected.", "Element is not is
				// Selected.");
				return false;
			}
		} else {
			// fail("Checking for element '"+reportElement+"' is Selected.",
			// "Element should be is Selected.", "Not able to find the locator
			// for Element. Check Object Repository.");
			return false;
		}
	}

	public Boolean isElementEnabled(String sElement) {
		// String reportElement=formatElementName(sElement);
		if (getwebDriverLocator(getLocator(sElement)) != null) {
			WebElement element = getwebDriverLocator(getLocator(sElement));
			if (element.isEnabled()) {
				// pass("Checking for element '"+reportElement+"' is Selected.",
				// "Element should be is Selected.", "Element is is Selected.");
				return true;
			} else {
				// fail("Checking for element '"+reportElement+"' is Selected.",
				// "Element should be is Selected.", "Element is not is
				// Selected.");
				return false;
			}
		} else {
			// fail("Checking for element '"+reportElement+"' is Selected.",
			// "Element should be is Selected.", "Not able to find the locator
			// for Element. Check Object Repository.");
			return false;
		}
	}

	/*** added for GWC ***/
	public boolean isPresence(String sElement, Boolean continueExecution) {
		try {
			if (getwebDriverLocator(getLocator(sElement)) != null) {
				WebElement element = getwebDriverLocator(getLocator(sElement));
				if (continueExecution) {
					if (!validations.elementPresent(element)) {
						this.flags.add(false);
						return false;
					} else {
						return true;
					}
				} else {
					if (!validations.elementPresent(element)) {
						this.flags.add(false);
						webDriver.quit();
						assertTestCase();
					}
				}
			} else {
				// Reporter.log(sElement
				// + " does not exists");
			}
		} catch (Exception e2) {
			// Reporter.log("Element does not exists" + e2.getStackTrace() +
			// "");
			e2.printStackTrace();
			// log.error(e2.getMessage());
		}
		return false;

	}
	
	
	//Wait for Element Present using WebElement
	//Author : Pooja Panse
    public String WaitForElementPresent(final WebElement sElement, String strElementName) throws Exception {
    	String strReturn = "";
    	String temp = gblTestData.get("StepTimeOut");
		int TimeInSeconds = Integer.parseInt(temp);
		
		FrameworkLogger.log("Waiting for element: " + sElement, LEVEL.info, this.getClass());
				try {
					ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
						public Boolean apply(WebDriver webDriver) {
							if (sElement != null) {
								return true;

							} else {
								return false;

							}
						}
					};

					Wait<WebDriver> wait = new WebDriverWait(webDriver, TimeInSeconds);
					try {
						wait.until(expectation);
					} catch (Exception e) {
						strReturn = "Timeout Error: Element '" + strElementName + "' not found with in " + TimeInSeconds + " seconds";
						 
						FrameworkLogger.log("Timeout. Exception: " + e.getMessage(), LEVEL.debug, this.getClass());
						throw e;
					}
				} catch (Exception e) {
					strReturn = "Timeout Error: Element '" + strElementName + "' not found with in " + TimeInSeconds + " seconds";
					FrameworkLogger.log("Error while waiting for element. Exception: " + e.getMessage(), LEVEL.debug,
							this.getClass());
				}
				
		return strReturn;
	}

/***************************
/**
	 * Wait for the webelement to be present on page till timeout
	 * 
	 * @param sElement
	 *            webElement to be checked for presence
	 * @return
	 * 
	 * @throws Exception
	 */
	public String WaitForElementPresent(final WebElement sElement) throws Exception {
		String strReturn = "";
		String temp = gblTestData.get("StepTimeOut");
		int TimeInSeconds = Integer.parseInt(temp);

		FrameworkLogger.log("Waiting for element: " + sElement, LEVEL.info, this.getClass());
		try {
			ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver webDriver) {
					if (validations.elementPresent(sElement)) {
						return true;

					} else {
						return false;

					}
				}
			};

			Wait<WebDriver> wait = new WebDriverWait(webDriver, TimeInSeconds);
			try {
				wait.until(expectation);
			} catch (Exception e) {
				strReturn = "Timeout Error: Element not found with in " + TimeInSeconds + " seconds";

				FrameworkLogger.log("Timeout. Exception: " + e.getMessage(), LEVEL.debug, this.getClass());

			}
		} catch (Exception e) {
			strReturn = "Timeout Error: Element not found with in " + TimeInSeconds + " seconds";
			FrameworkLogger.log("Error while waiting for element. Exception: " + e.getMessage(), LEVEL.debug,
					this.getClass());
		}

		return strReturn;
	}

	/**
	 * Handles click issues related to alerts, new window and navigations
	 * related flows
	 * 
	 * @param sElement
	 *            webElement to be clicked
	 * @param verifyEle
	 *            element that should appear on page after click operation in case of
	 *            navigation related flows...
	 * 
	 *            "" is required to be passed in case of alert and window
	 *            related flows
	 * 
	 */
	public void clickAndVerify(WebElement sElement, String verifyEle) {
		String strResult = "";
		boolean flag = false;
		int clickNo = 0;
		String verifyElem = null;
		final int windowSizeBefore = webDriver.getWindowHandles().size();
		int i = 0;
		if (verifyEle != "") {
			verifyElem = getLocator(verifyEle);
		}
		try {
			strResult = WaitForElementPresent(sElement);
			do {
				i++;

				if (strResult.equals("")) {
					try {
						switch (clickNo) {
						case 0:
							sElement.click();
							clickNo = clickNo + 1;
							break;
						case 1:
							sElement.sendKeys(Keys.ENTER);
							clickNo = clickNo + 1;
							break;
						case 2:
							((JavascriptExecutor) webDriver).executeScript("arguments[0].click();", sElement);
							clickNo = clickNo + 1;
							break;
						default:
							sElement.click();
							clickNo = clickNo + 1;
						}

						if (verifyEle == "") {

							WebDriverWait wait = new WebDriverWait(webDriver, 7);
							try {
								if (wait.until(ExpectedConditions.alertIsPresent()) != null) {

									flag = true;
								}
							} catch (Exception e) {

							}
							if (flag == false) {

								try {
									ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
										public Boolean apply(WebDriver webDriver) {
											int windowSize = webDriver.getWindowHandles().size();

											if (windowSize != windowSizeBefore) {

												return true;

											} else {
												return false;

											}
										}
									};

									Wait<WebDriver> wait1 = new WebDriverWait(webDriver, 10);
									wait1.until(expectation);
									if (expectation.apply(webDriver)) {
										flag = true;
									}
								} catch (Exception e) {
								}

							}
						} else {
							try {

								Wait<WebDriver> wait1 = new WebDriverWait(webDriver, 7);
								if (wait1.until(
										ExpectedConditions.visibilityOf(getwebDriverLocator(verifyElem))) != null)

									flag = true;
							} catch (Exception e) {
							}
						}

						if (flag) {
							pass("Click on '" + sElement + "'", "Should click the element '" + sElement + "'",
									"Clicked on  element '" + sElement + "'");
							break;
						}
					} catch (Exception e) {

					}
				} else {
					fail("Click on element'" + sElement + "'", "Should click the element '" + sElement + "'",
							strResult);
					break;
				}

			} while (i <= 7);
			if (flag == false) {
				fail("Click on element'" + sElement + "'", "Should click the element '" + sElement + "'",
						"Error while clicking on element '" + sElement + "'");
			}

		} catch (Exception e2) {
			fail("Click on element'" + sElement + "'", "Should click the element '" + sElement + "'",
					"Error while clicking on element '" + sElement + "'");
			FrameworkLogger.log("Error while clicking on Button '" + sElement + "'. Exception: " + e2.getMessage(),
					LEVEL.debug, this.getClass());
		}
	}

	/**
	 * Handles click issues related to alerts, new window and navigations
	 * related flows
	 * 
	 * @param sElement
	 *            Element to be clicked
	 * @param verifyEle
	 *            element that should appear on page after click operation in case of
	 *            navigation related flows...
	 * 
	 *            "" is required to be passed in case of alert and window
	 *            related flows
	 * 
	 */
	public void clickAndVerify(String sElement, String verifyEle) {
		String strResult = "";
		boolean flag = false;
		int clickNo = 0;
		final int windowSizeBefore = webDriver.getWindowHandles().size();
		String sEle = getLocator(sElement);
		String verifyElem = null;
		if (verifyEle != "") {
			verifyElem = getLocator(verifyEle);
		}
		int i = 0;
		try {
			strResult = WaitForElementPresent(getwebDriverLocator(sEle));
			do {
				i++;

				if (strResult.equals("")) {
					try {
						if (getwebDriverLocator(sEle) != null) {

							switch (clickNo) {
							case 0:
								getwebDriverLocator(sEle).click();
								clickNo = clickNo + 1;
								break;
							case 1:
								getwebDriverLocator(sEle).sendKeys(Keys.ENTER);
								clickNo = clickNo + 1;
								break;
							case 2:
								((JavascriptExecutor) webDriver).executeScript("arguments[0].click();",
										getwebDriverLocator(sEle));
								clickNo = clickNo + 1;
								break;
							default:
								getwebDriverLocator(sEle).click();
								clickNo = clickNo + 1;
							}
						}
						if (verifyEle == "") {

							WebDriverWait wait = new WebDriverWait(webDriver, 7);
							try {
								if (wait.until(ExpectedConditions.alertIsPresent()) != null) {
									flag = true;
								}
							} catch (Exception e) {

							}

							if (flag == false) {
								waitForPageToLoad(10000);

								try {
									ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
										public Boolean apply(WebDriver webDriver) {
											int windowSize = webDriver.getWindowHandles().size();

											if (windowSize != windowSizeBefore) {

												return true;

											} else {
												return false;

											}
										}
									};
									Wait<WebDriver> wait1 = new WebDriverWait(webDriver, 10);
									wait1.until(expectation);
									if (expectation.apply(webDriver)) {
										flag = true;
									}
								} catch (Exception e) {

								}
							}
						} else {
							try {

								Wait<WebDriver> wait1 = new WebDriverWait(webDriver, 7);
								if (wait1.until(
										ExpectedConditions.visibilityOf(getwebDriverLocator(verifyElem))) != null)
									flag = true;
							} catch (Exception e) {
							}
						}

						if (flag) {
							pass("Click on '" + sElement + "'", "Should click the element '" + sElement + "'",
									"Clicked on  element '" + sElement + "'");
							break;
						}

					} catch (Exception e) {

					}
				} else {
					fail("Click on element'" + sElement + "'", "Should click the element '" + sElement + "'",
							strResult);
					break;
				}

			} while (i <= 7);
			if (flag == false) {
				fail("Click on element'" + sElement + "'", "Should click the element '" + sElement + "'",
						"Error while clicking on element '" + sElement + "'");
			}
		} catch (Exception e2) {
			fail("Click on element'" + sElement + "'", "Should click the element '" + sElement + "'",
					"Error while clicking on element '" + sElement + "'");
			FrameworkLogger.log("Error while clicking on Button '" + sElement + "'. Exception: " + e2.getMessage(),
					LEVEL.debug, this.getClass());
		}
	}


		public String hostGet(SessionId session){
        
        String hostDetail = null;
        String hostName = null;
        int port = 0 ;
        
        JsonReader jsonReader = new JsonReader();
        List<Map<?,?>> json ;
        if (FileUtil.folderExists("./browsers.json")){
               json = jsonReader.parseJson("./browsers.json");
               for (Map<?, ?> test : json)
               {
                     hostName = test.get("server").toString().trim();
                     port = Integer.parseInt(test.get("port").toString().trim());
               }
               
        }
        
        String errorMsg = "Failed to acquire remote webdriver node and port info. Root cause: ";

        try {
               HttpHost host = new HttpHost(hostName, port);
               DefaultHttpClient client = new DefaultHttpClient();
               URL sessionURL = new URL("http://" + hostName + ":" + port + "/grid/api/testsession?session=" + session);
               //System.out.println("URL is : "+sessionURL);
               BasicHttpEntityEnclosingRequest r = new BasicHttpEntityEnclosingRequest("POST", sessionURL.toExternalForm());
               HttpResponse response = client.execute(host, r);
               //JSONObject object = extractObject(response);
               //URL myURL = new URL(object.getString("proxyId"));
               JsonObject myjsonobject =extractObject(response);
               JsonElement url = myjsonobject.get("proxyId");
               //System.out.println(url.getAsString());
               URL myURL = new URL(url.getAsString());
               if ((myURL.getHost() != null) && (myURL.getPort() != -1)) {
                     hostDetail = myURL.getHost()+":"+myURL.getPort();
               }

        } catch (Exception e) {
               //logger.log(Level.SEVERE, errorMsg, e);
               throw new RuntimeException(errorMsg, e);
        }
        return hostDetail;
 }

	
	private static JsonObject extractObject(HttpResponse resp) throws IOException {
		BufferedReader rd = new BufferedReader(new InputStreamReader(resp.getEntity().getContent()));
		StringBuffer s = new StringBuffer();
		String line;
		while ((line = rd.readLine()) != null) {
			s.append(line);
		}
		rd.close();
		JsonParser parser = new JsonParser();
		JsonObject objToReturn = (JsonObject)parser.parse(s.toString());
		//System.out.println("p:"+objToReturn.toString());
		//System.out.println("q:"+objToReturn.get("proxyId"));
		return objToReturn;
	}
 
	public String getWindowSessionId(String hostIP){
		String id = null;
		try{
		//	String hostIP = hostGet(((RemoteWebDriver)webDriver).getSessionId());
			//System.out.println("IP of Node Machine is: "+hostIP);
			
			
			Process p = Runtime.getRuntime().exec("psexec \\\\"+hostIP+" -u "+hostIP+"\\lite -p igate@123 cmd /c \"for /f \"tokens=3\" %F in ('qwinsta ^| findstr \"Active\"') do @echo %~F\"");
			String s = null;
			 BufferedReader stdInput = new BufferedReader(new
	                 InputStreamReader(p.getInputStream()));
	 
	            BufferedReader stdError = new BufferedReader(new
	                 InputStreamReader(p.getErrorStream()));
	 
	            // read the output from the command
	            //System.out.println("Here is the standard output of the command:\n");
	            while ((s = stdInput.readLine()) != null) {
	            	id = s.toString().trim();
	                System.out.println("***** "+s);
	            }
			}catch(Exception e){
				FrameworkLogger.log("Error while fetching Active sessionID. Exception: "+e.getMessage(), LEVEL.debug, this.getClass());
			}
		return id;
	}
	
	
	public String changeWindowSession(String hostIP){
		String id = null;
		try{
		//	String hostIP = hostGet(((RemoteWebDriver)webDriver).getSessionId());
			//System.out.println("IP of Node Machine is: "+hostIP);
			
			Process p = Runtime.getRuntime().exec("psexec \\\\"+hostIP+" -u "+hostIP+"\\lite -p igate@123 cmd /c \"tscon 1 /dest:console\"");
			
			String s = null;
			 BufferedReader stdInput = new BufferedReader(new
	                 InputStreamReader(p.getInputStream()));
	 
	            BufferedReader stdError = new BufferedReader(new
	                 InputStreamReader(p.getErrorStream()));
	            while ((s = stdInput.readLine()) != null) {
	            	
	            }
	            id = getWindowSessionId(hostIP);
			}catch(Exception e){
				FrameworkLogger.log("Error while fetching Active sessionID. Exception: "+e.getMessage(), LEVEL.debug, this.getClass());
			}
		return id;
	}
	
	public void acceptIEDownloadPopup() throws InterruptedException, IOException{
			try{
			String hostIP = hostGet(((RemoteWebDriver)webDriver).getSessionId());
			//System.out.println("IP of Node Machine is: "+hostIP);
			
			String id = getWindowSessionId(hostIP);
			System.out.println("Fetched Session Id: "+id);
			if (id == null ){
				id = changeWindowSession(hostIP);
			}
			//Process p = Runtime.getRuntime().exec("psexec \\\\"+hostIP+" -u "+hostIP+"\\mohsayya -p octo-2016 -i "+id+" -w D:\\ iepopup.exe");
			Process p = Runtime.getRuntime().exec("D:\\iepopup.exe");
			String s = null;
			 BufferedReader stdInput = new BufferedReader(new
	                 InputStreamReader(p.getInputStream()));
	 
	            BufferedReader stdError = new BufferedReader(new
	                 InputStreamReader(p.getErrorStream()));
	 
	            // read the output from the command
	            //System.out.println("Here is the standard output of the command:\n");
	            while ((s = stdInput.readLine()) != null) {
	               // System.out.println(s);
	            }

			}catch(Exception e){
				FrameworkLogger.log("Error while downloading file. Exception: "+e.getMessage(), LEVEL.debug, this.getClass());
			}
		}
	
	public String getHostIP(){
		String hostIP = null ;
		try{
			return hostGet(((RemoteWebDriver)webDriver).getSessionId());
		
		}catch(Exception e){ return hostIP;}
	}
	
	public void clearIEBrowserSession(String hostIP){
		System.out.println("Inside IE clear method....");
		String userName= "";
		String passWord = "";
		if(PropertyReader.getProperty("BrowserCleanUp", "").equalsIgnoreCase("True")){
		
			try{
				//String hostIP = hostGet(((RemoteWebDriver)webDriver).getSessionId());
//			
				//String userPass = PropertyReader.getProperty("userCred", "");
				//String userName = userPass.split(":")[0].trim();
				//String passWord = userPass.split(":")[1].trim();
				String users = PropertyReader.getProperty("NodeUsers", "").replace("[","").replace("]", "");
				Map<String, String> usersMap = new HashMap<String, String>();
				for(String user: users.split(",")){
					String nodeIP = user.split(":")[0].trim();
					String nodeCredentials = user.split(":")[1].trim();
					usersMap.put(nodeIP, nodeCredentials);
				}
				
				 userName = usersMap.get(hostIP).toString().split("\\|")[0].trim();
				 passWord = usersMap.get(hostIP).toString().split("\\|")[1].trim();
			
				
				//Process p = Runtime.getRuntime().exec("psexec \\\\"+hostIP+" -u igatecorp\\uparejiy -p Aug@2016 cmd /s /k \"TASKKILL /IM \"iexplore.exe\" /IM \"IEDriverServer.exe\" /F /T && exit\"");
				Process p = Runtime.getRuntime().exec("psexec \\\\"+hostIP+" -u "+userName+" -p "+passWord+" -s cmd /s /k \"TASKKILL /IM \"iepxplore.exe\" /IM \"IEDriverServer.exe\" /F /T && exit\"");
				String s = null;
				 BufferedReader stdInput = new BufferedReader(new
		                 InputStreamReader(p.getInputStream()));
		 
		            BufferedReader stdError = new BufferedReader(new
		                 InputStreamReader(p.getErrorStream()));
		 
		            // read the output from the command
		            //System.out.println("Here is the standard output of the command:\n");
		            while ((s = stdInput.readLine()) != null) {
		               // System.out.println(s);
		            }

			}catch(Exception e){}
		}
			
	}
	
	public void ieDownload() {
		HttpURLConnection conn = null;
		String hostIP = hostGet(((RemoteWebDriver)webDriver).getSessionId());
		URL url;
		try {
			url = new URL("http://"+hostIP + "/extra/IEDownloadServlet");
			conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.getResponseCode();
			if(conn.getResponseCode()== 200){
				pass("Download file", "File should be downloaded","File is downloaded successfully");
			}else{
				fail("Download file", "File should be downloaded","Error while downloading file");
			}
			System.out.println("Response code is: "+conn.getResponseCode());
        } catch (IOException e) {
        	FrameworkLogger.log("Error while downloading file. Exception: "+e.getMessage(), LEVEL.debug, this.getClass());
        	fail("Download file", "File should be downloaded","Error while downloading file");
		}
	} 
	
	public void extractZipFile(String zipPath, String zipOutput){
		
		List<String> fileList;
		//String INPUT_ZIP_FILE = "D:\\ieDownload\\export_10107_20161212_20161212055924021.zip";
		//String OUTPUT_FOLDER = "D:\\ieDownload\\ZipPut";
		
		String INPUT_ZIP_FILE = zipPath;
		String OUTPUT_FOLDER = zipOutput;
		
		byte[] buffer = new byte[1024];
		
		try{
			//create output directory is not exists
	    	File folder = new File(OUTPUT_FOLDER);
	    	if(!folder.exists()){
	    		folder.mkdir();
	    		System.out.println("Folder created!");
	    	}

	    	//get the zip file content
	    	ZipInputStream zis =
	    		new ZipInputStream(new FileInputStream(INPUT_ZIP_FILE));
	    	//get the zipped file list entry
	    	ZipEntry ze = zis.getNextEntry();

	    	while(ze!=null){

	    	   String fileName = ze.getName();
	           File newFile = new File(OUTPUT_FOLDER + File.separator + fileName);

	           System.out.println("file unzip : "+ newFile.getAbsoluteFile());

	            //create all non exists folders
	            //else you will hit FileNotFoundException for compressed folder
	            new File(newFile.getParent()).mkdirs();

	            FileOutputStream fos = new FileOutputStream(newFile);

	            int len;
	            while ((len = zis.read(buffer)) > 0) {
	       		fos.write(buffer, 0, len);
	            }

	            fos.close();
	            ze = zis.getNextEntry();
	    	}

	        zis.closeEntry();
	    	zis.close();

	    	System.out.println("Done");
		}catch(IOException e){
			System.out.println("Error");
		}
	}
	
	public String getNodeValue(String xpathStr, String filePath) {
		if (!xpathStr.startsWith("//")) {
			if (xpathStr.startsWith("/")) {
				xpathStr = "/" + xpathStr;
			} else {
				xpathStr = "//" + xpathStr;
			}
		}
		String value = null;
		Document doc = null;
		DocumentBuilder db;
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			db = dbf.newDocumentBuilder();
			doc = db.parse(filePath);
			doc.getDocumentElement().normalize();
		} catch (ParserConfigurationException e) {
			System.out.println("####### Error in parsing #######");
		} catch (SAXException e) {
			System.out.println("####### Error in parsing #######");
		} catch (IOException e) {
			System.out.println("####### Error in reading file #######");
		}
		Node nl = getNode(doc, xpathStr);
		if (nl != null) {
			value = nl.getTextContent();
		} else {
			System.out.println("******* No Node found *******");
		}
		return value;
	}

	public String getAttributeValue(String xpathStr, String filePath, String attrubte) {
		if (!xpathStr.startsWith("//")) {
			if (xpathStr.startsWith("/")) {
				xpathStr = "/" + xpathStr;
			} else {
				xpathStr = "//" + xpathStr;
			}
		}
		String value = null;
		Document doc = null;
		DocumentBuilder db;
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			db = dbf.newDocumentBuilder();
			doc = db.parse(filePath);
			doc.getDocumentElement().normalize();
		} catch (ParserConfigurationException e) {
			System.out.println("####### Error in parsing #######");
		} catch (SAXException e) {
			System.out.println("####### Error in parsing #######");
		} catch (IOException e) {
			System.out.println("####### Error in reading file #######");
		}
		Node nl = getNode(doc, xpathStr);
		if (nl != null) {
			value = nl.getAttributes().getNamedItem(attrubte).getTextContent();
		} else {
			System.out.println("******* No Node found *******");
		}
		return value;
	}
	
	private Node getNode(Document doc, String xpathStr) {
		try {
			XPathFactory xPathfactory = XPathFactory.newInstance();
			XPath xpath = xPathfactory.newXPath();
			XPathExpression expr = xpath.compile(xpathStr);
			Node nl = (Node) expr.evaluate(doc, XPathConstants.NODE);
			return nl;
		} catch (Exception e) {
			System.out.println("******* XPath not proper *******");
			return null;
		}
	}

	public enum DialogType{
		ALERT,CONFIRM,PROMPT
	}
	
	public void handleSafariAlertDialog(DialogType dialogType,AlertPopupButton alertActionButton){
		/*String script = "";
		if(isSafari()){
			if(dialogType.equals(DialogType.CONFIRM) && alertActionButton.equals(AlertPopupButton.OK_BUTTON)){
				script = "window.confirm = function(msg){console.log(msg); localStorage.alertText=msg; return true; }; "
						+ "window.alert = function(msg){console.log(msg); localStorage.alertText=msg; return true; }; ";
			}else if(dialogType.equals(DialogType.CONFIRM) && alertActionButton.equals(AlertPopupButton.CANCEL_BUTTON)){
				script = "window.confirm = function(msg){console.log(msg); localStorage.alertText=msg; return false; }; ";
			}else if(dialogType.equals(DialogType.ALERT) && alertActionButton.equals(AlertPopupButton.OK_BUTTON)){
				script = "window.alert = function(msg){console.log(msg); localStorage.alertText=msg; return true; }; "
						+ "window.confirm = function(msg){console.log(msg); localStorage.alertText=msg; return true; };";
			}else if(dialogType.equals(DialogType.PROMPT) && alertActionButton.equals(AlertPopupButton.OK_BUTTON)){
				script = "window.prompt = function(msg){console.log(msg); localStorage.alertText=msg; return true; }; ";
			}else{
				script = "window.alert = function(msg){console.log(msg); localStorage.alertText=msg; return true; }; ";
			}
			try{
				((JavascriptExecutor)webDriver).executeScript(script);
			}catch(Exception e){
				System.out.println("Test Failed - "+e.getMessage());
			}
		}*/
		
	}
	
	
	public boolean isMicrosoftEdge(){
		if((((RemoteWebDriver) webDriver).getCapabilities().getBrowserName().toString().equalsIgnoreCase("Microsoft Edge"))
				|| (((RemoteWebDriver) webDriver).getCapabilities().getBrowserName().toString().equalsIgnoreCase("MicrosoftEdge"))
						|| (((RemoteWebDriver) webDriver).getCapabilities().getBrowserName().toString().equalsIgnoreCase("Edge"))){
					return true;
		}else{
			return false;
		}
	}
	
	public boolean isSafari(){
		if((((RemoteWebDriver) webDriver).getCapabilities().getBrowserName().toString().equalsIgnoreCase("Safari"))
						&& (((RemoteWebDriver) webDriver).getCapabilities().getPlatform().toString().equalsIgnoreCase("mac"))){
			return true;
		}else{
			return false;
		}
	}
	
	
	/*
	 * To switch to new window using its Title
	 * @winHandle - window handle of current window
	 * @sValue - Title of new window 
	 */
	public boolean windowSwitch(String winHandle, Object sValue) {
		try {
			String title = sValue.toString();
			for (String handle : webDriver.getWindowHandles()) {
				if (!handle.equals(winHandle)) {
					webDriver.switchTo().window(handle);
					if (webDriver.getTitle().trim().equalsIgnoreCase(title)) {
						pass("Switch to window '" + title + "'", "Should switch to window '" + title + "'",
								"Switched to window '" + title + "'");
						return true;
					}
				}
			}
			return false;
		} catch (Exception e) {
			FrameworkLogger.log("Error while switching to Window. Exception: " + e.getMessage(), LEVEL.debug,
					this.getClass());
			return false;
		}
	}
	
	// Safari specific window Switch
	public boolean windowSwitch(Object sValue) {
		try {
			String title = sValue.toString();
			for (String handle : webDriver.getWindowHandles()) {
				
					webDriver.switchTo().window(handle);
					if (webDriver.getTitle().trim().equalsIgnoreCase(title)) {
						pass("Switch to window '" + title + "'", "Should switch to window '" + title + "'",
								"Switched to window '" + title + "'");
						return true;
				
					}
				
			}
			return false;
		} catch (Exception e) {
			System.out.println("Error while switching window");
			FrameworkLogger.log("Error while switching to Window. Exception: " + e.getMessage(), LEVEL.debug,
					this.getClass());
			return false;
		}
	}
	
	
	public void launchApplication(Object url) {
		String strStep = "Launch Application";
		String strExpected = "Applcation should launch URL: '" + url + "' successfully.";
		Capabilities cap = ((RemoteWebDriver) webDriver).getCapabilities();
		String platform = cap.getPlatform().toString();
		String browser = cap.getBrowserName().toString();
		String version = cap.getVersion().toString();

		boolean osState = false;
		try {
			if ((((RemoteWebDriver) webDriver).getCapabilities().getCapability("platformName").toString()
					.equalsIgnoreCase("iOS"))) {
				osState = true;
			}

		} catch (Exception e) {
			osState = false;
		}

		if (browser.isEmpty() || browser == null || browser.equals("")) {
			browser = "Unknown";
		}

		if (platform.isEmpty() || platform == null || platform.equals("")) {
			platform = "Unknown";
		}

		if (version.isEmpty() || version == null || version.equals("")) {
			version = "Unknown";
		}
		String osBrowserInfoStr = JsonFormatter.format(platform, browser, version);

		TestReportLogger.log(osBrowserInfoStr);

		try {
			if ((((RemoteWebDriver) webDriver).getCapabilities().getPlatform().toString().equalsIgnoreCase("ANDROID"))
					|| osState == true) {
			} else {

				
				webDriver.manage().window().maximize();
			}

			webDriver.get(url.toString());
			waitForPageToLoad(10);
			webDriver.manage().deleteAllCookies();
			pass(strStep, strExpected, "application launched successfully");
		} catch (Exception e) {
			FrameworkLogger.log("Error while launching the application. Exception: " + e.getMessage(), LEVEL.debug,
					this.getClass());
			fail(strStep, strExpected, "Failed to launch application");
		}
	}

	public void javaScriptClick(String sElement) {
		String reportEleName = formatElementName(sElement);
		try {
			JavascriptExecutor executor = (JavascriptExecutor) webDriver;
			if (getwebDriverLocator(getLocator(sElement)) != null) {
				WebElement element = getwebDriverLocator(getLocator(sElement));
				if(isMicrosoftEdge() || isSafari()) {
					executor.executeScript("var elem=arguments[0]; setTimeout(function() {elem.click();}, 100)", element);
				}else{
					executor.executeScript("arguments[0].click();", element);
				}
				
				pass("Click on '" + reportEleName + "'", "Should click the button '" + reportEleName + "'",
						"Clicked on  button '" + reportEleName + "'");
			} else {
				fail("Click on '" + reportEleName + "'", "Should click the button '" + reportEleName + "'",
						"Button '" + reportEleName + "' not found");
			}
		} catch (Exception e2) {
			e2.printStackTrace();
			fail("Click on '" + reportEleName + "'", "Should click the button '" + reportEleName + "'",
					"Error while clicking on Button '" + reportEleName + "'");
			FrameworkLogger.log("Error while clicking on Button '" + reportEleName + "'. Exception: " + e2.getMessage(),
					LEVEL.debug, this.getClass());
		}
	}
	
}
