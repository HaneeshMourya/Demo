package crossbrowser.library;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.List;
import org.apache.commons.lang3.RandomStringUtils;
import org.json.JSONObject;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MasterMenuItem {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();
	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private int rowCount = 1,rowInteration = 1;
	
	
//	public MasterMenuItem(WebDriver nodeDriver,Map inputData,Object or){
	public MasterMenuItem(WebDriver driver, Keywords actions, UIValidations uiActions, Map inputData, lib_MCD mcd, lib_RFM2 rfm){
		this.driver = driver;
		this.actions = actions;
		this.uiActions = uiActions;
		this.input = inputData;
		this.mcd = mcd;
		this.rfm = rfm;
		
//		mcd = new lib_MCD (driver, actions, uiActions, inputData);
//		rfm = new lib_RFM2 (driver, actions, uiActions, inputData, mcd);
	}
	
	@Test
	
	/*****************************************************************************
	 * Function Name: SearchMenuAndOpen()
	 * Date Created:14-Mar-2016
	 * Author : Archana Savanji
	 * Arguments: strMenuName - String. Menu name to search. for example: mnu_0351_PreRqM1.
	 * Description: This functions is used to search and open existing menu with default search filter setting. 
	 * This function will work for positive tests where menu is already created.
	 * Used in script : MNU_0351_MSU_VerifyMNUStatus
	
	 ******************************************************************************/
public void SearchMenuAndOpen(String strMenuName){
		
		System.out.println("*********************************** Start Test-Steps executions: Search Menu and Open");
		
		try{
			
			actions.setValue("ManageMenuItems.SearchText", strMenuName);
            actions.smartWait(3);
            
            actions.keyboardEnter("MasterMenuItemList.SearchButton");
            actions.smartWait(10);
            
            // Click searched row
            boolean bRowFound = driver.findElement(By.xpath(actions.getLocator("ManageMenuItems.MenuTableRow1"))).isDisplayed();
            System.out.println("Menu found status: " + bRowFound);
            if (bRowFound == true){
           	 try{
           	 String sMenuNo = driver.findElement(By.xpath(actions.getLocator("ManageMenuItems.MenuTableRow1"))).getText();
           	 System.out.println ("Menu Number is: "+sMenuNo);
           	 driver.findElement(By.xpath(actions.getLocator("ManageMenuItems.MenuTableRow1"))).click();
           	 
           	 mcd.SwitchToWindow("#Title");
           	  }
           	 catch(Exception err1){
//           		 System.out.println("Failed to click table row!");
           		 actions.catchException(err1);
           	 }
            }
            else{
           	 System.out.println("Menu is not displayed in search result table!");
            }            
            
		 }
	   catch (Exception err1){
//		   System.out.println("Error:" +err1);
		   actions.catchException(err1);
	   }
	   	
}
/*****************************************************************************
	 * Function Name: VerifyMenuStatus()
	 * Date Created:15-Mar-2016
	 * Author : Archana Savanji
	 * Arguments: strExpSatus - String. Expected Menu Status. for example: Active or Inactive.
	 * Description: This functions verify the status of menu (Active or Inactive). 
	 * Pre-rq to execute this function that "Manage Menu Items" page should be open with searched menu item.
	 * Used in script : MNU_0148_MMIL_StatusActiveCCEVM,MNU_0147_MMIL_StatusActiveCC
	
	 ******************************************************************************/
public void VerifyMenuStatus(String strExpSatus){
		
		System.out.println("*********************************** Start Test-Steps executions: Verify Menu Status");
		
		try{
		//	mcd.SwitchToWindow("Manage Menu Item");
            String strMnuStatusActual = driver.findElement(By.xpath(actions.getLocator("ManageMenuItems.PAStatus")))
					.getAttribute("value");
            
			if (strMnuStatusActual.equals(strExpSatus)) {
				actions.reportCreatePASS("Verify Menu status", "Expected Status : "+ strExpSatus,"Actual Status : "+ strMnuStatusActual, "Pass");
				System.out.println("Verify Menu status: Pass"+strMnuStatusActual );
			} else {
				actions.reportCreateFAIL("Verify Menu status", "Expected Status : "+ strExpSatus,"Actual Status : "+ strMnuStatusActual, "Fail");
				System.out.println("Verify Menu status: Fail"+strMnuStatusActual );

			}                                       
            
		 }
	   catch (Exception err1){
//		   System.out.println("Error:" +err1);
		   actions.catchException(err1);
	   }
   		
	
}

/*****************************************************************************
 * Function Name: SearchMenuAndChangeStatus()
 * Date Created:15-Mar-2016
 * Author : Archana Savanji
 * Arguments: strMenuName - String. Menu name to change status. strApplicationDate - String. Application Date., FEDate- integer. No of days to set Future date.
 * Description: This functions is used to change status of the Searched menu.
 * Used in script : MNU_0145_MMIL_StatusActiveEVM1

 ******************************************************************************/
	
	public void SearchMenuAndChangeStatus(String strMenuName,String strApplicationDate, int FEDate){
		
		System.out.println("*********************************** Start Test-Steps executions: Search Menu and Change Status");
		
		try{
			
			SearchMenuAndOpen(strMenuName);
			            
//            mcd.SwitchToWindow("#Title");
            
            // Click on Change status button
            boolean bChangeStatus = driver.findElement(By.xpath(actions.getLocator("ManageMenuItems.ChangeStatus"))).isDisplayed();
            if (bChangeStatus == true){
           	 actions.keyboardEnter("ManageMenuItems.ChangeStatus");
           	 Thread.sleep(1000);
//           	 actions.smartWait(10);
            }
            else{
           	 System.out.println("Change Status Button is not displayed!");
            }
            
            // Switch to window status change
            mcd.SwitchToWindow("Status Changes");
            actions.smartWait(5);
            
            // Click Add Status
            actions.keyboardEnter("StatusChanges.AddStatus");
            actions.smartWait(5);
            
            //Set Date
            driver.findElement(By.xpath(actions.getLocator("StatusChanges.datepicker"))).click();
            mcd.Get_future_date(FEDate, "Close",strApplicationDate);
            actions.smartWait(3);
           
            // Click Save button
            actions.keyboardEnter("StatusChanges.SaveBtn");
        //    actions.smartWait(5);
                                        
            
		 }
	   catch (Exception err1){
//		   System.out.println("Error:" +err1);
		   actions.catchException(err1);
	   }
	   
		
	
}

	/*****************************************************************************
	 * Function Name: AddNewMenuNameNo()
	 * Date Created:16-Mar-2016
	 * Date Updated:05-Aug-2016
	 * Author : Archana Savanji
	 * Arguments: String strMenuName,String strPType,String MIrange
	 * Description: This functions is used to Add New Menu with user inputs Menu Name and Number.
	 * Used in script : MNU_0139_MenuStatusDefault

	 ******************************************************************************/
	public void AddNewMenuNameNo(String strMenuName,String strPType,String MIrange){
								
			System.out.println("********************************************************************** Start Test-Steps executions: Add New Menu Item");
		
			int mi_num;
			
			WebElement ws=driver.findElement(By.xpath(actions.getLocator("MMIL.AddNewBtn")));
			ws.click();
			
			try{			  
			   Thread.sleep(3000);
			   actions.waitForPageToLoad(120);
			   actions.smartWait(60);
			   		   
			   mcd.SwitchToWindow("Add New Menu Item");	
			   actions.setValue("AddNewMI.MenuItemName",strMenuName);
			   boolean blnflag = true;
			   
			   do{
					
					mi_num=AutoGenerateMenuItemNumber (strPType,MIrange);
					actions.clear("AddNewMI.MenuItemNumber");
					actions.setValue("AddNewMI.MenuItemNumber", mi_num);
					actions.keyboardEnter("AddNewMI.Next");
					Thread.sleep(5000);
					
					boolean blnWindow = false;
					
					try{
						blnWindow = mcd.SwitchToWindow("@Manage Menu Items");
						if(blnWindow){
							System.out.println("Menu Name and Number is accepted successfully");
							blnflag = false;	
						}else{
							mcd.SwitchToWindow("Add New Menu Item");
							if (actions.isTextPresence("The entered number already exists in RFM2, Please enter another value", true)){
				            	 blnflag = true;
				            	 System.out.println("Entered  number "+mi_num+" is already exist.");
				               System.out.println(blnflag);
				             }
						}
						
					}catch(Exception err){
						if (actions.isTextPresence("The entered number already exists in RFM2, Please enter another value", true)){
			            	 blnflag = true;
			            	 System.out.println("Entered  number "+mi_num+" is already exist.");
			               System.out.println(blnflag);
			             }
					}

				}while(blnflag==true);
			   			  
			 }
		   catch (Exception err1){
			   System.out.println("Failed to open Add New Menu Item window! Error:" +err1);
		   }
		   
			
		
}

	/*****************************************************************************
	 * Function Name: NewMenuGeneralSettings()
	 * Date Created:15-Mar-2016
	 * Author : Archana Savanji
	 * Arguments: String strPType,String strPClass, String strPCategory, String strFG,String strPLName,String strPSName,String strPDTName,Boolean bPSave
	 * Description: This functions is used set values in General Setting tab.
	 * Used in script : MNU_0139_MenuStatusDefault

	 ******************************************************************************/
	public void NewMenuGeneralSettings(String strPType,String strPClass, String strPCategory, String strFG,String strPLName,String strPSName,String strPDTName,Boolean bPSave){
		
		try{
				
			System.out.println("********************************************************************** : Add New Menu Item - General Settings");
			
			String instance = mcd.GetGlobalData("Instance");
			if(instance.equalsIgnoreCase("QMAP") || instance.equalsIgnoreCase("AP")){
				actions.setValue("ManageMenuItemCurrentMenuItemDetails.MenuItemType", "SMI");
			}
			
			// actions.setValue("ManageMenuItem.ProductType",strPType);
			actions.setValue("ManageMenuItem.ProductClass", strPClass);
			actions.setValue("ManageMenuItem.ProductCategory", strPCategory);
			actions.setValue("ManageMenuItem.FamilyGroup",strFG);
			Select select =new Select(driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.DayPartCode"))));
			select.selectByIndex(1);
			actions.setValue("ManageMenuItem.ProductLName", strPLName);
			actions.setValue("ManageMenuItem.ProductSName",strPSName);
			actions.setValue("ManageMenuItem.ProductDTName", strPDTName);
			
			if (bPSave == true){
				Select select1 =new Select(driver.findElement(By.xpath(actions.getLocator("ManageMenuItems.PartialSave"))));
				// Select "Yes" option
				select1.selectByIndex(1);
			}
			else{
				Select select1 =new Select(driver.findElement(By.xpath(actions.getLocator("ManageMenuItems.PartialSave"))));
				// Select "No" option by default
				select1.selectByIndex(0);
			}		
			
		}catch (Exception err1){
			System.out.println("Failed to enter general settingd! Error: " + err1);
		}
	}
		/*****************************************************************************
	 * Function Name: AutoGenerateMenuItemNumber()
	 * Date Created:16-Mar-2016
	 * Author : Archana Savanji
	 * Arguments: String strPType,String MIrange
	 * Description: This functions is used generate Menu number based on menu and range.
	 * Used in script : MNU_0139_MenuStatusDefault

	 ******************************************************************************/	
public int AutoGenerateMenuItemNumber(String strPType,String MIrange){
	int mi_num=0;
		try{
				
			System.out.println("********************************************************************** : Auto Generate New Menu Item number");
			boolean blnflag=false;
			String[] strrange = MIrange.split("#");
			String s="";
			int mi_start=0,mi_end=0;
					
			try{
				boolean flag=false;
							
				switch (strPType) {
				case "CONTAINER_VALUE_MEAL":
					s = mcd.fn_GetRndName("Auto_CVM");
					mi_start=Integer.parseInt(strrange[4]);
					mi_end=Integer.parseInt(strrange[5]);
					break;
				case "PRODUCT":
					s = mcd.fn_GetRndName("Auto_Pro");
					mi_start=Integer.parseInt(strrange[4]);
					mi_end=Integer.parseInt(strrange[5]);
					break;
				case "VALUE_MEAL":
					s = mcd.fn_GetRndName("Auto_VM");
					mi_start=Integer.parseInt(strrange[4]);
					mi_end=Integer.parseInt(strrange[5]);
					break;
				case "CHOICE":
					s= mcd.fn_GetRndName("Auto_Choice");
					mi_start=Integer.parseInt(strrange[0]);
					mi_end=Integer.parseInt(strrange[1]);
					break;
				case "CHOICE_EVM":
					s= mcd.fn_GetRndName("Auto_ChoiceEVM");
					mi_start=Integer.parseInt(strrange[0]);
					mi_end=Integer.parseInt(strrange[1]);
					break;
				case "CHECK CATEGORY":
					s= mcd.fn_GetRndName("Auto_Check");
					mi_start=Integer.parseInt(strrange[2]);
					mi_end=Integer.parseInt(strrange[3]);
					break;
				case "NON_FOOD_PRODUCT":
					s = mcd.fn_GetRndName("Auto_NonPro");
					mi_start=Integer.parseInt(strrange[4]);
					mi_end=Integer.parseInt(strrange[5]);
					break;
				case "RAW_ITEM":
					s = mcd.fn_GetRndName("Auto_raw");
					mi_start=Integer.parseInt(strrange[4]);
					mi_end=Integer.parseInt(strrange[5]);
					break;
				case "EVM": 
					s= mcd.fn_GetRndName("Auto_EVM");
					mi_start=Integer.parseInt(strrange[4]);
					mi_end=Integer.parseInt(strrange[5]);
					break;
				case "COMMENT": 
					s= mcd.fn_GetRndName("Auto_CMNT");
					mi_start=Integer.parseInt(strrange[6]);
					mi_end=Integer.parseInt(strrange[7]);
					break;
				default:
					break;
				}
			}
			catch (Exception err){
				System.out.println ("Failed to select product range!");
			}
				System.out.println("product name:"+s);		
				mi_num=mcd.fn_GetRndNumInRange(mi_start, mi_end);				
			
		}
		catch (Exception err1){
			System.out.println("Failed to enter general settingd! Error: " + err1);
		}
		return mi_num;
}
	// ----------------------------------
		/*Feature Name : Master Menu Item List
		Functionality :Create Master Menu Item with or without copy existing
		@Param: MIrange- min limit and max limit ,MIparam-class,family group,category,strmsg -error message,strcopy-copy from existing yes or no
		Scenario ID : MNU_0098
		Author :Neha Manohar*/
		//-----------------------------------
	
		public int RFM_MI_CreateMenuItem_updated(String MIrange,String pro_type,String strmsg,String strmenutype){
		boolean blnflag=false;
		String[] strparam=strmenutype.split("#");
		String[] strrange = MIrange.split("#");
		String strerrmsg[]= strmsg.split("#");
		String s="";
		int mi_num=0,mi_start=0,mi_end=0;
		try{
			boolean flag=false;
			
			System.out.println("********************************************************************** Start Test-Steps executions");
			
			//	String MainWindow_NewMenuItem = driver.getWindowHandle();
			WebElement ws=driver.findElement(By.xpath("//*[@class='button button'][contains(text(),'Add New')]"));
			actions.click(ws);
		
			
			//actions.windowSwitch(MainWindow_NewMenuItem,"Add New Menu Item"); 
			mcd.SwitchToWindow("Add New Menu Item");
				
			switch (pro_type) {
			case "CONTAINER_VALUE_MEAL":
				s = "Auto_CVM_"+RandomStringUtils.randomAlphabetic(6);
				mi_start=Integer.parseInt(strrange[4]);
				mi_end=Integer.parseInt(strrange[5]);
				break;
			case "PRODUCT":
				s = "Auto_Pro_"+RandomStringUtils.randomAlphabetic(6);
				mi_start=Integer.parseInt(strrange[4]);
				mi_end=Integer.parseInt(strrange[5]);
				break;
			case "VALUE_MEAL":
				s = "Auto_VM_"+RandomStringUtils.randomAlphabetic(6);
				mi_start=Integer.parseInt(strrange[4]);
				mi_end=Integer.parseInt(strrange[5]);
				break;
			case "CHOICE":
				s= "Auto_Choice_"+RandomStringUtils.randomAlphabetic(6);
				mi_start=Integer.parseInt(strrange[0]);
				mi_end=Integer.parseInt(strrange[1]);
				break;
			case "CHOICE_EVM":
				s= mcd.fn_GetRndName("Auto_ChoiceEVM");
				mi_start=Integer.parseInt(strrange[0]);
				mi_end=Integer.parseInt(strrange[1]);
				break;
			case "CHECK CATEGORY":
				s= "Auto_Check_"+RandomStringUtils.randomAlphabetic(6);
				mi_start=Integer.parseInt(strrange[2]);
				mi_end=Integer.parseInt(strrange[3]);
				break;
			case "NON_FOOD_PRODUCT":
				s = "Auto_NonPro_"+RandomStringUtils.randomAlphabetic(6);
				mi_start=Integer.parseInt(strrange[4]);
				mi_end=Integer.parseInt(strrange[5]);
				break;
			case "RAW_ITEM":
				s = "Auto_NonPro_"+RandomStringUtils.randomAlphabetic(6);
				mi_start=Integer.parseInt(strrange[4]);
				mi_end=Integer.parseInt(strrange[5]);
				break;
			case "EVM": 
				s= "Auto_NonPro_"+RandomStringUtils.randomAlphabetic(6);
				mi_start=Integer.parseInt(strrange[4]);
				mi_end=Integer.parseInt(strrange[5]);
				break;
			case "COMMENT": 
				s= "Auto_CMNT_"+RandomStringUtils.randomAlphabetic(6);
				mi_start=Integer.parseInt(strrange[6]);
				mi_end=Integer.parseInt(strrange[7]);
				break;
			default:
				break;
			}
			
			System.out.println("product name:"+s);		
			actions.setValue("AddNewMI.MenuItemName",s);
			
				do{
				mi_num=mcd.fn_GetRndNumInRange(mi_start, mi_end);
				actions.clear("AddNewMI.MenuItemNumber");
				actions.setValue("AddNewMI.MenuItemNumber", mi_num);
				actions.keyboardEnter("AddNewMI.Next");
				Thread.sleep(3000);
				actions.waitForPageToLoad(180);
				boolean blnWindow = false;
				
				try{
					blnWindow = mcd.SwitchToWindow("@Manage Menu Items");
					if(blnWindow){
						System.out.println("Menu Name and Number is accepted successfully");
						blnflag = false;	
					}else{
						mcd.SwitchToWindow("Add New Menu Item");
						if (actions.isTextPresence(strerrmsg[0], true)){
			            	 blnflag = true;
			            	 System.out.println("Entered  number "+mi_num+" is already exist.");
			               System.out.println(blnflag);
			             }
					}
					
				}catch(Exception err){
					if (actions.isTextPresence(strerrmsg[0], true)){
		            	 blnflag = true;
		            	 System.out.println("Entered  number "+mi_num+" is already exist.");
		               System.out.println(blnflag);
		             }
				}

			}while(blnflag==true);
				
		//SETTING THE VALUE OF THE MANDATORY FIELDS
		String instance = mcd.GetGlobalData("Instance");
		if(instance.equalsIgnoreCase("AP") || instance.equalsIgnoreCase("QMAP") || instance.equalsIgnoreCase("EU")){
		actions.setValue("ManageMenuItemCurrentMenuItemDetails.MenuItemType", "SMI");
		}
		actions.setValue("ManageMenuItem.ProductClass",pro_type );
		actions.setValue("ManageMenuItem.ProductCategory", strparam[0]);
		actions.setValue("ManageMenuItem.FamilyGroup", strparam[1]);
		Select select =new Select(driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.DayPartCode"))));
		select.selectByIndex(1);
		actions.setValue("ManageMenuItem.ProductLName", s+"LN");
		actions.setValue("ManageMenuItem.ProductSName", s+"SN");
		actions.setValue("ManageMenuItem.ProductDTName", s+"DN");

		actions.click("ManageMenuItem.ApplySavebtn");
		actions.smartWait(180);
		
		if(pro_type.equals("CHOICE")|| pro_type.equals("CHOICE_EVM")||pro_type.equals("CHECK CATEGORY")){
			mcd.VerifyAlertMessageDisplayed(strerrmsg[4], strerrmsg[4],true,AlertPopupButton.OK_BUTTON);
			flag =true;
		}
		actions.verifyTextPresence(strerrmsg[2],true);
		 if(flag==false)
		 {
			actions.reportCreatePASS("Verify creation of Menu Item", "Menu Item of '"+pro_type+"' should be created",
					"Menu Item of '"+pro_type+"' is created", "Pass");
		 }
	  
	  //CLICKING CANCEL BUTTON TO NAVIGATE TO MAIN PAGE
	  actions.click("ManageMenuItem.Cancelbtn1");
	  actions.smartWait(180);
	  
	    }catch(Exception e){
		actions.reportCreateFAIL("Verify creation of Menu Item", "Menu Item of '"+pro_type+"' should be created",
				"Menu Item of '"+pro_type+"' is not created", "Fail");
		}
	return mi_num;
	}
	
	////====
	///
	//====
public void CopyExistingMI(String MIrange,String mi_num,String strmsg,boolean blnflag ) throws Exception{	
	
	//splitting the MI range
	String[] strrange = MIrange.split("#");
	String[] ermsg = strmsg.split("#");
	
	
	//Copying the menu Item number now
    actions.click("AddNewMI.Yes_rbtn");
    Thread.sleep(2000);
    //clicking on the select button
    actions.click("AddNewMI.selectbtn");
    Thread.sleep(1000);
    
    //Switching to New Pop up window
    mcd.SwitchToWindow("Copy Settings From Existing Menu Item");
    
    //Copy Settings From Existing Menu Item : Find Menu Item
    
    //searching for the specific Menu item
    actions.click("COPYMI.exactrbtn");
    actions.setValue("COPYMI.searchtextbox",mi_num );
    actions.click("COPYMI.searchbtn");
    Thread.sleep(1000);
    actions.waitForPageToLoad(120);
    
    //Select web table record now
   WebElement record = mcd.GetTableCellElement("COPYMI.datatable", 1, "Number", "a");
    record.click();
    Thread.sleep(2000);
    
    //switching to back to previous window
    mcd.SwitchToWindow("Add New Menu Item");
   
    actions.setValue("AddNewMI.MenuItemName", mcd.fn_GetRndName("VM_") );
    
  
    do{
    //Entering Name and number in the fields
       
    int mi_start= Integer.parseInt(strrange[4]); /// Getting the random number 
	int mi_end= Integer.parseInt(strrange[5]);  ////
	
	actions.clear("AddNewMI.MenuItemNumber"); 
    actions.setValue("AddNewMI.MenuItemNumber", mcd.fn_GetRndNumInRange(mi_start,mi_end));
    
    //reading value from the text box
    String menu_num = actions.getValue("AddNewMI.MenuItemNumber");
	actions.click("AddNewMI.Next");
	
	//===
	mcd.SwitchToWindow("Master Menu Item List");
	 try
	 {
		mcd.SwitchToWindow("Add New Menu Item");
		if (actions.isTextPresence(ermsg[0], true)){
         blnflag = true;
         //Reporter.log("Entered  number "+menu_num+" is already exist.");
         System.out.println(blnflag);
             										}
	 }catch(Exception e){
				blnflag = false;
				Thread.sleep(3000);
				mcd.SwitchToWindow("#Title");
	            //Reporter.log("Menu Name and Number is accepted successfully");
	            System.out.println(driver.getWindowHandles());
	 }
			}while(blnflag==true);

}	
/* Feature Name : Master Menu Item List
Functionality :Add a new mwnu item through copying existing menu item 
Scenario ID : MNU_1139
Author :Santosh Tangudu*
*/

public void CopyExistingMI_Other(String MIrange,String mi_num,String strmsg,boolean blnflag ) throws Exception{	
	
	//splitting the MI range
	String[] strrange = MIrange.split("#");
	String[] ermsg = strmsg.split("#");
	
	
	//Copying the menu Item number now
    actions.click("AddNewMI.Yes_rbtn");
    Thread.sleep(3000);
    //clicking on the select button
    actions.click("AddNewMI.selectbtn");
    Thread.sleep(2000);
    
    //Switching to New Pop up window
    //mcd.SwitchToWindow("Copy Settings From Existing Menu Item");
    mcd.SwitchToWindow("Copy Settings From Existing Menu Item : Find Menu Item");
    //Copy Settings From Existing Menu Item : Find Menu Item
    
    //searching for the specific Menu item
    //actions.click("COPYMI.exactrbtn");
    //actions.setValue("COPYMI.searchtextbox",mi_num );
    actions.click("COPYMI.searchbtn");
    Thread.sleep(2000);
    actions.waitForPageToLoad(120);
    
    //Select web table record now
   WebElement record = mcd.GetTableCellElement("COPYMI.datatable", 1, "Number", "a");
    record.click();
    Thread.sleep(3000);
    
    //switching to back to previous window
    mcd.SwitchToWindow("Add New Menu Item");
   
    actions.setValue("AddNewMI.MenuItemName", mcd.fn_GetRndName("VM_") );
    
  
    do{
    //Entering Name and number in the fields
       
    int mi_start= Integer.parseInt(strrange[4]); /// Getting the random number 
	int mi_end= Integer.parseInt(strrange[5]);  ////
	
	actions.clear("AddNewMI.MenuItemNumber"); 
    actions.setValue("AddNewMI.MenuItemNumber", mcd.fn_GetRndNumInRange(mi_start,mi_end));
    
    //reading value from the text box
    String menu_num = actions.getValue("AddNewMI.MenuItemNumber");
	actions.click("AddNewMI.Next");
	
	//===
	Thread.sleep(2000);
	boolean blnWindow = false;
	
	try{
		blnWindow = mcd.SwitchToWindow("@Manage Menu Items");
		if(blnWindow){
			System.out.println("Menu Name and Number is accepted successfully");
			blnflag = false;	
		}else{
			
			mcd.SwitchToWindow("Add New Menu Item");
			if (actions.isTextPresence(ermsg[0], true)){
            	 blnflag = true;
            	 System.out.println("Entered  number "+mi_num+" is already exist.");
               System.out.println(blnflag);
             }
		}
		
	}catch(Exception err){
		if (actions.isTextPresence(ermsg[0], true)){
        	 blnflag = true;
        	 System.out.println("Entered  number "+mi_num+" is already exist.");
           System.out.println(blnflag);
         }
	}
	
	
	
//	mcd.SwitchToWindow("Master Menu Item List");
//	 try
//	 {
//		mcd.SwitchToWindow("Add New Menu Item");
//		if (actions.isTextPresence(ermsg[0], true)){
//         blnflag = true;
//         Reporter.log("Entered  number "+menu_num+" is already exist.");
//         System.out.println(blnflag);
//             										}
//	 }catch(Exception e){
//				blnflag = false;
//				Thread.sleep(6000);
//				mcd.SwitchToWindow("#Title");
//	            Reporter.log("Menu Name and Number is accepted successfully");
//	            System.out.println(driver.getWindowHandles());
//	 }
			}while(blnflag==true);

}	

///===============
	/* Feature Name : Master Menu Item List
		Functionality :Invalid search menu item 
		Scenario ID : MNU_0088
		Author :Neha Manohar*
	 */
		public void RFM_MI_SearchMenuItem(String strsearchvalue) {
			String strPageTitle = "Master Menu Item List";
			String strPageSubHeading = "Master Menu Item List";
			String expmsg= "Search returned no matching results.";
			
			try{
				System.out.println("********************************************************************** Start Test-Steps executions");
			
			//Action specific to test flow
			System.out.println("> Click on exact match radio button");
			actions.smartWait(1000);
			actions.waitForPageToLoad(1000);
			actions.keyboardEnter("MasterMenuItemList.exactbtn");
			actions.keyboardEnter("MasterMenuItemList.exactbtn");
			actions.setValue("MasterMenuItemList.Searchfield",strsearchvalue);
			actions.keyboardEnter("MasterMenuItemList.Searchbtn");
//			Thread.sleep(5000);
			actions.smartWait(180);
			String message=actions.getValue("MasterMenuItemList.errmsg").toString();
			System.out.println("> enter search value");
			System.out.println(expmsg.equals(message));
			if (expmsg.equals(message)){
				actions.reportCreatePASS("Verify the Expected msg as '"+expmsg+"' is displayed or not", "Expected msg as '"+expmsg+"' is displayed", "Expected msg as '"+expmsg+"' is displayed", "Pass");
				
			}
			else{
				
				actions.reportCreateFAIL("Verify the Expected msg as '"+expmsg+"' is displayed or not", "Expected msg as '"+expmsg+"' is displayed", "Expected msg as '"+expmsg+"' is not displayed", "Fail");
					
			}
					
				
			}catch(Exception e){
//				System.out.println("Test Failed :: " + e.getCause() + " - " +  e.getMessage());
				actions.catchException(e);
			}
//			finally{
//				actions.verifyTestCase(this.getClass());
//			}
	
		}
		
		/* Feature Name : Master Menu Item List
		Functionality :Search by menu item number and name 
		Scenario ID : MNU_0087
		Author :Neha Manohar*
		 */
		public void MI_SearchMenuitem(){
			
			try{
				System.out.println("********************************************************************** Start Test-Steps executions");
			
				//Action specific to test flow
				actions.keyboardEnter("MasterMenuItemList.Searchbtn");
//				actions.waitForPageToLoad(9000);
//				Thread.sleep(6000);
				actions.smartWait(180);
				List<WebElement> xpaths = driver.findElements(By.xpath("//*[@id='menuItemsData']/tr"));
				
				//begins with radio button
				actions.keyboardEnter("MasterMenuItemList.begin_rbtn");
				actions.getwebDriverLocator(actions.getLocator("MasterMenuItemList.begin_rbtn")).sendKeys(Keys.SPACE);
				actions.clear("MasterMenuItemList.Searchfield");
				actions.setValue("MasterMenuItemList.Searchfield", "a");
				Thread.sleep(3000);
				actions.keyboardEnter("MasterMenuItemList.Searchbtn");
				actions.waitForPageToLoad(1000);
//				Thread.sleep(3000);
				actions.smartWait(1000);
				
				//added by Rehanshu
				rowCount = driver.findElements(By.xpath("//*[@id='menuItemsData']/tr/td[2]")).size();
				if(rowCount>4){
					rowInteration = 5;
				}
				for (int i = 1;i<rowInteration;i++){
				String values=driver.findElement(By.xpath("//*[@id='menuItemsData']/tr["+i+"]/td[2]")).getAttribute("name");
				String valuesNameCol =driver.findElement(By.xpath("//*[@id='menuItemsData']/tr["+i+"]/td[2]")).getText();
				values = mcd.GetTableCellValue("MasterMenuItemList.datatable", i, 2, "", "");
				if(values.toLowerCase().startsWith("a") || valuesNameCol.toLowerCase().startsWith("a")){
					actions.reportCreatePASS("Verify the Menu item "+values+" begining with 'a' is displayed or not ", "Menu item "+values+" begining with 'a' should get displayed", "Menu item "+values+" begining with 'a' is displayed", "Pass");
					
				}else{
					actions.reportCreatePASS("Verify the Menu item "+values+" begining with 'a' is displayed or not ", "Menu item "+values+" begining with 'a' should get displayed", "Menu item "+values+" begining with 'a' is not displayed", "Fail");
				}			
				}
				
				//ends with radio button
				actions.smartWait(1000);
				actions.waitForPageToLoad(500);
				actions.keyboardEnter("MasterMenuItemList.end_rbtn");
				actions.getwebDriverLocator(actions.getLocator("MasterMenuItemList.end_rbtn")).sendKeys(Keys.SPACE);
				actions.clear("MasterMenuItemList.Searchfield");
				actions.setValue("MasterMenuItemList.Searchfield", "a");
				actions.keyboardEnter("MasterMenuItemList.Searchbtn");
				actions.waitForPageToLoad(1000);
//				Thread.sleep(3000);
				actions.smartWait(1000);
				actions.waitForPageToLoad(1000);
				rowCount = driver.findElements(By.xpath("//*[@id='menuItemsData']/tr/td[2]")).size();
				if(rowCount>4){
					rowInteration = 5;
				}
				for (int i = 1;i<rowInteration;i++){
					String values=driver.findElement(By.xpath("//*[@id='menuItemsData']/tr["+i+"]/td[2]")).getText();
					String valuesNameCol =driver.findElement(By.xpath("//*[@id='menuItemsData']/tr["+i+"]/td[1]")).getText();
					if(values.toLowerCase().endsWith("a") || valuesNameCol.toLowerCase().endsWith("a")){
						
						actions.reportCreatePASS("Verify the Menu item"+values+" ending with 'a' is displayed or not" , "Menu item"+values+" ending with 'a' should get displayed", "Menu item"+values+" ending with 'a' is displayed", "Pass");
						
					}else{
						actions.reportCreateFAIL("Verify the Menu item"+values+" ending with 'a' is displayed or not" , "Menu item"+values+" ending with 'a' should get displayed", "Menu item"+values+" ending with 'a' is not displayed", "Fail");
						
					}			
					}
				
				//conatins radio button
				actions.keyboardEnter("MasterMenuItemList.contain_rbtn");
				actions.getwebDriverLocator(actions.getLocator("MasterMenuItemList.contain_rbtn")).sendKeys(Keys.SPACE);
				actions.clear("MasterMenuItemList.Searchfield");
				actions.setValue("MasterMenuItemList.Searchfield", "a");
				actions.keyboardEnter("MasterMenuItemList.Searchbtn");
//				actions.waitForPageToLoad(9000);
//				Thread.sleep(3000);
				actions.smartWait(1000);
				rowCount = driver.findElements(By.xpath("//*[@id='menuItemsData']/tr/td[2]")).size();
				if(rowCount>2){
					rowInteration = 3;
				}
					for (int i = 1;i<rowInteration;i++){
						String values=driver.findElement(By.xpath("//*[@id='menuItemsData']/tr["+i+"]/td[2]")).getText();
						String valuesNameCol =driver.findElement(By.xpath("//*[@id='menuItemsData']/tr["+i+"]/td[1]")).getText();
						if(values.toLowerCase().contains("a") || valuesNameCol.toLowerCase().contains("a")){
					    actions.reportCreatePASS("Verify the Menu item "+values+" containing 'a' is displayed or not" , "Menu item "+values+" containing 'a' should get displayed", "Menu item "+values+" containing 'a' is displayed", "Pass");
						
					}else{
						actions.reportCreateFAIL("Verify the Menu item "+values+" containing 'a' is displayed or not" , "Menu item "+values+" containing 'a' should get displayed", "Menu item "+values+" containing 'a' is not displayed", "Fail");
						
					}			
					}
				 /*Verify menu item number search functionality*/
				//contains radio button
				actions.keyboardEnter("MasterMenuItemList.contain_rbtn");
				actions.getwebDriverLocator(actions.getLocator("MasterMenuItemList.contain_rbtn")).sendKeys(Keys.SPACE);
				actions.clear("MasterMenuItemList.Searchfield");
				actions.setValue("MasterMenuItemList.Searchfield", "1");
				actions.keyboardEnter("MasterMenuItemList.Searchbtn");
//				actions.waitForPageToLoad(9000);
//				Thread.sleep(3000);
				actions.smartWait(1000);
				rowCount = driver.findElements(By.xpath("//*[@id='menuItemsData']/tr/td[1]")).size();
				if(rowCount>4){
					rowInteration = 5;
				}
					for (int i = 1;i<5;i++){
						String values=driver.findElement(By.xpath("//*[@id='menuItemsData']/tr["+i+"]/td[1]")).getText();
						String valuesNameCol =driver.findElement(By.xpath("//*[@id='menuItemsData']/tr["+i+"]/td[2]")).getText(); 
						if(values.contains("1") || valuesNameCol.contains("1")){
							actions.reportCreatePASS("Verify the Menu item "+values+" containing '1' is displayed or not", "Menu item "+values+" containing '1' should get displayed", "Menu item "+values+" containing '1' is displayed", "Pass");
							
						}else{
							actions.reportCreateFAIL("Verify the Menu item "+values+" containing '1' is displayed or not", "Menu item "+values+" containing '1' should get displayed", "Menu item "+values+" containing '1' is not displayed", "Fail");
						
						}			
						}
				/*begins with*/
				actions.keyboardEnter("MasterMenuItemList.begin_rbtn");
				actions.getwebDriverLocator(actions.getLocator("MasterMenuItemList.begin_rbtn")).sendKeys(Keys.SPACE);
				actions.clear("MasterMenuItemList.Searchfield");
				actions.setValue("MasterMenuItemList.Searchfield", "2");
				actions.keyboardEnter("MasterMenuItemList.Searchbtn");
//				actions.waitForPageToLoad(9000);
//				Thread.sleep(3000);
				actions.waitForPageToLoad(9000);
				actions.smartWait(1000);
				rowCount = driver.findElements(By.xpath("//*[@id='menuItemsData']/tr/td[1]")).size();
				if(rowCount>4){
					rowInteration = 5;
				}
					for (int i = 1;i<5;i++){
						String values=driver.findElement(By.xpath("//*[@id='menuItemsData']/tr["+i+"]/td[1]")).getText();
						String values_1 = mcd.GetTableCellValue("MasterMenuItemList.datatable", i, 2, "", "");
						if((values.startsWith("2")) || (values_1.startsWith("2"))){
							actions.reportCreatePASS("Verify the Menu item "+values+" containing '2' is displayed not " , "Menu item "+values+" containing '2' should get displayed", "Menu item "+values+" containing '2' is displayed","Pass");

						}else{
							actions.reportCreateFAIL("Verify the Menu item "+values+" containing '2' is displayed not " , "Menu item "+values+" containing '2' should get displayed", "Menu item "+values+" containing '2' is not displayed","Fail");
							
						}			
						}	
				
				/*ends with*/
				actions.keyboardEnter("MasterMenuItemList.end_rbtn");
				actions.getwebDriverLocator(actions.getLocator("MasterMenuItemList.end_rbtn")).sendKeys(Keys.SPACE);
				actions.clear("MasterMenuItemList.Searchfield");
				actions.setValue("MasterMenuItemList.Searchfield", "3");
				actions.keyboardEnter("MasterMenuItemList.Searchbtn");
				actions.waitForPageToLoad(9000);
//				Thread.sleep(3000);
				actions.smartWait(180);
				rowCount = driver.findElements(By.xpath("//*[@id='menuItemsData']/tr/td[1]")).size();
				if(rowCount>4){
					rowInteration = 5;
				}
					for (int i = 1;i<rowInteration;i++){
						String values=driver.findElement(By.xpath("//*[@id='menuItemsData']/tr["+i+"]/td[1]")).getText();
						String valuesNameCol =driver.findElement(By.xpath("//*[@id='menuItemsData']/tr["+i+"]/td[2]")).getText();
						if(values.endsWith("3") || valuesNameCol.endsWith("3")){
							actions.reportCreatePASS("Verify the Menu item "+values+" containing '3' is displayed or not" , "Menu item "+values+" containing '3' should get displayed", "Menu item "+values+" containing '3' is displayed", "Pass");
							
						}else{
							actions.reportCreateFAIL("Verify the Menu item "+values+" containing '3' is displayed or not" , "Menu item "+values+" containing '3' should get displayed", "Menu item "+values+" containing '3' is not displayed", "Fail");
						
						}			
						}		
						
			}catch(Exception e){
//				System.out.println("Test Failed :: " + e.getCause() + " - " +  e.getMessage());
				actions.catchException(e);
				}
//				finally{
//					actions.verifyTestCase(this.getClass());
//				}
		
			}

		/*Feature Name : Menu Item Set
		Functionality :Create new menu item set without copy from existing as NO
		Scenario ID : MNU_0001
		Author :Neha Manohar*
		 */
		
		
		public String MNU_0001_CreateMenuItemSet(){
            String s="";
            try{
            System.out.println("********************************************************************** Start Test-Steps executions");
            //Reporter.log("----> Steps to create menu item set with copy from existing setting as NO ");
            //Action specific test flow
            actions.click("MenuItemSets.NewMenuItemSet");
            Thread.sleep(2000);
            
            //switch to new menu item set window
            mcd.SwitchToWindow("Add New Menu Item Set");
            
            //menu item set name
            s= mcd.fn_GetRndName("Auto");
            actions.setValue("MenuItemSets.MenuItemSetName", s);
            actions.keyboardEnter("MenuItemSets.Selectbtn");
            Thread.sleep(2000);
            
            mcd.SwitchToWindow("Select Node"); 
            
            mcd.Selectrestnode("MenuItemSets.LeftTable", "Australia");
            
            Thread.sleep(2000);
            mcd.SwitchToWindow("Add New Menu Item Set");                          


            actions.click("MenuItemSets.Nextbtn");
            Thread.sleep(3000);
            mcd.SwitchToWindow("@Manage Menu Item Set : Common Menu Item Selector");

            actions.keyboardEnter("AddRemoveMenu.ViewFullList");
            actions.smartWait(120);
            actions.setValue("AddRemoveMenu.Availability","Available");
            Thread.sleep(2000);
            actions.smartWait(180);
            List<WebElement> Add_Chkbox = driver.findElements(By.xpath(".//input[@type = 'checkbox'][contains(@onclick, 'addMenuItem')]"));
            int Item_Counts = Add_Chkbox.size();
            int i_temp = 0;
            for (int n=0; n< Item_Counts; n++){
                            //Check whether enabled for Add or not
                            if((Add_Chkbox.get(n).isEnabled())){
                                            //Check box enabled - Add Item
                                            Add_Chkbox.get(n).sendKeys(Keys.SPACE);
                                            i_temp++;
                            }else{
                                            System.out.println("This MI is already added");                                                 
                            }
                            
                            if (i_temp==2){
                                            System.out.println("Selected 3 items for Add MI");
                                            break;
                            }
                            Thread.sleep(500);
            }
            
            actions.keyboardEnter("AddRemoveMenu.Savebtn");
            actions.smartWait(120);                
            actions.verifyTextPresence("Your changes have been saved.", true);
            Thread.sleep(2000);
            actions.keyboardEnter("MenuItemSets.ReturnToSet");
            actions.smartWait(120);
            
            mcd.SwitchToWindow("#Title");
            
            }catch(Exception e){
//            e.printStackTrace();
            //Reporter.log("Failed Test"+e.getMessage());
            	actions.catchException(e);
			}
			return s;
			}


		
		/*public String MNU_0001_CreateMenuItemSet(){
			String s="";
		try{
			System.out.println("********************************************************************** Start Test-Steps executions");
			Reporter.log("----> Steps to create menu item set with copy from existing setting as NO ");
			//Action specific test flow
			String MainWindow_NewMenuItem = driver.getWindowHandle();
			System.out.println("Title :" +driver.getTitle());
			actions.click("MenuItemSets.NewMenuItemSet");
			actions.waitForPageToLoad(15);
			Thread.sleep(3000);
				
			//switch to new menu item set window
			actions.windowSwitch(MainWindow_NewMenuItem,"Add New Menu Item Set"); 
			System.out.println("Title :" +driver.getTitle());
			
			//menu item set name
			s= mcd.fn_GetRndName("Auto");
			actions.setValue("MenuItemSets.MenuItemSetName", s);
			
			String MainWindow_NewMenuItem1 = driver.getWindowHandle();
			System.out.println(MainWindow_NewMenuItem1);
			System.out.println("Title :" +driver.getTitle());
			
			actions.keyboardEnter("MenuItemSets.Selectbtn");
			Thread.sleep(6000);
			actions.WaitForWindowToBe(3,10);
			actions.windowSwitch(MainWindow_NewMenuItem1,"Select Node"); 
			System.out.println("Title :" +driver.getTitle());
			mcd.Selectrestnode("MenuItemSets.LeftTable", "Australia");
			
			Thread.sleep(5000);
			System.out.println(driver.getWindowHandles());
			actions.windowSwitch(MainWindow_NewMenuItem1, "Add New Menu Item Set");
			Thread.sleep(5000);
			System.out.println("Title :" +driver.getTitle());
			                 
                     
            
            Thread.sleep(6000);
			actions.keyboardEnter("MenuItemSets.Nextbtn");
			actions.waitForPageToLoad(9000);
			Thread.sleep(6000);
			System.out.println("Title :" +driver.getWindowHandles());
			driver.switchTo().window(MainWindow_NewMenuItem);
			
			actions.keyboardEnter("AddRemoveMenu.ViewFullList");
			actions.waitForPageToLoad(6000);
			Thread.sleep(6000);
			actions.setValue("AddRemoveMenu.Availability","Available");
			actions.waitForPageToLoad(6000);
			Thread.sleep(7000);
			List<WebElement> Add_Chkbox = driver.findElements(By.xpath(".//input[@type = 'checkbox'][contains(@onclick, 'addMenuItem')]"));
			int Item_Counts = Add_Chkbox.size();
			int i_temp = 0;
			for (int n=0; n< Item_Counts; n++){
				//Check whether enabled for Add or not
				if((Add_Chkbox.get(n).isEnabled())){
					//Check box enabled - Add Item
					Add_Chkbox.get(n).sendKeys(Keys.SPACE);
					i_temp++;
				}else{
					System.out.println("This MI is already added");				
				}
				
				if (i_temp==2){
					System.out.println("Selected 3 items for Add MI");
					break;
				}
				Thread.sleep(1000);
			}
			
			actions.keyboardEnter("AddRemoveMenu.Savebtn");
			actions.waitForPageToLoad(10000);
			Thread.sleep(3000);		
			actions.verifyTextPresence("Your changes have been saved.", true);
			Thread.sleep(2000);
			actions.keyboardEnter("MenuItemSets.ReturnToSet");
			Thread.sleep(2000);
			actions.waitForPageToLoad(10000);
			
		}catch(Exception e){
			e.printStackTrace();
			Reporter.log("Failed Test"+e.getMessage());
		}
		return s;
		}*/
		
		/*Feature Name : Menu Item Set
		Functionality : Verify field level error mgs while creating menu item set
		Scenario ID : MNU_0003
		Author :Neha Manohar*
		 */
		public void MNU_0003_MenuItemSetFieldValidation(String strmsg,String strrest)throws InterruptedException{
			String[] errmsg= strmsg.split("#");
				//Reporter.log("----> Verify sorting,pagination,search and field level error messages while creating a new menu item set.");
				//Reporter.log("Verify view full list functionality");
				actions.keyboardEnter("MenuItemSets.ViewFullList");
				actions.waitForPageToLoad(10000);
//				Thread.sleep(5000);
				actions.smartWait(180);
				//Verify sorting for menu item set  name
				actions.keyboardEnter("MenuItemSets.SortName");
				actions.waitForPageToLoad(10000);
				Thread.sleep(5000);
				actions.smartWait(180);
				//Reporter.log("Sort records by menu item set name in descending order");
				//Reporter.log("Verify down arrow is displayed");
				boolean blnflag=mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.SortNameDownImage");
				if(blnflag){
					//Reporter.log("Down sorting arrow on menu item set is displayed.");
					actions.reportCreatePASS("Verify Down Sort arrow on Menu item set", "Down Sort arrow should be displayed", "Down Sort arrow is displayed", "PASS");
					//System.out.println("Down sorting arrow on menu item set is displayed.");
				}else{
//					Reporter.log("Down sorting arrow on menu item set is not displayed.");
//					System.out.println("Down sorting arrow on menu item set is not displayed.");
					actions.reportCreateFAIL("Verify Down Sort arrow on Menu item set", "Down Sort arrow should be displayed", "Down Sort arrow is not displayed", "FAIL");
				}
//				Thread.sleep(5000);
				actions.keyboardEnter("MenuItemSets.SortName");
				actions.waitForPageToLoad(10000);
//				Thread.sleep(5000);
				actions.smartWait(180);
//				Reporter.log("Sort records by menu item set name in ascending order");
//				Reporter.log("Verify up arrow is displayed");
				boolean blnflag2=mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.SortNameUpImage");
				if(blnflag2){
//					Reporter.log("Up sorting arrow on menu item set is displayed.");
//					System.out.println("Up sorting arrow on menu item set is displayed.");
					actions.reportCreatePASS("Verify Up Sort arrow on Menu item set", "Up Sort arrow should be displayed", "Up Sort arrow is displayed", "PASS");
				}else{
//					Reporter.log("Up sorting arrow on menu item set is not displayed.");
//					System.out.println("Up sorting arrow on menu item set is not displayed.");
					actions.reportCreateFAIL("Verify Up Sort arrow on Menu item set", "Up Sort arrow should be displayed", "Up Sort arrow is not displayed", "FAIL");
				}
//				Thread.sleep(5000);
				//verify sorting for node name
				actions.keyboardEnter("MenuItemSets.SortNode");
				actions.waitForPageToLoad(10000);
				Thread.sleep(5000);
				actions.smartWait(180);
//				Reporter.log("Sort records by menu item set name in descending order");
//				Reporter.log("Verify down arrow is displayed");
				boolean blnflag3=mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.SortNodeUpImage");
				if(blnflag3){
//					Reporter.log("Up sorting arrow on Node Name is displayed.");
//					System.out.println("Up sorting arrow on Node Name is displayed.");
					actions.reportCreatePASS("Verify Up Sort arrow on Node Name", "Up Sort arrow should be displayed", "Up Sort arrow is displayed", "PASS");
				}else{
//					Reporter.log("Up sorting arrow on Node Name is not displayed.");
//					System.out.println("Up sorting arrow on Node Name is not displayed.");
					actions.reportCreateFAIL("Verify Up Sort arrow on Node Name", "Up Sort arrow should be displayed", "Up Sort arrow is not displayed", "FAIL");
				}
//				Thread.sleep(5000);
				actions.keyboardEnter("MenuItemSets.SortNode");
				actions.waitForPageToLoad(10000);
//				Thread.sleep(5000);
				actions.smartWait(180);
//				Reporter.log("Sort records by node name in ascending order");
//				Reporter.log("Verify up arrow is displayed");
				boolean blnflag4=mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.SortNodeDownImage");
				if(blnflag4){
//					Reporter.log("Down sorting arrow on Node Name is displayed.");
//					System.out.println("Down sorting arrow on Node Name is displayed.");
					actions.reportCreatePASS("Verify Down Sort arrow on Node Name", "Down Sort arrow should be displayed", "Down Sort arrow is displayed", "PASS");
				}else{
//					Reporter.log("Down sorting arrow on Node Name is not displayed.");
//					System.out.println("Down sorting arrow on Node Name is not displayed.");
					actions.reportCreateFAIL("Verify Down Sort arrow on Node Name", "Down Sort arrow should be displayed", "Down Sort arrow is not displayed", "FAIL");
				}
//				Thread.sleep(8000);
				//Verify pagination
//				Reporter.log("Verify pagination on menu item sets.");
//				System.out.println("Verify pagination on menu item sets.");
				if(mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.pagnext")){
//					Reporter.log("Next pagination link is displayed");
//					System.out.println("Next pagination link is displayed");
					actions.reportCreatePASS("Verify Next pagination link", "Next pagination link should be displayed", "Next pagination link is displayed", "PASS");
//					Reporter.log("Clicke on next link");
					actions.keyboardEnter("MenuItemSets.pagnext");
//					actions.waitForPageToLoad(5000);
//					Thread.sleep(6000);
					actions.smartWait(180);
				}else{
//					Reporter.log("Sufficient records not found for pagination");
//					System.out.println("Sufficient records not found for pagination");
					actions.reportCreatePASS("Verify Next pagination link", "Next pagination link should be displayed", "Sufficient records not present for next pagination link to be displayed", "PASS");
				}
				
				if(mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.pagprev")){
//					Reporter.log("Previous pagination link is displayed");
//					System.out.println("Previous pagination link is displayed");
					actions.reportCreatePASS("Verify Previous pagination link", "Previous pagination link should be displayed", "Previous pagination link is displayed", "PASS");
//					Reporter.log("Clicke on previous link");
					actions.keyboardEnter("MenuItemSets.pagprev");
//					actions.waitForPageToLoad(5000);
//					Thread.sleep(6000);
					actions.smartWait(180);
				}else{
//					Reporter.log("Sufficient records not found for pagination");
//					System.out.println("Sufficient records not found for pagination");
					actions.reportCreatePASS("Verify Previous pagination link", "Previous pagination link should be displayed", "Sufficient records not present for previous pagination link to be displayed", "FAIL");
				}
				
				//verify blank serach---------udpated by Rehanshu
				System.out.println("Blank Search");
				actions.waitForPageToLoad(2000);
				actions.keyboardEnter("MenuItemSets.Searchbtn");
				//actions.waitForPageToLoad(2000);
				Thread.sleep(4000);
				mcd.VerifyAlertMessageDisplayed("Error Message",errmsg[5],true,AlertPopupButton.OK_BUTTON);
				Thread.sleep(2000);
				System.out.println("invalid Search");
				actions.setValue("MenuItemSets.Searchfield", "$$$$$$$");
				actions.keyboardEnter("MenuItemSets.Searchbtn");
//				Thread.sleep(3000);
//				actions.waitForPageToLoad(8000);
				actions.smartWait(180);
				actions.verifyTextPresence("Search returned no matching results.", true);
				actions.keyboardEnter("MenuItemSets.ViewFullList");
//				actions.waitForPageToLoad(9000);
//				Thread.sleep(10000);
				actions.smartWait(180);
				String existingMIname= driver.findElement(By.xpath("//*[@id='menuItemSetData']/tr[1]/td[1]")).getText();
				actions.setValue("MenuItemSets.Searchfield", existingMIname);
				actions.keyboardEnter("MenuItemSets.Searchbtn");
//				actions.waitForPageToLoad(9000);
//				Thread.sleep(6000);
				actions.smartWait(180);
				String MainWindow_NewMenuItem = driver.getWindowHandle();
				System.out.println("Title :" +driver.getTitle());
				actions.keyboardEnter("MenuItemSets.NewMenuItemSet");
				//actions.click("MenuItemSets.NewMenuItemSet");
				actions.waitForPageToLoad(5000);
				Thread.sleep(3000);
					
				//switch to new menu item set window
				try {
					mcd.SwitchToWindow("Add New Menu Item Set");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//actions.windowSwitch(MainWindow_NewMenuItem,"Add New Menu Item Set");

				actions.waitForPageToLoad(1000);
				System.out.println("Title :" +driver.getTitle());
				
				actions.keyboardEnter("MenuItemSets.Nextbtn");
				mcd.VerifyAlertMessageDisplayed("Error",errmsg[0] , true,AlertPopupButton.OK_BUTTON);
				Thread.sleep(2000);
				System.out.println("title:"+driver.getTitle());
//				Reporter.log("Verify error messgae while creating menu item set without selecting node");
//				System.out.println("Verify error messgae while creating menu item set without selecting node");
//				Reporter.log("enter existing menu item set name");
//				System.out.println("enter existing menu item ste name");
				actions.setValue("MenuItemSets.BTMenuItemSetNameTextBox", existingMIname);
				actions.keyboardEnter("MenuItemSets.Nextbtn");
				mcd.VerifyAlertMessageDisplayed("Error",errmsg[2] , true,AlertPopupButton.OK_BUTTON);
				//actions.verifyTextPresence(errmsg[2], true);
				String MainWindow_NewMenuItem1 = driver.getWindowHandle();
				System.out.println("Title :" +driver.getTitle());
				
				actions.keyboardEnter("MenuItemSets.Selectbtn");
				Thread.sleep(6000);
				//actions.WaitForWindowToBe(3,10);
				//actions.windowSwitch(MainWindow_NewMenuItem1,"Select Node");
				try {
					mcd.SwitchToWindow("Select Node");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Title rest :" +driver.getTitle());
				mcd.Selectrestnode("MenuItemSets.LeftTable",strrest);
				Thread.sleep(3000);
				System.out.println(driver.getWindowHandles());
				driver.switchTo().window(MainWindow_NewMenuItem1);
				//actions.windowSwitch(MainWindow_NewMenuItem1, "Add New Menu Item Set");

//				Reporter.log("Verify error messgae when existing menu item set name is used while creating new menu item set name");
				actions.keyboardEnter("MenuItemSets.Nextbtn");
				try {
					mcd.SwitchToWindow("Add New Menu Item Set");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				actions.waitForPageToLoad(2000);
				if(actions.isElementPresent("AddNewMenuItemSet.BTErrorMessageDuplicateName")){
					actions.reportCreatePASS("Verify Error Message Displayed", "Error message: Menu Item Set Name already exists, please enter a different Menu Item Set Name. should be displayed", "Error message: Menu Item Set Name already exists, please enter a different Menu Item Set Name. is displayed", "PASS");
				}else{
					actions.reportCreatePASS("Verify Error Message Displayed", "Error message: Menu Item Set Name already exists, please enter a different Menu Item Set Name. should be displayed", "Error message: Menu Item Set Name already exists, please enter a different Menu Item Set Name. is not displayed", "FAIL");
				}
				//actions.verifyTextPresence(errmsg[1], true);
				
//				Reporter.log("Verify error messgae when copy from existing is selected as 'Yes' and menu item set is not selected ");
				actions.setValue("MenuItemSets.CopyYes", "Yes");
				Thread.sleep(500);
				actions.keyboardEnter("MenuItemSets.Nextbtn");
				Thread.sleep(3000);
				mcd.VerifyAlertMessageDisplayed("Error",errmsg[3] , true,AlertPopupButton.OK_BUTTON);
				Thread.sleep(2000);
				actions.keyboardEnter("MenuItemSets.Cancelbtn");
				Thread.sleep(3000);
//				Reporter.log("Verify error messgae after clicking on cancel button without saving changes ");
				mcd.VerifyAlertMessageDisplayed("Confirmation",errmsg[4],true,AlertPopupButton.OK_BUTTON);
				Thread.sleep(500);
				driver.switchTo().window(MainWindow_NewMenuItem);
			
		}
		
		/*Feature Name : Menu Item Set
		Functionality :Create new menu item set with copy from existing setting as YES.
		Scenario ID : MNU_0002
		Author :Neha Manohar*
		 */
		
		public String MNU_0002_CreateMenuItemSet(String strmenuname,String strrest,String strmsg)throws InterruptedException{
			String str="";
			try{
			
			String[] msg= strmsg.split("#");
//				Reporter.log("----> Steps to create menu item set with copy from existing setting as YES ");
//				Reporter.log("Click on new menu item set button");
				String MainWindow_NewMenuItem = driver.getWindowHandle();
				System.out.println("Title :" +driver.getTitle());
				actions.keyboardEnter("MenuItemSets.NewMenuItemSet");
				//actions.waitForPageToLoad(5000);
				Thread.sleep(5000);
					
				//switch to new menu item set window
				
				//actions.windowSwitch(MainWindow_NewMenuItem,"Add New Menu Item Set"); 

				mcd.SwitchToWindow("Add New Menu Item Set");

				System.out.println("Title :" +driver.getTitle());
				str= mcd.fn_GetRndName("Auto");
				actions.setValue("MenuItemSets.BTMenuItemSetNameTextBox", str);
				
				
				String MainWindow_NewMenuItem1 = driver.getWindowHandle();
				System.out.println("Title :" +driver.getTitle());
				
				actions.keyboardEnter("MenuItemSets.Selectbtn");
				Thread.sleep(6000);
				//actions.WaitForWindowToBe(3,10);
				//actions.windowSwitch(MainWindow_NewMenuItem1,"Select Node");
				mcd.SwitchToWindow("Select Node");
				
				System.out.println("Title rest :" +driver.getTitle());
				mcd.Selectrestnode("MenuItemSets.LeftTable",strrest);
				Thread.sleep(3000);
				System.out.println(driver.getWindowHandles());
				driver.switchTo().window(MainWindow_NewMenuItem1);
									
				//select copy from existing menu item set as yes
				actions.setValue("MenuItemSets.CopyYes","Yes");
				Thread.sleep(500);
				actions.keyboardEnter("MenuItemSets.SelectCopybtn");
				Thread.sleep(4000);
				System.out.println(driver.getWindowHandles());
				String MainWindow_NewMenuItem2 = driver.getWindowHandle();
				//actions.windowSwitch(MainWindow_NewMenuItem2,"Select Menu Item Set to Copy");
				mcd.SwitchToWindow("Select Menu Item Set to Copy");
				
				System.out.println("Title :" +driver.getTitle());
				Thread.sleep(3000);
				actions.setValue("MenuItemSets.Searchfield",strmenuname);
				Thread.sleep(2000);
				actions.keyboardEnter("MenuItemSets.Searchbtn");
				Thread.sleep(5000);
				actions.waitForPageToLoad(9000);
				actions.keyboardEnter("MenuItemSets.TableFirstValue");
				//actions.windowSwitch(MainWindow_NewMenuItem2,"Add New Menu Item Set");
				mcd.SwitchToWindow("Add New Menu Item Set");
				
				actions.keyboardEnter("MenuItemSets.Nextbtn");
				//Thread.sleep(9000);
				//actions.waitForPageToLoad(10000);
				//System.out.println("title"+driver.getTitle());
				Thread.sleep(6000);
				driver.switchTo().window(MainWindow_NewMenuItem);
				System.out.println("Tilte :" +driver.getTitle());
				Thread.sleep(3000);
				actions.verifyTextPresence(msg[6],true);
				Thread.sleep(2000);
				actions.keyboardEnter("MenuItemSets.ReturnToSet");
				Thread.sleep(2000);
				actions.waitForPageToLoad(180);
				return str;
			}
			catch (Exception e) {
				// TODO Auto-generated catch block
				
				e.printStackTrace();
			}
			return str;
			
		}
		
		
 ////Create Drink Volume
		
		public String create_drink_volume(String errmsg)
		{
			String DV_name="";
			String msg[]=errmsg.split("#");
			try{
			//Adding the new record
			actions.click("DRINKVOLUME.NewDrinkVolbtn");
		    Thread.sleep(2000);
		    
		    //Getting the element from the table
		    WebElement DrinkVol_txt=mcd.GetTableCellElement("DRINKVOLUME.Datatable", 1, "Name", "input");
		    WebElement DrinkVol_code=mcd.GetTableCellElement("DRINKVOLUME.Datatable", 1, "Code", "input");
		    
		    boolean flag=false;
		    do{
		    DrinkVol_txt.clear();	
		    DrinkVol_txt.sendKeys("DV"+mcd.fn_GetRndAlphabaticString(6));
		    DrinkVol_code.clear();
		    DrinkVol_code.sendKeys(mcd.fn_GetRndNumericString(3));
		    
		    //Getting the name and code
		    DV_name=DrinkVol_txt.getAttribute("value");
		    String code= DrinkVol_code.getAttribute("value");
		    
		    //clicking on the save btn
		    actions.click("DRINKVOLUME.Savebtn");
		    
		    //waiting for record to get saved
		    actions.smartWait(10);
		    
		    try {
				// Verify that confirmation popup is displayed
				Alert popup = driver.switchTo().alert();
				if (popup != null) {
					// Verify the message displayed
					System.out.println("> Verify the message displayed");
					String strActualMsg = popup.getText().trim();
				if(strActualMsg.contains("Name")){	
				mcd.VerifyAlertMessageDisplayed("Information", msg[0], true, AlertPopupButton.OK_BUTTON);
				flag=true;
				}else
				{
				mcd.VerifyAlertMessageDisplayed("Information", msg[1], true, AlertPopupButton.OK_BUTTON);
				flag=true;
				}
				}
		    }catch (Exception e) {
			System.out.println("Name and Number accepted successfully");
			}
		    }while(flag==true);
				 
		    //verrify the success message is displayed or not
		    actions.verifyTextPresence(msg[3], true);

		}catch (Exception e)
		{
//			System.out.println(e.getMessage());
			actions.catchException(e);
		}
			return DV_name;
		}

		
		//-----------------------------------
		/*Feature Name : Ingredient Group
		Functionality :Create new ingredient group
		Scenario ID : MNU_1173
		Author : Sonam */
		//-----------------------------------
		
		public String RFM_MNU_IngredientGroup_Create(String[] strIGColumnNames, String strIGName, String strIGSelectFlag, String strIGMinQuantity, String strIGMaxQuantity, String strResultMessage) throws Exception{
			
			//Click on New Ingredient Group Button
			actions.click("IngredientGroupPage.NewIGBtn");
			
			//Get the Ingredient group table fields 
			
			//Name Field
			WebElement eleIGName = mcd.GetTableCellElement("IngredientGroupPage.Table", 1, strIGColumnNames[0].trim(), "input");
			//Name Select
			WebElement eleIGSelect1 = mcd.GetTableCellElement("IngredientGroupPage.Table", 1, strIGColumnNames[1].trim(), "input");
			
			//Quantity
			List <WebElement> eleQuantfields = driver.findElements(By.xpath(actions.getLocator("IngredientGroupPage.QuantityFields")));
			//Minimum Quantity
			WebElement eleIGQuantityMin = eleQuantfields.get(0);
			//Maximum Quantity
			WebElement eleIGQuantityMax = eleQuantfields.get(1);
			
			//Get unique name
			strIGName = mcd.fn_GetRndName(strIGName);
			strIGName = strIGName.subSequence(0, 7).toString();
			strIGName = strIGName.replace("_", "");
			
			//Enter Ingredient Name
			eleIGName.sendKeys(strIGName);
			
			//Check/Uncheck Ingredient Select 
			if(strIGSelectFlag.trim().equalsIgnoreCase("yes")){
				eleIGSelect1.sendKeys(Keys.SPACE);	
			}
			
			//Enter Minimum quantity
			eleIGQuantityMin.sendKeys(strIGMinQuantity);
			//Enter Maximum quantity
			eleIGQuantityMax.sendKeys(strIGMaxQuantity);
			
			//Save the changes
			actions.click("IngredientGroupPage.SaveBtn");
			
			actions.smartWait(180);
			
			
			Boolean blnUniq = false;
			do{
				String strMsg = null;
				
				try{
					strMsg = driver.switchTo().alert().getText().trim();
					if(strMsg.equalsIgnoreCase("Ingredient Group Name already exists, please enter another name.")){
						driver.switchTo().alert().accept();
						blnUniq = true;
					}
				
					//Clear Ingredient Name
					eleIGName.clear();
				
					//Get unique name
					strIGName = mcd.fn_GetRndName(strIGName);
					strIGName = strIGName.subSequence(0, 7).toString();
					strIGName = strIGName.replace("_", "");
				
					//Enter Ingredient Name
					eleIGName.sendKeys(strIGName);
				
					//Save the changes
					actions.click("IngredientGrp.SaveBtn");
					actions.smartWait(180);
				}catch(Exception e){
					System.out.println("No Pop up msg. IG name is unique");
				}
			}while(blnUniq);
			
			
			//verify success message
			actions.verifyTextPresence(strResultMessage, false);
			
			actions.reportCreatePASS("Verify Ingredient group is created", "New Ingredient group should be created", "New Ingredient group is created", "PASS");
			
			return strIGName;
			
		}
		
		
		
		// ----------------------------------
		/*Feature Name : Ingredient Group
		Functionality : Delete Ingredient Group
		Scenario ID : POS_1173
		Author : Sonam */
		//-----------------------------------
		
		public String RFM_MNU_IngredientGroup_Delete(String strIGName, String strDeletePopupMsg, String strDeleteSuccessMsg) throws Exception {
				
				//Variable Declarations
				Boolean VerifyPopUpMsg;
				String flagDelete = null;
				String xpath1 = null;
				int row_cnt = mcd.GetTableRowCount("IngredientGroupPage.Table");
				for (int i = 0; i < row_cnt-1; i++) {
					WebElement name = driver.findElement(By.xpath("//*[@id='ingredientGroupName"+i+"']"));
					String IG_name = name.getAttribute("value");
					if(IG_name.trim().equalsIgnoreCase(strIGName)){
						int j = i+1;
						xpath1 = "//*[@id='ingredeintPrepTable']/tbody/tr["+j+"]/td[4]/a";
						//Click on Delete icon
						driver.findElement(By.xpath(xpath1)).click();
						Thread.sleep(2000);
						break;
					}
				}
				VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Confirmation message ", strDeletePopupMsg, true, AlertPopupButton.CANCEL_BUTTON);
				if (VerifyPopUpMsg = true){
					System.out.println(strDeletePopupMsg + " message displayed as expected - PASS");
				}else{
					System.out.println(strDeletePopupMsg + " message Not displayed - FAIL");
				}
				//Again Click on Delete icon
				driver.findElement(By.xpath(xpath1)).click();
				Thread.sleep(2000);
				VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Confirmation message", strDeletePopupMsg, true, AlertPopupButton.OK_BUTTON);
				if (VerifyPopUpMsg = true){
					System.out.println(strDeletePopupMsg + " message displayed as expected - PASS");
				}else{
					System.out.println(strDeletePopupMsg + " message Not displayed - FAIL");
				}
				Thread.sleep(5000);		
				try {
					mcd.SwitchToWindow("Ingredient Groups");
					String strTitle = driver.getTitle();
					if (strTitle.equalsIgnoreCase("Ingredient Groups")) {
						Thread.sleep(2000);
						String getTextDelete=driver.findElement(By.xpath(actions.getLocator("IngredientGroupsPopup.OkButton"))).getText();
						System.out.println(getTextDelete);
						actions.keyboardEnter("IngredientGroupsPopup.OkButton");
						Thread.sleep(5000);
						System.out.println("Popup is displayed as expected - PASS");
						flagDelete = "No";
						actions.reportCreatePASS("Verify Ingredient group is deleted", "Ingredient group should be deleted", "Ingredient group is not deleted as assigned to Menu Item", "PASS");					
					}
				} catch (Exception e) {
						System.out.println("No Popup displayed");
						WebElement msg_element = driver.findElement(By.xpath("//*[@id='ingredientGroups_infoCode']/li/span"));
						String temp_msg = msg_element.getText();
						if(temp_msg.equals(strDeleteSuccessMsg)){
							System.out.println(strDeleteSuccessMsg + " message is displayed as expected "  + "- PASS");
							actions.reportCreatePASS("Verify Ingredient group is deleted", "Ingredient group should be deleted", "Ingredient group is deleted", "PASS");
							flagDelete = "Yes";
						}else{
							System.out.println(strDeleteSuccessMsg + " message is Not displayed"  + "- FAIL");
							actions.reportCreateFAIL("Verify Ingredient group is deleted", "Ingredient group should be deleted", "Ingredient group is not deleted", "FAIL");
						}
				}
				
				return flagDelete;
		}		
		
		
		// ----------------------------------
				/*Feature Name : Master Menu Item List
				Functionality :Create Master Menu Item with or without copy existing which is Partially saved
				@Param: MIrange- min limit and max limit ,MIparam-class,family group,category,strmsg -error message,strcopy-copy from existing yes or no
				Scenario ID : MNU_0243
				Author :Akanksha Rani*/
				//-----------------------------------
			
				public int RFM_MI_CreateMenuItem_PartialSave(String MIrange,String pro_type,String strmsg,String strmenutype){
				boolean blnflag=false;
				String[] strparam=strmenutype.split("#");
				String[] strrange = MIrange.split("#");
				String strerrmsg[]= strmsg.split("#");
				String s="";
				int mi_num=0,mi_start=0,mi_end=0;
				try{
					boolean flag=false;
					
					System.out.println("********************************************************************** Start Test-Steps executions");
					
					//	String MainWindow_NewMenuItem = driver.getWindowHandle();
					WebElement ws=driver.findElement(By.xpath("//*[@class='button button'][contains(text(),'Add New')]"));
					actions.click(ws);
					
					//actions.windowSwitch(MainWindow_NewMenuItem,"Add New Menu Item"); 
					mcd.SwitchToWindow("Add New Menu Item");
						
					switch (pro_type) {
					case "CONTAINER_VALUE_MEAL":
						s = "Auto_CVM_"+RandomStringUtils.randomAlphabetic(6);
						mi_start=Integer.parseInt(strrange[4]);
						mi_end=Integer.parseInt(strrange[5]);
						break;
					case "PRODUCT":
						s = "Auto_Pro_"+RandomStringUtils.randomAlphabetic(6);
						mi_start=Integer.parseInt(strrange[4]);
						mi_end=Integer.parseInt(strrange[5]);
						break;
					case "VALUE_MEAL":
						s = "Auto_VM_"+RandomStringUtils.randomAlphabetic(6);
						mi_start=Integer.parseInt(strrange[4]);
						mi_end=Integer.parseInt(strrange[5]);
						break;
					case "CHOICE":
						s= "Auto_Choice_"+RandomStringUtils.randomAlphabetic(6);
						mi_start=Integer.parseInt(strrange[0]);
						mi_end=Integer.parseInt(strrange[1]);
						break;
					case "CHOICE_EVM":
						s= mcd.fn_GetRndName("Auto_ChoiceEVM");
						mi_start=Integer.parseInt(strrange[0]);
						mi_end=Integer.parseInt(strrange[1]);
						break;
					case "CHECK CATEGORY":
						s= "Auto_Check_"+RandomStringUtils.randomAlphabetic(6);
						mi_start=Integer.parseInt(strrange[2]);
						mi_end=Integer.parseInt(strrange[3]);
						break;
					case "NON_FOOD_PRODUCT":
						s = "Auto_NonPro_"+RandomStringUtils.randomAlphabetic(6);
						mi_start=Integer.parseInt(strrange[4]);
						mi_end=Integer.parseInt(strrange[5]);
						break;
					case "RAW_ITEM":
						s = "Auto_NonPro_"+RandomStringUtils.randomAlphabetic(6);
						mi_start=Integer.parseInt(strrange[4]);
						mi_end=Integer.parseInt(strrange[5]);
						break;
					case "EVM": 
						s= "Auto_NonPro_"+RandomStringUtils.randomAlphabetic(6);
						mi_start=Integer.parseInt(strrange[4]);
						mi_end=Integer.parseInt(strrange[5]);
						break;
					case "COMMENT": 
						s= "Auto_CMNT_"+RandomStringUtils.randomAlphabetic(6);
						mi_start=Integer.parseInt(strrange[6]);
						mi_end=Integer.parseInt(strrange[7]);
						break;
					default:
						break;
					}
					
					System.out.println("product name:"+s);		
					actions.setValue("AddNewMI.MenuItemName",s);
					
						do{
						mi_num=mcd.fn_GetRndNumInRange(mi_start, mi_end);
						actions.clear("AddNewMI.MenuItemNumber");
						actions.setValue("AddNewMI.MenuItemNumber", mi_num);
						actions.keyboardEnter("AddNewMI.Next");
						
						boolean blnWindow = false;
						
						try{
							blnWindow = mcd.SwitchToWindow("@Manage Menu Items");
							if(blnWindow){
								System.out.println("Menu Name and Number is accepted successfully");
								blnflag = false;	
							}else{
								mcd.SwitchToWindow("Add New Menu Item");
								if (actions.isTextPresence(strerrmsg[0], true)){
					            	 blnflag = true;
					            	 System.out.println("Entered  number "+mi_num+" is already exist.");
					               System.out.println(blnflag);
					             }
							}
							
						}catch(Exception err){
							if (actions.isTextPresence(strerrmsg[0], true)){
				            	 blnflag = true;
				            	 System.out.println("Entered  number "+mi_num+" is already exist.");
				               System.out.println(blnflag);
				             }
						}

					}while(blnflag==true);
						
				//SETTING THE VALUE OF THE MANDATORY FIELDS
				String instance = mcd.GetGlobalData("Instance");
				if(instance.equalsIgnoreCase("AP") || instance.equalsIgnoreCase("QMAP")){
				actions.setValue("ManageMenuItemCurrentMenuItemDetails.MenuItemType", "SMI");
				}
				actions.setValue("ManageMenuItem.ProductClass",pro_type );
				actions.setValue("ManageMenuItem.ProductCategory", strparam[0]);
				actions.setValue("ManageMenuItem.FamilyGroup", strparam[1]);
				Select select =new Select(driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.DayPartCode"))));
				select.selectByIndex(1);
				actions.setValue("ManageMenuItem.ProductLName", s+"LN");
				actions.setValue("ManageMenuItem.ProductSName", s+"SN");
				actions.setValue("ManageMenuItem.ProductDTName", s+"DN");

				//Setting "Yes" for PartialSaveDropDown
				actions.setValue("ManageMenuItems.ARPartialSaveDropDown", "Yes");
				String PartialSaveDropDownvalue= driver.findElement(By.xpath(actions.getLocator("ManageMenuItems.ARPartialSaveDropDown"))).getAttribute("value");
				actions.click("ManageMenuItem.ApplySavebtn");
				if(pro_type.equals("CHOICE")|| pro_type.equals("CHOICE_EVM")||pro_type.equals("CHECK CATEGORY") || PartialSaveDropDownvalue.equals("1")){
					mcd.VerifyAlertMessageDisplayed(strerrmsg[4], strerrmsg[4],false,AlertPopupButton.OK_BUTTON);
					flag =true;
				}
				actions.smartWait(180);
				actions.verifyTextPresence(strerrmsg[2],true);
				 if(flag==false)
				 {
					actions.reportCreatePASS("Verify creation of Menu Item", "Menu Item of '"+pro_type+"' should be created",
							"Menu Item of '"+pro_type+"' is created", "Pass");
				 }
			  
			  //CLICKING CANCEL BUTTON TO NAVIGATE TO MAIN PAGE
			  actions.click("ManageMenuItem.Cancelbtn1");
			  actions.smartWait(180);
			  
			    }catch(Exception e){
				actions.reportCreateFAIL("Verify creation of Menu Item", "Menu Item of '"+pro_type+"' should be created",
						"Menu Item of '"+pro_type+"' is not created", "Fail");
				}
			return mi_num;
			}
			
				
				/*************************************************************************
				 * Functionality : Search store
				 * 
				 * @param tblElemnt : Table Element locator
				 * @param MINam : Menu Item Name OR number
				 * @param srchTxtbxLoctr : Search Text box UI locator
				 * @param rowNumbr : row number for destination menu item
				 * @param colmnNam : column name to select
				 * @param isSelectMI : 'true' if need to perform navigation to searched Menu item
				 *******************************************************************************/
				public void searchAndSelctMenuItem(String tblElemnt, String MINam, String srchTxtbxLoctr, int rowNumbr, String colmnNam, boolean isSelectMI) {

					try {
						actions.clear(srchTxtbxLoctr);
						/** search and navigate to expected MI */
						actions.setValue(srchTxtbxLoctr, MINam);
						actions.WaitForElementPresent("MenuItemDetails.exactMatchRadioBtn", 180);
						actions.javaScriptClick("MenuItemDetails.exactMatchRadioBtn");
						actions.WaitForElementPresent("RFM.SearchButton", 180);
						actions.keyboardEnter("RFM.SearchButton");
						mcd.smartsync(180);
						if (isSelectMI) {
							// select store
							WebElement selStor = mcd.GetTableCellElement("RFMProductionRoutingPage.Table", rowNumbr, colmnNam, "a");
							actions.keyboardEnter(selStor);
							mcd.smartsync(180);
							String pagTitle = driver.getTitle();
							if(pagTitle.equalsIgnoreCase("Restaurant Menu Item List")){
								actions.click(mcd.GetTableCellElement("RFMProductionRoutingPage.Table", rowNumbr, colmnNam, "a"));
							}
						}	
						
					} catch (Exception eSerchSel) {
						actions.catchException(eSerchSel);
					}

				}

				/**
				 * removing future settings
				 * 
				 * @param tblElemnt : Table Element
				 * @param MINam : Menu Item Name OR number
				 * @param rowNumbr : row number for destination menu item
				 * @param colmnNam : column name for destination menu item ('Future Settings' OR 'Future Setting')
				 * @param colmnElmntTyp : column element type
				 */

				public void removeFutrSetngs(String tblElemnt, String MINam, int rowNumbr, String colmnNam, String colmnElmntTyp) {
					String getFuturDt = mcd.GetTableCellValue(tblElemnt, rowNumbr, colmnNam, colmnElmntTyp, "");
					try {
						// select first menu item
						WebElement menuItmStor = mcd.GetTableCellElement(tblElemnt, rowNumbr, colmnNam, colmnElmntTyp);
						actions.keyboardEnter(menuItmStor);
						mcd.waitAndSwitch("#Title");

						// click on 'Remove All' button
						actions.WaitForElementPresent("MasterFee.PPRemoveFtrSetBtn", 180);
						actions.click("MasterFee.PPRemoveFtrSetBtn");

						// verify alert
						mcd.waitForMsg("Warning", "Are you sure you want to remove the future settings?", "", "");

						// verify on screen messasge
						mcd.waitAndSwitch("@Restaurant Menu Item List");
						mcd.waitForMsg("Onscreen", "Future settings have been successfully removed.", "", "RestaurantMenuItemList.PAFutureSetRemovlMsg");

					} catch (Exception eRemovFutrSetng) {
						if (!getFuturDt.isEmpty()) {
							System.out.println("Future Settings doesn't exists!!!");

						} else {
							actions.catchException(eRemovFutrSetng);
						}
					}
				}

				/* FUNCTION : // select store
				 *
				 * @param strRest : Store to search and select 
				 * 
				 * **/

				public void searchAndSelctStore(String strRest) {
					try {
						actions.keyboardEnter("RestaurantMenuItemList.SelectRestaurant");
						mcd.waitAndSwitch("Select a Restaurant");
						actions.click("MenuItemTaxReport.ExactMatchBtn");
						actions.WaitForElementPresent("RFMSelectNode.SearchEditbox", 180);
						actions.setValue("RFMSelectNode.SearchEditbox", strRest);
						actions.WaitForElementPresent("RFM.SearchButton", 180);
						actions.keyboardEnter("RFM.SearchButton");
						mcd.smartsync(180);
						mcd.Selectrestnode("SelectNode.NodeTable", strRest);
						mcd.waitAndSwitch("@Restaurant Menu Item List");
					} catch (Exception eSrchAndSlct) {
						actions.catchException(eSrchAndSlct);
					}
				}

}			



