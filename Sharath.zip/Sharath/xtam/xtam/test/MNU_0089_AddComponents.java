package xtam.test;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0089_AddComponents {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();
	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;
	// Test Data variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo, tcDescription, strMenuItemName;

	public MNU_0089_AddComponents(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();
		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strMarket = mcd.GetTestData("DT_MARKET");
		tcDescription = mcd.GetTestData("DT_Description");
		strMenuItemName = mcd.GetTestData("DT_MenuItemName");

	}

	@Test
	public void MNU_010MNU_0089_AddComponents() throws InterruptedException {
		String strPageTitle = "Master Menu Item List";
		String strPageSubHeading = "Master Menu Item List";

		try {

			System.out.println(
					"********************************************************************** Test execution starts");
			// Note : View Full List button is not displayed in 2.14.
			actions.setTestcaseDescription(
					"Add component-Search functionality for composition, can adds and comments and 'View Full List' button.");
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Verify Page Header */
			// System.out.println("> Verify Page Heading");
			// mcd.VerifyPageHeading(strPageSubHeading, "SubHeading");

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow

			/* search menu item for component type as composition */
			actions.setValue("MenuItemSets.SearchTextBox", strMenuItemName);
			actions.click("MasterMenuItemList.Searchbtn");
			Thread.sleep(1000);
			actions.smartWait(5);
			// selecting the first menu item
			actions.click("MasterMenuItemList.selectmenuitem1");
			Thread.sleep(3000);
			actions.smartWait(10);
			// getting the updated title of page
			mcd.SwitchToWindow("#Title");
			Thread.sleep(1000);
			// click on component tab
			actions.keyboardEnter("MasterMenuItemList.NavComptab");
			Thread.sleep(3000);
			actions.smartWait(10);
			// click on add component
			actions.keyboardEnter("AddRemoveComponent.AddCompbtn");
			System.out.println("Clicked on add remove components button");
			Thread.sleep(3000);
			actions.waitForPageToLoad(20);

			// Switch to 'Common Menu Item Selector'
			mcd.SwitchToWindow("Common Menu Item Selector");

			/* composition view full list */
			try {
				actions.keyboardEnter("AddRemoveComponent.Composition");
				actions.smartWait(120);
				// click on view full list button
				actions.keyboardEnter("COPYMI.searchbtn");
				actions.smartWait(180);
				actions.reportCreatePASS(
						"Verify the List of menu items should be display menu items of composition type",
						"List of menu items of composition type should get displayed",
						"Search result displayed as expected.", "Pass");
				this.displaycomponent();
			} catch (Exception err1) {
				actions.reportCreateFAIL(
						"Verify the List of menu items should be display menu items of composition type",
						"List of menu items of composition type should get displayed",
						"Search result is not displayed as expected.", "Fail");
			}

			/* can adds view full list */
			try {
				Thread.sleep(1000);
				actions.click("AddRemoveComponent.Canadds");
				// click on view full list
				actions.keyboardEnter("COPYMI.searchbtn");
				Thread.sleep(4000);
				actions.smartWait(10);
				actions.waitForPageToLoad(9);
				actions.reportCreatePASS("Verify the List of menu items should be display menu items of Can adds type",
						"List of menu items of Can adds type should get displayed",
						"Search result displayed as expected.", "Pass");
				this.displaycomponent();
			} catch (Exception err1) {
				actions.reportCreateFAIL("Verify the List of menu items should be display menu items of Can adds type",
						"List of menu items of Can adds type should get displayed",
						"Search result is not displayed as expected.", "Fail");
			}

			/* comments view full list */
			try {
				Thread.sleep(1000);
				actions.click("AddRemoveComponent.Comments");

				actions.keyboardEnter("COPYMI.searchbtn");
				Thread.sleep(4000);
				actions.smartWait(10);
				actions.waitForPageToLoad(9);

				actions.reportCreatePASS("Verify the List of menu items should be display menu items of Comments type",
						"List of menu items of Comments type should get displayed",
						"Search result displayed as expected.", "Pass");
				this.displaycomponent();
			} catch (Exception err1) {
				actions.reportCreateFAIL("Verify the List of menu items should be display menu items of Comments type",
						"List of menu items of Comments type should get displayed",
						"Search result is not displayed as expected.", "Fail");
			}

			/* composition search */
			System.out.println("Search functionality for Composition");

			actions.click("AddRemoveComponent.Composition");
			actions.setValue("AddRemoveComponent.Searchfield", "a");
			// click on search button
			actions.keyboardEnter("AddRemoveComponent.Searchbtn");
			Thread.sleep(4000);
			actions.smartWait(10);
			actions.waitForPageToLoad(9);

			this.displaycomponent();

			/* can adds search */
			System.out.println("Search functionality for Can-adds");
			actions.javaScriptClick("AddRemoveComponent.Canadds");
			actions.clear("AddRemoveComponent.Searchfield");
			Thread.sleep(4000);

			actions.setValue("AddRemoveComponent.Searchfield", "a");
			actions.keyboardEnter("AddRemoveComponent.Searchbtn");
			Thread.sleep(4000);
			actions.smartWait(10);
			actions.waitForPageToLoad(9);

			this.displaycomponent();

			/* comments search */
			System.out.println("Search functionality for Comments");

			actions.javaScriptClick("AddRemoveComponent.Comments");
			actions.clear("AddRemoveComponent.Searchfield");
			Thread.sleep(1000);

			actions.setValue("AddRemoveComponent.Searchfield", "a");
			actions.keyboardEnter("AddRemoveComponent.Searchbtn");
			Thread.sleep(4000);
			actions.smartWait(10);
			actions.waitForPageToLoad(9000);

			this.displaycomponent();
			Thread.sleep(1000);

			actions.javaScriptClick("AddRemoveComponent.Cancelbtn_");
			// actions.javaScriptClick(driver.findElement(By.id("menuItemSelectorForm_")));

			Thread.sleep(1000);
			actions.waitForPageToLoad(10);

			mcd.SwitchToWindow("Manage Menu Items");

			Thread.sleep(1000);
			actions.javaScriptClick("ApplyChangesDetails.cancel");
			Thread.sleep(1000);
			actions.waitForPageToLoad(10);

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());

		} finally {
			actions.quitBrowser();

			actions.verifyTestCase(this.getClass());
		}

	}

	public void displaycomponent() {
		boolean blnstatus = false;
		String values = "";
		List<WebElement> xpaths = driver.findElements(By.xpath("//*[@id='commonTableBody']/tr/td[4]"));
		if (xpaths.size() > 0) {
			for (int i = 1; i < 4; i++) {
				values = driver.findElement(By.xpath("//*[@id='commonTableBody']/tr[" + i + "]/td[4]")).getText();
				if (values.toLowerCase().contains("a")) {
					blnstatus = true;
				} else {
					blnstatus = false;
					break;
				}

			}
			if (blnstatus) {
				actions.reportCreatePASS("Verify the Menu Item " + values + " containing a is displaying or not",
						"Menu item-" + values + " containing 'a' should get displayed",
						"Menu item-" + values + " containing 'a' is displayed", "Pass");

			} else {
				actions.reportCreatePASS("Verify the Menu Item " + values + " containing a is displaying or not",
						"Menu item-" + values + " containing 'a' should get displayed",
						"Menu item-" + values + " containing 'a' is not displayed", "Fail");
			}
		} else {
			actions.reportCreateFAIL("Verify that Menu items of selected Composition type are avialable or not",
					"Menu items of selected composition type should be avialable",
					"Menu items of selected composition type are not avialable", "Fail");

		}
	}
}
