package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20438_VrfDNmeExstinDiffMKT {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();
	private lib_MCD mcd;
	private lib_RFM2 rfm;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String dtErrMsg;
	private String strErrMsg[];
	private int dnCode;
	private String strSize, strDnCode, dnDescription;
	private boolean flag;


	public MNU_20438_VrfDNmeExstinDiffMKT(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		dtErrMsg = mcd.GetTestData("DT_Err_Msg");

	}

	@Test
	public void test_MNU_20438_VrfDNmeExstinDiffMKT() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription("Verify that if Dimension Name with same name exists in multiple markets, and if a Dimension Name from one market is deleted, it doesn�t get deleted from other market.");
			
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
			actions.waitForPageToLoad(120);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);		
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			actions.waitForPageToLoad(120);
			actions.smartWait(60);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			//Create dimension set 
			System.out.println("Start");
			strErrMsg = dtErrMsg.split("#");
			actions.click("DimensionName.NewDimensionNameButton");
			Thread.sleep(1000);
			int rowCount=0;
			 rowCount = mcd.GetTableRowCount("DimensionName.Table");
			System.out.println("> > > > RowCount:" + rowCount);
			dnCode = mcd.fn_GetRndNumInRange(1, 20);
			strSize = Integer.toString(dnCode);
			mcd.SetTableCellValue("DimensionName.Table", rowCount, "Size Order", strSize, "input", "value");
			dnCode = mcd.fn_GetRndNumInRange(1, 99999);
			strDnCode = Integer.toString(dnCode);
			dnDescription = mcd.fn_GetRndName("Auto_DN");
			mcd.SetTableCellValue("DimensionName.Table", rowCount, "Description", dnDescription, "input", "value");
			mcd.SetTableCellValue("DimensionName.Table", rowCount, "Code", strDnCode, "input", "value");
			actions.click("DimensionGroup.SaveButton");
			actions.waitForPageToLoad(120);
			actions.smartWait(30);
			
			//Verify on screen message for successfully creating the dimesion set
			flag = mcd.VerifyOnscreenMessage("SubstitutionGroups.InfoMessage", strErrMsg[2], true);
			if (flag) {
				actions.reportCreatePASS("Verify the info message",
						"Message '" + strErrMsg[2] + "' should be displayed", "Expected message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the info message",
						"Message '" + strErrMsg[2] + "' should be displayed", "Expected message is not displayed",
						"FAIL");
			}
			
			//Navigate to home page to change the market	
			actions.select_menu("RFMHome.Navigate", "Home");
			actions.click("Home.ChangeMarket");
		
			//Navigate to Dimension Names page with in American Samoa Market
			rfm.SelectMarket("American Samoa");
			actions.waitForPageToLoad(120);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			actions.waitForPageToLoad(120);
			actions.smartWait(60);

			//Creating a new Dimension Set in American Samoa with the same name which is creted in Australasia market
			actions.click("DimensionName.NewDimensionNameButton");
			rowCount = mcd.GetTableRowCount("DimensionName.Table");
			mcd.SetTableCellValue("DimensionName.Table", rowCount, "Size Order", strSize, "input", "value");
			mcd.SetTableCellValue("DimensionName.Table", rowCount, "Description", dnDescription, "input", "value");
			mcd.SetTableCellValue("DimensionName.Table", rowCount, "Code", strDnCode, "input", "value");
			actions.click("DimensionGroup.SaveButton");
			
			//To delete the dimension name that is just created
			rowCount = mcd.GetTableRowCount("DimensionName.Table");			
			String strName=null;
			for(int i=1;i<=rowCount;i++){
				strName = mcd.GetTableCellElement("DimensionName.Table", i, "Description", "input").getAttribute("value");
				if (strName.trim().equalsIgnoreCase(dnDescription.trim())) {
					actions.click(mcd.GetTableCellElement("DimensionName.Table", i, "Delete", "img"));
					break;
				}
			}
			
			//Verify on screen message for delete
			mcd.VerifyAlertMessageDisplayed("Warning", "Are you sure you want to delete the selected item?", true, AlertPopupButton.OK_BUTTON);
			flag = mcd.VerifyOnscreenMessage("SubstitutionGroups.InfoMessage", "Delete has been successfully completed.", true);
			if (flag) {
				actions.reportCreatePASS("Verify the onscreen message",
						"Delete confirmation message should be displayed", "Message displayed as expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the onscreen message",
						"Delete confirmation message should be displayed", "Message is not displayed as expected", "FAIL");
			}
		
			//Navigate to home page to change the market	
			actions.select_menu("RFMHome.Navigate", "Home");
			actions.click("Home.ChangeMarket");
		
			//Navigate to Dimension Names page with in Australasia Market
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
			actions.waitForPageToLoad(120);		
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			actions.waitForPageToLoad(120);
			actions.smartWait(60);
			
			//To verify the dimension name that is just deleted in another in current market and it should not get deleted 
			rowCount = mcd.GetTableRowCount("DimensionName.Table");			
			strName = null;
			flag= false;
			for(int i=1;i<=rowCount;i++){
				strName = mcd.GetTableCellElement("DimensionName.Table", i, "Description", "input").getAttribute("value");
				if (strName.trim().equalsIgnoreCase(dnDescription.trim())) {
					flag = true;
					break;					
				}				
			}
			
			if(flag){
				actions.reportCreatePASS("Verify that if Dimension Name with same name exists in multiple",
						"Dimension Name with same name should present", "Dimension Name with same name exists", "PASS");
			} else {
				actions.reportCreateFAIL("Verify that if Dimension Name with same name exists in multiple",
						"Dimension Name with same name should present", "Dimension Name with same name does not exists", "FAIL");
			
			}
			
			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}
