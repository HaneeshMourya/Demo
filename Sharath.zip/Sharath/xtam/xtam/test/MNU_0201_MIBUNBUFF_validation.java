package xtam.test;

import java.text.SimpleDateFormat;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0201_MIBUNBUFF_validation {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo, strNavigation, mainwindow, popwin1, strmsgs, msg[], popupwin, strApplicationDate;
	// TODO: Declare test-data variables for other data-parameters

	public MNU_0201_MIBUNBUFF_validation(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strNavigation = mcd.GetTestData("DT_Navigation");
		strmsgs = mcd.GetTestData("DT_MSG");

		msg = strmsgs.split("#");

		// TODO: GetTestData for other data-parameters
	}

	@Test
	public void test_MNU_0201_MI_BUNBUFF_Inact_validation() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			// setting the description now
			actions.setTestcaseDescription(
					"Verify that status can only be set to inactive when bun buffer is not associated to a menu item.");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
			actions.waitForPageToLoad(180);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(180);
			actions.smartWait(30);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// Searching for the menu ItemS and select Active from drop down
			actions.click("MasterMenuItemList.Searchbtn");
			actions.smartWait(180);
			actions.setValue("ManageMenuItems.StatusFilter", mcd.GetTestData("DT_STATUS"));
			actions.smartWait(180);

			// Clicking on menu item
			WebElement rec_sel = mcd.GetTableCellElement("MasterMenuItemList.datatable", 1, "Number", "a");
			String strRecname = rec_sel.getText();
			actions.click(rec_sel);
			actions.smartWait(180);

			// Click on POS/KVS settings link
			actions.click("ManageMenuItem.POSKVS_tab");
			actions.smartWait(180);
			actions.waitForPageToLoad(10);
			actions.WaitForElementPresent("MMIPOSKVSTAB.BunBuffer");

			// Selecting values of the Bun Buffer drop down
			String dropdwn_val = mcd.getdropdownvalues("MMIPOSKVSTAB.BunBuffer");
			System.out.println(dropdwn_val);
			String value[] = dropdwn_val.split(",");
			String setval = actions.getValue("MMIPOSKVSTAB.BunBuffer");
			for (int b = 0; b < msg.length; b++) {
				if (!setval.equals(value[b])) {
					actions.setValue("MMIPOSKVSTAB.BunBuffer", value[b]);
					actions.reportCreatePASS("Setting the value for Day part code to " + value[b],
							"Setting the value for Day part code to " + value[b],
							"Setting the value for Day part code to " + value[b], "PASS");
					break;
				}

			}

			// Click on apply button
			actions.click("ManageMenuItem.ApplySavebtn");
			Thread.sleep(5000);

			try {
				driver.switchTo().alert().accept();
				actions.smartWait(60);
				mcd.SwitchToWindow("Apply Changes Details");
				actions.getWebElement("ApplyChangesDetails.save").sendKeys(Keys.ENTER);
			} catch (Exception er2) {

			}
			mcd.SwitchToWindow("@Manage Menu Items");
			actions.smartWait(180);

			// Verifying on-screen message
			if (actions.isTextPresence(msg[1], true)) {
				actions.reportCreatePASS("Pass: valdiation message is displayed as Expected.",
						"Pass: valdiation message is displayed as Expected.",
						"Pass: valdiation message is displayed as Expected.", "PASS");
			} else {
				actions.reportCreateFAIL("Fail: valdiation message not displayed as Expected.",
						"Fail: valdiation message not displayed as Expected.",
						"Fail: valdiation message not displayed as Expected.", "FAIL");
			}

			// Changing MENUITEM status
			actions.mouseOver("ManageMenuItem.ApprovalStatus");
			actions.click("ManageMenuItem.ApprovalStatus");
			if (mcd.GetGlobalData("Instance").equalsIgnoreCase("AP")) {
				mcd.SwitchToWindow("Status Changes");
				actions.keyboardEnter("StatusChanges.AddStatus");
			} else {
				mcd.waitAndSwitch("Approval Status Changes");
				actions.keyboardEnter("StatusChanges.AddStatusButton");
			}

			// Selecting date form calendar
			actions.click("StatusChanges.datepicker");
			if (!mcd.GetGlobalData("Instance").equalsIgnoreCase("AP")) {
				SimpleDateFormat ft = new SimpleDateFormat("MMM dd, yyyy hh:mm:ss a");
				java.util.Date t = ft.parse(strApplicationDate);
				ft.applyPattern("dd/MM/yyyy");
				strApplicationDate = ft.format(t);
			}
			mcd.sel_current_date("StatusChanges.datepicker", strApplicationDate);

			if (mcd.GetGlobalData("Instance").equalsIgnoreCase("AP")) {
				driver.findElement(By.xpath(actions.getLocator("StatusChanges.Save"))).click();
			} else {
				driver.findElement(By.xpath(actions.getLocator("ApprovalStatusChanges.SaveBtn"))).click();
			}

			// Verifying alert message
			if (mcd.GetGlobalData("Instance").equalsIgnoreCase("AP")) {
				if (mcd.VerifyAlertMessageDisplayed("Confirmation", msg[0].trim(), true, AlertPopupButton.OK_BUTTON)) {
					actions.reportCreatePASS("Verify Alert Message '" + msg[0].trim() + " is displayed or not",
							msg[0].trim() + " should be displayed", msg[0].trim() + " is displayed", "Pass");

				} else {
					actions.reportCreateFAIL("Verify Alert Message '" + msg[0].trim() + " is displayed or not",
							msg[0].trim() + " should be displayed", msg[0].trim() + " is not displayed", "Fail");
				}
				mcd.waitAndSwitch("Menu Item List");
			} else {

				mcd.waitAndSwitch("Menu Item List");
			}

			// Verifying warning message while changing menu item to inactive
			String check_msg;
			if (mcd.GetGlobalData("Instance").equalsIgnoreCase("AP"))
				check_msg = msg[3];
			else
				check_msg = msg[0];
			if (actions.isTextPresence(check_msg.trim(), true)) {
				actions.reportCreatePASS("Verify Message '" + check_msg.trim() + " is displayed or not",
						check_msg.trim() + " should be displayed", msg[2].trim() + " is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify Message '" + check_msg.trim() + " is displayed or not",
						check_msg.trim() + " should be displayed", msg[2].trim() + " is not displayed", "Fail");
			}

			// Click on Cancel button
			actions.click("RFM.CancelButton");
			actions.waitForPageToLoad(10);
			if (mcd.GetGlobalData("Instance").equalsIgnoreCase("AP"))
				mcd.SwitchToWindow("Status Changes");
			else
				mcd.SwitchToWindow("Approval Status Changes");
			actions.click("StatusChanges.CancelBtn");
			if (mcd.GetGlobalData("Instance").equalsIgnoreCase("AP"))
				driver.switchTo().alert().accept();
			mcd.SwitchToWindow("@Manage Menu Items");

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}
