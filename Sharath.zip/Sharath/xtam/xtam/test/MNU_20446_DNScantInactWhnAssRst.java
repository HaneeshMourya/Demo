package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20446_DNScantInactWhnAssRst {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strNavigateTo_1;

	// TODO: Declare test-data variables for other data-parameters
	private String strRest;
	private boolean flag;
	private String setName;
	private String strErrmsg[];
	private String dtErr;
	private String strUserID;
	private String restProfile;

	public MNU_20446_DNScantInactWhnAssRst(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();
		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strNavigateTo_1 = mcd.GetTestData("DT_NAVIGATE_TO_1");

		// TODO: GetTestData for other data-parameters
		strRest = mcd.GetTestData("DT_Node");
		dtErr = mcd.GetTestData("DT_ERR_MSG");
		strUserID = mcd.GetTestData("DT_USER_NAME");

	}

	@Test
	public void test_MNU_20446_DNScantInactWhnAssRst() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(
					"Verify that Dimension Name Set cannot be made Inactive if it assigned to one or more restaurants");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// Verifying Search Full List by Dimension Name Set Name text box
			String textbox = driver.findElement(By.xpath(actions.getLocator("CopyScreenSet.CopySearchTextBox")))
					.getAttribute("type");
			if (textbox.equals("text")) {
				actions.reportCreatePASS("Verifying Search Full List by Dimension Name Set Name text box",
						"Verifying Search Full List by Dimension Name Set Name text box should display",
						"Verifying Search Full List by Dimension Name Set Name text box is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Search Full List by Dimension Name Set Name text box",
						"Verifying Search Full List by Dimension Name Set Name text box should display",
						"Verifying Search Full List by Dimension Name Set Name text box is NOT displayed", "FAIL");

			}

			// Verifying Search within Status DDL
			if (actions.isElementEnabled("ManageDimensionGroups.SearchWithinStatus")) {
				actions.reportCreatePASS("Verifying Search within Status DDL", "Search within Status DDL should enable",
						"Search within Status DDL is enable", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Search within Status DDL", "Search within Status DDL should enable",
						"Search within Status DDL is not enable", "FAIL");

			}

			// Verifying Status DDL
			if (!actions.isElementEnabled("RestMIList.MIStatusDrpdwn")) {
				actions.reportCreatePASS("Verifying Status DDL", "Status  DDL should disable", "Status DDL is disable",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verifying Status DDL", "Status  DDL should disable",
						"Status  DDL is not diable", "FAIL");

			}

			// Verifying filter button
			// Verifying presence of 'Next' Button
			Boolean Filterbutton;
			Filterbutton = actions.isElementPresent("DimesionNameSet.Filter");
			reporting_Pass_Fail("Verify whether 'Filter' Button is present", "'Filter' Button should be present",
					"'Filter' Button is present", "'Filter' Button is not present", Filterbutton);

			// Verifying new dimension button
			if (actions.isElementPresent("DimensionNameSet.NewDimensionSetButton")) {
				actions.reportCreatePASS("Verify New dimension name set  button",
						"New dimension name set button should display", "New dimension name set button is displayed",
						"PASS");
			} else {

				actions.reportCreateFAIL("Verify New dimension name set button",
						"New dimension name set button should display",
						"New dimension name set button is not displayed", "FAIL");
			}

			/*
			 * // Verifying market for AP String market =
			 * driver.findElement(By.xpath(actions.getLocator(
			 * "ScreenSet.FilterListMarketTextBox"))) .getAttribute("value"); if
			 * (market.equals("Australasia")) { actions.reportCreatePASS(
			 * "Verify market name text box",
			 * "Market name text box should disble with with text box",
			 * "Market name text box should disble with with text box is display"
			 * , "PASS"); } else {
			 * 
			 * actions.reportCreateFAIL("Verify market name text box",
			 * "Market name text box should diable with with text box",
			 * "Market name text box should disble with with text box is not display"
			 * , "FAIL");
			 * 
			 * }
			 */

			// Verifying market for US
			String market1 = driver.findElement(By.xpath(actions.getLocator("ScreenSet.FilterListMarketTextBox")))
					.getAttribute("value");
			if (market1.equals("US Country Office")) {
				actions.reportCreatePASS("Verify market name text box",
						"Market name text box should disble with with text box",
						"Market name text box should disble with with text box is display", "PASS");
			} else {

				actions.reportCreateFAIL("Verify market name text box",
						"Market name text box should diable with with text box",
						"Market name text box should disble with with text box is not display", "FAIL");

			}
			// Verifying country
			if (!actions.isElementEnabled("ScreenSet.FilterListRegionDD")) {
				actions.reportCreatePASS("Verify country ddl", "Country ddl should disable", "Country ddl is disable",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify country ddl", "Country ddl should disable",
						"Country ddl is NOT disable", "FAIL");

			}

			// Verifying columns code,description,size order and delete
			verifyTablecolumnsPresent("DimensionName.Table", "Name");
			verifyTablecolumnsPresent("DimensionName.Table", "Node");
			verifyTablecolumnsPresent("DimensionName.Table", "Status");
			verifyTablecolumnsPresent("DimensionName.Table", "Delete");

			// Creating dimension name set
			actions.smartWait(100);
			actions.WaitForElementPresent("DimensionNameSet.NewDimensionSetButton");
			strErrmsg = dtErr.split("#");
			actions.click("DimensionNameSet.NewDimensionSetButton");
			Thread.sleep(2000);
			actions.smartWait(50);
			mcd.SwitchToWindow("Dimension Name Sets");
			actions.click("DimensionNameSet.SelectButton");
			actions.smartWait(180);

			// Selecting restaurant number
			mcd.SwitchToWindow("Select Node");
			mcd.Selectrestnode("SelectNode.Table", strRest);
			mcd.SwitchToWindow("Dimension Name Sets");
			do {
				boolean blnWindow = false;
				setName = mcd.fn_GetRndName("Auto_DNS");
				actions.clear("DimensionNameSet.SetNameTextBox");
				actions.setValue("DimensionNameSet.SetNameTextBox", setName);
				actions.click("DimensionNameSet.NextButton");
				Thread.sleep(10000);

				// Checking unic name and number for dimension name set
				try {
					blnWindow = mcd.SwitchToWindow("@Dimension Name Set");
					if (blnWindow) {
						System.out.println("Menu Name and Number is accepted successfully");
						flag = false;
					} else {
						mcd.SwitchToWindow("Dimension Name Sets");
						if (actions.isTextPresence(strErrmsg[0], true)) {
							flag = true;
							System.out.println("Entered  number " + setName + " is already exist.");
							System.out.println(flag);
						}
					}

				} catch (Exception e) {
					if (actions.isTextPresence(strErrmsg[0], true)) {
						flag = true;
						System.out.println("Entered  number " + setName + " is already exist.");
						System.out.println(flag);
					}

				}

			} while (flag);

			// Navigate to restaurant profile
			System.out.println("> Navigate to :: " + strNavigateTo_1);
			actions.select_menu("RFMHome.Navigate", strNavigateTo_1);
			actions.smartWait(50);
			mcd.SwitchToWindow("#Title");
			actions.click("DimensionNameSet.ViewFullListButton");
			actions.smartWait(50);

			// Selecting one restaurant
			String rest = mcd.GetTableCellValue("DimensionName.Table", 1, "Number", "", "");
			WebElement Element = mcd.GetTableCellElement("DimensionName.Table", 1, "Number", "a");

			// Checking for restaurant have future settings
			if (actions.isElementPresent("RestaurantProfile.FutureSetting")) {
				actions.click(Element);
				actions.smartWait(50);
				actions.click("RestaurantProfile.OperationsDetailsTab");
				actions.smartWait(50);
				actions.setValue("DimensionNameSet.RestProfile", setName);
				actions.click("SubstitutionGroups.ApplyButton");
				Thread.sleep(2000);
				// mcd.smartsync(180);
				boolean booAlert = mcd.VerifyAlertMessageDisplayed("Warning Message",
						"Are you sure you want to save changes to the current settings? These changes will NOT propagate to the future settings.",
						true, AlertPopupButton.OK_BUTTON);
				actions.smartWait(100);
				flag = mcd.VerifyOnscreenMessage("SubstitutionGroups.InfoMessage", strErrmsg[2], true);
				if (flag) {
					actions.reportCreatePASS("Verify the action message after assigning DNS to a Restaurant",
							"Message '" + strErrmsg[2] + " ' should be displayed", "Expected Message is displayed",
							"PASS");
				} else {
					actions.reportCreateFAIL("Verify the action message after assigning DNS to a Restaurant",
							"Message '" + strErrmsg[2] + " ' should be displayed", "Expected Message is not displayed",
							"FAIL");
				}
				actions.smartWait(100);
			}
			// Restaurant does not have future settings and assign dimension
			// name set to restaurant
			else {

				actions.click(Element);
				actions.smartWait(50);
				actions.click("RestaurantProfile.OperationsDetailsTab");
				actions.smartWait(50);
				actions.setValue("DimensionNameSet.RestProfile", setName);
				actions.click("SubstitutionGroups.ApplyButton");
				mcd.smartsync(180);
				mcd.SwitchToWindow("Apply Changes Details");
				actions.click("ApplyChangesDetails.Save");
				mcd.smartsync(180);
				mcd.SwitchToWindow("Restaurant Profile");
				Thread.sleep(2000);
				flag = mcd.VerifyOnscreenMessage("SubstitutionGroups.InfoMessage", strErrmsg[2], true);

				if (flag) {
					actions.reportCreatePASS("Verify the action message after assigning DNS to a Restaurant",
							"Message '" + strErrmsg[2] + " ' should be displayed", "Expected Message is displayed",
							"PASS");
				} else {
					actions.reportCreateFAIL("Verify the action message after assigning DNS to a Restaurant",
							"Message '" + strErrmsg[2] + " ' should be displayed", "Expected Message is not displayed",
							"FAIL");
				}

				actions.smartWait(100);
			}

			// Navigate to dimension name set
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			actions.smartWait(50);
			mcd.SwitchToWindow("#Title");
			actions.setValue("DimensionNameSet.SearchSetTextbox", setName);
			actions.click("SubstitutionGroups.SearchButton");
			actions.smartWait(50);

			// Changing dimension name set to inactive
			Element = mcd.GetTableCellElement("DimensionName.Table", 1, "Name", "a");
			actions.click(Element);
			actions.smartWait(50);
			actions.setValue("DimensionNameSet.StatusDropDown", "Inactive");
			actions.click("DimensionNameSet.SaveButton");
			actions.smartWait(50);

			// Verifying error message
			flag = mcd.VerifyOnscreenMessage("SubstitutionGroups.ErrorMessage", strErrmsg[3], true);

			if (flag) {
				actions.reportCreatePASS("Verify the action message after assigning DNS to a Restaurant",
						"Message '" + strErrmsg[3] + " ' should be displayed", "Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the action message after assigning DNS to a Restaurant",
						"Message '" + strErrmsg[3] + " ' should be displayed", "Expected Message is not displayed",
						"FAIL");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	public void verifyTablecolumnsPresent(String tableLocator, String colName) {

		boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

		if (iscolPresent) {
			actions.reportCreatePASS("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is present in table", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is NOT present in table",
					"Fail");
		}
	}

	// Function for Reporting Pass/Fail
	public void reporting_Pass_Fail(String Desc, String ExpRes, String ActRes_Pass, String ActRes_Fail,
			Boolean status) {
		if (status) {
			actions.reportCreatePASS(Desc, ExpRes, ActRes_Pass, "PASS");
		}

		if (!status) {
			actions.reportCreateFAIL(Desc, ExpRes, ActRes_Fail, "FAIL");
		}
	}
}
