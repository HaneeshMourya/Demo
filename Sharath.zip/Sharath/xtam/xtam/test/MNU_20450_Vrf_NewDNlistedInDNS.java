package xtam.test;

import java.util.Map;
import java.util.Vector;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class MNU_20450_Vrf_NewDNlistedInDNS {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strNavigateTo_1;
	// TODO: Declare test-data variables for other data-parameters
	private String dnDescription;
	private int dnCode;
	private String strDnCode;
	private String strSize;
	private boolean flag;
	private String dtErrMsg;
	private String strErrMsg[];
	private String strUserID;

	public MNU_20450_Vrf_NewDNlistedInDNS(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strNavigateTo_1 = mcd.GetTestData("DT_NAVIGATE_TO_1");
		// TODO: GetTestData for other data-parameters
		dtErrMsg = mcd.GetTestData("DT_Err_Msg");
		strUserID = mcd.GetTestData("DT_USER_NAME");
	}

	@Test
	public void test_MNU_20450_Vrf_NewDNlistedInDNS() throws InterruptedException {
		String strPageTitle = ""; // TODO: Exact page-title
		String strPageSubHeading = ""; // TODO: Page Heading

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(
					"Verify that dimension name set contains only those name which are present in the system & also verify that newly added dimension name is getting added into dimension name set ");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
			actions.waitForPageToLoad(120);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			actions.waitForPageToLoad(120);
			actions.smartWait(60);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// Storing all DN into one string
			Vector Desc_Dimensions1 = new Vector();
			int iRows = mcd.GetTableRowCount("DimensionName.Table");
			for (int i = 1; i < iRows; i++) {
				String Description = mcd.GetTableCellValue("DimensionName.Table", i, 2, "input[1]", "");
				Desc_Dimensions1.add(Description);
			}
			System.out.println(Desc_Dimensions1);

			// Navigate to Dimension name set
			actions.select_menu("RFMHome.Navigate", strNavigateTo_1);
			actions.smartWait(15);
			mcd.SwitchToWindow("#Title");

			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			actions.smartWait(180);

			// Checking all DNS are displayed
			int dns_rc = mcd.GetTableRowCount("DimensionName.Table");
			if (dns_rc > 0) {
				actions.reportCreatePASS("Verify All active/inactive DNS", "All active/inactive DNS should disply",
						"All active/inactive DNS are displyed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify All active/inactive DNS", "All active/inactive DNS should disply",
						"All active/inactive DNS are not displyed", "FAIL");
			}
			actions.keyboardEnter("DimesionNameSets.Firstlink");
			actions.smartWait(180);

			// Storing DNS names into one string
			Vector Desc_Dimensions2 = new Vector();
			int iRows1 = mcd.GetTableRowCount("DimensionName.Table");
			for (int i = 1; i < iRows1; i++) {
				String Description1 = mcd.GetTableCellValue("DimensionName.Table", i, 2, "input[1]", "");
				Desc_Dimensions2.add(Description1);
			}

			boolean CompareDesc = (Desc_Dimensions1.equals(Desc_Dimensions2));

			// Comparing DN to DNS name
			if (CompareDesc) {
				actions.reportCreatePASS("Verifying DN", "All DN  should present in DNS", "All DN are displayed in DNS",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verifying DN", "All DN  should present in DNS",
						"All DN are not displayed in DNS", "FAIL");
			}

			actions.keyboardEnter("RFM.CancelBtn");
			actions.smartWait(180);

			// Navigate to DN
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			actions.waitForPageToLoad(120);
			actions.smartWait(60);
			mcd.SwitchToWindow("#Title");
			strErrMsg = dtErrMsg.split("#");

			// Click on new dimension name button
			actions.click("DimensionName.NewDimensionNameButton");
			Thread.sleep(1000);
			int rowCount = mcd.GetTableRowCount("DimensionName.Table");
			dnCode = mcd.fn_GetRndNumInRange(1, 20);
			strSize = Integer.toString(dnCode);
			mcd.SetTableCellValue("DimensionName.Table", rowCount, "Size Order", strSize, "input", "value");
			dnCode = mcd.fn_GetRndNumInRange(1, 9999);
			strDnCode = Integer.toString(dnCode);
			dnDescription = mcd.fn_GetRndName("Auto_DN");

			// Entering data into each and every cell of dimension
			mcd.SetTableCellValue("DimensionName.Table", rowCount, "Description", dnDescription, "input", "value");
			mcd.SetTableCellValue("DimensionName.Table", rowCount, "Code", strDnCode, "input", "value");
			actions.click("DimensionGroup.SaveButton");
			Thread.sleep(5000);

			try {
				// Verifying on screen message
				flag = mcd.VerifyAlertMessageDisplayed("Warning Message", strErrMsg[0], true,
						AlertPopupButton.OK_BUTTON);
				actions.click("DimensionGroup.SaveButton");
				if (!flag) {
					flag = mcd.VerifyAlertMessageDisplayed("Warning Message", strErrMsg[1], true,
							AlertPopupButton.OK_BUTTON);
				} else {
					flag = mcd.VerifyAlertMessageDisplayed("Warning Message", strErrMsg[0], true,
							AlertPopupButton.OK_BUTTON);
				}
				flag = true;

			} catch (Exception f) {
				flag = false;
				actions.smartWait(15);

			}

			flag = mcd.VerifyOnscreenMessage("SubstitutionGroups.InfoMessage", strErrMsg[2], true);
			if (flag) {
				actions.reportCreatePASS("Verify the info message",
						"Message '" + strErrMsg[2] + "' should be displayed", "Expected message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the info message",
						"Message '" + strErrMsg[2] + "' should be displayed", "Expected message is not displayed",
						"FAIL");
			}

			// ** Select Menu Option *//*
			System.out.println("> Navigate to :: " + strNavigateTo_1);
			actions.select_menu("RFMHome.Navigate", strNavigateTo_1);
			actions.smartWait(15);
			mcd.SwitchToWindow("#Title");

			actions.click("SetAssignmentReport.SearchButton");
			actions.smartWait(15);

			// Click on DNS
			String strDNS = mcd.GetTableCellValue("DimensionName.Table", 1, "Name", "", "");
			WebElement Element = mcd.GetTableCellElement("DimensionName.Table", 1, "Name", "a");
			Element.click();
			actions.smartWait(25);
			mcd.SwitchToWindow("#Title");
			rowCount = mcd.GetTableRowCount("DimensionName.Table");

			// Checking for newly created DN
			String val = "";
			flag = false;
			for (int i = 1; i <= rowCount; i++) {
				val = mcd.GetTableCellValue("DimensionName.Table", i, "Description", "input", "value");
				if (val.equals(dnDescription)) {
					flag = true;
					break;
				}
			}

			// Verifying results
			if (flag) {
				actions.reportCreatePASS("Verify the Newly added Dimension Name is available in the Dimension Name Set",
						"Newly added Dimension Name should be available in the Dimension Name Set",
						"Newly added Dimension Name is available in the Dimension Name Set", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the Newly added Dimension Name is available in the Dimension Name Set",
						"Newly added Dimension Name should be available in the Dimension Name Set",
						"Newly added Dimension Name is not available in the Dimension Name Set", "FAIL");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}
