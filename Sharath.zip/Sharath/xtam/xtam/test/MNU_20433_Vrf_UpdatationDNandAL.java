package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20433_Vrf_UpdatationDNandAL {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();
	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strLevel;
	private String strNavigateTo;

	// TODO: Declare test-data variables for other data-parameters
	private String dnDescription;
	private boolean flag;
	private String dtErrMsg;
	private String[] strErrMsg;
	private String strUserID;
	private String tcDescription;

	// length variable to compare updated name
	private int brforeLength, afterLength;

	public MNU_20433_Vrf_UpdatationDNandAL(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strLevel = mcd.GetTestData("DT_Level");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");

		// TODO: GetTestData for other data-parameters
		dtErrMsg = mcd.GetTestData("DT_Err_Msg");
		strUserID = mcd.GetTestData("DT_USER_NAME");
		tcDescription = mcd.GetTestData("DT_Description");

	}

	@Test
	public void test_MNU_20433_Vrf_UpdatationDNandAL() throws InterruptedException {
		String strPageTitle = "Dimension Names"; // TODO: Exact page-title
		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(tcDescription);

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
			actions.smartWait(60);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			actions.waitForPageToLoad(120);
			actions.smartWait(60);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();
			
			//Verifying dimension name button
			if(actions.isElementPresent("DimensionNames.NewDimensionName"))
			{
				actions.reportCreatePASS("Verify NewDimensionName button", "NewDimensionName button should display", "NewDimensionName buttom is displayed", "PASS");
			}else{
				actions.reportCreateFAIL("Verify NewDimensionName button", "NewDimensionName button should display", "NewDimensionName button is not displayed", "FAIL");

			}
			
			//Verifying Save button
			if(actions.isElementPresent("RFMQueueRoutingPopupPage.SaveButton"))
			{
				actions.reportCreatePASS("Verify Save button", "Save button should display", "Save buttom is displayed", "PASS");
			}else{
				actions.reportCreateFAIL("Verify Save button", "Save button should display", "Save button is not displayed", "FAIL");

			}
			
			//Verifying Cancel button
			if(actions.isElementPresent("RFMQueueManagementPage.CancelButton"))
			{
				actions.reportCreatePASS("Verify Cancel button", "Cancel button should display", "Cancel buttom is displayed", "PASS");
			}else{
				actions.reportCreateFAIL("Verify Cancel button", "Cancel button should display", "Cancel button is not displayed", "FAIL");

			}
			
			

			//Verifying columns code,description,size order and delete
			verifyTablecolumnsPresent("DimensionName.Table", "Code");
			verifyTablecolumnsPresent("DimensionName.Table", "Description");
			verifyTablecolumnsPresent("DimensionName.Table", "Size Order");
			verifyTablecolumnsPresent("DimensionName.Table", "Delete");
			
			
			// Updating dimension name
			System.out.println("Start");
			strErrMsg = dtErrMsg.split("#");
			dnDescription = mcd.GetTableCellValue("DimensionName.Table", 1, "Description", "input", "value");

			// Getting the before update length
			brforeLength = dnDescription.length();
			dnDescription = dnDescription + "_U";
			mcd.SetTableCellValue("DimensionName.Table", 1, "Description", dnDescription, "input", "value");

			// Getting the after update length
			afterLength = mcd.GetTableCellValue("DimensionName.Table", 1, "Description", "input", "value").length();

			// If length are same then rename the update name
			if (brforeLength == afterLength)
				dnDescription = "NONE";
			mcd.SetTableCellValue("DimensionName.Table", 1, "Description", dnDescription, "input", "value");

			// Click on Save button
			actions.click("DimensionGroup.SaveButton");
			actions.smartWait(180);
			flag = mcd.VerifyOnscreenMessage("SubstitutionGroups.InfoMessage", strErrMsg[2], true);
			if (flag) {
				actions.reportCreatePASS("Verify the info message",
						"Message '" + strErrMsg[2] + "' should be displayed", "Expected message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the info message",
						"Message '" + strErrMsg[2] + "' should be displayed", "Expected message is not displayed",
						"FAIL");
			}

			// Verifying the audit logs:
			boolean blnAudit = false;
			blnAudit = rfm.VerifyAuditLog_Entry(strPageTitle, "Update", strLevel);

			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Entry for Update Dimension Names",
						"Audit log should be generated for Update Dimension Names",
						"Audit log generated for Update Dimension Names succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Entry for Update Dimension Names",
						"Audit log should be generated for Update Dimension Names",
						"Audit log not generated for Update Dimension Names succesfully", "FAIL");
			}

			// Verifying audit log details
			blnAudit = rfm.RFM_VerifyAuditLog_Details("RFM2", strUserID, strPageTitle, "Update", strLevel, strMarket,
					"Dimension Name has been updated.");
			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Details for Update Dimension Names",
						"Audit log details should be generated for Update Dimension Names",
						"Audit log details generated for Dimension Names succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Details for Update Dimension Names",
						"Audit log details should be generated for Update Dimension Names",
						"Audit log details not generated for Dimension Namesitem succesfully", "FAIL");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
	
	public void verifyTablecolumnsPresent(String tableLocator, String colName) {

        boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

        if (iscolPresent) {
               actions.reportCreatePASS("Verify " + colName + " Column is present in table",
                            colName + " Column should be present in table", colName + " Column is present in table", "Pass");
        } else {
               actions.reportCreateFAIL("Verify " + colName + " Column is present in table",
                            colName + " Column should be present in table", colName + " Column is NOT present in table",
                            "Fail");
        }
 }
}
