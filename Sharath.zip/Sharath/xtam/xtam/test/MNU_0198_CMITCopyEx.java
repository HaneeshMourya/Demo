package xtam.test;

import java.util.Map;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import crossbrowser.library.Keywords;
import crossbrowser.library.Keywords.DialogType;
import crossbrowser.library.PackageValidation;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.XMLValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0198_CMITCopyEx {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private XMLValidations xmlValidation;
	private PackageValidation pkg;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strprotype, strMIrange, strmsg, strmenutype;
	// TODO: Declare test-data variables for other data-parameters

	public MNU_0198_CMITCopyEx(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		pkg = new PackageValidation(driver, actions, uiActions, inputData, mcd, rfm);
		xmlValidation = new XMLValidations();

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strprotype = mcd.GetTestData("DT_MENUITEMCLASS");
		strMIrange = mcd.GetTestData("DT_MIRANGE");
		strmsg = mcd.GetTestData("DT_ERR_MSG");
		strmenutype = mcd.GetTestData("DT_MIPARAM");
		// TODO: GetTestData for other data-parameters
	}

	@Test
	public void test_MNU_0198_CMITCopyEx() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"Create a menu item by using copy settings from existing functionality and Active' Menu Items of Class=Check Category/Choice can be created without Components");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// calling the create Menu item function
			int menuitem = RFM_MI_CreatecopyexistingMenuItem_updated(strMIrange, strprotype, strmsg, strmenutype);
			actions.reportCreatePASS("Verify that Menu item is created or not",
					"Menu Item number-" + menuitem + " of Class-" + strprotype + " should get created ",
					"Menu Item number-" + menuitem + " of Class-" + strprotype
							+ " created with copy settings from existing  succesfully",
					"Pass");

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	public int RFM_MI_CreatecopyexistingMenuItem_updated(String MIrange, String pro_type, String strmsg,
			String strmenutype) {
		boolean blnflag = false;
		String[] strparam = strmenutype.split("#");
		String[] strrange = MIrange.split("#");
		String strerrmsg[] = strmsg.split("#");
		String s = "";
		int mi_num = 0, mi_start = 0, mi_end = 0;
		try {
			boolean flag = false;

			System.out.println(
					"********************************************************************** Start Test-Steps executions");

			// String MainWindow_NewMenuItem = driver.getWindowHandle();
			WebElement ws = driver.findElement(By.xpath("//*[@class='button button'][contains(text(),'Add New')]"));
			actions.click(ws);

			// actions.windowSwitch(MainWindow_NewMenuItem,"Add New Menu Item");
			mcd.SwitchToWindow("Add New Menu Item");

			switch (pro_type) {
			case "CONTAINER_VALUE_MEAL":
				s = "Auto_CVM_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "PRODUCT":
				s = "Auto_Pro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "VALUE_MEAL":
				s = "Auto_VM_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "CHOICE":
				s = "Auto_Choice_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[0]);
				mi_end = Integer.parseInt(strrange[1]);
				break;
			case "CHOICE_EVM":
				s = mcd.fn_GetRndName("Auto_ChoiceEVM");
				mi_start = Integer.parseInt(strrange[0]);
				mi_end = Integer.parseInt(strrange[1]);
				break;
			case "CHECK CATEGORY":
				s = "Auto_Check_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[2]);
				mi_end = Integer.parseInt(strrange[3]);
				break;
			case "NON_FOOD_PRODUCT":
				s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "RAW_ITEM":
				s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "EVM":
				s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "COMMENT":
				s = "Auto_CMNT_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[6]);
				mi_end = Integer.parseInt(strrange[7]);
				break;
			default:
				break;
			}

			System.out.println("product name:" + s);
			actions.setValue("AddNewMI.MenuItemName", s);
			actions.javaScriptClick("MMILAddNewMenuItem.yrdbtn");
			actions.keyboardEnter("RFMHome.Select");
			mcd.waitAndSwitch("Copy Settings From Existing Menu Item : Find Menu Item");
			actions.keyboardEnter("MasterMenuItemList.Searchbtn");
			actions.smartWait(20);
			WebElement record = mcd.GetTableCellElement("ScreenSet.Table", 1, "Number", "a");
			actions.click(record);
			mcd.SwitchToWindow("Add New Menu Item");

			do {
				mi_num = mcd.fn_GetRndNumInRange(mi_start, mi_end);
				actions.clear("AddNewMI.MenuItemNumber");
				actions.setValue("AddNewMI.MenuItemNumber", mi_num);
				actions.keyboardEnter("AddNewMI.Next");
				Thread.sleep(3000);
				actions.waitForPageToLoad(180);
				boolean blnWindow = false;

				try {
					blnWindow = mcd.SwitchToWindow("@Manage Menu Items");
					if (blnWindow) {
						System.out.println("Menu Name and Number is accepted successfully");
						blnflag = false;
					} else {
						mcd.SwitchToWindow("Add New Menu Item");
						if (actions.isTextPresence(strerrmsg[0], true)) {
							blnflag = true;
							System.out.println("Entered  number " + mi_num + " is already exist.");
							System.out.println(blnflag);
						}
					}

				} catch (Exception err) {
					if (actions.isTextPresence(strerrmsg[0], true)) {
						blnflag = true;
						System.out.println("Entered  number " + mi_num + " is already exist.");
						System.out.println(blnflag);
					}
				}

			} while (blnflag == true);

			// Navigate to �POS/KVS Settings� tab
			actions.smartWait(10);
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("ManageMenuItem.POSKVS_tab");
			mcd.VerifyAlertMessageDisplayed("Warning", "Do you want to create menu item and continue?", true,
					AlertPopupButton.OK_BUTTON);
			actions.smartWait(5);

			// Navigate to 'Components' tab
			actions.click("ManageMenuItem.Components");
			actions.smartWait(20);

			// Click on <Add/Remove>button
			actions.click("ManageMenuItems.AddRemove");
			mcd.waitAndSwitch("Common Menu Item Selector");

			// Add the menu item
			actions.click("MasterMenuItemList.Searchbtn");
			actions.smartWait(20);
			WebElement elem_checkbox = mcd.GetTableCellElement("AddRemoveComponent.webtable", 1, "Add", "input[1]");
			actions.javaScriptClick(elem_checkbox);
			WebElement elem_checkbox1 = mcd.GetTableCellElement("AddRemoveComponent.webtable", 2, "Add", "input[1]");
			actions.javaScriptClick(elem_checkbox1);
			actions.click("ManageMenuItem.SaveasCSVbtn");
			mcd.SwitchToWindow("@Title");

			// Click on Apply Button
			actions.keyboardEnter("CurrentMenuItemDetails.Apply");
			mcd.waitAndSwitch("Apply Changes Details");
			actions.click("ApplyChangesDetails.FutureDateRadioButton");
			actions.click("ApplyChangesDetails.CalendarIcon");
			actions.smartWait(10);
			mcd.Get_future_date(3, "Close", strApplicationDate);
			actions.keyboardEnter("ApplyChangesDetails.RPSaveButton");
			mcd.SwitchToWindow("Manage Menu Items");
			actions.smartWait(10);

			// Click on Status change button and select the future date
			actions.keyboardEnter("ManageMenuItems.ChangeStatus");

			if (input.get("_rowId").toString().toUpperCase().contains("US")) {
				Thread.sleep(1000);
				mcd.waitAndSwitch("Approval Status Changes");
				actions.smartWait(80);
				actions.click("StatusChanges.AddStatusButton");
				actions.click("StatusChanges.CalandarWidgetActiveStatus");
				mcd.Get_future_date(0, "Close", strApplicationDate);
				actions.keyboardEnter("GlobalSettingsMenuItemCustomParam.save");
				mcd.waitAndSwitch("Run Menu Item Usage Report");
				actions.keyboardEnter("GlobalSettingsMenuItemCustomParam.cancel");
				mcd.waitAndSwitch("Approval Status Changes");
				actions.smartWait(10);
				actions.keyboardEnter("MenuItemCustomParam.cancel");
				mcd.SwitchToWindow("@Title");

			}

			else if (input.get("_rowId").toString().toUpperCase().contains("AP")) {
				mcd.waitAndSwitch("Status Changes");
				actions.click("ApprovalStatusChanges.AddBtn");
				actions.click("StatusChanges.CalandarWidgetActiveStatus");
				mcd.Get_future_date(0, "Close", strApplicationDate);
				actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
				actions.keyboardEnter("MenuItemCustomParam.save");
				mcd.VerifyAlertMessageDisplayed("Warning",
						"Defining a status on todays date will override the existing current status.Are you sure you want to proceed?",
						true, AlertPopupButton.OK_BUTTON);
				actions.smartWait(10);
				actions.keyboardEnter("MenuItemCustomParam.cancel");
				mcd.SwitchToWindow("@Title");
			}

			// Click on Remove all button and verify alert message
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.click("ManageMenuItems.RemoveAllFutureSettings");
			mcd.VerifyAlertMessageDisplayed("Warning", "Are you sure you want to remove the future settings?", true,
					AlertPopupButton.OK_BUTTON);
			actions.smartWait(10);
			mcd.SwitchToWindow("Master Menu Item List");

		} catch (Exception e) {

		}
		return mi_num;
	}

	//// ====
	///
	// ====
	public void CopyExistingMenuI(String MIrange, String mi_num, String strmsg, boolean blnflag) throws Exception {

		// splitting the MI range
		String[] strrange = MIrange.split("#");
		String[] ermsg = strmsg.split("#");

		// Copying the menu Item number now
		actions.click("AddNewMI.Yes_rbtn");
		Thread.sleep(2000);
		// clicking on the select button
		actions.click("AddNewMI.selectbtn");
		Thread.sleep(1000);

		// Switching to New Pop up window
		mcd.SwitchToWindow("Copy Settings From Existing Menu Item");

		// Copy Settings From Existing Menu Item : Find Menu Item

		// searching for the specific Menu item
		actions.click("COPYMI.exactrbtn");
		actions.setValue("COPYMI.searchtextbox", mi_num);
		actions.click("COPYMI.searchbtn");
		Thread.sleep(1000);
		actions.waitForPageToLoad(120);

		// Select web table record now
		WebElement record = mcd.GetTableCellElement("COPYMI.datatable", 1, "Number", "a");
		record.click();
		Thread.sleep(2000);

		// switching to back to previous window
		mcd.SwitchToWindow("Add New Menu Item");

		actions.setValue("AddNewMI.MenuItemName", mcd.fn_GetRndName("VM_"));

		do {
			// Entering Name and number in the fields

			int mi_start = Integer.parseInt(strrange[4]); /// Getting the random
															/// number
			int mi_end = Integer.parseInt(strrange[5]); ////

			actions.clear("AddNewMI.MenuItemNumber");
			actions.setValue("AddNewMI.MenuItemNumber", mcd.fn_GetRndNumInRange(mi_start, mi_end));

			// reading value from the text box
			String menu_num = actions.getValue("AddNewMI.MenuItemNumber");
			actions.click("AddNewMI.Next");

			// ===
			mcd.SwitchToWindow("Master Menu Item List");
			try {
				mcd.SwitchToWindow("Add New Menu Item");
				if (actions.isTextPresence(ermsg[0], true)) {
					blnflag = true;
					// Reporter.log("Entered number "+menu_num+" is already
					// exist.");
					System.out.println(blnflag);
				}
			} catch (Exception e) {
				blnflag = false;
				Thread.sleep(3000);
				mcd.SwitchToWindow("#Title");
				// Reporter.log("Menu Name and Number is accepted
				// successfully");
				System.out.println(driver.getWindowHandles());
			}
		} while (blnflag == true);

	}
}
