package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.MasterMenuItem;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20205_VrfyCompoInactive {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private MasterMenuItem mmi;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strWM1;
	private String MIrange;
	private String pro_type;
	private String strmsg;
	private String strPageSubHeading;
	private String strmenutype;
	// TODO: Declare test-data variables for other data-parameters

	public MNU_20205_VrfyCompoInactive(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		mmi = new MasterMenuItem(driver, actions, uiActions, inputData, mcd, rfm);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strWM1 = mcd.GetTestData("WarningMessage1");
		strPageSubHeading = "Master Menu Item List";
		MIrange = mcd.GetTestData("DT_MIRANGE");
		pro_type = mcd.GetTestData("DT_MENUITEMCLASS");
		strmsg = mcd.GetTestData("DT_ERR_MSG");
		strmenutype = mcd.GetTestData("DT_MIPARAM");
		// TODO: GetTestData for other data-parameters
	}

	@Test
	public void test_MNU_20205_VrfyCompoInactive() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// Creating Test Data --

			// creating menu item 1
			int MenuNumber_1 = mmi.RFM_MI_CreateMenuItem_updated(MIrange, pro_type, strmsg, strmenutype);
			String strMI_1 = Integer.toString(MenuNumber_1);

			// creating menu item 2
			int MenuNumber_2 = mmi.RFM_MI_CreateMenuItem_updated(MIrange, pro_type, strmsg, strmenutype);
			String strMI_2 = Integer.toString(MenuNumber_2);
			actions.WaitForElementPresent("MasterMenuItemList.SearchTextField", 100);
			actions.smartWait(100);

			// Search for the menu item 2, select it and navigate to componanats
			// tab
			actions.setValue("MasterMenuItemList.SearchTextField", strMI_2);
			actions.keyboardEnter("MasterMenuItemList.SearchButton");
			actions.smartWait(100);
			actions.keyboardEnter("MasterMenuItemList.TableFirstValue");
			actions.smartWait(100);
			actions.click("ManageMenuItems.Components");
			actions.smartWait(100);

			// Click on add or remove button and search for the menu item 1
			actions.click("MMICurrentMenuItemDetails.adrmv");
			Thread.sleep(2000);
			mcd.SwitchToWindow("Common Menu Item Selector");
			actions.setValue("CommonMenuItemSelector.SearchTextBox", strMI_1);
			actions.click("SetAssignmentReport.SearchButton");
			actions.smartWait(10);

			// Select the menu item and save it
			actions.click("CommonMenuItemSelector.AddCheckBox");
			actions.click("RFMQueueRoutingPopupPage.SaveButton");
			mcd.SwitchToWindow("Manage Menu Items");
			actions.click("RFMMMIL.Applybtn");
			Thread.sleep(3000);
			try {
				mcd.SwitchToWindow("Apply Changes Details");
				actions.click("MasterMenuItemList.ApplyChangeSave");
			} catch (Exception e) {

			}

			mcd.SwitchToWindow("Manage Menu Items");
			actions.click("RFMPresentationRoutingSetPage.CancelButton");

			// Search for the menu item that is just updated
			actions.clear("MasterMenuItemList.SearchTextField");
			actions.setValue("MasterMenuItemList.SearchTextField", strMI_2);
			actions.keyboardEnter("MasterMenuItemList.SearchButton");
			actions.smartWait(100);
			actions.keyboardEnter("MasterMenuItemList.TableFirstValue");
			actions.smartWait(100);

			/** Step 2: change Status */
			mcd.SwitchToWindow("#Title");
			actions.WaitForElementPresent("ManageMenuItems.ChangeAprrovalStatusButton", 100);
			actions.keyboardEnter("ManageMenuItems.ChangeAprrovalStatusButton");
			if (strMarket.equals("US Country Office")) {
				mcd.SwitchToWindow("Approval Status Changes");
				actions.WaitForElementPresent("ApprovalStatusChanges.AddButton", 100);
				actions.keyboardEnter("ApprovalStatusChanges.AddButton");
				actions.click("ApprovalStatusChanges.CalendarIconScnd");
				mcd.sel_current_date("ApprovalStatusChanges.CalendarIconScnd", strApplicationDate);
				actions.keyboardEnter("ApprovalStatusChanges.SaveButton1");
				try {
					boolean booAlert = mcd.VerifyAlertMessageDisplayed("Warning Message", strWM1, false,
							AlertPopupButton.OK_BUTTON);

				} catch (Exception err) {
				}

				try {

					mcd.SwitchToWindow("Run Menu Item Usage Report");
					List<WebElement> ele_OkButton = driver.findElements(By.xpath("//*[@id='_td']/a"));
					actions.click(ele_OkButton.get(1));
				} catch (Exception err) {
				}
				mcd.SwitchToWindow("Approval Status Changes");
				List<WebElement> ele_CancelButton = driver.findElements(By.xpath("//*[@class='button']"));
				for(int i=0;i<ele_CancelButton.size();i++ ){
					if(ele_CancelButton.get(i).getText().trim().equalsIgnoreCase("cancel")){
						actions.javaScriptClick(ele_CancelButton.get(i));	
					}		
				}
				
			}

			if (strMarket.equals("Australasia")) {
				mcd.SwitchToWindow("Status Changes");
				actions.WaitForElementPresent("ApprovalStatusChanges.AddButton", 100);
				actions.keyboardEnter("ApprovalStatusChanges.AddButton");
				actions.click("ApprovalStatusChanges.CalendarIconScnd");
				mcd.sel_current_date("ApprovalStatusChanges.CalendarIconScnd", strApplicationDate);
				actions.keyboardEnter("ApprovalStatusChanges.SaveButton");

				try {
					boolean booAlert = mcd.VerifyAlertMessageDisplayed("Warning Message", strWM1, true,
							AlertPopupButton.OK_BUTTON);
					mcd.SwitchToWindow("Run Menu Item Usage Report");
					List<WebElement> ele_OkButton = driver.findElements(By.xpath("//*[@id='_td']/a"));
					actions.click(ele_OkButton.get(1));
				} catch (Exception err) {
				}

				Thread.sleep(2000);
				mcd.SwitchToWindow("Status Changes");
				actions.click("ApprovalStatusChanges.CancelButton");
			}

			Thread.sleep(2000);
			mcd.SwitchToWindow("Manage Menu Items");
			Thread.sleep(2000);
			actions.keyboardEnter("ManageMenuItems.CancelButton");
			actions.smartWait(100);
			Thread.sleep(2000);
			mcd.SwitchToWindow("#Title");

			actions.WaitForElementPresent("MasterMenuItemList.SearchTextField", 100);
			actions.smartWait(100);

			actions.clear("MasterMenuItemList.SearchTextField");
			actions.setValue("MasterMenuItemList.SearchTextField", strMI_1);

			// added by Sunny
			actions.keyboardEnter("MasterMenuItemList.SearchButton");
			actions.smartWait(100);
			actions.keyboardEnter("MasterMenuItemList.TableFirstValue");
			actions.smartWait(100);
			mcd.SwitchToWindow("#Title");
			actions.WaitForElementPresent("ManageMenuItems.StatusTextBox", 100);
			actions.smartWait(100);

			String strValue = driver.findElement(By.xpath(actions.getLocator("ManageMenuItems.StatusTextBox")))
					.getAttribute("value");
			System.out.println(strValue);

			if (strValue.equals("Active")||strValue.equalsIgnoreCase("Approved")) {
				actions.reportCreatePASS("The status of the menu item is 'Active'.",
						"The status of the menu item should be 'Active'.", "The status of the menu item is 'Active'.",
						"Pass");
			} else {
				actions.reportCreateFAIL("The status of the menu item is 'Active'.",
						"The status of the menu item should be 'Active'.",
						"The status of the menu item is not 'Active'.", "Fail");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}
