package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20486_CreateSRGCopy {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo, strExptMessage;
	private String strOperation, strActivity, strLevel, strUID, strDBName;

	public MNU_20486_CreateSRGCopy(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strExptMessage = mcd.GetTestData("DT_ALERT");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strActivity = mcd.GetTestData("DT_ACTIVITY");
		strLevel = mcd.GetTestData("DT_LEVEL");
		strDBName = mcd.GetTestData("DT_DBNAME");
		strUID = mcd.GetTestData("DT_USERID");
	}

	@Test
	public void test_MNU_20486_CreateSRGCopy() throws InterruptedException {

		try {
			System.out.println("************************************ Test execution starts");

			actions.setTestcaseDescription(
					"Verify the functionality for Creating New Smart Reminder Group with copying existing settings.");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Navigate to Smart Reminder Group */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			String[] strMessage = strExptMessage.split("#");
			actions.WaitForElementPresent("SmartReminderGroup.NewSmartReminderGroupButton", 100);

			// Get the Existing First Smart Reminder Group name
			String strExistValue = driver
					.findElement(By.xpath(actions.getLocator("SmartReminderGroup.TableFirstValue"))).getText();
			System.out.println(strExistValue);

			// Creating New Smart Reminder Group
			actions.keyboardEnter("SmartReminderGroup.NewSmartReminderGroupButton");
			mcd.SwitchToWindow("Add New Smart Reminder Group");

			// GUI verification of Smart Reminder Group Name text box
			if (actions.isElementPresent("AddNewSmartReminderGroup.SearchTextBox")) {
				actions.reportCreatePASS("Verify Smart Reminder Group Name text box",
						"Smart Reminder Group Name text box should be displayed",
						"Smart Reminder Group Name text box is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify Smart Reminder Group Name text box",
						"Smart Reminder Group Name text box should be displayed",
						"Smart Reminder Group Name text box is not displayed", "Fail");
			}

			// Validating for Copy existing Smart Reminder Group Name radio
			// button 'No' is selected by default
			if (actions.isElementSelected("AddNewSmartReminderGroup.RadioNo")) {
				actions.reportCreatePASS("Verify Copy Settings from existing Smart Reminder Group radio button",
						"'No' radio button should be selected by default", "'No' radio button is selected by default",
						"Pass");
			} else {
				actions.reportCreateFAIL("Verify Copy Settings from existing Smart Reminder Group radio button",
						"'No' radio button should be selected by default",
						"'No' radio button is not selected by default", "Fail");
			}

			// Validating for the length of Smart Reminder Group Name text box
			String TestLongName = generateRepeatingString('a', 65);
			actions.setValue("AddNewSmartReminderGroup.SearchTextBox", TestLongName);
			String strEntered = driver
					.findElement(By.xpath(actions.getLocator("AddNewSmartReminderGroup.SearchTextBox")))
					.getAttribute("value");
			if (strEntered.length() == 50) {
				actions.reportCreatePASS("Verify Smart Remainder Group Name text box accepts only 50 characters",
						"Smart Remainder Group Name text box should accept 50 characters",
						"Smart Remainder Group Name text box accepts 50 characters", "Pass");
			} else {
				actions.reportCreateFAIL("Verify Smart Remainder Group Name text box accepts only 50 characters",
						"Smart Remainder Group Name text box should accept 50 characters",
						"Smart Remainder Group Name text box does not accept 50 characters", "Fail");
			}
			actions.clear("AddNewSmartReminderGroup.SearchTextBox");
			actions.keyboardEnter("AddNewSmartReminderGroup.Next");
			boolean IsAlert = false;
			IsAlert = mcd.VerifyAlertMessageDisplayed("Alert", strMessage[0], true, AlertPopupButton.OK_BUTTON);
			if (IsAlert) {
				actions.reportCreatePASS("Verify " + strMessage[0], strMessage[0] + " should be displayed",
						strMessage[0] + " is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify " + strMessage[0], strMessage[0] + " should be displayed",
						strMessage[0] + " is not displayed", "Fail");
			}

			// Validating error message for existing Smart Reminder Group Name
			actions.setValue("AddNewSmartReminderGroup.SearchTextBox", strExistValue);
			actions.keyboardEnter("AddNewSmartReminderGroup.Next");
			mcd.smartsync(180);
			if (actions.isTextPresence(strMessage[1], true)) {
				actions.reportCreatePASS("Verify " + strMessage[1], strMessage[1] + " should be displayed",
						strMessage[1] + " is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify " + strMessage[1], strMessage[1] + " should be displayed",
						strMessage[1] + " is not displayed", "Fail");
			}

			// Enter valid Smart Reminder Group Name and select 'Yes' for Copy
			// Existing SRG
			actions.clear("AddNewSmartReminderGroup.SearchTextBox");
			String strRandName = mcd.fn_GetRndName("Auto");
			actions.setValue("AddNewSmartReminderGroup.SearchTextBox", strRandName);
			/** Click on 'Yes' radio Button */
			Thread.sleep(2000);
			actions.javaScriptClick("AddNewSmartReminderGroup.RadioYes");
			actions.keyboardEnter("AddNewSmartReminderGroup.Next");
			Thread.sleep(5000);

			// Validating select Copy existing Smart Reminder Group Name error
			// message
			boolean IsBlnalert;
			IsBlnalert = mcd.VerifyAlertMessageDisplayed("Alert", strMessage[2], true, AlertPopupButton.OK_BUTTON);
			if (IsBlnalert) {
				actions.reportCreatePASS("Verify " + strMessage[2], strMessage[2] + " should be displayed",
						strMessage[2] + " is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify " + strMessage[2], strMessage[2] + " should be displayed",
						strMessage[2] + " is not displayed", "Fail");
			}

			/** Click on Copy Smart Reminder */
			actions.keyboardEnter("AddNewSmartReminderGroup.CopySmartReminderGroupCopy");
			mcd.waitAndSwitch("Copy Smart Reminder Group");
			actions.WaitForElementPresent("CopySmartReminderGroup.FirstValue", 100);
			/** Selecting First Value */
			actions.click("CopySmartReminderGroup.FirstValue");
			mcd.waitAndSwitch("Add New Smart Reminder Group");
			actions.keyboardEnter("AddNewSmartReminderGroup.Next");
			Thread.sleep(5000);
			driver.switchTo().window("");
			mcd.waitAndSwitch("Smart Reminder Group");

			// Validating the Group Name text box accepts only 50 characters
			actions.clear("SmartReminderGroup.FirstName");
			String TestLongName1 = generateRepeatingString('a', 55);
			actions.setValue("SmartReminderGroup.FirstName", TestLongName1);
			String strEntered1 = driver.findElement(By.xpath(actions.getLocator("SmartReminderGroup.FirstName")))
					.getAttribute("value");
			if (strEntered1.length() == 50) {
				actions.reportCreatePASS(
						"Verify Smart Remainder Default Group Name text box accepts only 50 characters",
						"Smart Remainder Default Group Name text box should accept 50 characters",
						"Smart Remainder Default Group Name text box accepts 50 characters", "Pass");
			} else {
				actions.reportCreateFAIL(
						"Verify Smart Remainder Default Group Name text box accepts only 50 characters",
						"Smart Remainder Default Group Name text box should accept 50 characters",
						"Smart Remainder Default Group Name text box does not accept 50 characters", "Fail");
			}
			// Validating for blank Group Name error message
			actions.clear("SmartReminderGroup.FirstName");
			actions.keyboardEnter("SmartReminderGroup.SaveButton");
			boolean IsBlnalrt;
			IsBlnalrt = mcd.VerifyAlertMessageDisplayed("Alert", strMessage[3], true, AlertPopupButton.OK_BUTTON);
			if (IsBlnalrt) {
				actions.reportCreatePASS("Verify " + strMessage[3], strMessage[3] + " should be displayed",
						strMessage[3] + " is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify " + strMessage[3], strMessage[3] + " should be displayed",
						strMessage[3] + " is not displayed", "Fail");
			}

			// Entering valid group name
			String strRandName1 = mcd.fn_GetRndName("Auto");
			actions.clear("SmartReminderGroup.FirstName");
			/** Set Value in First Name */
			actions.setValue("SmartReminderGroup.FirstName", strRandName1);

			// Validating Question text box accepts only 250 characters
			String TestLongName2 = generateRepeatingString('a', 255);
			actions.setValue("SmartReminderGroup.FirstQuestion", TestLongName2);
			String strEntered2 = driver.findElement(By.xpath(actions.getLocator("SmartReminderGroup.FirstQuestion")))
					.getAttribute("value");
			if (strEntered2.length() == 250) {
				actions.reportCreatePASS("Verify Smart Remainder Group Question text box accepts only 250 characters",
						"Smart Remainder Group Question text box should accept 250 characters",
						"Smart Remainder Group Question text box accepts 250 characters", "Pass");
			} else {
				actions.reportCreateFAIL("Verify Smart Remainder Group Question text box accepts only 250 characters",
						"Smart Remainder Group Question text box should accept 250 characters",
						"Smart Remainder Group Question text box does not accept 250 characters", "Fail");
			}

			// Validating error message for blank question text box
			actions.clear("SmartReminderGroup.FirstQuestion");
			actions.keyboardEnter("SmartReminderGroup.SaveButton");
			boolean IsBlnQuest;
			IsBlnQuest = mcd.VerifyAlertMessageDisplayed("Alert", strMessage[4], true, AlertPopupButton.OK_BUTTON);
			if (IsBlnQuest) {
				actions.reportCreatePASS("Verify " + strMessage[4], strMessage[4] + " should be displayed",
						strMessage[4] + " is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify " + strMessage[4], strMessage[4] + " should be displayed",
						strMessage[4] + " is not displayed", "Fail");
			}

			// Entering valid question in question text box
			String strRandName2 = mcd.fn_GetRndName("Question");
			actions.clear("SmartReminderGroup.FirstQuestion");
			/** Set Value in First Question */
			actions.setValue("SmartReminderGroup.FirstQuestion", strRandName2);

			// Validating for 'unsaved data will be lost' error message
			actions.keyboardEnter("RFM.Cancelbtn");
			boolean IsUnsavdalrt;
			IsUnsavdalrt = mcd.VerifyAlertMessageDisplayed("Alert", strMessage[5], true,
					AlertPopupButton.CANCEL_BUTTON);
			if (IsUnsavdalrt) {
				actions.reportCreatePASS("Verify " + strMessage[5], strMessage[5] + " should be displayed",
						strMessage[5] + " is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify " + strMessage[5], strMessage[5] + " should be displayed",
						strMessage[5] + " is not displayed", "Fail");
			}

			// Smart Reminder Group will be created by clicking on Save button
			actions.keyboardEnter("SmartReminderGroup.SaveButton");
			mcd.smartsync(180);

			// Verifying Smart Reminder Group creation success message
			boolean booMsg = mcd.VerifyOnscreenMessage("ManageMenuItems.SaveMessage", strMessage[6], true);
			System.out.println(booMsg);
			if (booMsg == true) {
				actions.reportCreatePASS("Verify " + strMessage[6], strMessage[6] + " should be displayed",
						strMessage[6] + " is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify " + strMessage[6], strMessage[6] + " should be displayed",
						strMessage[6] + " is not displayed", "Fail");
			}

			// verify the audit log for Smart Reminder Group creation
			if (rfm.VerifyAuditLog_Entry(strOperation, strActivity, strLevel)) {
				actions.reportCreatePASS("Verifying the Audit log", "Audit log should display correct values",
						"Audit log displayed correct values", "Pass");
			} else {
				actions.reportCreateFAIL("Verifying the Audit log", "Audit log should display correct values",
						"Audit log not displayed correct values", "Fail");
			}

			String strDescription = "Smart Reminder Group " + strRandName + " has been created.";
			// verify the audit log details for Smart Reminder Group creation
			if (rfm.RFM_VerifyAuditLog_Details(strDBName, strUID, strOperation, strActivity, strLevel, strMarket,
					strDescription)) {
				actions.reportCreatePASS("Verifying the Audit log details",
						"Audit log details should display correct values", "Audit log displayed correct values",
						"Pass");
			} else {
				actions.reportCreateFAIL("Verifying the Audit log details",
						"Audit log details should display correct values",
						"Audit log details not displayed correct values", "Fail");
			}

			/** Logout the application */
			rfm.Logout();
		} catch (Exception e) {
			// reporting the Fail condition
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}

	public static String generateRepeatingString(char c, Integer n) {
		StringBuilder b = new StringBuilder();
		for (Integer x = 0; x < n; x++)
			b.append(c);
		return b.toString();
	}
}
