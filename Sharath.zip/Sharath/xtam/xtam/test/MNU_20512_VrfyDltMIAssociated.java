package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20512_VrfyDltMIAssociated {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo, strNavigateToMMIL;
	private String strFlavor;
	private String strWM1;
	private String strWM2,strwm3;
	private boolean flag;

	// TODO: Declare test-data variables for other data-parameters

	public MNU_20512_VrfyDltMIAssociated(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strNavigateToMMIL = mcd.GetTestData("DT_NavigateToMMIL");
		strFlavor = mcd.GetTestData("DT_Flavor");
		strWM1 = mcd.GetTestData("WarningMessage1");
		strWM2 = mcd.GetTestData("WarningMessage2");
		strwm3  = mcd.GetTestData("DT_WarningMessage");

		// TODO: GetTestData for other data-parameters
	}

	@Test
	public void test_MNU_20512_VrfyDltMIAssociated() throws InterruptedException {
		String strPageTitle = "";
		String strPageSubHeading = "Master Flavors";
		String strPageSubHeading1 = "Master Menu Item List";

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(
					"Verify that the user is not able to delete an existing Flavor if it has been associated with Menu item");
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			// actions.smartWait(15);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Verify Page Header */
			System.out.println("> Verify Page Heading");
			mcd.VerifyPageHeading(strPageSubHeading, "SubHeading");

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();
			// ------------------------------------------------------------------------
			// Creating Master Flavor
			actions.WaitForElementPresent("MasterFlavors.NewFlavor", 100);
			actions.keyboardEnter("MasterFlavors.NewFlavor");

			int rw_cnt = mcd.GetTableRowCount("RFMHome.Table");
			System.out.println(rw_cnt);
			String strRandName = mcd.fn_GetRndName("Auto");
			System.out.println(strRandName);
			mcd.SetTableCellValue("RFMHome.Table", rw_cnt, "Flavor Name", strRandName, "input", "value");

			do {
				int randomNum = mcd.fn_GetRndNumInRange(0, 99);
				System.out.println(randomNum);
				String strI = "" + randomNum;
				System.out.println(strI);
				mcd.SetTableCellValue("RFMHome.Table", rw_cnt, "Nozzle Id", strI, "input", "value");
				actions.click("MasterFlavors.SaveButton");
				try {

					// flag = actions.isAlertPresent(5);
					if (flag) {
						mcd.VerifyAlertMessageDisplayed("Warning Message", strWM2, true, AlertPopupButton.OK_BUTTON);
					}

				} catch (Exception f) {
					flag = false;

				}

			} while (flag);

			// Verify the on-screen message
			flag = mcd.VerifyOnscreenMessage("MasterFlavor.InfoMessage", "Your changes have been saved.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Navigate Master Menu Item List
			System.out.println("> Navigate to :: " + strNavigateToMMIL);
			actions.select_menu("RFMHome.Navigation", strNavigateToMMIL);

			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			// Verify Page Header
			System.out.println("> Verify Page Heading");
			mcd.VerifyPageHeading(strPageSubHeading1, "SubHeading");

			// Select any menu item
			actions.click("MasterMenuItemList.SearchButton_New");
			actions.smartWait(50);
			WebElement menuitem = mcd.GetTableCellElement("RFMQueueManagementPage.Table", 1, "Number", "a");
			actions.keyboardEnter(menuitem);

			// Set the family group DDL
			actions.setValue("RestMIList.LevelUpFamilyGrpDrpdwn", "REGULAR_DRINK");
			actions.smartWait(30);
			actions.click("ManageMenuItem.ApplySavebtn");
			if (mcd.VerifyAlertMessageDisplayed("Information", strwm3, true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + strwm3 + " 'is Present or not",
						strwm3 + " should be present", strwm3 + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + strwm3 + " 'is Present or not",
						strwm3 + " should be present", strwm3 + " is not present", "Fail");
			}
			
			// Click on ABS Setting tab and set the flavor ddl Value is newly
			// created Master Flavor
			actions.keyboardEnter("ManageMenuItem.ABS_tab");
			actions.smartWait(20);
			actions.setValue("MasterMenuItemList.ABSFlavorEnable", strRandName);
			actions.smartWait(50);
			actions.setValue("ManageMenuItems.CupSize", "Large");
			actions.smartWait(50);
			actions.setValue("ManageMenuItems.LidOption", "No Lid");
			actions.smartWait(50);
			actions.setValue("ManageMenuItems.IceSelection", "Full Ice Drink");
			actions.smartWait(50);
			
			if (strMarket.equals("US Country Office"))
			{
			 actions.setValue("MasterMenuItemList.NGABSVolume_ACT", "DVBOPuv");
			}else{
				actions.setValue("MasterMenuItemList.NGABSVolume_ACT", "DVAVNun");
			}
			actions.smartWait(50);

			// Click on save button and verify the on-screen message
			actions.click("ManageMenuItem.ApplySavebtn");
			mcd.waitAndSwitch("Apply Changes Details");
			actions.click("ApplyChangesDetails.SaveBtn");
			mcd.SwitchToWindow("@Manage Menu Items");
			actions.smartWait(20);

			flag = mcd.VerifyOnscreenMessage("MassSetAssignment.OnScreenMessage", "Your changes have been saved.",true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Navigate to Master Flavor
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			// actions.smartWait(15);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			// Click on Delete button on newly created Mater Flavor
			List<WebElement> MasterFlavorsetList = driver
					.findElements(By.xpath(actions.getLocator("MasterFlavor.FlavorNameList")));
			String MasterFlavorSet;

			for (int i = 0; i < MasterFlavorsetList.size(); i++) {
				MasterFlavorSet = MasterFlavorsetList.get(i).getAttribute("value");

				if (MasterFlavorSet.trim().equals(strRandName))

				{
					i = i + 1;

					WebElement DeleteFlavor = driver
							.findElement(By.xpath("//*[@id='Sess1']/tbody/tr[" + i + "]/td[3]/a"));

					actions.click(DeleteFlavor);
					if (mcd.VerifyAlertMessageDisplayed("Information", strWM1, true, AlertPopupButton.OK_BUTTON)) {
						actions.reportCreatePASS("Veriyfing the '" + strWM1 + " 'is Present or not",
								strWM1 + " should be present", strWM1 + " is present", "Pass");
					} else {
						actions.reportCreateFAIL("Veriyfing the '" + strWM1 + " 'is Present or not",
								strWM1 + " should be present", strWM1 + " is not present", "Fail");
					}
					mcd.SwitchToWindow("Warning!");

					boolean booMsg = mcd.VerifyOnscreenMessage("Warning.Message1",
							"You must remove this Flavor from the above Menu Item(s) before you can delete it.", true);
					System.out.println(booMsg);

					if (booMsg == true) {
						actions.reportCreatePASS(
								"Message: 'You must remove this Flavor from the above Menu Item(s) before you can delete it.' is Displayed",
								"Message: 'You must remove this Flavor from the above Menu Item(s) before you can delete it.' should Displayed",
								"Message: 'You must remove this Flavor from the above Menu Item(s) before you can delete it.' is Displayed",
								"Pass");
					} else {
						actions.reportCreateFAIL(
								"Message: 'You must remove this Flavor from the above Menu Item(s) before you can delete it.' is Displayed",
								"Message: 'You must remove this Flavor from the above Menu Item(s) before you can delete it.' should Displayed",
								"Message: 'You must remove this Flavor from the above Menu Item(s) before you can delete it.' is not Displayed",
								"Fail");
					}

					boolean booMsg1 = mcd.VerifyOnscreenMessage("Warning.Message2",
							"The selected Flavor cannot be deleted because it is currently used by the following Menu Item(s):",
							true);
					System.out.println(booMsg1);

					if (booMsg1 == true) {
						actions.reportCreatePASS(
								"Message: 'The selected Flavor cannot be deleted because it is currently used by the following Menu Item(s):' is Displayed",
								"Message: 'The selected Flavor cannot be deleted because it is currently used by the following Menu Item(s):' should Displayed",
								"Message: 'The selected Flavor cannot be deleted because it is currently used by the following Menu Item(s):' is Displayed",
								"Pass");
					} else {
						actions.reportCreateFAIL(
								"Message: 'The selected Flavor cannot be deleted because it is currently used by the following Menu Item(s):' is Displayed",
								"Message: 'The selected Flavor cannot be deleted because it is currently used by the following Menu Item(s):' should Displayed",
								"Message: 'The selected Flavor cannot be deleted because it is currently used by the following Menu Item(s):' is not Displayed",
								"Fail");
					}

					boolean booDisplayed = driver.findElement(By.xpath(actions.getLocator("Warning.OK"))).isDisplayed();
					System.out.println(booDisplayed);
					if (booDisplayed == true) {
						actions.reportCreatePASS("'OK' button is Displayed", "'OK' button should Displayed",
								"'OK' button is Displayed", "Pass");
					} else {
						actions.reportCreateFAIL("'OK' button is Displayed", "'OK' button should Displayed",
								"'OK' button is not Displayed", "Fail");
					}

					actions.keyboardEnter("Warning.OK");

					mcd.SwitchToWindow("@Master Flavor");
					actions.smartWait(10);
					break;
				}
			}

			
			 

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}

	}

}
