package xtam.test;

import java.util.Map;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.CSVValidations;

public class MNU_20502_CreateFlavor {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private CSVValidations csv;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strWM1;
	private String strWM2;
	private String strWM3;
	private String strNavigateToReport, strNavigateToView, strNavigateToAdmin, strNavigateToHOME, strNavigateToQM;
	private String strDBName, strUserID, strOperation, strActivity, strLevel, strNodeName, strDescription,
			strSuccessMsg;
	boolean AuditEntry;
	String AuditDesc;
	boolean AuditDetail;

	// TODO: Declare test-data variables for other data-parameters

	public MNU_20502_CreateFlavor(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		csv = new CSVValidations();

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strWM1 = mcd.GetTestData("WarningMessage1");
		strWM2 = mcd.GetTestData("WarningMessage2");
		strWM3 = mcd.GetTestData("WarningMessage3");

		strDBName = mcd.GetTestData("DT_DB_NAME");
		strUserID = mcd.GetTestData("DT_USER_ID");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strActivity = mcd.GetTestData("DT_ACTIVITY");
		strLevel = mcd.GetTestData("DT_LEVEL");
		strNodeName = mcd.GetTestData("DT_NODE_NAME");

		// TODO: GetTestData for other data-parameters
	}

	@Test
	public void test_MNU_20502_CreateFlavor() throws InterruptedException {
		String strPageTitle = ""; // TODO: Exact page-title
		String strPageSubHeading = "Master Flavors"; // TODO: Page Heading

		try {
			System.out
					.println("********************************************************************** Test execution starts");
			actions.setTestcaseDescription("Verify that the user is able to create a new Flavor.");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			actions.smartWait(5);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.waitAndSwitch("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			actions.smartWait(15);

			// ------------------------------------------------------------------------
			// Actions specific to test-flow

			// Click on 'New Flavor' button
			actions.keyboardEnter("MasterFlavors.NewFlavor");

			// Click on Save button
			actions.keyboardEnter("MasterFlavors.SaveButton");

			// A pop up message 'Please enter Flavor name' should be displayed
			boolean booMsg1 = mcd.VerifyAlertMessageDisplayed("Warning Message", strWM1, true,
					AlertPopupButton.OK_BUTTON);

			System.out.println(booMsg1);

			if (booMsg1 == true) {
				actions.reportCreatePASS("Message: 'Please enter Flavor name' is Displayed",
						"Message: 'Please enter Flavor name' should Displayed",
						"Message: 'Please enter Flavor name.' is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Message: 'Please enter Flavor name' is Displayed",
						"Message: 'Please enter Flavor name' should Displayed",
						"Message: 'Please enter Flavor name' is not Displayed", "Fail");
			}

			// Enter a flavor name with length more than 50 strings
			String MaxLen = driver.findElement(By.id("flavorName0")).getAttribute("maxlength");

			if (MaxLen.equals("50")) {
				actions.reportCreatePASS("User should not be able to enter more than 50 Strings.",
						"Max Length for Flavor Name should be 50", "Max Length for Flavor Name is 50", "Pass");
			} else {
				actions.reportCreateFAIL("User should not be able to enter more than 50 Strings.",
						"Max Length for Flavor Name should be 50", "Max Length for Flavor Name is not 50", "Fail");
			}

			int rw_cnt = mcd.GetTableRowCount("RFMHome.Table");
			System.out.println(rw_cnt);
			int i = 1;
			String strTableValues, strI, strTableNozal, strUniQNozzle;
			strTableValues = "";
			strI = "";
			strUniQNozzle = "1";
			String strRandName = mcd.fn_GetRndName("Auto");
			boolean bflag = false;

			// Generate unique flavor name and Nozzle id to create new
			if (rw_cnt > 0) {
				strTableValues = driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[" + i + "]/td[1]/input[1]"))
						.getAttribute("value");
				strTableValues = strTableValues+strRandName;
				System.out.println("Flavor Name " + i + ":" + strTableValues);

				for (i = 1; i < rw_cnt; i++) {
					int randomNum = mcd.fn_GetRndNumInRange(0, 99);
					System.out.println(randomNum);
					strI = "" + randomNum;
					System.out.println(strI);

					strTableNozal = driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[" + i + "]/td[2]/input[1]"))
							.getAttribute("value");
					System.out.println("Nozzle Id " + i + ":" + strTableNozal);
					if (strTableNozal.equals(strI))
						bflag = false;
					else {
						bflag = true;
						strUniQNozzle = strI;
						break;
					}
				}

				String strValue = driver.findElement(By.xpath(actions.getLocator("MasterFlavors.FirstFlavorName")))
						.getAttribute("value");
				System.out.println(strValue);

			}


			mcd.SetTableCellValue("RFMHome.Table", rw_cnt, "Flavor Name", strTableValues, "input",
					"value");
			mcd.SetTableCellValue("RFMHome.Table", rw_cnt, "Nozzle Id", strUniQNozzle, "input", "value");
			actions.keyboardEnter("MasterFlavors.SaveButton");
			Thread.sleep(5000);
			try {
				//mcd.smartsync(10);
				actions.verifyTextPresence("Your changes have been saved.", true);
				// mcd.waitAndSwitch("@Title");
			} catch (Exception e) {
				System.out.println(">> Your changes have been saved. message is not displayed...");
			}
			

			// Navigate to Home page and verify the Audit log details			
			AuditEntry = rfm.VerifyAuditLog_Entry(strOperation, "Create", strLevel);
			System.out.println(AuditEntry);
			
			AuditDesc = "Master Flavors " + strTableValues + " has been created.";
			AuditDetail = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID, strOperation, "Create", strLevel,
					strNodeName, AuditDesc);
			System.out.println(AuditDetail);

			// Verify Audit Log ID in CSV file for Create operation
			String AuditLogId = rfm.GetAuditLogID(strOperation);
			mcd.GetTableCellElement("RFMHomePage.AuditLog", "Operations", strOperation, "", "", "Id", "a").sendKeys(
					Keys.ENTER);
			Thread.sleep(1000);
			mcd.waitAndSwitch("Manage Audit Log");
			VerifyAuditLogPrint();
			VerifyAuditLogCSV(AuditLogId, "Create");

			// Verify Error : Flavor Name already exists, please enter another
			// Flavor Name.
			// Verify Error : Nozzle Id already exists, please enter another
			// Nozzle Id.
			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			actions.smartWait(5);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.waitAndSwitch("#Title");
			
			// Click on 'New Flavor' button
			actions.keyboardEnter("MasterFlavors.NewFlavor");
			Thread.sleep(3000);

			i = 1;
			rw_cnt = mcd.GetTableRowCount("RFMHome.Table");
			System.out.println(rw_cnt);

			strTableValues = driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[" + i + "]/td[1]/input[1]"))
					.getAttribute("value");
			System.out.println("Flavor Name " + i + ":" + strTableValues);

			strTableNozal = driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[" + i + "]/td[2]/input[1]"))
					.getAttribute("value");
			System.out.println("Nozzle Id " + i + ":" + strTableNozal);			
			driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[" + rw_cnt + "]/td[1]/input[1]")).sendKeys(
					strTableValues);			
			driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[" + rw_cnt + "]/td[2]/input[1]")).sendKeys(
					strTableNozal);
			actions.click("MasterFlavors.SaveButton");

			boolean booMsg2 = mcd.VerifyAlertMessageDisplayed("Warning Message",
					"Flavor Name already exists, please enter another Flavor Name.", true,
					AlertPopupButton.OK_BUTTON);

			System.out.println(booMsg2);
			if (booMsg2 == true) {
				actions.reportCreatePASS(
						"Message: 'Flavor Name already exists, please enter another Flavor Name.' is Displayed",
						"Message: 'Flavor Name already exists, please enter another Flavor Name.' should Displayed",
						"Message: 'Flavor Name already exists, please enter another Flavor Name.' is Displayed",
						"Pass");
			} else {
				actions.reportCreateFAIL(
						"Message: 'Flavor Name already exists, please enter another Flavor Name.' is Displayed",
						"Message: 'Flavor Name already exists, please enter another Flavor Name.' should Displayed",
						"Message: 'Flavor Name already exists, please enter another Flavor Name.' is not Displayed",
						"Fail");
			}

			strTableValues = strTableValues + 1;
			driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[" + rw_cnt + "]/td[1]/input[1]")).clear();
			actions.smartWait(5);
			driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[" + rw_cnt + "]/td[1]/input[1]")).sendKeys(
					strTableValues);
			driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[" + rw_cnt + "]/td[2]/input[1]")).clear();
			driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[" + rw_cnt + "]/td[2]/input[1]")).sendKeys(
					strTableNozal);

			actions.click("MasterFlavors.SaveButton");

			boolean booMsg3 = mcd.VerifyAlertMessageDisplayed("Warning Message",
					"Nozzle Id already exists, please enter another Nozzle Id.", true, AlertPopupButton.OK_BUTTON);

			System.out.println(booMsg3);

			if (booMsg3 == true) {
				actions.reportCreatePASS(
						"Message: 'Nozzle Id already exists, please enter another Nozzle Id.' is Displayed",
						"Message: 'Nozzle Id already exists, please enter another Nozzle Id.' should Displayed",
						"Message: 'Nozzle Id already exists, please enter another Nozzle Id.' is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL(
						"Message: 'Nozzle Id already exists, please enter another Nozzle Id.' is Displayed",
						"Message: 'Nozzle Id already exists, please enter another Nozzle Id.' should Displayed",
						"Message: 'Nozzle Id already exists, please enter another Nozzle Id.' is not Displayed",
						"Fail");
			}

			WebElement CancelBtn = driver.findElement(By.xpath("//*[contains(text(),'Cancel')]"));
			actions.click(CancelBtn);
			Thread.sleep(3000);
			
			mcd.VerifyAlertMessageDisplayed("Warning Message",
					"Unsaved data will be lost. Are you sure you want to proceed?", true,
					AlertPopupButton.OK_BUTTON);
			
			// ------------------------------------------------------------------------

			/** Logout the application */
			driver.switchTo().window("");
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	// Functions to Verify Audit log functionality for Print and Save as CSV
	// File

	public void VerifyAuditLogPrint() {

		// Click print button, Print popup should be displayed
		try {

			WebElement printBtn = driver.findElement(By.xpath("//a[contains(text(),'Print')]"));
			actions.keyboardEnter(printBtn);
			Thread.sleep(5000);
			Alert myAlert = driver.switchTo().alert();
			Thread.sleep(2000);
			actions.reportCreatePASS("Click Print button", "Print Window should be displayed.",
					"Print Window is displayed.", "PASS");
			myAlert.dismiss();

		} catch (Exception error1) {
			System.out.println("Print Alert is not displayed");
		}

	}

	public void VerifyAuditLogCSV(String AuditLogId, String strOperation) {

		// Click Save as CSV file button and verify that Audit log Id is
		// displayed in CSV
		try {
			WebElement SaveCSVBtn = driver.findElement(By.xpath("//a[contains(text(),'Save as CSV File')]"));
			actions.javaScriptClick(SaveCSVBtn);
			Thread.sleep(3000);

			actions.ieDownload();
			Thread.sleep(3000);

			WebElement OKBtn = driver.findElement(By.xpath("//a[contains(text(),'OK')]"));
			actions.javaScriptClick(OKBtn);

			String targetData = "{\"Id\":\"" + AuditLogId + "\"}";

			boolean csvFlag = csv.validateColumnsData("AuditLogDetail.CSV", "Id", AuditLogId, targetData, false, true);

			System.out.println("CSV field validation = " + csvFlag);

			if (csvFlag)
				actions.reportCreatePASS("Verify AuditLogDetail.CSV file for " + strOperation + " operation.",
						"Auditlog Id should be displayed in CSV file.", "Auditlog Id is displayed in CSV file.", "PASS");
			else
				actions.reportCreateFAIL("Verify AuditLogDetail.CSV file for " + strOperation + " operation.",
						"Auditlog Id should be displayed in CSV file.", "Auditlog Id is not displayed in CSV file.",
						"FALSE");

			mcd.waitAndSwitch("@RFM - Home");
		} catch (Exception error2) {
			System.out.println("Failed to verify CSV file...");
		}

	}
}
