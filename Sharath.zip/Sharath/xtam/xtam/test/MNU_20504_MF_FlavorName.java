/*
 * JIRA ID: RFM-4235
 */
package xtam.test;

import java.util.Map;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.CSVValidations;

public class MNU_20504_MF_FlavorName {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private CSVValidations csv;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strWM1;
	boolean AuditEntry;
	// TODO: Declare test-data variables for other data-parameters

	public MNU_20504_MF_FlavorName(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		csv = new CSVValidations();
		
		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strWM1 = mcd.GetTestData("WarningMessage1");

		// TODO: GetTestData for other data-parameters
	}

	@Test
	public void test_MNU_20504_MF_FlavorName() throws InterruptedException {
		String strPageTitle = ""; // TODO: Exact page-title
		String strPageSubHeading = "Master Flavors"; // TODO: Page Heading

		try {
			System.out.println("********************************************************************** Test execution starts");
			actions.setTestcaseDescription("Verify that the field validation of Flavor Name. Verify that the user is able to create a new Flavor.");
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Verify Page Header */
			//System.out.println("> Verify Page Heading");
			//mcd.VerifyPageHeading(strPageSubHeading, "SubHeading");

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------ Actions specific to test-flow

			actions.smartWait(100);
			//waiting for element to be present
			actions.WaitForElementPresent("MasterFlavors.NewFlavor", 100);
			//click on new flavor button
			actions.keyboardEnter("MasterFlavors.NewFlavor");
			//getting row count
			int rw_cnt = mcd.GetTableRowCount("RFMHome.Table");
			System.out.println(rw_cnt);
			
			try {
			//click on save button
			actions.click("MasterFlavors.SaveButton");
			
			// A pop up message 'Please enter Flavor name' should be displayed
			boolean bflag = mcd.VerifyAlertMessageDisplayed("Warning", "Please enter Flavor Name.", true, AlertPopupButton.OK_BUTTON);
			if(bflag==true){
				actions.reportCreatePASS("Verify Message: 'Please enter Flavor Name.'", "Message: 'Please enter Flavor Name.' should Displayed", "Message: 'Please enter Flavor Name.' is Displayed", "Pass");
			}else{
				actions.reportCreateFAIL("Verify Message: 'Please enter Flavor Name.'", "Message: 'Please enter Flavor Name.' should Displayed", "Message: 'Please enter Flavor Name.' is not Displayed", "Fail");
			}
			
			}
			catch (Exception err1){
				System.out.println("Failed to verify error:Please enter Flavor Name.");
			}
			
			
			try {

			// Enter a flavor name which is already existing at the market. Ex: PP1
			// Verify Message: Flavor Name already exists, please enter another Flavor Name.		
			
			String strTableValues = driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[" + 1 + "]/td[1]/input[1]"))
					.getAttribute("value");
			System.out.println("Flavor Name " + 1 + ":" + strTableValues);

			String strTableNozal = driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[" + 1 + "]/td[2]/input[1]"))
					.getAttribute("value");
			System.out.println("Nozzle Id " + 1 + ":" + strTableNozal);		
			
			
			//inputting value in the table 
			mcd.SetTableCellValue("RFMHome.Table", rw_cnt, "Flavor Name", strTableValues, "input", "value");
			mcd.SetTableCellValue("RFMHome.Table", rw_cnt, "Nozzle Id", "99", "input", "value");
			
			//click on save button
			actions.click("MasterFlavors.SaveButton");
			
			// A pop up message 'Flavor Name already exists, please enter another Flavor Name.' should be displayed
			boolean bflag2 = mcd.VerifyAlertMessageDisplayed("Warning", "Flavor Name already exists, please enter another Flavor Name.", true, AlertPopupButton.OK_BUTTON);
			if(bflag2==true){
				actions.reportCreatePASS("Verify Message: 'Flavor Name already exists, please enter another Flavor Name.'", "Message should be Displayed", "Message is Displayed", "Pass");
			}else{
				actions.reportCreateFAIL("Verify Message: 'Flavor Name already exists, please enter another Flavor Name.'", "Message should be Displayed", "Message is not Displayed", "Fail");
			}
			
			
			// Enter a Nozzle Id which already exists in the market. Ex: 1
			
			strTableValues = strTableValues+"2";
			//inputting value in the table 
			mcd.SetTableCellValue("RFMHome.Table", rw_cnt, "Flavor Name", strTableValues, "input", "value");
			mcd.SetTableCellValue("RFMHome.Table", rw_cnt, "Nozzle Id", strTableNozal, "input", "value");
			
			//click on save button
			actions.click("MasterFlavors.SaveButton");
			
			// A pop up message 'Nozzle Id already exists, please enter another Nozzle Id.' should be displayed
			boolean bflag3 = mcd.VerifyAlertMessageDisplayed("Warning", "Nozzle Id already exists, please enter another Nozzle Id.", true, AlertPopupButton.OK_BUTTON);
			if(bflag3==true){
				actions.reportCreatePASS("Verify Message: 'Nozzle Id already exists, please enter another Nozzle Id.'", "Message should be Displayed", "Message is Displayed", "Pass");
			}else{
				actions.reportCreateFAIL("Verify Message: 'Nozzle Id already exists, please enter another Nozzle Id.'", "Message should be Displayed", "Message is not Displayed", "Fail");
			}
					
			}
			catch (Exception err2){
				System.out.println("Failed to verify error for exisiting Flavor Name and Nozzle Id");
			}
			
			// The Flavor name should be saved with the Nozzle Id in the Grid and a information message on the top as 'Your changes have been saved.'
			
			//generating random name
			String strRandName=mcd.fn_GetRndName("Auto");
			
			strRandName=strRandName+"$#";
			//inputting value in the table 
			mcd.SetTableCellValue("RFMHome.Table", rw_cnt, "Flavor Name", strRandName, "input", "value");
			boolean flag1;
			do {
				
				actions.smartWait(100);
				flag1 = false;
				int randomNum = mcd.fn_GetRndNumInRange(0, 99);
				System.out.println(randomNum);
				String strI = "" + randomNum;
				System.out.println(strI);					
				
				//inputting value in the table 
				mcd.SetTableCellValue("RFMHome.Table", rw_cnt, "Nozzle Id", strI, "input", "value");
				
				//click on save button
				actions.click("MasterFlavors.SaveButton");
				
				
				
				//actions.smartWait(100);
				//verifying on screen save message
				//changed by Sunny
				
				try {
					System.out.println("> Click on OK button of Alert Box");
					if (mcd.VerifyAlertMessageDisplayed("Warning Message", strWM1, true, AlertPopupButton.OK_BUTTON)) {
						flag1 = true;
						}
					} 
				
				
				catch (Exception err) {
										}		
				Thread.sleep(5000);
				
				
			} 
			
			while (flag1 == true);
			
			Thread.sleep(5000);
			actions.verifyTextPresence("Your changes have been saved.", true);
		
			
			// Navigate to Home page and verify the Audit log details		
			String strLevel="";
			if (mcd.GetGlobalData("Instance").contains("AP"))
				strLevel = "Australasia";
			else
				strLevel = "Market";
			
			AuditEntry = rfm.VerifyAuditLog_Entry("Master Flavors", "Create", strLevel);
			System.out.println(AuditEntry);
		
			// Verify Audit Log ID in CSV file for Create operation
			String AuditLogId = rfm.GetAuditLogID("Master Flavors");
			mcd.GetTableCellElement("RFMHomePage.AuditLog", "Operations", "Master Flavors", "", "", "Id", "a").sendKeys(
					Keys.ENTER);
			Thread.sleep(1000);
			mcd.waitAndSwitch("Manage Audit Log");
			VerifyAuditLogPrint();
			VerifyAuditLogCSV(AuditLogId, "Create");

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
	
	// Functions to Verify Audit log functionality for Print and Save as CSV
		// File

		public void VerifyAuditLogPrint() {

			// Click print button, Print popup should be displayed
			try {

				WebElement printBtn = driver.findElement(By.xpath("//a[contains(text(),'Print')]"));
				actions.keyboardEnter(printBtn);
				Thread.sleep(5000);
				Alert myAlert = driver.switchTo().alert();
				Thread.sleep(2000);
				actions.reportCreatePASS("Click Print button", "Print Window should be displayed.",
						"Print Window is displayed.", "PASS");
				myAlert.dismiss();

			} catch (Exception error1) {
				System.out.println("Print Alert is not displayed");
			}

		}

		public void VerifyAuditLogCSV(String AuditLogId, String strOperation) {

			// Click Save as CSV file button and verify that Audit log Id is
			// displayed in CSV
			try {
				WebElement SaveCSVBtn = driver.findElement(By.xpath("//a[contains(text(),'Save as CSV File')]"));
				actions.javaScriptClick(SaveCSVBtn);
				Thread.sleep(3000);

				actions.ieDownload();
				Thread.sleep(3000);

				WebElement OKBtn = driver.findElement(By.xpath("//a[contains(text(),'OK')]"));
				actions.javaScriptClick(OKBtn);

				String targetData = "{\"Id\":\"" + AuditLogId + "\"}";

				boolean csvFlag = csv.validateColumnsData("AuditLogDetail.CSV", "Id", AuditLogId, targetData, false, true);

				System.out.println("CSV field validation = " + csvFlag);

				if (csvFlag)
					actions.reportCreatePASS("Verify AuditLogDetail.CSV file for " + strOperation + " operation.",
							"Auditlog Id should be displayed in CSV file.", "Auditlog Id is displayed in CSV file.", "PASS");
				else
					actions.reportCreateFAIL("Verify AuditLogDetail.CSV file for " + strOperation + " operation.",
							"Auditlog Id should be displayed in CSV file.", "Auditlog Id is not displayed in CSV file.",
							"FALSE");

				mcd.waitAndSwitch("@RFM - Home");
			} catch (Exception error2) {
				System.out.println("Failed to verify CSV file...");
			}

		}
}
