package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20426_VrfAL_StatusChangesDG {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();
	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;

	// TODO: Declare test-data variables for other data-parameters
	private String dgName;
	private boolean flag;
	private String strUserID;
	private String strLevel;

	public MNU_20426_VrfAL_StatusChangesDG(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();
		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");

		// TODO: GetTestData for other data-parameters
		strUserID = mcd.GetTestData("DT_USER_NAME");
		strLevel = mcd.GetTestData("DT_LEVEL");

	}

	@Test
	public void test_MNU_20426_VrfAL_StatusChangesDG() throws InterruptedException {
		String strPageTitle = "Dimension Groups"; // TODO: Exact page-title
		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription("Verify  Audit Log when Status of Dimension Group is changed");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// Creating New dimension Group with inactive
			actions.click("DimensionGroup.NewDimensionGroupButton");
			actions.smartWait(15);
			actions.setValue("DimensionGroups.StatusDDL", "Inactive");
			dgName = mcd.fn_GetRndName("Auto_DG");
			actions.clear("DimensionGroup.DimensionGroupName");
			actions.setValue("DimensionGroup.DimensionGroupName", dgName);
			actions.click("DimensionGroup.SaveButton");
			flag = mcd.VerifyOnscreenMessage("DimensionGroup.InfoMessage", "Your changes have been saved.", true);
			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Changing Dimension grOup to ACTIVE
			actions.click("DimensionGroup.CancelButton");
			actions.smartWait(15);
			mcd.SwitchToWindow("#Title");
			actions.clear("ProductionRouting.SearchTextField");
			actions.setValue("ProductionRouting.SearchTextField", dgName);
			actions.click("ManageDimensionGroup.SearchButton");
			actions.smartWait(15);
			WebElement Element = mcd.GetTableCellElement("ManageDimensionGroup.Table", 1, "Group Name", "a/pre");
			actions.click(Element);
			mcd.SwitchToWindow("#Title");
			actions.setValue("DimensionGroups.StatusDDL", "Active");
			actions.click("DimensionGroups.ApplyButton");
			actions.smartWait(15);
			flag = mcd.VerifyOnscreenMessage("DimensionGroup.InfoMessage", "Your changes have been saved.", true);
			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Verifying Audit Logs
			boolean blnAudit = false;
			blnAudit = rfm.VerifyAuditLog_Entry(strPageTitle, "Update", strLevel);

			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Entry for update Dimension Group",
						"Audit log should be generated for Update Dimension group",
						"Audit log generated for Update Dimension group succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Entry for Update Dimension Group",
						"Audit log should be generated for Update Dimension group",
						"Audit log not generated for Update Dimension group succesfully", "FAIL");
			}

			// Verify details of audit log
			blnAudit = rfm.RFM_VerifyAuditLog_Details("RFM2", strUserID, strPageTitle, "Update", strLevel, strMarket,
					"Dimension Group " + dgName + " has been updated.");
			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Details for Update Dimension Group",
						"Audit log details should be generated for Update Dimension group",
						"Audit log details generated for Dimension group item succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Details for Update Dimension Group",
						"Audit log details should be generated for Update Dimension group",
						"Audit log details not generated for Dimension group item succesfully", "FAIL");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}
