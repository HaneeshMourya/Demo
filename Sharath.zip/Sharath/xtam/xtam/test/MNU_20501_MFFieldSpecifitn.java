package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;


public class MNU_20501_MFFieldSpecifitn {
       private Keywords actions;
       private WebDriver driver;
       private Map input;
       private UIValidations uiActions;
       private SoftAssert softAssert = new SoftAssert();
       
       private lib_MCD mcd;
       private lib_RFM2 rfm;
       
       private String strApplicationDate;
       
       // Test-Data Variables
       private Object strURL;
       private Object strUserName;
       private Object strPassword;
       private String strMarket;
       private String strNavigateTo;
       // TODO: Declare test-data variables for other data-parameters

       
       public MNU_20501_MFFieldSpecifitn (WebDriver nodeDriver, Map inputData, Object or){
              driver = nodeDriver;
              input = inputData;
              actions = new Keywords(driver, or);
              uiActions = new UIValidations();
              
              mcd = new lib_MCD (driver, actions, uiActions, inputData);
              rfm = new lib_RFM2 (driver, actions, uiActions, inputData, mcd);

              // Read input Test-Data
              strURL                     = mcd.GetTestData("DT_URL");
              strUserName   = mcd.GetTestData("DT_USER_NAME");
              strPassword   = mcd.GetTestData("DT_PASSWORD");
              strMarket            = mcd.GetTestData("DT_MARKET");
              strNavigateTo        = mcd.GetTestData("DT_NAVIGATE_TO");
              // TODO: GetTestData for other data-parameters
       }
       
       @Test
       public void test_MNU_20501_MFFieldSpecifitn() throws InterruptedException {
              String strPageTitle = "";                // TODO: Exact page-title
              String strPageSubHeading = "Master Flavors";           // TODO: Page Heading
              
              
              try {
                     System.out.println("********************************************************************** Test execution starts");
                     actions.setTestcaseDescription("Verify the field specifications in the Master Flavor page");
                     /** Launch and Login RFM */
                     System.out.println("> Launch and Login RFM");
                     rfm.LaunchAndLogin(strURL, strUserName, strPassword);
                     
                     /** Select Market (Node) */
                     System.out.println("> Select Market (Node)");
                     rfm.SelectMarket(strMarket);
              
                     /** Select Menu Option */
                     System.out.println("> Navigate to :: " + strNavigateTo);
                     actions.select_menu("RFMHome.Navigation",strNavigateTo);
                     Thread.sleep(2000);
                     actions.waitForPageToLoad(120);

                     /** Verify Page Header */
                    // System.out.println("> Verify Page Heading");
                     //mcd.VerifyPageHeading(strPageSubHeading, "SubHeading");

                     /** Update title of new Page  */
                     mcd.SwitchToWindow("#Title");
                     
                     /** Get application time */
                     WebElement apptime = mcd.getdate();
                     strApplicationDate = apptime.getText();


                     // ------------------------------------------------------------------------ Actions specific to test-flow
                     //Waiting for element to be present
                     actions.WaitForElementPresent("RFMHome.Table", 100);
                     //verifying column name
                     boolean booDisplayed=mcd.RFM_VerifyTableColumns("RFMHome.Table", "Flavor Name,Nozzle Id,Delete");
                     System.out.println(booDisplayed);
                     if(booDisplayed==true){
                    	 System.out.println("Present");
                    	 actions.reportCreatePASS("Column Headers 'Flavor Name,Nozzle Id,Delete' is Displayed", "Column Headers 'Flavor Name,Nozzle Id,Delete' should Displayed", "Column Headers 'Flavor Name,Nozzle Id,Delete' is Displayed", "Pass"); 
                     }else{
                    	 actions.reportCreateFAIL("Column Headers 'Flavor Name,Nozzle Id,Delete' is Displayed", "Column Headers 'Flavor Name,Nozzle Id,Delete' should Displayed", "Column Headers 'Flavor Name,Nozzle Id,Delete' is not Displayed", "Fail");
                     }
                     
                     //verifying the new button
                     boolean booDisplayed1= driver.findElement(By.xpath(actions.getLocator("MasterFlavors.NewFlavor"))).isDisplayed();
                     System.out.println(booDisplayed1);
                     if(booDisplayed1==true){
                    	 System.out.println("Present");
                    	 actions.reportCreatePASS("New Flavor Button is Present", "New Flavor Button should Present", "New Flavor Button is Present", "Pass"); 
                     }else{
                    	 actions.reportCreateFAIL("New Flavor Button is Present", "New Flavor Button should Present", "New Flavor Button is not Present", "Fail");
                     }
                     //verifying the save button
                     boolean booDisplayed2= driver.findElement(By.xpath(actions.getLocator("MasterFlavors.SaveButton"))).isDisplayed();
                     System.out.println(booDisplayed2);
                     if(booDisplayed2==true){
                    	 System.out.println("Present");
                    	 actions.reportCreatePASS("Save Button is Present", "Save Button should Present", "Save Button is Present", "Pass"); 
                     }else{
                    	 actions.reportCreateFAIL("Save Button is Present", "Save Button should Present", "Save Button is not Present", "Fail");
                     }
                     //verifying the cancel button
                     boolean booDisplayed3= driver.findElement(By.xpath(actions.getLocator("MasterFlavors.CancelButton"))).isDisplayed();
                     System.out.println(booDisplayed3);
                     if(booDisplayed3==true){
                    	 System.out.println("Present");
                    	 actions.reportCreatePASS("Cancel Button is Present", "Cancel Button should Present", "Cancel Button is Present", "Pass"); 
                     }else{
                    	 actions.reportCreateFAIL("Cancel Button is Present", "Cancel Button should Present", "Cancel Button is not Present", "Fail");
                     }

                     // ------------------------------------------------------------------------ 
                     
                     /** Logout the application */
                     rfm.Logout();
                     

              } catch(Exception e) {
                     
                     //reporting the Fail condition
                     actions.catchException(e);
                     
              } finally {
                     actions.quitBrowser();
                     actions.verifyTestCase(this.getClass());
                     
                           
              }
       }
}
