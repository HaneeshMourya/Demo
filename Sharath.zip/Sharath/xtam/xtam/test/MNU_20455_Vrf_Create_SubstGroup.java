package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20455_Vrf_Create_SubstGroup {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo, sgName, strmsg, msg[];
	private boolean flag;
	private String strwm, ExpectWm[];
	private String SubDDL, ExpectSubDdl[];
	private String strOperation, StrActivity, StrLevel, StrLevedetails, strDBName, strUserID;

	public MNU_20455_Vrf_Create_SubstGroup(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strwm = mcd.GetTestData("DT_WarningMessages");
		StrLevel = mcd.GetTestData("DT_LEVEL");
		StrLevedetails = mcd.GetTestData("DT_LevelDetails");
		StrActivity = mcd.GetTestData("DT_ACTIVITY");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strDBName = mcd.GetTestData("DT_DBNAME");
		strUserID = mcd.GetTestData("DT_USER_NAME");
		strmsg = mcd.GetTestData("DT_MSG");
		SubDDL = mcd.GetTestData("DT_Substitution");
		// TODO: GetTestData for other data-parameters
		ExpectWm = strwm.split("#");
		msg = strmsg.split("#");
		ExpectSubDdl = SubDDL.split("#");
	}

	@Test
	public void test_MNU_20455_Vrf_Create_SubstGroup() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(
					"Verify 'Create' functionality of New Substitution Group and also verify audit log for that");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// click on Search Button and get first value
			actions.keyboardEnter("SubstitutionGroups.SearchButton");
			actions.smartWait(50);

			String SubName = driver.findElement(By.xpath(actions.getLocator("SubstitutionGroup.FirstValue"))).getText();
			System.out.println(SubName);

			// Create New Substitution Group
			actions.click("SubstitutionGroups.NewSGButton");
			actions.smartWait(50);

			// Don�t enter Substitution Name and click on Save Button
			actions.click("SubstitutionGroups.SaveButton");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWm[0], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWm[0] + " 'is Present or not",
						ExpectWm[0] + " should be present", ExpectWm[0] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWm[0] + " 'is Present or not",
						ExpectWm[0] + " should be present", ExpectWm[0] + " is not present", "Fail");
			}

			// Enter duplicate Substitution group name and click on save button
			actions.smartWait(30);
			actions.clear("SubstitutionGroups.SubstitutionGroupName");
			actions.setValue("SubstitutionGroups.SubstitutionGroupName", SubName);
			actions.click("SubstitutionGroups.SaveButton");
			actions.smartWait(30);

			// Verify the on-screen message
			flag = mcd.VerifyOnscreenMessage("ManageTenderType.MsgText",
					"Substitution Group Name already exists; please enter a different Substitution Group Name.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message",
						"Message 'Substitution Group Name already exists; please enter a different Substitution Group Name.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message",
						"Message 'Substitution Group Name already exists; please enter a different Substitution Group Name.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Enter Substitution Group Name more than 60 characters
			actions.smartWait(30);
			actions.clear("SubstitutionGroups.SubstitutionGroupName");
			String strVal2;
			strVal2 = generateString('c', 61);
			System.out.println(strVal2.length());
			actions.clear("SubstitutionGroups.SubstitutionGroupName");
			actions.setValue("SubstitutionGroups.SubstitutionGroupName", strVal2);
			actions.smartWait(50);
			String newsubstitutionname = driver
					.findElement(By.xpath(actions.getLocator("SubstitutionGroups.SubstitutionGroupName")))
					.getAttribute("value");
			System.out.println(newsubstitutionname.length());
			if (newsubstitutionname.length() <= 60) {
				actions.reportCreatePASS("verify the whether search box accepected more than 60 Characters",
						"search box should be accepected more than 60 Characters",
						"search box should not be accepected more than 60 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether Search box accepected 60 characters",
						"search box should be accepected more than 60 Characters ",
						"search box should be accepected more than 60 Characters", "FAIL");
			}

			// Enter substitution Group Name and Select �Inactive� status from
			// Status DDL
			actions.smartWait(30);
			actions.clear("SubstitutionGroups.SubstitutionGroupName");
			actions.setValue("SubstitutionGroups.SubstitutionGroupName", "Substitution");
			actions.setValue("SubstitutionGroup.Status", "Inactive");

			// Select "Cancel" button
			actions.click("SubstitutionGroups.CancelButton");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWm[1], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWm[1] + " 'is Present or not",
						ExpectWm[1] + " should be present", ExpectWm[1] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWm[1] + " 'is Present or not",
						ExpectWm[1] + " should be present", ExpectWm[1] + " is not present", "Fail");
			}

			// Again, Select "New Substitution Group" button
			actions.smartWait(30);
			actions.click("SubstitutionGroups.NewSGButton");
			actions.smartWait(50);

			do {
				sgName = mcd.fn_GetRndName("Auto_SG");
				actions.clear("SubstitutionGroups.SubstitutionGroupName");
				actions.setValue("SubstitutionGroups.SubstitutionGroupName", sgName);

				actions.click("SubstitutionGroups.SaveButton");

				flag = mcd.VerifyOnscreenMessage("SubstitutionGroups.InfoMessage", "Your changes have been saved.",
						true);
			} while (!(flag));

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}

			actions.click("SubstitutionGroups.CancelButton");
			actions.smartWait(15);

			// Verify the Audit log Details boolean
			boolean AuditlogCorrectValuesDisplayed1 = rfm.VerifyAuditLog_Entry(strOperation, StrActivity, StrLevel);

			if (AuditlogCorrectValuesDisplayed1) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "strExpectActivity[1],Level",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation," + "ActivityValue,Level",
						"Correct values are not displayed", "Fail");
			}

			String AuditDescc = "Substitution Group " + sgName + " has been created.";

			boolean isAuditlogCorrectValuesDisplayed1 = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID,
					strOperation, StrActivity, StrLevel, StrLevedetails, AuditDescc);

			if (isAuditlogCorrectValuesDisplayed1) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are not displayed", "Fail");
			}

			// Navigate to Substitution Group
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			// Create New Substitution Group
			actions.smartWait(30);
			actions.click("SubstitutionGroups.NewSGButton");
			actions.smartWait(50);

			String SubGName = mcd.fn_GetRndName("Auto_SG");
			actions.clear("SubstitutionGroups.SubstitutionGroupName");
			actions.setValue("SubstitutionGroups.SubstitutionGroupName", SubGName);

			// Click "Add Menu Item" button
			actions.click("SubstitutionGroup.AddMITBtn");
			mcd.waitAndSwitch("Common Menu Item Selector");

			// Click "Continue" button
			actions.smartWait(20);
			actions.click("CommonMenuItem.ContinueBtn");
			mcd.SwitchToWindow("@Title");

			// Again, Click "Add Menu Item" button and Click "Cancel" button
			actions.click("SubstitutionGroup.AddMITBtn");
			mcd.waitAndSwitch("Common Menu Item Selector");
			actions.smartWait(20);
			actions.click("CommonMenuItem.CancelBtn");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWm[1], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWm[1] + " 'is Present or not",
						ExpectWm[1] + " should be present", ExpectWm[1] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWm[1] + " 'is Present or not",
						ExpectWm[1] + " should be present", ExpectWm[1] + " is not present", "Fail");
			}
			mcd.SwitchToWindow("@Title");

			// Again, Click "Add Menu Item" button and Enter invalid search
			// criteria
			actions.click("SubstitutionGroup.AddMITBtn");
			mcd.waitAndSwitch("Common Menu Item Selector");
			actions.smartWait(20);
			actions.clear("CommonMenuItem.SearchText");
			actions.setValue("CommonMenuItem.SearchText", "Fulllist");
			actions.click("CommonMenuItem.SearchBtn");
			actions.smartWait(20);

			// Verify the on-screen message
			flag = mcd.VerifyOnscreenMessage("POSLayout.OnscreenMessage", "Search returned no matching results.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message",
						"Message 'Search returned no matching results.'", "Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message",
						"Message 'Search returned no matching results.'", "Expected Message is not displayed", "FAIL");
			}

			// Enter valid search criteria
			actions.clear("CommonMenuItem.SearchText");
			actions.setValue("CommonMenuItem.SearchText", "1");
			actions.click("CommonMenuItem.SearchBtn");
			actions.smartWait(20);

			// Verify the Add Check box should be disabled
			if ((actions.isElementEnabled("AddMenuItem.AddCheckBox"))) {
				actions.reportCreatePASS("verify the 'Add check box' is disable", "Add check box is disable",
						"Add check box should be disable", "Pass");

			} else {

				actions.reportCreateFAIL("verify the 'Add check box' is disable", "Add check box is disable",
						"Add check box should not be disable", "Fail");
			}

			// Sort the result by "Number" in descending order
			actions.clear("CommonMenuItem.SearchText");
			actions.click("CommonMenuItem.SearchBtn");
			actions.smartWait(20);
			actions.click("AddMenuItem.NumberLink");
			actions.smartWait(20);
			WebElement sort_dsc = driver.findElement(By.xpath(actions.getLocator("AddMenuItem.NumberArrowDsc")));
			String migc1 = mcd.GetTableCellValue("RFMManageTenderType.TenderTypeTable", 1, "Number", "", "");
			String migc2 = mcd.GetTableCellValue("RFMManageTenderType.TenderTypeTable", 2, "Number", "", "");

			if (Integer.parseInt(migc1) > Integer.parseInt(migc2)) {
				actions.reportCreatePASS("Valdating the Sort desceding", "Should display Correct sorted result",
						"Number values are displayed as desceding order", "Pass");
			} else {
				actions.reportCreateFAIL("Valdating the Sort desceding", "Should display Correct sorted result",
						"Number values are not displayed as desceding order", "Fail");
			}

			// Sort the result by "Number" in ascending order
			actions.clear("CommonMenuItem.SearchText");
			actions.click("CommonMenuItem.SearchBtn");
			actions.smartWait(20);
			WebElement sort_asc = driver.findElement(By.xpath(actions.getLocator("AddMenuItem.NumberArrowASC")));
			String migc = mcd.GetTableCellValue("RFMManageTenderType.TenderTypeTable", 1, "Number", "", "");
			String migcc = mcd.GetTableCellValue("RFMManageTenderType.TenderTypeTable", 2, "Number", "", "");
			if (Integer.parseInt(migc) < Integer.parseInt(migcc)) {
				actions.reportCreatePASS("Valdating the Sort Asceding", "Should display Correct sorted result",
						"Number values are displayed as ascending order", "Pass");
			} else {
				actions.reportCreateFAIL("Valdating the Sort Asceding", "Should display Correct sorted result",
						"Number values are not displayed as ascending order", "Fail");
			}

			// Filter menu items using "Availability" filter
			actions.clear("CommonMenuItem.SearchText");
			actions.click("CommonMenuItem.SearchBtn");
			actions.smartWait(20);
			String Availability = "Available";
			actions.setValue("AddRemoveMenu.Availability", Availability);
			mcd.smartsync(40);

			if (mcd.GetTableRowCount("RFMManageTenderType.TenderTypeTable") > 0) {

				String record_name = mcd.GetTableCellValue("RFMManageTenderType.TenderTypeTable", 1, "Availability", "",
						"");
				verify_search_result("contains", record_name, Availability);
			}

			// Filter menu items using "Availability" filter
			actions.clear("CommonMenuItem.SearchText");
			actions.click("CommonMenuItem.SearchBtn");
			actions.smartWait(20);
			String Assigned = "Assigned";
			actions.setValue("AddRemoveMenu.Availability", Assigned);
			mcd.smartsync(40);

			if (mcd.GetTableRowCount("RFMManageTenderType.TenderTypeTable") > 0) {

				String record_name = mcd.GetTableCellValue("RFMManageTenderType.TenderTypeTable", 1, "Availability", "",
						"");
				verify_search_result("contains", record_name, Assigned);
			}

			// Check the checkbox to add a menu item
			actions.clear("CommonMenuItem.SearchText");
			actions.click("CommonMenuItem.SearchBtn");
			actions.smartWait(20);
			WebElement elem_checkbox = mcd.GetTableCellElement("AddRemoveComponent.webtable", 1, "Add", "input");
			actions.javaScriptClick(elem_checkbox);
			WebElement elem_checkbox1 = mcd.GetTableCellElement("AddRemoveComponent.webtable", 2, "Add", "input");
			actions.javaScriptClick(elem_checkbox1);

			// Click on �View Current Changes� button
			actions.click("CommonMenuItemSelector.ViewCurrentChanges");
			mcd.waitAndSwitch("View Current Changes");

			// Uncheck the �Add� checkbox
			actions.javaScriptClick("ViewCurrentChanges.AddAll");
			actions.javaScriptClick("ViewCurrentChanges.AddAll");
			actions.click("ViewCurrentChanges.OKButton");
			mcd.SwitchToWindow("Common Menu Item Selector");

			// Click "Continue" button
			actions.smartWait(20);
			actions.click("CommonMenuItem.ContinueBtn");
			mcd.SwitchToWindow("@Title");

			// Click on save button verify alert message
			actions.click("DimensionGroup.SaveButton");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWm[2], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWm[2] + " 'is Present or not",
						ExpectWm[2] + " should be present", ExpectWm[2] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWm[2] + " 'is Present or not",
						ExpectWm[2] + " should be present", ExpectWm[2] + " is not present", "Fail");
			}

			// Select "Substitution Name" for 1st menu items
			actions.smartWait(10);
			actions.setValue("SubstitutionGroups.SubstitutionNameDDL", ExpectSubDdl[0]);
			actions.smartWait(20);
			actions.click("DimensionGroup.SaveButton");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWm[2], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWm[2] + " 'is Present or not",
						ExpectWm[2] + " should be present", ExpectWm[2] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWm[2] + " 'is Present or not",
						ExpectWm[2] + " should be present", ExpectWm[2] + " is not present", "Fail");
			}

			// Select Duplicate "Substitution Name" for 2nd menu items
			actions.smartWait(10);
			actions.setValue("SubstitutionGroup.SubstitutionDDL2", ExpectSubDdl[0]);
			actions.smartWait(20);
			actions.click("DimensionGroup.SaveButton");
			actions.smartWait(20);

			// Verify the on-screen message
			flag = mcd.VerifyOnscreenMessage("ManageTenderType.MsgText",
					"Substitution should be unique within the Substitution Group.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message",
						"Message 'Substitution should be unique within the Substitution Group.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message",
						"Message 'Substitution should be unique within the Substitution Group.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Select Distinct "Substitution Name" for 2nd menu items
			actions.smartWait(10);
			actions.setValue("SubstitutionGroup.SubstitutionDDL2", ExpectSubDdl[1]);
			actions.smartWait(20);
			actions.click("DimensionGroup.SaveButton");
			actions.smartWait(20);

			// Verify the on-screen message
			flag = mcd.VerifyOnscreenMessage("MassSetAssignment.OnScreenMessage", "Your changes have been saved.",
					true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
	// To generate the string of specific size

	public static String generateString(char c, Integer n) {
		StringBuilder b = new StringBuilder();
		for (Integer x = 0; x < n; x++)
			b.append(c);
		return b.toString();
	}

	public void verify_search_result(String search_type, String record_name, String srchtxt) {
		switch (search_type) {

		case "max":
		case "invalid":
			actions.verifyTextPresence(msg[0], true);
			break;
		case "null":
			mcd.VerifyAlertMessageDisplayed("Information", msg[1], true, AlertPopupButton.OK_BUTTON);
			break;
		case "contains":
			if (record_name.contains(srchtxt)) {
				actions.reportCreatePASS("Valdating the Search result with Special Character",
						"Should display Correct result", "Correct result is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Valdating the Search result", "Should display Correct result",
						"Correct results are not displayed", "Fail");
			}
			break;
		case "equal":
			if (record_name.equals(srchtxt)) {
				actions.reportCreatePASS("Valdating the Search result", "Should display Correct result" + srchtxt,
						"Correct result is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Valdating the Search result for" + srchtxt,
						"Should display Correct result for " + srchtxt, "Correct results are not displayed", "Fail");
			}
			break;
		case "filter":
			if (record_name.contains(srchtxt)) {

				actions.reportCreatePASS("Valdating the Search result with status filter",
						"Should display Correct result", "Correct results are displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Valdating the Search result with status filter",
						"Should display Correct result", "Correct results are not displayed", "Fail");
			}
			break;
		}

	}
}
