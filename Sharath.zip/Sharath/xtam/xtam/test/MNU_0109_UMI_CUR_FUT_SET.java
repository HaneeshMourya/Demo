package xtam.test;

import java.io.IOException;
import java.sql.Date;
import java.sql.Driver;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.thoughtworks.selenium.webdriven.commands.IsAlertPresent;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0109_UMI_CUR_FUT_SET {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();
	private lib_MCD mcd;
	private lib_RFM2 rfm;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket, strApplicationDate;
	private String strNavigateTo, strMsg;
	String[] strPOP;

	public MNU_0109_UMI_CUR_FUT_SET(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strMsg = mcd.GetTestData("DT_MSG");
		strPOP = strMsg.split(",");
	}

	@Test
	public void test_MNU_0109_UMI_CUR_FUT_SET() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(
					"Verify Update Menu Item Details (Current with Future Settings) functionality");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(180);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow

			// Verify all fields in Manage Menu Item Screen
			if (!actions.isElementEnabled("RFMExportOptions.Market")) {
				actions.reportCreatePASS("Verify Market textbox is Present", " Market textbox Should be Disabled",
						" Market textbox is Disabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Market textbox is Present", " Market textbox Should be Disabled",
						" Market textbox is not Disabled", "FAIL");
			}

			if (actions.isElementPresent("MenuItems.NewMenuItemSet")) {
				actions.reportCreatePASS("Verify New Menu Item Set is Present", "New Menu Item Set Should be Present",
						"New Menu Item Set is Present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify New Menu Item Set is Present", "New Menu Item Set Should be Present",
						"New Menu Item Set is  not Present", "FAIL");
			}
			if (actions.isElementPresent("ScreenSet.FilterCountry")) {
				actions.reportCreatePASS("Verify Country Drop Down is Present", " Country Drop Down Should be Present",
						" Country Drop Down is Present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Country Drop Down is Present", " Country Drop Down Should be Present",
						" Country Drop Down is not Present", "FAIL");
			}
			if (actions.isElementPresent("ScreenSet.FilterButton")) {
				actions.reportCreatePASS("Verify Filter Button is Present", "Filter Button  Should be Present",
						"Filter Button is Present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Filter Button is Present", "Filter Button  Should be Present",
						"Filter Button is Present", "FAIL");
			}
			verifyTablecolumnsPresent("ScreenSet.ScreenSetList", "Name");
			verifyTablecolumnsPresent("ScreenSet.ScreenSetList", "Node");

			// Click on any Menu Item Set
			WebElement Element1 = mcd.GetTableCellElement("MenuItemSets.Table", 1, "Name", "a");
			String ele = Element1.getText();
			actions.setValue("MenuItemSets.SearchSetName", ele);
			actions.click("MenuItems.Searchbtn5");
			actions.smartWait(50);
			WebElement Element = mcd.GetTableCellElement("MenuItemSets.Table", 1, "Name", "a");
			actions.keyboardEnter(Element);
			actions.smartWait(15);

			// Select any menu item number
			WebElement Ele = mcd.GetTableCellElement("ViewGeneratedReport.ReportTable", 1, "Future Settings", "a");
			WebElement Ele1 = mcd.GetTableCellElement("ViewGeneratedReport.ReportTable", 1, "Number", "a");
			String menuItemNo = Ele1.getText();

			// Verify Future Settings
			String text = Ele.getText();
			if (text.isEmpty()) {

				// Update Long Name & Click on Apply Button,Select Future Date
				Element = mcd.GetTableCellElement("MenuItemSets.Table", 1, "Number", "a");
				actions.keyboardEnter(Element);
				actions.smartWait(15);
				rfm.SelectCustOrResetButton("Are you sure you want to Reset the Default values to the Menu Item?",
						"MenuItemSets.Custbtn", "MenuItemSets.Resetbtn");
				actions.clear("ManageMenuItem.ProductLName");
				String value =mcd.fn_GetRndName("Auto");
				actions.setValue("ManageMenuItem.ProductLName", value);
				actions.click("ManageMenuItem.ApplySavebtn");
				mcd.SwitchToWindow("Apply Changes Details");
				actions.waitForPageToLoad(10000);
				actions.click("FeeSet.FutureRadioBtn");
				actions.click("MenuItemSets.FutureCal");
				mcd.Get_future_date(1, "Close", strApplicationDate);
				actions.keyboardEnter("MenuItemSets.ApplyChangeSave");
				actions.smartWait(20);
				mcd.SwitchToWindow("@Manage Menu Items");
				actions.click("AddNewSmartReminderGroup.Cancel");
				actions.smartWait(40);
			}

			// Select required menu item number with future setting assigned to
			// it
			Element = mcd.GetTableCellElement("MenuItemSets.Table", 1, "Number", "a");
			actions.keyboardEnter(Element);
			actions.smartWait(15);

			// Verify all fileds in Manage Menu Item Screen
			String changeStatus = driver.findElement(By.xpath(actions.getLocator("ManageMenuItems.ChangeStatus")))
					.getAttribute("class");
			if (changeStatus.contains("disableButton")) {
				actions.reportCreatePASS("verify Change Status Button", "Change Status Button should be disabled",
						"Change Status Button is disabled", "PASS");
			} else {
				actions.reportCreateFAIL("verify Change Status Button", "Change Status Button should be disabled",
						"Change Status Button is not disabled", "FAIL");
			}
			if (actions.isElementPresent("ManageMenuItem.ComponentsTab")) {
				actions.reportCreatePASS("Verify Components Tab", "Components Tab should be Present",
						"Components Tab is Present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Components Tab", "Components Tab should be Present",
						"Components Tab is not Present", "FAIL");
			}
			if (actions.isElementPresent("ManageMenuItem.ABSSetting")) {
				actions.reportCreatePASS("Verify ABS Setting Tab", "ABS Setting should be Present",
						"ABS Setting is Present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify ABS Setting Tab", "ABS Setting should be Present",
						"ABS Setting is not Present", "FAIL");
			}

			String applyButton = driver.findElement(By.xpath(actions.getLocator("MasterMenuItemList.Apply")))
					.getAttribute("class");
			if (applyButton.contains("disableButton")) {
				actions.reportCreatePASS("verify Apply Button", "Apply Button should be disabled",
						"Apply Button is disabled", "PASS");
			} else {
				actions.reportCreateFAIL("verify Apply Button", "Apply Button should be disabled",
						"Apply Button is not disabled", "FAIL");
			}
			rfm.SelectCustOrResetButton("Are you sure you want to Reset the Default values to the Menu Item?",
					"MenuItemSets.Custbtn", "MenuItemSets.Resetbtn");

			// Click on Cancel Button
			actions.click("AddNewSmartReminderGroup.Cancel");
			actions.smartWait(20);

			// MENU ITEM > Menu Item > Menu Item Sets
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(180);
			mcd.SwitchToWindow("#Title");

			// Click on any Menu Item Set
			actions.setValue("MenuItemSets.SearchSetName", ele);
			actions.click("MenuItems.Searchbtn5");
			actions.smartWait(50);
			WebElement Element4 = mcd.GetTableCellElement("MenuItemSets.Table", 1, "Name", "a");
			actions.keyboardEnter(Element4);
			actions.smartWait(15);

			// Click on required menu item number having future setting
			// hyperlink
			Element = mcd.GetTableCellElement("MenuItemSets.Table", 1, "Number", "a");
			actions.keyboardEnter(Element);
			actions.smartWait(15);

			// Click Customized Settings button & Verify the Station Group DDL
			rfm.SelectCustOrResetButton("Are you sure you want to Reset the Default values to the Menu Item?",
					"MenuItemSets.Custbtn", "MenuItemSets.Resetbtn");

			String selectValue = new Select(
					driver.findElement(By.xpath(actions.getLocator("MenuItemSets.StationGroup"))))
							.getFirstSelectedOption().getText();
			if (selectValue.equals("Select")) {
				actions.reportCreatePASS("Verify Station Group Drop Down",
						"Station Group Drop Down should be Select(default)",
						"Station Group Drop Down is Select(default)", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Station Group Drop Down",
						"Station Group Drop Down should be Select(default)",
						"Station Group Drop Down is Select(default)", "FAIL");
			}

			// Navigate to presentation setting tab & Select Customized Settings
			// button
			actions.javaScriptClick("ManageMenuItems.PresentationSettings");
			actions.smartWait(20);
			rfm.SelectCustOrResetButton("Are you sure you want to Reset the Default values to the Menu Item?",
					"MenuItemSets.Custbtn", "MenuItemSets.Resetbtn");

			// Click Ellipses icon for Image field & Click OK button
			actions.click("CurrentMenuItemDetails.Image");
			mcd.SwitchToWindow("Assigned Images");
			actions.click("NewScreen.OKButton");
			mcd.SwitchToWindow("@Manage Menu Items");

			// Navigate to POS\KVS setting tab
			actions.javaScriptClick("ManageMenuItem.POSTab");
			actions.smartWait(20);
			rfm.SelectCustOrResetButton("Are you sure you want to Reset the Default values to the Menu Item?",
					"MenuItemSets.Custbtn", "MenuItemSets.Resetbtn");

			// Click Ellipsis icon for Equivalent field & Enter Parent menu
			// item,Click on Search Button
			actions.click("RestaurantMenuItemList.Equivalent");
			mcd.SwitchToWindow("Common Menu Item Selector");
			actions.setValue("CommonMenuItemSelector.SearchBox", menuItemNo);
			actions.click("CopyComponents.SearchExactMatch");
			actions.click("AddRemoveComponent.Searchbtn");
			actions.smartWait(180);
			actions.verifyTextPresence("Search returned no matching results.", true);

			// Click on Cancel button
			actions.keyboardEnter("ManageMenuItem.Cancelbtn1");
			actions.waitForPageToLoad(20);
			mcd.SwitchToWindow("@Manage Menu Items");

			// Click "View Future settings" button & Click on OK button
			actions.keyboardEnter("ManageMenuItem.ViewFutureSettings");
			mcd.SwitchToWindow("Manage Menu Items");
			actions.click("ManageMenuItem.OK");
			mcd.SwitchToWindow("$Manage Menu Items");

			// Click Ellipsis & Enter Parent menu item,Click on Search Button
			actions.click("RestaurantMenuItemList.Equivalent");
			mcd.SwitchToWindow("Common Menu Item Selector");
			actions.clear("CommonMenuItemSelector.SearchBox");
			actions.setValue("CommonMenuItemSelector.SearchBox", menuItemNo);
			actions.click("AddRemoveComponent.Searchbtn");
			actions.smartWait(180);

			// Select any Menu Item & Click on Continue Button
			actions.setValue("AddRemoveMenu.Availability", "Available");
			actions.smartWait(180);
			WebElement checkbox = mcd.GetTableCellElement("AddRemoveComponent.webtable", 1, "Add", "input");
			actions.javaScriptClick(checkbox);
			actions.click("CommonMenuItem.ContinueBtn");
			mcd.SwitchToWindow("@Manage Menu Items");

			// Click on Apply Button
			actions.click("ManageMenuItem.ApplySavebtn");
			if (mcd.VerifyAlertMessageDisplayed("Warning Message", strPOP[1], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Verify the alert message",
						"Message 'Are you sure you want to save changes to the current settings?' ",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the alert message",
						"Message 'Are you sure you want to save changes to the current settings?'",
						"Expected Message is not displayed", "FAIL");
			}
			actions.smartWait(20);
			actions.verifyTextPresence(strPOP[0], true);

			// Select Trigger Display
			Boolean flag;
			List<WebElement> Values = driver
					.findElements(By.xpath(actions.getLocator("ManageMenuItem.TriggerDisplayonORB")));
			flag = Values.get(0).isSelected();
			if (flag = true) {
				actions.click(Values.get(1));
			} else {
				actions.click(Values.get(0));
			}

			// Click on Apply Button & Verify Msg
			actions.click("ManageMenuItem.ApplySavebtn");
			actions.verifyTextPresence(strPOP[0], true);

			// Click on Cancel Button
			actions.click("AddNewSmartReminderGroup.Cancel");
			actions.smartWait(20);
			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}

	// Verify Table Header Fields
	public void verifyTablecolumnsPresent(String tableLocator, String colName) {

		boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

		if (iscolPresent) {
			actions.reportCreatePASS("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is present in table", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is NOT present in table",
					"Fail");
		}
	}

}
