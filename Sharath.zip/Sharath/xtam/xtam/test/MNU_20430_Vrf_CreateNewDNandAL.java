package xtam.test;

import java.util.List;
import java.util.Map;

import org.eclipse.jdt.internal.compiler.parser.ParserBasicInformation;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20430_Vrf_CreateNewDNandAL {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strLevel;
	private WebElement Element;
	// TODO: Declare test-data variables for other data-parameters
	private String dnDescription;
	private int dnCode;
	private String strDnCode;
	private String strSize;
	private boolean flag;
	private String dtErrMsg;
	private String strErrMsg[];
	private String strUserID;
	private String tcDescription;
	private String dgName, strNavigateTo_1, strNavigateTo_2,strRest;
	private String miName;

	public MNU_20430_Vrf_CreateNewDNandAL(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		// added for level
		strLevel = mcd.GetTestData("DT_Level");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		dtErrMsg = mcd.GetTestData("DT_Err_Msg");
		strUserID = mcd.GetTestData("DT_USER_NAME");
		tcDescription = mcd.GetTestData("DT_Description");

		strNavigateTo_1 = mcd.GetTestData("DT_NAVIGATE_TO_1");
		strNavigateTo_2 = mcd.GetTestData("DT_NAVIGATE_TO_2");
		strRest=mcd.GetTestData("DT_REST_NUM");
	}

	@Test
	public void test_MNU_20430_Vrf_CreateNewDNandAL() throws InterruptedException {
		String strPageTitle = "Dimension Names"; // TODO: Exact page-title
		String strPageSubHeading = ""; // TODO: Page Heading

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"Verify Creation of a new Dimension Name , verify the Audit Log for same and verify this newly created name is displayed in - 1.)dimension group,  2.)Dimension Name Set ");
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
			actions.waitForPageToLoad(120);

	//** Select Menu Option *//*
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			actions.waitForPageToLoad(120);
			actions.smartWait(30);

			//** Update title of new Page *//*
			mcd.SwitchToWindow("#Title");

			//** Get application time *//*
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			actions.setTestcaseDescription(tcDescription);
			strErrMsg = dtErrMsg.split("#");

			// Verifying GUI of dimension names

			// Verifying table columns of dimension names
			verifyTablecolumnsPresent("FieldPermissions.Table", "Code");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Description");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Size Order");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Delete");

			// Verifying Cancel button
			if (actions.isElementPresent("RFM.CancelBtn")) {
				actions.reportCreatePASS("Verifying Cancel button", "Cancel button should present",
						"Cancel button is present", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Cancel button", "Cancel button should present",
						"Cancel button is not present", "FAIL");
			}

			// Click on New dimension name button
			actions.click("DimensionName.NewDimensionNameButton");
			Thread.sleep(1000);
			int rowCount = mcd.GetTableRowCount("DimensionName.Table");
			dnCode = mcd.fn_GetRndNumInRange(1, 20);
			strSize = Integer.toString(dnCode);
			mcd.SetTableCellValue("DimensionName.Table", rowCount, "Size Order", strSize, "input", "value");

			// Generating code and description and entering data into particular
			// text box
			dnCode = mcd.fn_GetRndNumInRange(1, 99999);
			strDnCode = Integer.toString(dnCode);
			dnDescription = mcd.fn_GetRndName("Auto_DN");
			mcd.SetTableCellValue("DimensionName.Table", rowCount, "Description", dnDescription, "input", "value");
			mcd.SetTableCellValue("DimensionName.Table", rowCount, "Code", strDnCode, "input", "value");
			actions.click("DimensionGroup.SaveButton");
			actions.verifyTextPresence("Your changes have been saved.", true);

			// Verifying the audit logs:
			boolean blnAudit = false;
			blnAudit = rfm.VerifyAuditLog_Entry(strPageTitle, "Create", strLevel);

			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Entry for Create Dimension Names",
						"Audit log should be generated for Create Dimension Names",
						"Audit log generated for Create Dimension Names succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Entry for Create Dimension Names",
						"Audit log should be generated for Create Dimension Names",
						"Audit log not generated for Create Dimension Names succesfully", "FAIL");
			}

			// Verifying the audit logs details
			blnAudit = rfm.RFM_VerifyAuditLog_Details("RFM2", strUserID, strPageTitle, "Create", strLevel, strMarket,
					"Dimension Name " + dnDescription + " has been created.");
			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Details for Create Dimension Names",
						"Audit log details should be generated for Create Dimension Names",
						"Audit log details generated for Dimension Names succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Details for Create Dimension Names",
						"Audit log details should be generated for Create Dimension Names",
						"Audit log details not generated for Dimension Namesitem succesfully", "FAIL");
			}

			
			
			
			
			
			// Now validating this Dimension name in the dimension Group

			System.out.println("> Navigate to :: " + strNavigateTo_1);
			actions.select_menu("RFMHome.Navigate", strNavigateTo_1);
			actions.smartWait(10);
			mcd.SwitchToWindow("#Title");

			// Click on New dimension group button
			actions.click("DimensionGroup.NewDimensionGroupButton");
			actions.smartWait(180);
			mcd.SwitchToWindow("#Title");

			// Verifying status drop down value with active
			Boolean resultStatus;
			Select selObj = new Select(driver.findElement(By.xpath(actions.getLocator("DimensionGroups.StatusDDL"))));
			resultStatus = selObj.getFirstSelectedOption().getText().trim().equalsIgnoreCase("Active");
			reporting_Pass_Fail("Verify whether Status Active is selected by default for Status DDL",
					"Status Active should be selected by default", "Status Active is selected by default",
					"Status Active is not selected by default", resultStatus);

			// Verifying dimension group column names
			verifyTablecolumnsPresent("FieldPermissions.Table", "Menu Item Code");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Menu Item Name");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Menu Item Status");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Dimension");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Delete");

			// Creating new dimension group
			do {

				dgName = mcd.fn_GetRndName("Auto_DG");
				actions.clear("DimensionGroup.DimensionGroupName");
				actions.setValue("DimensionGroup.DimensionGroupName", dgName);

				// Click on save button and verify on screen message
				actions.click("DimensionGroup.SaveButton");
				flag = mcd.VerifyOnscreenMessage("DimensionGroup.InfoMessage", "Your changes have been saved.", true);
			} while (!(flag));

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Adding menu items to dimension group
			actions.click("DimensionGroup.AddMenuItemButton");
			mcd.waitAndSwitch("Common Menu Item Selector");
			actions.click("SetAssignmentReport.SearchButton");
			actions.smartWait(10);
			Element = mcd.GetTableCellElement("CommonMenuItemSelector.Table", 1, "Add", "input");
			Element.sendKeys(Keys.SPACE);
			miName = mcd.GetTableCellValue("CommonMenuItemSelector.Table", 1, "Name", "", "");
			actions.click("CommonMenuItemSelector.ContinueButton");
			Thread.sleep(2000);
			mcd.SwitchToWindow("Dimension Groups");

			// Selecting dimension from drop down list
			String Default = actions.getValue("DimensionGroups.DimensionDDlist");
			String DDlist = mcd.getdropdownvalues("DimensionGroups.DimensionDDlist");
			String[] DDValues = DDlist.split(",");

			// Verifying created dimension name is displayed in drop down or not
			boolean avail = false;
			int i = 0;

			for (i = 0; i < DDValues.length; i++) {
				if (DDValues[i].equals(dnDescription)) {
					avail = true;
					break;
				}
			}

			if (avail) {
				actions.setValue("DimensionGroups.DimensionDDlist", DDValues[i]);
				actions.reportCreatePASS("Verify the Drop down Dimension Name",
						"Dimension Name should be available in the drop down",
						"Dimension Name is available in the drop down", "PASS");
			} else {
				actions.reportCreatePASS("Verify the Drop down Dimension Name",
						"Dimension Name should be available in the drop down",
						"Dimension Name is not available in the drop down", "FAIL");
			}

			// Click on Save button and verify on screen message
			actions.click("DimensionGroups.ApplyButton");
			actions.smartWait(80);

			flag = false;
			flag = mcd.VerifyOnscreenMessage("DimensionGroup.InfoMessage", "Your changes have been saved.", true);
			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}

			
			
			
			
		
			
			
			
			
			
			
			// Navigate Menu item>dimension>dimension name set
			System.out.println("> Navigate to :: " + strNavigateTo_2);
			actions.select_menu("RFMHome.Navigate", strNavigateTo_2);
			actions.smartWait(10);
			mcd.SwitchToWindow("#Title");

			// GUI verification for dimension name set

			if (!actions.isElementEnabled("RestMIList.MIStatusDrpdwn")) {
				actions.reportCreatePASS("Verify Status drop down", "Status drop down should be disable",
						"Status drop down is disable", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Status drop down", "Status drop down should be disable",
						"Status drop down is NOT  disable", "FAIL");
			}

			// Verify market drop down is disable
			if (!actions.isElementEnabled("MenuItemSets.Marketdrp")) {
				actions.reportCreatePASS("Verify Market  drop down", "Market  drop down should be disable",
						"Market  drop down is disable", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Market  drop down", "Market  drop down should be disable",
						"Market  drop down is NOT  disable", "FAIL");
			}

			// Verifying Country drop down is disable
			if (!actions.isElementEnabled("ScreenSet.FilterListRegionDD")) {
				actions.reportCreatePASS("Verify Country  drop down", "Country  drop down should be disable",
						"Country  drop down is disable", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Country  drop down", "Country  drop down should be disable",
						"Country  drop down is NOT  disable", "FAIL");
			}

			// Verify New Dimension Name Set button

			if (actions.isElementPresent("DimensionNameSet.NewDimensionSetButton")) {
				actions.reportCreatePASS("Verify New Dimension Name Set button",
						"New Dimension Name Set button should be display", "New Dimension Name Set button is displayed",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify New Dimension Name Set button",
						"New Dimension Name Set button should be display",
						"New Dimension Name Set button is NOT  displayed", "FAIL");
			}

			// Verifying New Dimension Name Set columns
			verifyTablecolumnsPresent("FieldPermissions.Table", "Name");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Node");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Status");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Delete");

			//Click on New dimension button and creating dimension name set
			String setName=mcd.fn_GetRndName("DSN_");
			actions.click("DimensionNameSet.NewDimensionSetButton");
			//Thread.sleep(2000);
			mcd.SwitchToWindow("Dimension Name Sets");
			actions.click("DimensionNameSet.SelectButton");
			mcd.SwitchToWindow("Select Node");
			mcd.Selectrestnode_JavaScriptClk("SelectNode.Table", strMarket);
			//SetAssignmentReport.AvailableSetTable
			//mcd.Selectrestnode_JavaScriptClk("SelectNode.Table", strRest);
			
			//Thread.sleep(2000);
			/*mcd.SwitchToWindow("Select Node");
			mcd.Selectrestnode("SelectNode.Table", strRest);*/
			mcd.SwitchToWindow("Dimension Name Sets");
			boolean blnWindow = false;
			actions.clear("DimensionNameSet.SetNameTextBox");
			actions.setValue("DimensionNameSet.SetNameTextBox", setName);
			actions.click("DimensionNameSet.NextButton");
			mcd.SwitchToWindow("@Dimension Name Set");
						
			//Update dimension name set table columns
			verifyTablecolumnsPresent("FieldPermissions.Table", "Code");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Description");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Size Order");
			
			/*//Verifying disable fields of DNS
			List< WebElement> dis_ele=driver.findElements(By.xpath("//*[@id='taxTypeData']/tr/td/input"));
			int a=dis_ele.size();
			Boolean flag =false;	
			 
			 for(int j=1;i< a;i++)
			 {
				 String ele=driver.findElement(By.xpath("//*[@id='taxTypeData']/tr["+ j +"]/td/input")).getAttribute("disabled");
				 if(ele.contains("true"))
				 {
					 flag=true;
					
				 }
				 else
				 {
					 flag=false;
					 break;
				 }
			 }
			 
			 if(flag)
			 {
				 actions.reportCreatePASS("Verify Code,Description,Size Order All the values", "Code,Description,Size Order All the values should disable", "Code,Description,Size Order All the values are disable", "PASS");
			 }else{
				 actions.reportCreateFAIL("Verify Code,Description,Size Order All the values", "Code,Description,Size Order All the values should disable", "Code,Description,Size Order All the values are not disable", "FAIL");
			 }*/
			 
			 //Click on customize settings button
			 actions.keyboardEnter("TaxChainVerify.Customize");
			 
			 //Check size order field is enable
			 if(actions.isElementEnabled("DimesionNameSets.Sordorder"))
			 {
				 actions.reportCreatePASS("Verify Size order text box", "Size order text box should enable", "Size order text box is enable", "PASS");
			 }else{
				 actions.reportCreateFAIL("Verify Size order text box", "Size order text box should enable", "Size order text box is not enable", "FAIL"); 
			 }
			 
			 //Checking Code and Description are disable
			 if(!actions.isElementEnabled("DimesionNameSets.Code"))
			 {
				 actions.reportCreatePASS("Verify Code column", "Code column should disable", "Code column is disable", "PASS");
			 }else{
				 actions.reportCreateFAIL("Verify Code column", "Code column should disable", "Code column is not disable", "FAIL"); 
			 }
			 
			 if(!actions.isElementEnabled("ManageMenuItem.ComponentsTableRow1Name"))
			 {
				 actions.reportCreatePASS("Verify Description column", "Description column should disable", "Description column is disable", "PASS");
			 }else{
				 actions.reportCreateFAIL("Verify Description column", "Description column should disable", "Description column is not disable", "FAIL"); 
			 }
			 
			 
			/** Logout the application */
			rfm.Logout();

		} catch (

		Exception e)

		{

			// reporting the Fail condition
			actions.catchException(e);

		} finally

		{
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	// VERIFYING TABLE COLUMS CODE
	public void verifyTablecolumnsPresent(String tableLocator, String colName) {

		boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

		if (iscolPresent) {
			actions.reportCreatePASS("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is present in table", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is NOT present in table",
					"Fail");
		}
	}

	/////// METHOD WE HAVE TO USE FOR THIS
	public void reporting_Pass_Fail(String Desc, String ExpRes, String ActRes_Pass, String ActRes_Fail,
			Boolean status) {
		if (status) {
			actions.reportCreatePASS(Desc, ExpRes, ActRes_Pass, "PASS");
		}

		if (!status) {
			actions.reportCreateFAIL(Desc, ExpRes, ActRes_Fail, "FAIL");
		}
	}

}
