package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;


public class MNU_20105_VerifyMI_ABSSettings {
       private Keywords actions;
       private WebDriver driver;
       private Map input;
       private UIValidations uiActions;
       private SoftAssert softAssert = new SoftAssert();
       
       private lib_MCD mcd;
       private lib_RFM2 rfm;
       
       private String strApplicationDate;
       
       // Test-Data Variables
       private Object strURL;
       private Object strUserName;
       private Object strPassword;
       private String strMarket;
       private String strNavigateTo;

       // TODO: Declare test-data variables for other data-parameters

       
       public MNU_20105_VerifyMI_ABSSettings (WebDriver nodeDriver, Map inputData, Object or){
              driver = nodeDriver;
              input = inputData;
              actions = new Keywords(driver, or);
              uiActions = new UIValidations();
              
              mcd = new lib_MCD (driver, actions, uiActions, inputData);
              rfm = new lib_RFM2 (driver, actions, uiActions, inputData, mcd);

              // Read input Test-Data
              strURL                     = mcd.GetTestData("DT_URL");
              strUserName   			= mcd.GetTestData("DT_USER_NAME");
              strPassword   			= mcd.GetTestData("DT_PASSWORD");
              strMarket            = mcd.GetTestData("DT_MARKET");
              strNavigateTo        = mcd.GetTestData("DT_NAVIGATE_TO");

              
       }
       
       @Test
       public void test_MNU_20105_VerifyMI_ABSSettings() throws InterruptedException {
              String strPageTitle = "";                // TODO: Exact page-title
              String strPageSubHeading = "Master Menu Item List";          // TODO: Page Heading
              
              
              try {
                     System.out.println("********************************************************************** Test execution starts");
                     actions.setTestcaseDescription("Verify mandatory & non-mandatory fields & field level error messages while creating a Menu Item(ABS Settings)");

                     /** Launch and Login RFM */
                     System.out.println("> Launch and Login RFM");
                     rfm.LaunchAndLogin(strURL, strUserName, strPassword);
                     
                     /** Select Market (Node) */
                     System.out.println("> Select Market (Node)");
                     rfm.SelectMarket(strMarket);
              
                     //Navigate to Master menu item list
                     System.out.println("> Navigate to :: " + strNavigateTo);
                     actions.select_menu("RFMHome.Navigation",strNavigateTo);
                     Thread.sleep(2000);
                     actions.waitForPageToLoad(120);

                     
                     /** Update title of new Page  */
                     mcd.SwitchToWindow("#Title");
                     
                     /** Get application time */
                     WebElement apptime = mcd.getdate();
                     strApplicationDate = apptime.getText();

                     
                     //Click on Search button
                     actions.WaitForElementPresent("MasterMenuItemList.SearchButton", 100);
                     actions.smartWait(100);
                     /** Click on Search Button - added by Sunny Mittal*/
                     actions.keyboardEnter("MasterMenuItemList.SearchButton");
                     actions.smartWait(100); 
                     actions.WaitForElementPresent("MasterMenuItemList.FamilyGroupFilter");
                     
                     //Selecting 'REGULAR_DRINK' from the Drop down and Click on Menu item
                     actions.setValue("MasterMenuItemList.FamilyGroupFilter", "REGULAR_DRINK");
                     actions.smartWait(100);
                     actions.WaitForElementPresent("MasterMenuItemList.TableFirstValue");
                     actions.keyboardEnter("MasterMenuItemList.TableFirstValue");
                     actions.smartWait(100);
                     mcd.SwitchToWindow("#Title");
                     actions.WaitForElementPresent("ManageMenuItems.ABSSettings", 100);
                     
                     //Click on ABS Settings tab
                     actions.keyboardEnter("ManageMenuItems.ABSSettings");
                     actions.smartWait(100);
                     
                     //Verifying default drop down value of Cup size
                    // String dDVal=driver.findElement(By.xpath(actions.getLocator("ManageMenuItems.CupSize")));
                     Select defaul_Val=new Select(driver.findElement(By.xpath(actions.getLocator("ManageMenuItems.CupSize"))));
                     String default_text=defaul_Val.getFirstSelectedOption().getText();
                     if(default_text.equalsIgnoreCase("Select"))
                     {
                    	 actions.reportCreatePASS("Verifying CupSize drop down default value", "CupSize drop down default value Select should be diaply", "CupSize  drop down default value Select is displayed", "PASS");
                    	 
                     }else{
                    	 actions.reportCreateFAIL("Verifying CupSize drop down default value", "CupSize drop down default value Select should be diaply", "CupSize  drop down default value Select is not displayed", "FAIL"); 
                     }
                     
                     
                   //Verifying default drop down value of Flavor 
                     Select defaul_Flavor=new Select(driver.findElement(By.xpath(actions.getLocator("MasterMenuItemList.ABSFlavorEnable"))));
                     String default_fla=defaul_Flavor.getFirstSelectedOption().getText();
                     if(default_fla.equalsIgnoreCase("Select"))
                     {
                    	 actions.reportCreatePASS("Verifying Flavor drop down default value", "Flavor drop down default value Select should be diaply", "Flavor  drop down default value Select is displayed", "PASS");
                    	 
                     }else{
                    	 actions.reportCreateFAIL("Verifying Flavor drop down default value", "Flavor drop down default value Select should be diaply", "Flavor  drop down default value Select is not displayed", "FAIL"); 
                     }
                     
                     
                   //Verifying default drop down value of Lid Option 
                     Select defaul_Lid_Option=new Select(driver.findElement(By.xpath(actions.getLocator("MasterMenuItemList.ABSLidoptionEnable"))));
                     String default_Option=defaul_Lid_Option.getFirstSelectedOption().getText();
                     if(default_Option.equalsIgnoreCase("Select"))
                     {
                    	 actions.reportCreatePASS("Verifying Lid Option  drop down default value", "Lid Option  drop down default value Select should be diaply", "Lid Option   drop down default value Select is displayed", "PASS");
                    	 
                     }else{
                    	 actions.reportCreateFAIL("Verifying Lid Option  drop down default value", "Lid Option  drop down default value Select should be diaply", "Lid Option   drop down default value Select is not displayed", "FAIL"); 
                     }
                     
                   //Verifying default drop down value of Ice Selection
                     Select Ice_Selection=new Select(driver.findElement(By.xpath(actions.getLocator("MasterMenuItemList.ABSLidoptionEnable"))));
                     String Selection=Ice_Selection.getFirstSelectedOption().getText();
                     if(Selection.equalsIgnoreCase("Select"))
                     {
                    	 actions.reportCreatePASS("Verifying Ice Selection  drop down default value", "Ice Selection  drop down default value Select should be diaply", "Ice Selection   drop down default value Select is displayed", "PASS");
                    	 
                     }else{
                    	 actions.reportCreateFAIL("Verifying Ice Selection  drop down default value", "Ice Selection  drop down default value Select should be diaply", "Ice Selection   drop down default value Select is not displayed", "FAIL"); 
                     }
                     
                     
                   //Verifying default drop down value of Ice Product Definition
                     Select Ice_Product_Definition=new Select(driver.findElement(By.xpath(actions.getLocator("MasterMenuItemList.ABSLidoptionEnable"))));
                     String Product=Ice_Product_Definition.getFirstSelectedOption().getText();
                     if(Product.equalsIgnoreCase("Select"))
                     {
                    	 actions.reportCreatePASS("Verifying Ice Product Definition  drop down default value", "Ice Product Definition  drop down default value Select should be diaply", "Ice Product Definition   drop down default value Select is displayed", "PASS");
                    	 
                     }else{
                    	 actions.reportCreateFAIL("Verifying Ice Product Definition  drop down default value", "Ice Product Definition  drop down default value Select should be diaply", "Ice Product Definition   drop down default value Select is not displayed", "FAIL"); 
                     }
                     
                     
                     //Verifying NGABSDDL
                     if(actions.isElementEnabled("ManageMenuItem.NGABSDDL"))
                     {
                    	 actions.reportCreatePASS("Verifyig NGABSVolume drop down", "NGABSVolume drop down should be enable", "NGABSVolume drop down is enable", "PASS");
                     }else{
                    	 actions.reportCreateFAIL("Verifyig NGABSVolume drop down", "NGABSVolume drop down should be enable", "NGABSVolume drop down is not enable", "FAIL");
                     }
                     
                     
                     /** Verify if CupSize drop down contains all the values */
         			String strDDVal=driver.findElement(By.xpath(actions.getLocator("ManageMenuItems.CupSize"))).getText();
         			System.out.println(strDDVal);
         			 try{
         			if(strDDVal.contains("Child")&&strDDVal.contains("Large")&&strDDVal.contains("Medium")&&strDDVal.contains("Promo1")&&strDDVal.contains("Promo2")&&strDDVal.contains("Promo3")&&strDDVal.contains("Small")&&strDDVal.contains("X-large")){
         				System.out.println("Required List is Presentin Cup Size Drop Down List");
         				actions.reportCreatePASS("Required List is Present in 'Cup Size' Drop Down List", "Required List should Present in 'Cup Size' Drop Down List", "Required List is Present in 'Cup Size' Drop Down List", "Pass");
         			}
         			}catch(Exception err){
         				System.out.println("Required List is not Present");
         				actions.reportCreateFAIL("Required List is Present in 'Cup Size' Drop Down List", "Required List should Present in 'Cup Size' Drop Down List", "Required List is not Present in 'Cup Size' Drop Down List", "Fail");
         			}

         			 /** Verify if LidOption drop down contains all the values */
         			String strDDVal1=driver.findElement(By.xpath(actions.getLocator("ManageMenuItems.LidOption"))).getText();
         			System.out.println(strDDVal1);
         			try{
         			if(strDDVal1.contains("No Lid")&&strDDVal1.contains("With Lid")){
         				System.out.println("Required List is Presentin Lid Option Drop Down List");
         				actions.reportCreatePASS("Required List is Present in 'Lid Option' Drop Down List", "Required List should Present in 'Lid Option' Drop Down List", "Required List is Present in 'Lid Option' Drop Down List", "Pass");
         			}
         			}catch(Exception err){
         				System.out.println("Required List is not Present");
         				actions.reportCreateFAIL("Required List is Present in 'Lid Option' Drop Down List", "Required List should Present in 'Lid Option' Drop Down List", "Required List is not Present in 'Lid Option' Drop Down List", "Fail");
         			}
         			
         			
         			 /** Verify if IceSelection drop down contains all the values */
         			String strDDVal2=driver.findElement(By.xpath(actions.getLocator("ManageMenuItems.IceSelection"))).getText();
         			System.out.println(strDDVal2);
         			try{
         			if(strDDVal2.contains("Empty Cup")&&strDDVal2.contains("Full Ice Drink")&&strDDVal2.contains("Full Ice Only")&&strDDVal2.contains("Light Ice")&&strDDVal2.contains("Light Ice Only")&&strDDVal2.contains("No Ice Drink")&&strDDVal2.contains("Regular Ice Drink")&&strDDVal2.contains("Regular Ice Only")){
         				System.out.println("Required List is Presentin Ice Selection Drop Down List");
         				actions.reportCreatePASS("Required List is Present in 'Ice Selection' Drop Down List", "Required List should Present in 'Ice Selection' Drop Down List", "Required List is Present in 'Ice Selection' Drop Down List", "Pass");
         			}
         			}catch(Exception err){
         				System.out.println("Required List is not Present");
         				actions.reportCreateFAIL("Required List is Present in 'Ice Selection' Drop Down List", "Required List should Present in 'Ice Selection' Drop Down List", "Required List is not Present in 'Ice Selection' Drop Down List", "Fail");
         			}
         			
         			  
                     /** Logout the application */
                     rfm.Logout();
                     

              } catch(Exception e) {
                     
                     //reporting the Fail condition
                     actions.catchException(e);
                     
              } finally {
                     actions.quitBrowser();
                     actions.verifyTestCase(this.getClass());
                     
                           
              }
       }
}
