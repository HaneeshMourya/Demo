package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20420_Vrf_DelOfMIinDG {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();
	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;

	// TODO: Declare test-data variables for other data-parameters
	private String dgName;
	private boolean flag;
	private String miName_1;
	private String strUserID;
	private String tcDescription;
	private String strlevel, msg;

	public MNU_20420_Vrf_DelOfMIinDG(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");

		// TODO: GetTestData for other data-parameters
		strUserID = mcd.GetTestData("DT_USER_NAME");
		tcDescription = mcd.GetTestData("DT_Description");
		strlevel = mcd.GetTestData("DT_LEVEL");
		msg = mcd.GetTestData("DT_MSG");
	}

	@Test
	public void test_MNU_20420_Vrf_DelOfMIinDG() throws InterruptedException {
		String strPageTitle = "Dimension Groups"; // TODO: Exact page-title
		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription("Verify Audit Log when Menu Item is deleted from Dimension Group");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			actions.smartWait(15);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// Verifying Search Full List by Dimension Group Name text box
			String textbox = driver.findElement(By.xpath(actions.getLocator("ProductionRouting.SearchTextField")))
					.getAttribute("type");
			if (textbox.equals("text")) {
				actions.reportCreatePASS("Verifying Search Full List by Dimension Group Name text box",
						"Verifying Search Full List by Dimension Group Name text box should display",
						"Verifying Search Full List by Dimension Group Name text box is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Search Full List by Dimension Group Name text box",
						"Verifying Search Full List by Dimension Group Name text box should display",
						"Verifying Search Full List by Dimension Group Name text box is NOT displayed", "FAIL");

			}

			// Verifying Search within Status DDL
			if (actions.isElementEnabled("ManageDimensionGroup.STSearchWithInStatus")) {
				actions.reportCreatePASS("Verifying Search within Status DDL", "Search within Status DDL should enable",
						"Search within Status DDL is enable", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Search within Status DDL", "Search within Status DDL should enable",
						"Search within Status DDL is not enable", "FAIL");

			}

			// Verifying search button
			if (actions.isElementPresent("SetAssignmentReport.SearchButton")) {
				actions.reportCreatePASS("Verify Search button", "Search button should display",
						"Search button is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Search button", "Search button should display",
						"Search button is not displayed", "FAIL");
			}

			// Verifying New dimension group button
			if (actions.isElementPresent("DimensionGroup.NewDimensionGroupButton")) {
				actions.reportCreatePASS("Verify New Dimension Group button",
						"New Dimension Group button should display", "New Dimension Group button is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify New Dimension Group button",
						"New Dimension Group button should display", "New Dimension Group button is not displayed",
						"FAIL");
			}

			// Verifying save button
			if (actions.isElementPresent("RFMQueueRoutingPopupPage.SaveButton")) {
				actions.reportCreatePASS("Verify Save button", "Save button should display", "Save button is displayed",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Save button", "Save button should display",
						"Save button is not displayed", "FAIL");
			}

			// Verifying CANCEL button
			if (actions.isElementPresent("RFMQueueManagementPage.CancelButton")) {
				actions.reportCreatePASS("Verify Cancel button", "Cancel button should display",
						"Cancel button is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Cancel button", "Cancel button should display",
						"Cancel button is not displayed", "FAIL");
			}

			// Verifying columns code,description,size order and delete
			verifyTablecolumnsPresent("UpdateTaxType.TaxBreakTable", "Group Name");
			verifyTablecolumnsPresent("UpdateTaxType.TaxBreakTable", "Status");
			verifyTablecolumnsPresent("UpdateTaxType.TaxBreakTable", "Delete");

			// Creating New dimension group
			System.out.println("Start");
			actions.click("DimensionGroup.NewDimensionGroupButton");
			actions.smartWait(15);
			actions.setValue("DimensionGroups.StatusDDL", "Inactive");
			dgName = mcd.fn_GetRndName("Auto_DG");
			actions.clear("DimensionGroup.DimensionGroupName");
			actions.setValue("DimensionGroup.DimensionGroupName", dgName);
			actions.click("DimensionGroup.SaveButton");
			flag = mcd.VerifyOnscreenMessage("DimensionGroup.InfoMessage", "Your changes have been saved.", true);
			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Adding menu items to dimension group
			actions.keyboardEnter("DimensionGroup.CancelButton");
			mcd.SwitchToWindow("@Manage Dimension Groups");
			actions.smartWait(20);
			actions.setValue("DimensionGroup.SearchField", dgName);
			actions.javaScriptClick("RFMPresentationRoutingSetSelectNodePage.SearchButton");
			actions.smartWait(40);
			actions.keyboardEnter("ManageDimensionGroups.Firstele");
			mcd.SwitchToWindow("#Title");
			actions.click("DimensionGroup.AddMenuItemButton");
			Thread.sleep(5000);
			mcd.SwitchToWindow("Common Menu Item Selector");
			actions.smartWait(15);
			actions.checkElement(actions.getLocator("MenuItemPriceandTaxByRestaurant.NBSearchButton"), 180);
			actions.click("MenuItemPriceandTaxByRestaurant.NBSearchButton");
			actions.smartWait(15);
			WebElement ele = mcd.GetTableCellElement("CommonMenuItemSelector.Table", 1, "Add", "input");
			actions.click(ele);
			actions.click("CommonMenuItemSelector.ContinueButton");
			mcd.SwitchToWindow("Dimension Groups");
			String Default = actions.getValue("DimensionGroups.DimensionDDlist");
			String DDlist = mcd.getdropdownvalues("DimensionGroups.DimensionDDlist");
			String[] DDValues = DDlist.split(",");
			if (Default.equals(DDValues[0])) {
				actions.setValue("DimensionGroups.DimensionDDlist", DDValues[1]);
			} else {
				actions.setValue("DimensionGroups.DimensionDDlist", DDValues[2]);
			}

			// Deleting menu item from Demension group
			actions.keyboardEnter("RFMQueueRoutingPopupPage.SaveButton");
			actions.smartWait(180);
			actions.click("UpdateProductionroutingSet.RouteFirstDelIcon");
			flag = mcd.VerifyAlertMessageDisplayed("Warning Message", msg, true, AlertPopupButton.OK_BUTTON);
			if (flag) {
				actions.reportCreatePASS("Verify the Alert Message",
						"Message 'Are you sure you want to delete the selected item?' should be displayed",
						"Expected Message is dispayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the Alert Message",
						"Message 'Are you sure you want to delete the selected item?' should be displayed",
						"Expected Message is not dispayed", "FAIL");
			}
			mcd.VerifyOnscreenMessage("DimensionGroups.DeleteInfoMessage", "Delete has been successfully completed.",
					true);

			// Verify Audit Log and details of audit log
			boolean blnAudit = false;
			blnAudit = rfm.VerifyAuditLog_Entry(strPageTitle, "Update", strlevel);
			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Entry for update Dimension Group",
						"Audit log should be generated for Update Dimension group",
						"Audit log generated for Update Dimension group succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Entry for Update Dimension Group",
						"Audit log should be generated for Update Dimension group",
						"Audit log not generated for Update Dimension group succesfully", "FAIL");
			}

			blnAudit = rfm.RFM_VerifyAuditLog_Details("RFM2", strUserID, strPageTitle, "Update", strlevel, strMarket,
					"Dimension Group " + dgName + " has been updated.");
			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Details for Update Dimension Group",
						"Audit log details should be generated for Update Dimension group",
						"Audit log details generated for Dimension group item succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Details for Update Dimension Group",
						"Audit log details should be generated for Update Dimension group",
						"Audit log details not generated for Dimension group item succesfully", "FAIL");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	public void verifyTablecolumnsPresent(String tableLocator, String colName) {

		boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

		if (iscolPresent) {
			actions.reportCreatePASS("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is present in table", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is NOT present in table",
					"Fail");
		}
	}
}
