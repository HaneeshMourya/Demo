package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20434_Vrf_DeletionOfDNandAL {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();
	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strLevel;
	private String strNavigateTo;

	// TODO: Declare test-data variables for other data-parameters
	private String dnDescription;
	private int dnCode;
	private String strDnCode;
	private String strSize;
	private boolean flag;
	private String dtErrMsg;
	private String strErrMsg[];
	private String strUserID;
	private String Value;
	private WebElement Element;
	private String tcDescription;

	public MNU_20434_Vrf_DeletionOfDNandAL(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();
		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strLevel = mcd.GetTestData("DT_Level");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");

		// TODO: GetTestData for other data-parameters
		dtErrMsg = mcd.GetTestData("DT_Err_Msg");
		strUserID = mcd.GetTestData("DT_USER_NAME");
		tcDescription = mcd.GetTestData("DT_Description");
	}

	@Test
	public void test_MNU_20434_Vrf_DeletionOfDNandAL() throws InterruptedException {
		String strPageTitle = "Dimension Names";

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			// Test Case description
			actions.setTestcaseDescription(
					"Verify Deleting of Dimension Name entry and verify the Audit Log for delete.");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
			actions.waitForPageToLoad(120);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			actions.waitForPageToLoad(120);
			actions.smartWait(60);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// Verifying dimension name button
			if (actions.isElementPresent("DimensionNames.NewDimensionName")) {
				actions.reportCreatePASS("Verify NewDimensionName button", "NewDimensionName button should display",
						"NewDimensionName buttom is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify NewDimensionName button", "NewDimensionName button should display",
						"NewDimensionName button is not displayed", "FAIL");

			}

			// Verifying Save button
			if (actions.isElementPresent("RFMQueueRoutingPopupPage.SaveButton")) {
				actions.reportCreatePASS("Verify Save button", "Save button should display", "Save buttom is displayed",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Save button", "Save button should display",
						"Save button is not displayed", "FAIL");

			}

			// Verifying Cancel button
			if (actions.isElementPresent("RFMQueueManagementPage.CancelButton")) {
				actions.reportCreatePASS("Verify Cancel button", "Cancel button should display",
						"Cancel buttom is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Cancel button", "Cancel button should display",
						"Cancel button is not displayed", "FAIL");

			}

			// Verifying columns code,description,size order and delete
			verifyTablecolumnsPresent("DimensionName.Table", "Code");
			verifyTablecolumnsPresent("DimensionName.Table", "Description");
			verifyTablecolumnsPresent("DimensionName.Table", "Size Order");
			verifyTablecolumnsPresent("DimensionName.Table", "Delete");

			// Creating New dimension name with name ,code and size
			strErrMsg = dtErrMsg.split("#");
			actions.click("DimensionName.NewDimensionNameButton");
			actions.smartWait(180);
			int rowCount = mcd.GetTableRowCount("DimensionName.Table");
			dnCode = mcd.fn_GetRndNumInRange(1, 20);
			strSize = Integer.toString(dnCode);
			mcd.SetTableCellValue("DimensionName.Table", rowCount, "Size Order", strSize, "input", "value");
			dnCode = mcd.fn_GetRndNumInRange(1, 99999);
			strDnCode = Integer.toString(dnCode);
			dnDescription = mcd.fn_GetRndName("Auto_DN");
			mcd.SetTableCellValue("DimensionName.Table", rowCount, "Description", dnDescription, "input", "value");
			mcd.SetTableCellValue("DimensionName.Table", rowCount, "Code", strDnCode, "input", "value");
			actions.click("DimensionGroup.SaveButton");

			// Verifying save changes message on screen
			flag = mcd.VerifyOnscreenMessage("SubstitutionGroups.InfoMessage", strErrMsg[2], true);
			if (flag) {
				actions.reportCreatePASS("Verify the info message",
						"Message '" + strErrMsg[2] + "' should be displayed", "Expected message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the info message",
						"Message '" + strErrMsg[2] + "' should be displayed", "Expected message is not displayed",
						"FAIL");
			}

			// Deleting created dimension name
			rowCount = mcd.GetTableRowCount("DimensionName.Table");
			for (int i = 1; i <= rowCount; i++) {
				Value = mcd.GetTableCellValue("DimensionName.Table", i, "Description", "input", "value");
				if (Value.equals(dnDescription)) {
					Element = mcd.GetTableCellElement("DimensionName.Table", i, "Delete", "a");
					break;
				}
			}
			actions.click(Element);
			actions.isAlertPresent(20);

			// Verifying delete pop-up message
			flag = mcd.VerifyAlertMessageDisplayed("Warning Message", strErrMsg[3], true, AlertPopupButton.OK_BUTTON);
			if (flag) {
				actions.reportCreatePASS("Verify text on alert box",
						"Message '" + strErrMsg[3] + "' should be displayed", "Expected message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify text on alert box",
						"Message '" + strErrMsg[3] + "' should be displayed", "Expected message is not displayed",
						"FAIL");
			}

			// Added as failing sometime on navigation to home
			actions.waitForPageToLoad(120);
			actions.smartWait(60);

			// Verifying the audit log
			boolean blnAudit = false;
			blnAudit = rfm.VerifyAuditLog_Entry(strPageTitle, "Delete", strLevel);
			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Entry for Delete Dimension Names",
						"Audit log should be generated for Delete Dimension Names",
						"Audit log generated for Delete Dimension Names succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Entry for Delete Dimension Names",
						"Audit log should be generated for Delete Dimension Names",
						"Audit log not generated for Delete Dimension Names succesfully", "FAIL");
			}

			// Verify Audit log details
			blnAudit = rfm.RFM_VerifyAuditLog_Details("RFM2", strUserID, strPageTitle, "Delete", strLevel, strMarket,
					"Dimension Name " + dnDescription + " has been deleted.");
			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Details for Delete Dimension Names",
						"Audit log details should be generated for Delete Dimension Names",
						"Audit log details generated for Dimension Names succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Details for Delete Dimension Names",
						"Audit log details should be generated for Delete Dimension Names",
						"Audit log details not generated for Dimension Namesitem succesfully", "FAIL");
			}

			/** Logout the application */
			rfm.Logout();
		} catch (Exception e) {
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}

	}

	public void verifyTablecolumnsPresent(String tableLocator, String colName) {

		boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

		if (iscolPresent) {
			actions.reportCreatePASS("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is present in table", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is NOT present in table",
					"Fail");
		}
	}

}
