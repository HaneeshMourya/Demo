package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20453_FieldValidationsDNS {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String[] strErrMsg;
	private String dtErrMsg;
	private boolean flag;
	private String strOperation, StrActivity, StrLevel, StrLevedetails, strDBName, strUserID;

	public MNU_20453_FieldValidationsDNS(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		StrLevel = mcd.GetTestData("DT_LEVEL");
		StrLevedetails = mcd.GetTestData("DT_LevelDetails");
		StrActivity = mcd.GetTestData("DT_ACTIVITY");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strDBName = mcd.GetTestData("DT_DBNAME");
		strUserID = mcd.GetTestData("DT_USER_NAME");
		// TODO: GetTestData for other data-parameters
		dtErrMsg = mcd.GetTestData("DT_ERR_MSG_1");
		strErrMsg = dtErrMsg.split("#");
	}

	@Test
	public void test_MNU_20453_FieldValidationsDNS() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"To verify the field validations of the Set Name Text Field on Update Dimension Name Set Screen");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			actions.smartWait(15);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Verify the Dimension Set Page

			// Verifying presence of 'New Dimension Name Set' Button
			Boolean NewDNSbutton;
			NewDNSbutton = actions.isElementPresent("DimensionNameSet.NewDimensionSetButton");
			reporting_Pass_Fail("Verify whether 'New Dimension Name Set' Button is present",
					"'New Dimension Name Set' Button should be present", "'New Dimension Name Set' Button is present",
					"'New Dimension Name Set' Button is not present", NewDNSbutton);

			// Verifying 'Dimension Search' Text Box
			Boolean DSTextbox;
			DSTextbox = actions.isElementPresent("DimensionNameSet.SearchSetTextbox");
			reporting_Pass_Fail("Verify whether Dimension Search Textbox is present",
					"Dimension Search Textbox should be present", "Dimension Search Textbox is present",
					"Dimension Search Textbox is not present", DSTextbox);

			// Verifying 'Search within Status' Filter
			Boolean resultStatus;
			Select selObj = new Select(
					driver.findElement(By.xpath(actions.getLocator("DimensionNameSets.srchwtnsts"))));
			resultStatus = selObj.getFirstSelectedOption().getText().trim().equalsIgnoreCase("Active/Inactive");
			reporting_Pass_Fail(
					"Verify whether Search within Status Active/Inactive is selected by default for Status DDL",
					"Search within Status Active/Inactive should be selected by default",
					"Search within Status Active/Inactive is selected by default",
					"Search within Status Active/Inactive is not selected by default", resultStatus);

			// Get the Dimension Name
			actions.keyboardEnter("RestaurantSet.Searchbtn");
			actions.smartWait(15);
			String dup = mcd.GetTableCellValue("DimensionName.Table", 2, "Name", "", "");
			System.out.println("> > > > dup: " + dup);

			// Select Exiting Dimension Set
			String Dsetname = mcd.GetTableCellValue("DimensionName.Table", 1, "Name", "", "");
			System.out.println("> > > > Dsetname: " + Dsetname);
			String restNum = mcd.GetTableCellValue("DimensionName.Table", 1, "Name", "", "");
			WebElement Element = mcd.GetTableCellElement("DimensionName.Table", 1, "Name", "a");
			actions.keyboardEnter(Element);
			actions.smartWait(25);
			mcd.SwitchToWindow("#Title");

			// Enters the test data in the Dimension Name Set Name Text Field
			// and clicks on Save button
			actions.clear("DimensionNameSet.DimensionNameSet");
			String val = mcd.fn_GetRndName("Auto");
			actions.setValue("DimensionNameSet.DimensionNameSet", val);
			actions.click("DimensionNameSet.SaveButton");
			actions.smartWait(10);

			// Verify the on-screen message
			flag = mcd.VerifyOnscreenMessage("DimensionNameSets.InfoMessage", "Your changes have been saved.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Search for 60 characters
			actions.clear("DimensionNameSet.DimensionNameSet");
			Element = actions.getWebElement("DimensionNameSet.DimensionNameSet");
			String temp = Element.getAttribute("value");
			System.out.println("> > > > Temp : " + temp);
			int len = temp.length();
			boolean flag = true;

			do {

				if (len > 60) {
					flag = false;
				} else {
					System.out.println("> > > > Temp : " + temp);
					temp = temp + 'a';
					len = temp.length();
				}
			} while (flag);
			System.out.println("> > > Now Len: " + len);
			actions.clear("DimensionNameSet.DimensionNameSet");
			actions.setValue("DimensionNameSet.DimensionNameSet", temp);
			actions.click("DimensionNameSet.SaveButton");
			Thread.sleep(1000);
			Element = actions.getWebElement("DimensionNameSet.DimensionNameSet");
			val = Element.getAttribute("value");
			System.out.println("> > > val:" + val);

			if ((val.length()) == (temp.length())) {

				actions.reportCreateFAIL("Verify that field cannot accept more than 60 characters",
						"Dimension Name set field should not accept more than 60 characters",
						"Dimension Name set field is accepted more than 60 characters", "FAIL");
			} else {
				actions.reportCreatePASS("Verify that field cannot accept more than 60 characters",
						"Dimension Name set field should not accept more than 60 characters",
						"Dimension Name set field is not accepted more than 60 characters", "PASS");
			}
			// Updates the Dimension Name Set Name and clicks on Save button
			actions.clear("DimensionNameSet.DimensionNameSet");
			val = mcd.fn_GetRndName("Auto");
			actions.clear("DimensionNameSet.DimensionNameSet");
			actions.setValue("DimensionNameSet.DimensionNameSet", val);
			actions.click("DimensionNameSet.SaveButton");
			actions.smartWait(20);

			// Verify the on-screen message
			flag = mcd.VerifyOnscreenMessage("DimensionNameSets.InfoMessage", "Your changes have been saved.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Select the Dimension Name Set Name Text Field to blank and clicks
			// on Save button
			actions.clear("DimensionNameSet.DimensionNameSet");
			actions.click("DimensionNameSet.SaveButton");
			flag = mcd.VerifyAlertMessageDisplayed("Warning Message", strErrMsg[4], true, AlertPopupButton.OK_BUTTON);
			if (flag) {
				actions.reportCreatePASS("Verify the alert message",
						"Message '" + strErrMsg[4] + "' should be displayed", "Expected message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the alert message",
						"Message '" + strErrMsg[4] + "' should be displayed", "Expected message is not displayed",
						"FAIL");
			}

			// Delete the Dimension Name Set Name from the Text Field, enters
			// the same name again and clicks on Save button
			Element = actions.getWebElement("DimensionNameSet.DimensionNameSet");
			temp = Element.getAttribute("value");
			actions.clear("DimensionNameSet.DimensionNameSet");
			actions.setValue("DimensionNameSet.DimensionNameSet", val);
			actions.click("DimensionNameSet.SaveButton");
			Thread.sleep(1000);
			flag = mcd.VerifyAlertMessageDisplayed("Warning Message", strErrMsg[5], true, AlertPopupButton.OK_BUTTON);
			if (flag) {
				actions.reportCreatePASS("Verify the alert message",
						"Message '" + strErrMsg[5] + "' should be displayed", "Expected message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the alert message",
						"Message '" + strErrMsg[5] + "' should be displayed", "Expected message is not displayed",
						"FAIL");
			}

			// Updates the same name which is already present in the application
			// and clicks on Save button.
			actions.clear("DimensionNameSet.DimensionNameSet");
			actions.setValue("DimensionNameSet.DimensionNameSet", dup);
			actions.click("DimensionNameSet.SaveButton");
			actions.smartWait(15);
			flag = mcd.VerifyOnscreenMessage("SubstitutionGroups.ErrorMessage", strErrMsg[0], true);
			if (flag) {
				actions.reportCreatePASS("Verify the info message",
						"Message '" + strErrMsg[0] + "' should be displayed", "Expected message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the info message",
						"Message '" + strErrMsg[0] + "' should be displayed", "Expected message is not displayed",
						"FAIL");
			}

			// Clicks on any link in the application
			actions.clear("DimensionNameSet.DimensionNameSet");
			actions.setValue("DimensionNameSet.DimensionNameSet", "bbb");
			actions.click("DimensionNameSet.CancelButton");
			flag = mcd.VerifyAlertMessageDisplayed("Warning Message", strErrMsg[6], true,
					AlertPopupButton.CANCEL_BUTTON);
			if (flag) {
				actions.reportCreatePASS("Verify the alert message",
						"Message '" + strErrMsg[6] + "' should be displayed", "Expected message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the alert message",
						"Message '" + strErrMsg[6] + "' should be displayed", "Expected message is not displayed",
						"FAIL");
			}
			// Updates the Set Name again back to DIMS1 and clicks on Save
			// button.
			actions.clear("DimensionNameSet.DimensionNameSet");
			actions.setValue("DimensionNameSet.DimensionNameSet", Dsetname);
			actions.click("DimensionNameSet.SaveButton");
			actions.smartWait(10);
			
			// Verify the on-screen message
			flag = mcd.VerifyOnscreenMessage("DimensionNameSets.InfoMessage", "Your changes have been saved.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}
			// Updates the Set Name which is not present in the application and
			// clicks on Save button.
			actions.clear("DimensionNameSet.DimensionNameSet");
			String Dim = mcd.fn_GetRndName("DimensionSet");
			actions.clear("DimensionNameSet.DimensionNameSet");
			actions.setValue("DimensionNameSet.DimensionNameSet", Dim);
			actions.click("DimensionNameSet.SaveButton");
			actions.smartWait(20);

			// Verify the on-screen message
			flag = mcd.VerifyOnscreenMessage("DimensionNameSets.InfoMessage", "Your changes have been saved.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Verify the Audit log Details
			boolean AuditlogCorrectValuesDisplayed1 = rfm.VerifyAuditLog_Entry(strOperation, StrActivity, StrLevel);

			if (AuditlogCorrectValuesDisplayed1) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "strExpectActivity[1],Level",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation," + "ActivityValue,Level",
						"Correct values are not displayed", "Fail");
			}

			String AuditDescc = "Dimension Name Set " + Dim + " has been updated.";

			boolean isAuditlogCorrectValuesDisplayed1 = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID,
					strOperation, StrActivity, StrLevel, StrLevedetails, AuditDescc);

			if (isAuditlogCorrectValuesDisplayed1) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are not displayed", "Fail");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}

	}

	// Function for Reporting Pass/Fail
	public void reporting_Pass_Fail(String Desc, String ExpRes, String ActRes_Pass, String ActRes_Fail,
			Boolean status) {
		if (status) {
			actions.reportCreatePASS(Desc, ExpRes, ActRes_Pass, "PASS");
		}

		if (!status) {
			actions.reportCreateFAIL(Desc, ExpRes, ActRes_Fail, "FAIL");
		}
	}
	// To generate the string of specific size

	public static String generateString(char c, Integer n) {
		StringBuilder b = new StringBuilder();
		for (Integer x = 0; x < n; x++)
			b.append(c);
		return b.toString();
	}
}
