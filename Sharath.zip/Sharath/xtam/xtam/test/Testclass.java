package xtam.test;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;

public class Testclass {
		private Keywords actions;
		private WebDriver driver;
		private Map input;
		private UIValidations uiActions;
		private SoftAssert softAssert = new SoftAssert();
		private lib_MCD mcd;
		private lib_RFM2 rfm;

		// Test Data variables
		private Object strURL;
		private Object strUserName;
		private Object strPassword;
		private String strMarket, MIparam, iceProductValue, flavour, menutype, range, errmsg, pro_type;
		private String strNavigateTo;
		private boolean flag = false;
		private boolean flagfuture = false;
		private String strApplicationDate;

		public Testclass(WebDriver nodeDriver, Map inputData, Object or) {
			driver = nodeDriver;
			input = inputData;
			actions = new Keywords(driver, or);
			uiActions = new UIValidations();
			mcd = new lib_MCD(driver, actions, uiActions, inputData);
			rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

			// Read input Test-Data
			strURL = mcd.GetTestData("DT_URL");
			strUserName = mcd.GetTestData("DT_USER_NAME");
			strPassword = mcd.GetTestData("DT_PASSWORD");
			strMarket = mcd.GetTestData("DT_MARKET");
			MIparam = mcd.GetTestData("DT_MenuItemParam");
			strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
			pro_type = mcd.GetTestData("DT_MENUITEMCLASS");
			range = mcd.GetTestData("DT_MIRANGE");
			errmsg = mcd.GetTestData("DT_ERR_MSG");
			menutype = mcd.GetTestData("DT_MIPARAM");
			flavour = mcd.GetTestData("DT_Flavour");
		}

		@Test

		public void MNU_0106_ABSSettings() throws InterruptedException {
			String[] strmenutype = MIparam.split("#");
			try {
				System.out.println(
						"********************************************************************** Start Test-Steps executions");

				actions.setTestcaseDescription("Menu Item Details (ABS Settings) � Form Rules");

				/** Launch and Login RFM */
				Reporter.log("Lanuch application-" + strURL);
				rfm.LaunchAndLogin(strURL, strUserName, strPassword);
				actions.waitForPageToLoad(10000);
				actions.smartWait(1000);

				/** Select Market (Node) */
				Reporter.log("Select market-" + strMarket);
				rfm.SelectMarket(strMarket);
				actions.waitForPageToLoad(120);

				/** Select Menu Option */
				System.out.println("> Navigate to :: " + strNavigateTo);
				actions.select_menu("RFMHome.Navigation", strNavigateTo);
				Thread.sleep(2000);
				actions.waitForPageToLoad(120);

				/** Update title of new Page */
				mcd.SwitchToWindow("#Title");

				/** Get application time */
				WebElement apptime = mcd.getdate();
				strApplicationDate = apptime.getText();
				
			//	-------------------------------------------------------------------------------------
				actions.keyboardEnter("RestaurantProfile.searchbuttn");
				mcd.SwitchToWindow("Add MI")
				
				String[] strrange=range.split("#");
				
				


}

		
