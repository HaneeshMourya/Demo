package xtam.test;

import java.util.Map;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import crossbrowser.library.Keywords;
import crossbrowser.library.Keywords.DialogType;
import crossbrowser.library.PackageValidation;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.XMLValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0101_VerifGS {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private XMLValidations xmlValidation;
	private PackageValidation pkg;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strWM, ExpectWM[], ExpectMenutype[], Protype[], strerrmsg[];
	private boolean flag;
	private String pro_type, range, errmsg, menutype;
	// TODO: Declare test-data variables for other data-parameters

	public MNU_0101_VerifGS(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		pkg = new PackageValidation(driver, actions, uiActions, inputData, mcd, rfm);
		xmlValidation = new XMLValidations();

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strWM = mcd.GetTestData("DT_WarningMessage");
		pro_type = mcd.GetTestData("DT_MENUITEMCLASS");
		range = mcd.GetTestData("DT_MIRANGE");
		errmsg = mcd.GetTestData("DT_ERR_MSG");
		menutype = mcd.GetTestData("DT_MIPARAM");
		// TODO: GetTestData for other data-parameters
		ExpectWM = strWM.split("#");
		ExpectMenutype = menutype.split("#");
		Protype = pro_type.split("#");
		strerrmsg = errmsg.split("#");
	}

	@Test
	public void test_MNU_0101_VerifGS() throws InterruptedException {
		String strPageTitle = ""; // TODO: Exact page-title
		String strPageSubHeading = ""; // TODO: Page Heading

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"Verify mandatory & non-mandatory fields & field level error messages while creating a Menu Item(General settings)");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Verifying 'Begins With' Radio Button
			Boolean BeginsRadioBtn;
			BeginsRadioBtn = actions.isElementPresent("ManageMenuItemSet.BeginsWith");
			reporting_Pass_Fail("Verify whether Begins With Radio Button is present",
					"Begins With Radio Button should be present", "Begins With Radio Button is present",
					"Begins With Radio Button is not present", BeginsRadioBtn);

			// Verifying 'Ends With' Radio Button
			Boolean EndsRadioBtn;
			EndsRadioBtn = actions.isElementPresent("ManageMenuItemSet.EndWith");
			reporting_Pass_Fail("Verify whether Ends With Radio Button is present",
					"Ends With Radio Button should be present", "Ends With Radio Button is present",
					"Ends With Radio Button is not present", EndsRadioBtn);

			// Verifying 'Contains' Radio Button
			Boolean ContainsRadioBtn;
			ContainsRadioBtn = actions.isElementPresent("ManageMenuItemSet.Contains");
			reporting_Pass_Fail("Verify whether Contains Radio Button is present",
					"Contains Radio Button should be present", "Contains Radio Button is present",
					"Contains Radio Button is not present", ContainsRadioBtn);

			// Verifying 'Exact Match' Radio Button
			Boolean ExactRadioBtn;
			ExactRadioBtn = actions.isElementPresent("ManageMenuItemSet.ExactMatch");
			reporting_Pass_Fail("Verify whether Exact Match Radio Button is present",
					"Exact Match Radio Button should be present", "Exact Match Radio Button is present",
					"Exact Match Radio Button is not present", ExactRadioBtn);

			// Verifying 'Search Full List by Menu Item Number or Name' Text Box
			Boolean SearchTextbox;
			SearchTextbox = actions.isElementPresent("MasterMenuItemList.SearchTextField");
			reporting_Pass_Fail("Verify whether Search Full List by Menu Item Number or Name Textbox is present",
					"Search Full List by Menu Item Number or Name Textbox should be present",
					"Search Full List by Menu Item Number or Name Textbox is present",
					"Search Full List by Menu Item Number or Name Textbox is not present", SearchTextbox);

			// Verifying presence of 'Search' Button
			Boolean Searchbutton;
			Searchbutton = actions.isElementPresent("ManageMenuItem.searchButton");
			reporting_Pass_Fail("Verify whether 'Search' Button is present", "'Search' Button should be present",
					"'Search' Button is present", "'Search' Button is not present", Searchbutton);

			// Verifying 'Search Within Family Group' Filter
			Boolean resultStatus;
			Select selObj = new Select(driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.FamilyGroup"))));
			resultStatus = selObj.getFirstSelectedOption().getText().trim().equalsIgnoreCase("All");
			reporting_Pass_Fail("Verify whether Search Within Family Group All is selected by default for Status DDL",
					"Search Within Family Group All should be selected by default",
					"Search Within Family Group All is selected by default",
					"Search Within Family Group All is not selected by default", resultStatus);

			// Select New Menu Item button
			actions.keyboardEnter("MasterMenuItemList.AddNew");
			mcd.waitAndSwitch("Add New Menu Item");

			// Select Cancel
			actions.smartWait(5);
			actions.keyboardEnter("AddNewMI.Cancel");
			mcd.SwitchToWindow("@Title");

			// Select New Menu Item button
			actions.keyboardEnter("MasterMenuItemList.AddNew");
			mcd.waitAndSwitch("Add New Menu Item");

			// Select Next and click on OK button on pop-up message
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("AddNewMI.Next");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[0], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[0] + " 'is Present or not",
						ExpectWM[0] + " should be present", ExpectWM[0] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[0] + " 'is Present or not",
						ExpectWM[0] + " should be present", ExpectWM[0] + " is not present", "Fail");
			}

			// Keep Menu Item Name field blank and Enter value for Menu Item
			// Number
			actions.clear("AddNewMI.txt");
			actions.clear("AddNewMI.MenuItemNumber");
			actions.setValue("AddNewMI.MenuItemNumber", "0101");

			// Select Next and click on OK button on pop-up message
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("AddNewMI.Next");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[1], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[1] + " 'is Present or not",
						ExpectWM[1] + " should be present", ExpectWM[1] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[1] + " 'is Present or not",
						ExpectWM[1] + " should be present", ExpectWM[1] + " is not present", "Fail");
			}

			// Enter a value for Menu Item Name and Keep Menu Item Number blank
			actions.clear("AddNewMI.txt");
			actions.setValue("AddNewMI.txt", "MenuItem");
			actions.clear("AddNewMI.MenuItemNumber");

			// Select Next and click on OK button on pop-up message
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("AddNewMI.Next");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[2], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[2] + " 'is Present or not",
						ExpectWM[2] + " should be present", ExpectWM[2] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[2] + " 'is Present or not",
						ExpectWM[2] + " should be present", ExpectWM[2] + " is not present", "Fail");
			}

			// Enter invalid value for Menu Item Number
			actions.clear("AddNewMI.MenuItemNumber");
			actions.setValue("AddNewMI.MenuItemNumber", "@#");

			// Select Next and click on OK button on pop-up message
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("AddNewMI.Next");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[3], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[3] + " 'is Present or not",
						ExpectWM[3] + " should be present", ExpectWM[3] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[3] + " 'is Present or not",
						ExpectWM[3] + " should be present", ExpectWM[3] + " is not present", "Fail");
			}

			// Enter a duplicate value for Menu Item Number which already exists
			// in application for selected market
			actions.clear("AddNewMI.MenuItemNumber");
			actions.setValue("AddNewMI.MenuItemNumber", "1");

			// Select Next and Verify Error Message
			actions.keyboardEnter("AddNewMI.Next");
			actions.smartWait(10);
			flag = mcd.VerifyOnscreenMessage("AddNewFlavorSet.ErrorMessage",
					"The entered number already exists in RFM2, Please enter another value", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message",
						"Message 'The entered number already exists in RFM2, Please enter another value'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message",
						"Message 'The entered number already exists in RFM2, Please enter another value'",
						"Expected Message is not displayed", "FAIL");
			}

			// Select Cancel and click on Cancel button on pop-up message
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.CANCEL_BUTTON);
			actions.keyboardEnter("AddNewMI.Cancel");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[4], true, AlertPopupButton.CANCEL_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[4] + " 'is Present or not",
						ExpectWM[4] + " should be present", ExpectWM[4] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[4] + " 'is Present or not",
						ExpectWM[4] + " should be present", ExpectWM[4] + " is not present", "Fail");
			}

			// Select Cancel and click OK Button on pop-up message
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("AddNewMI.Cancel");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[4], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[4] + " 'is Present or not",
						ExpectWM[4] + " should be present", ExpectWM[4] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[4] + " 'is Present or not",
						ExpectWM[4] + " should be present", ExpectWM[4] + " is not present", "Fail");
			}

			// Select New Menu Item button
			mcd.SwitchToWindow("@Title");
			actions.smartWait(5);
			actions.keyboardEnter("MasterMenuItemList.AddNew");
			mcd.waitAndSwitch("Add New Menu Item");

			// Create a product menu item
			int Product = RFM_MI_CreateMenuItem_updated(range, Protype[0], errmsg, menutype);

			// Verify Manage Menu Item : Current Menu Item Screen

			// Verifying 'Name' Text Box
			Boolean ProductNameTextbox;
			ProductNameTextbox = actions.isElementPresent("ManageMenuItems.MenuItemName");
			reporting_Pass_Fail(
					"Verify whether �Name� with default value entered while creating (editable) Textbox is present",
					"�Name� with default value entered while creating (editable) Textbox should be present",
					"�Name� with default value entered while creating (editable) Textbox is present",
					"�Name� with default value entered while creating (editable) Textbox is not present",
					ProductNameTextbox);

			// Verifying 'Partial Save'DDL
			Boolean Status;
			Select Obj = new Select(
					driver.findElement(By.xpath(actions.getLocator("MasterMenuItemList.ParitalSaveDDL"))));
			Status = Obj.getFirstSelectedOption().getText().trim().equalsIgnoreCase("No");
			reporting_Pass_Fail("Verify whether Parital Save No is selected by default for Status DDL",
					"Parital Save No should be selected by default", "Parital Save No is selected by default",
					"Parital Save No is not selected by default", Status);

			// Enter all Mandatory Data except �Menu Item Class�
			String instance = mcd.GetGlobalData("Instance");
			if (instance.equalsIgnoreCase("AP") || instance.equalsIgnoreCase("QMAP")
					|| instance.equalsIgnoreCase("EU")) {
				actions.setValue("ManageMenuItemCurrentMenuItemDetails.MenuItemType", "SMI");
			}
			actions.setValue("ManageMenuItem.ProductCategory", ExpectMenutype[0]);
			actions.setValue("ManageMenuItem.FamilyGroup", ExpectMenutype[1]);
			actions.setValue("ManageMenuItem.DayPartCode", "BREAKFAST_MENU");
			/*
			 * Select select = new
			 * Select(driver.findElement(By.xpath(actions.getLocator(
			 * "ManageMenuItem.DayPartCode"))));
			 * select.selectByVisibleText("BREAKFAST_MENU");
			 */
			// Select Save and click OK button on pop-up message
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("ManageMenuItem.ApplySavebtn");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[5], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[5] + " 'is Present or not",
						ExpectWM[5] + " should be present", ExpectWM[5] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[5] + " 'is Present or not",
						ExpectWM[5] + " should be present", ExpectWM[5] + " is not present", "Fail");
			}

			// Select �Menu Item Class�
			actions.setValue("ManageMenuItem.ProductClass", Protype[0]);

			// Enter all Mandatory Data except �Menu Item Category�
			actions.setValue("ManageMenuItem.ProductCategory", "Select");

			// Select Save and click OK button on pop-up message
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("ManageMenuItem.ApplySavebtn");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[6], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[6] + " 'is Present or not",
						ExpectWM[6] + " should be present", ExpectWM[6] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[6] + " 'is Present or not",
						ExpectWM[6] + " should be present", ExpectWM[6] + " is not present", "Fail");
			}

			// Select �Menu Item Category�
			actions.setValue("ManageMenuItem.ProductCategory", ExpectMenutype[0]);

			// Enter all Mandatory Data except �Day Part Code�
			actions.setValue("ManageMenuItem.DayPartCode", "Select");
			// select.selectByVisibleText("Select");

			// Select Save and click OK button on pop-up message
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("ManageMenuItem.ApplySavebtn");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[7], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[7] + " 'is Present or not",
						ExpectWM[7] + " should be present", ExpectWM[7] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[7] + " 'is Present or not",
						ExpectWM[7] + " should be present", ExpectWM[7] + " is not present", "Fail");
			}

			// Select �Day Part Code�
			actions.setValue("ManageMenuItem.DayPartCode", "BREAKFAST_MENU");
			// select.selectByVisibleText("BREAKFAST_MENU");

			// Enter all Mandatory Data except �Long Name� for Default Device
			actions.clear("ManageMenuItem.ProductSName");
			actions.setValue("ManageMenuItem.ProductSName", "SN");
			actions.clear("ManageMenuItem.ProductDTName");
			actions.setValue("ManageMenuItem.ProductDTName", "DN");

			// Select Save and click OK button on pop-up message
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("ManageMenuItem.ApplySavebtn");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[8], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[8] + " 'is Present or not",
						ExpectWM[8] + " should be present", ExpectWM[8] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[8] + " 'is Present or not",
						ExpectWM[8] + " should be present", ExpectWM[8] + " is not present", "Fail");
			}

			// Enter �Long Name� more than 60 characters
			actions.clear("ManageMenuItem.ProductLName");
			actions.clear("ManageMenuItem.ProductSName");
			actions.clear("ManageMenuItem.ProductDTName");
			String strVal2;
			strVal2 = generateString('c', 61);
			System.out.println(strVal2.length());
			actions.setValue("ManageMenuItem.ProductLName", strVal2);
			String charc = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.ProductLName")))
					.getAttribute("value");
			System.out.println(charc.length());
			if (charc.length() >= 60) {
				actions.reportCreatePASS("verify the whether Long Name search box accepected more than 60 Characters",
						"Long Name search box should be accepected more than 60 Characters",
						"Long Name search box should not  be accepected more than 60 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether Long Name box accepected 60 characters",
						"Long Name search box should be accepected more than 60 Characters ",
						"Long Name search box should be accepected more than 60 Characters", "FAIL");
			}

			// Enter valid �Long Name�
			actions.clear("ManageMenuItem.ProductLName");
			actions.setValue("ManageMenuItem.ProductLName", "Long Name");

			// Enter all Mandatory Data except �Short Name� for Default Device
			actions.clear("ManageMenuItem.ProductDTName");
			actions.setValue("ManageMenuItem.ProductDTName", "DTName");

			// Select Save and click OK button on pop-up message
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("ManageMenuItem.ApplySavebtn");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[9], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[9] + " 'is Present or not",
						ExpectWM[9] + " should be present", ExpectWM[9] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[9] + " 'is Present or not",
						ExpectWM[9] + " should be present", ExpectWM[9] + " is not present", "Fail");
			}

			// Enter �Short Name� more than 30 characters
			actions.clear("ManageMenuItem.ProductLName");
			actions.clear("ManageMenuItem.ProductSName");
			actions.clear("ManageMenuItem.ProductDTName");
			String strVal;
			strVal = generateString('c', 31);
			System.out.println(strVal.length());
			actions.setValue("ManageMenuItem.ProductSName", strVal);
			String shortcharc = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.ProductSName")))
					.getAttribute("value");
			System.out.println(shortcharc.length());
			if (shortcharc.length() >= 30) {
				actions.reportCreatePASS("verify the whether Short Name search box accepected more than 30 Characters",
						"Short Name search box should be accepected more than 30 Characters",
						"Short Name search box should not  be accepected more than 30 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether Short Name Search box accepected 30 characters",
						"Short Name search box should be accepected more than 30 Characters ",
						"Short Name search box should be accepected more than 30 Characters", "FAIL");
			}

			// Enter valid �Short Name�
			actions.clear("ManageMenuItem.ProductSName");
			actions.setValue("ManageMenuItem.ProductSName", "ProductSname");

			// Enter all Mandatory Data except �DT Name� for Default Device
			actions.clear("ManageMenuItem.ProductLName");
			actions.setValue("ManageMenuItem.ProductLName", "ProductLongName");

			// Select Save and click OK button on pop-up message
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("ManageMenuItem.ApplySavebtn");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[10], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[10] + " 'is Present or not",
						ExpectWM[10] + " should be present", ExpectWM[10] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[10] + " 'is Present or not",
						ExpectWM[10] + " should be present", ExpectWM[10] + " is not present", "Fail");
			}

			// Enter �DT Name� more than 30 characters
			actions.clear("ManageMenuItem.ProductLName");
			actions.clear("ManageMenuItem.ProductSName");
			actions.clear("ManageMenuItem.ProductDTName");
			String Val;
			Val = generateString('c', 31);
			System.out.println(Val.length());
			actions.setValue("ManageMenuItem.ProductDTName", Val);
			String DTcharc = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.ProductDTName")))
					.getAttribute("value");
			System.out.println(DTcharc.length());
			if (DTcharc.length() >= 30) {
				actions.reportCreatePASS("verify the whether DT Name search box accepected more than 30 Characters",
						"DT Name search box should be accepected more than 30 Characters",
						"DT Name search box should not  be accepected more than 30 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether DT Name Search box accepected 30 characters",
						"DT Name search box should be accepected more than 30 Characters ",
						"DT Name search box should be accepected more than 30 Characters", "FAIL");
			}

			// Enter valid �DT Name'
			actions.clear("ManageMenuItem.ProductDTName");
			actions.setValue("ManageMenuItem.ProductDTName", "ProductDTNameM");

			// Enter more than 50 characters into Summary Monitor Name
			actions.clear("ManageMenuItem.SummaryMointoryName");
			String SMNVal;
			SMNVal = generateString('c', 51);
			System.out.println(SMNVal.length());
			actions.setValue("ManageMenuItem.SummaryMointoryName", SMNVal);
			String SMNcharc = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.SummaryMointoryName")))
					.getAttribute("value");
			System.out.println(SMNcharc.length());
			if (SMNcharc.length() >= 50) {
				actions.reportCreatePASS(
						"verify the whether Summary Mointory  Name search box accepected more than 50 Characters",
						"Summary Mointory Name search box should be accepected more than 50 Characters",
						"Summary Mointory Name search box should not  be accepected more than 50 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether Summary Mointory Name Search box accepected 50 characters",
						"Summary Mointory Name search box should be accepected more than 50 Characters ",
						"Summary Mointory Name search box should be accepected more than 50 Characters", "FAIL");
			}

			// Enter valid �Summary Monitor Name�
			actions.clear("ManageMenuItem.SummaryMointoryName");
			actions.setValue("ManageMenuItem.SummaryMointoryName", "SummaryMointory");

			// Enter more than 5 characters into Short Monitor Name
			actions.clear("ManageMenuItem.ShortMointorName");
			String SHNVal;
			SHNVal = generateString('c', 6);
			System.out.println(SHNVal.length());
			actions.setValue("ManageMenuItem.ShortMointorName", SHNVal);
			String SHcharc = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.ShortMointorName")))
					.getAttribute("value");
			System.out.println(SHcharc.length());
			if (SHcharc.length() >= 5) {
				actions.reportCreatePASS(
						"verify the whether Short Mointor  Name search box accepected more than 5 Characters",
						"Short Mointor Name search box should be accepected more than 5 Characters",
						"Short Mointor Name search box should not  be accepected more than 5 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether Short Mointor Name Search box accepected 5 characters",
						"Short Mointor Name search box should be accepected more than 5 Characters ",
						"Short Mointor Name search box should be accepected more than 5 Characters", "FAIL");
			}

			// Enter valid �Short Monitor Name�
			actions.clear("ManageMenuItem.ShortMointorName");
			actions.setValue("ManageMenuItem.ShortMointorName", "ShortMointor");

			// Enter more than 100 characters into CSO Name
			actions.clear("MasterMenuItemList.CSOname");
			String CSOVal;
			CSOVal = generateString('c', 101);
			System.out.println(CSOVal.length());
			actions.setValue("MasterMenuItemList.CSOname", CSOVal);
			String csocharc = driver.findElement(By.xpath(actions.getLocator("MasterMenuItemList.CSOname")))
					.getAttribute("value");
			System.out.println(csocharc.length());
			if (csocharc.length() >= 100) {
				actions.reportCreatePASS("verify the whether CSO Name search box accepected more than 100 Characters",
						"CSO Name search box should be accepected more than 100 Characters",
						"CSO Name search box should not  be accepected more than 100 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether CSO Name Search box accepected 100 characters",
						"CSO Name search box should be accepected more than 100 Characters ",
						"CSO Name search box should be accepected more than 100 Characters", "FAIL");
			}

			// Enter valid �CSO Name'
			actions.clear("MasterMenuItemList.CSOname");
			actions.setValue("MasterMenuItemList.CSOname", "ProductCSO");

			// Enter more than 100 characters into COD Name
			actions.clear("ManageMenuItem.CODName");
			String CODVal;
			CODVal = generateString('c', 101);
			System.out.println(CODVal.length());
			actions.setValue("MasterMenuItemList.CSOname", CODVal);
			String codcharc = driver.findElement(By.xpath(actions.getLocator("MasterMenuItemList.CSOname")))
					.getAttribute("value");
			System.out.println(codcharc.length());
			if (codcharc.length() >= 100) {
				actions.reportCreatePASS("verify the whether COD Name search box accepected more than 100 Characters",
						"COD Name search box should be accepected more than 100 Characters",
						"COD Name search box should not  be accepected more than 100 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether COD Name Search box accepected 100 characters",
						"COD Name search box should be accepected more than 100 Characters ",
						"COD Name search box should be accepected more than 100 Characters", "FAIL");
			}

			// Enter valid �COD Name�
			actions.clear("ManageMenuItem.CODName");
			actions.setValue("ManageMenuItem.CODName", "ProductCOD");

			// Enter more than 30 characters into Alternative Name
			actions.clear("ManageMenuItem.AlternateName");
			String altVal;
			altVal = generateString('c', 31);
			System.out.println(altVal.length());
			actions.setValue("ManageMenuItem.AlternateName", altVal);
			String altcharc = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.AlternateName")))
					.getAttribute("value");
			System.out.println(altcharc.length());
			if (altcharc.length() >= 30) {
				actions.reportCreatePASS(
						"verify the whether Alternative Name search box accepected more than 30 Characters",
						"Alternative Name search box should be accepected more than 30 Characters",
						"Alternative Name search box should not  be accepected more than 30 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether Alternative Name Search box accepected 30 characters",
						"Alternative Name search box should be accepected more than 30 Characters ",
						"Alternative Name search box should be accepected more than 30 Characters", "FAIL");
			}

			// Enter valid �Alternative Name�
			actions.clear("ManageMenuItem.AlternateName");
			actions.setValue("ManageMenuItem.AlternateName", "ProductAlternate");

			// Select Cancel and click Cancel button on pop-up message
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("ManageMenuItem.Cancelbtn_New");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[4], true, AlertPopupButton.CANCEL_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[4] + " 'is Present or not",
						ExpectWM[4] + " should be present", ExpectWM[4] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[4] + " 'is Present or not",
						ExpectWM[4] + " should be present", ExpectWM[4] + " is not present", "Fail");
			}

			// Select Cancel and click OK Button on pop-up message
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("ManageMenuItem.Cancelbtn_New");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[4], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[4] + " 'is Present or not",
						ExpectWM[4] + " should be present", ExpectWM[4] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[4] + " 'is Present or not",
						ExpectWM[4] + " should be present", ExpectWM[4] + " is not present", "Fail");
			}

			// Click on Add new menu item
			actions.smartWait(5);
			actions.keyboardEnter("MasterMenuItemList.AddNew");
			mcd.waitAndSwitch("Add New Menu Item");

			// Create a product menu item
			int Checkcategory = RFM_MI_CreateMenuItem_updated(range, Protype[1], errmsg, menutype);

			// Enter all the mandatory fields
			instance = mcd.GetGlobalData("Instance");
			if (instance.equalsIgnoreCase("AP") || instance.equalsIgnoreCase("QMAP")
					|| instance.equalsIgnoreCase("EU")) {
				actions.setValue("ManageMenuItemCurrentMenuItemDetails.MenuItemType", "SMI");
			}
			actions.setValue("ManageMenuItem.ProductClass", Protype[1]);
			actions.setValue("ManageMenuItem.ProductCategory", ExpectMenutype[0]);
			actions.setValue("ManageMenuItem.FamilyGroup", ExpectMenutype[1]);
			// select.selectByVisibleText("BREAKFAST_MENU");
			actions.setValue("ManageMenuItems.DayPartCode", ExpectMenutype[2]);
			actions.setValue("ManageMenuItem.ProductLName", "LN");
			actions.setValue("ManageMenuItem.ProductSName", "SN");
			actions.setValue("ManageMenuItem.ProductDTName", "DN");

			// Click on Save button
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("ManageMenuItem.ApplySavebtn");
			mcd.VerifyAlertMessageDisplayed("Warning Message", strerrmsg[4], true, AlertPopupButton.OK_BUTTON);

			if (input.get("_rowId").toString().toUpperCase().contains("US")) {
				actions.smartWait(50);
				// Verify on screen message
				flag = mcd.VerifyOnscreenMessage("ManageMenuItem.ErrorMessage",
						"Menu Item Number for check category should be from 10000000 - 10000999", true);

				if (flag) {
					actions.reportCreatePASS("Verify the on-screen message",
							"Message 'Menu Item Number for check category should be from 10000000 - 10000999'",
							"Expected Message is displayed", "PASS");
				} else {
					actions.reportCreateFAIL("Verify the on-screen message",
							"Message 'Menu Item Number for check category should be from 10000000 - 10000999'",
							"Expected Message is not displayed", "FAIL");
				}

			} else if (input.get("_rowId").toString().toUpperCase().contains("AP")) {
				actions.smartWait(50);
				// verify on screen message
				flag = mcd.VerifyOnscreenMessage("ManageMenuItem.ErrorMessage",
						"Menu Item Number for check category should be from 20000000 - 20000999", true);

				if (flag) {
					actions.reportCreatePASS("Verify the on-screen message",
							"Message 'Menu Item Number for check category should be from 20000000 - 20000999'",
							"Expected Message is displayed", "PASS");
				} else {
					actions.reportCreateFAIL("Verify the on-screen message",
							"Message 'Menu Item Number for check category should be from 20000000 - 20000999'",
							"Expected Message is not displayed", "FAIL");
				}

			}

			// Select Cancel button and click OK button on pop-up message
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("ManageMenuItem.Cancelbtn_New");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[4], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[4] + " 'is Present or not",
						ExpectWM[4] + " should be present", ExpectWM[4] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[4] + " 'is Present or not",
						ExpectWM[4] + " should be present", ExpectWM[4] + " is not present", "Fail");
			}

			// Click on Add new menu item
			actions.smartWait(5);
			actions.keyboardEnter("MasterMenuItemList.AddNew");
			mcd.waitAndSwitch("Add New Menu Item");

			// Create a product menu item
			int Choice = RFM_MI_CreateMenuItem_updated(range, Protype[2], errmsg, menutype);

			// Enter all the mandatory fields
			instance = mcd.GetGlobalData("Instance");
			if (instance.equalsIgnoreCase("AP") || instance.equalsIgnoreCase("QMAP")
					|| instance.equalsIgnoreCase("EU")) {
				actions.setValue("ManageMenuItemCurrentMenuItemDetails.MenuItemType", "SMI");
			}
			actions.setValue("ManageMenuItem.ProductClass", Protype[2]);
			actions.setValue("ManageMenuItem.ProductCategory", ExpectMenutype[0]);
			actions.setValue("ManageMenuItem.FamilyGroup", ExpectMenutype[1]);
			actions.setValue("ManageMenuItems.DayPartCode", ExpectMenutype[2]);
			actions.setValue("ManageMenuItem.ProductLName", "LN");
			actions.setValue("ManageMenuItem.ProductSName", "SN");
			actions.setValue("ManageMenuItem.ProductDTName", "DN");

			// Click on Save button
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("ManageMenuItem.ApplySavebtn");
			mcd.VerifyAlertMessageDisplayed(strerrmsg[4], strerrmsg[4], true, AlertPopupButton.OK_BUTTON);

			// Verify on screen message
			actions.smartWait(50);
			flag = mcd.VerifyOnscreenMessage("ManageMenuItem.ErrorMessage",
					"Menu Item Number for choice category should be from 10000000 - 10000999", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message",
						"Message 'Menu Item Number for choice category should be from 10000000 - 10000999'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message",
						"Message 'Menu Item Number for choice category should be from 10000000 - 10000999'",
						"Expected Message is not displayed", "FAIL");
			}

			// Select Cancel button and click OK button on pop-up message
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("ManageMenuItem.Cancelbtn_New");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[4], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[4] + " 'is Present or not",
						ExpectWM[4] + " should be present", ExpectWM[4] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[4] + " 'is Present or not",
						ExpectWM[4] + " should be present", ExpectWM[4] + " is not present", "Fail");
			}

			// Click on Add new menu item
			actions.smartWait(5);
			actions.keyboardEnter("MasterMenuItemList.AddNew");
			mcd.waitAndSwitch("Add New Menu Item");

			// Create a product menu item
			int Comment = RFM_MI_CreateMenuItem_updated(range, Protype[3], errmsg, menutype);

			// Enter all the mandatory fields
			instance = mcd.GetGlobalData("Instance");
			if (instance.equalsIgnoreCase("AP") || instance.equalsIgnoreCase("QMAP")
					|| instance.equalsIgnoreCase("EU")) {
				actions.setValue("ManageMenuItemCurrentMenuItemDetails.MenuItemType", "SMI");
			}
			actions.setValue("ManageMenuItem.ProductClass", Protype[3]);
			actions.setValue("ManageMenuItem.ProductCategory", ExpectMenutype[0]);
			actions.setValue("ManageMenuItem.FamilyGroup", ExpectMenutype[1]);
			actions.setValue("ManageMenuItems.DayPartCode", ExpectMenutype[2]);
			actions.setValue("ManageMenuItem.ProductLName", "LN");
			actions.setValue("ManageMenuItem.ProductSName", "SN");
			actions.setValue("ManageMenuItem.ProductDTName", "DN");

			// Click on Save button
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("ManageMenuItem.ApplySavebtn");
			if (pro_type.equals("CHOICE") || pro_type.equals("CHOICE_EVM") || pro_type.equals("CHECK CATEGORY")) {
				mcd.VerifyAlertMessageDisplayed(strerrmsg[4], strerrmsg[4], true, AlertPopupButton.OK_BUTTON);
				flag = true;
			}

			if (input.get("_rowId").toString().toUpperCase().contains("US")) {
				actions.smartWait(50);
				// Verify on screen message
				flag = mcd.VerifyOnscreenMessage("ManageMenuItem.ErrorMessage",
						"Menu Item Number for comment category should be from 80000000 - 80009999", true);

				if (flag) {
					actions.reportCreatePASS("Verify the on-screen message",
							"Message 'Menu Item Number for comment category should be from 80000000 - 80009999'",
							"Expected Message is displayed", "PASS");
				} else {
					actions.reportCreateFAIL("Verify the on-screen message",
							"Message 'Menu Item Number for comment category should be from 80000000 - 80009999'",
							"Expected Message is not displayed", "FAIL");
				}

			} else if (input.get("_rowId").toString().toUpperCase().contains("AP")) {
				actions.smartWait(50);
				// verify on screen message
				flag = mcd.VerifyOnscreenMessage("ManageMenuItem.ErrorMessage",
						"Menu Item Number for comment category should be from 8500 - 9000", true);

				if (flag) {
					actions.reportCreatePASS("Verify the on-screen message",
							"Message 'Menu Item Number for comment category should be from 8500 - 9000'",
							"Expected Message is displayed", "PASS");
				} else {
					actions.reportCreateFAIL("Verify the on-screen message",
							"Message 'Menu Item Number for comment category should be from 8500 - 9000'",
							"Expected Message is not displayed", "FAIL");
				}

			}

			// Select Cancel button and click OK button on pop-up message
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("ManageMenuItem.Cancelbtn_New");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[4], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[4] + " 'is Present or not",
						ExpectWM[4] + " should be present", ExpectWM[4] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[4] + " 'is Present or not",
						ExpectWM[4] + " should be present", ExpectWM[4] + " is not present", "Fail");
			}

			// Click on Add new menu item
			actions.smartWait(5);
			actions.keyboardEnter("MasterMenuItemList.AddNew");
			mcd.waitAndSwitch("Add New Menu Item");

			// Create a product menu item
			int Productmenuitem = RFM_MI_CreateMenuItem_updated(range, Protype[0], errmsg, menutype);

			// Enter all the mandatory fields
			instance = mcd.GetGlobalData("Instance");
			if (instance.equalsIgnoreCase("AP") || instance.equalsIgnoreCase("QMAP")
					|| instance.equalsIgnoreCase("EU")) {
				actions.setValue("ManageMenuItemCurrentMenuItemDetails.MenuItemType", "SMI");
			}
			actions.setValue("ManageMenuItem.ProductClass", Protype[0]);
			actions.setValue("ManageMenuItem.ProductCategory", ExpectMenutype[0]);
			actions.setValue("ManageMenuItem.FamilyGroup", ExpectMenutype[1]);
			actions.setValue("ManageMenuItems.DayPartCode", ExpectMenutype[2]);
			actions.setValue("ManageMenuItem.ProductLName", "LN");
			actions.setValue("ManageMenuItem.ProductSName", "SN");
			actions.setValue("ManageMenuItem.ProductDTName", "DN");

			// click on POS/KVS Setting Tab and click Cancel button on pop-up
			// message
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.CANCEL_BUTTON);
			actions.keyboardEnter("ManageMenuItem.POSKVS_tab");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[11], true, AlertPopupButton.CANCEL_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[11] + " 'is Present or not",
						ExpectWM[11] + " should be present", ExpectWM[11] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[11] + " 'is Present or not",
						ExpectWM[11] + " should be present", ExpectWM[11] + " is not present", "Fail");
			}

			// click on cancel button and click OK button on pop-up message
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("ManageMenuItem.Cancelbtn_New");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[4], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[4] + " 'is Present or not",
						ExpectWM[4] + " should be present", ExpectWM[4] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[4] + " 'is Present or not",
						ExpectWM[4] + " should be present", ExpectWM[4] + " is not present", "Fail");
			}

			// Click on Add new menu item
			actions.smartWait(5);
			actions.keyboardEnter("MasterMenuItemList.AddNew");
			mcd.waitAndSwitch("Add New Menu Item");

			// Create a product menu item
			int Productmenu = RFM_MI_CreateMenuItem_updated(range, Protype[0], errmsg, menutype);

			// Enter all the mandatory fields
			instance = mcd.GetGlobalData("Instance");
			if (instance.equalsIgnoreCase("AP") || instance.equalsIgnoreCase("QMAP")
					|| instance.equalsIgnoreCase("EU")) {
				actions.setValue("ManageMenuItemCurrentMenuItemDetails.MenuItemType", "SMI");
			}
			actions.setValue("ManageMenuItem.ProductClass", Protype[0]);
			actions.setValue("ManageMenuItem.ProductCategory", ExpectMenutype[0]);
			actions.setValue("ManageMenuItem.FamilyGroup", ExpectMenutype[1]);
			actions.setValue("ManageMenuItems.DayPartCode", ExpectMenutype[2]);
			actions.setValue("ManageMenuItem.ProductLName", "LN");
			actions.setValue("ManageMenuItem.ProductSName", "SN");
			actions.setValue("ManageMenuItem.ProductDTName", "DN");

			// click on POS/KVS Setting Tab and click Cancel button on pop-up
			// message
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("ManageMenuItem.POSKVS_tab");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[11], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[11] + " 'is Present or not",
						ExpectWM[11] + " should be present", ExpectWM[11] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[11] + " 'is Present or not",
						ExpectWM[11] + " should be present", ExpectWM[11] + " is not present", "Fail");
			}

			// Verify on-Screen message
			actions.smartWait(50);
			flag = mcd.VerifyOnscreenMessage("ManageMenuItem.SaveMessage", "Menu Item created successfully.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Menu Item created successfully.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Menu Item created successfully.'",
						"Expected Message is not displayed", "FAIL");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	// Function for Reporting Pass/Fail
	public void reporting_Pass_Fail(String Desc, String ExpRes, String ActRes_Pass, String ActRes_Fail,
			Boolean status) {
		if (status) {
			actions.reportCreatePASS(Desc, ExpRes, ActRes_Pass, "PASS");
		}

		if (!status) {
			actions.reportCreateFAIL(Desc, ExpRes, ActRes_Fail, "FAIL");
		}
	}

	public int RFM_MI_CreateMenuItem_updated(String MIrange, String pro_type, String strmsg, String strmenutype) {
		boolean blnflag = false;
		String[] strparam = strmenutype.split("#");
		String[] strrange = MIrange.split("#");
		String strerrmsg[] = strmsg.split("#");
		String s = "";
		int mi_num = 0, mi_start = 0, mi_end = 0;
		try {
			boolean flag = false;

			System.out.println(
					"********************************************************************** Start Test-Steps executions");

			switch (pro_type) {
			case "CONTAINER_VALUE_MEAL":
				s = "Auto_CVM_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "PRODUCT":
				s = "Auto_Pro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "VALUE_MEAL":
				s = "Auto_VM_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "CHOICE":
				s = "Auto_Choice_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[0]);
				mi_end = Integer.parseInt(strrange[1]);
				break;
			case "CHOICE_EVM":
				s = mcd.fn_GetRndName("Auto_ChoiceEVM");
				mi_start = Integer.parseInt(strrange[0]);
				mi_end = Integer.parseInt(strrange[1]);
				break;
			case "CHECK CATEGORY":
				s = "Auto_Check_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[2]);
				mi_end = Integer.parseInt(strrange[3]);
				break;
			case "NON_FOOD_PRODUCT":
				s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "RAW_ITEM":
				s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "EVM":
				s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "COMMENT":
				s = "Auto_CMNT_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[6]);
				mi_end = Integer.parseInt(strrange[7]);
				break;
			default:
				break;
			}

			System.out.println("product name:" + s);
			actions.setValue("AddNewMI.MenuItemName", s);

			do {
				mi_num = mcd.fn_GetRndNumInRange(mi_start, mi_end);
				actions.clear("AddNewMI.MenuItemNumber");
				actions.setValue("AddNewMI.MenuItemNumber", mi_num);
				actions.keyboardEnter("AddNewMI.Next");
				Thread.sleep(3000);
				actions.waitForPageToLoad(180);
				boolean blnWindow = false;

				try {
					blnWindow = mcd.SwitchToWindow("@Manage Menu Items");
					if (blnWindow) {
						System.out.println("Menu Name and Number is accepted successfully");
						blnflag = false;
					} else {
						mcd.SwitchToWindow("Add New Menu Item");
						if (actions.isTextPresence(strerrmsg[0], true)) {
							blnflag = true;
							System.out.println("Entered  number " + mi_num + " is already exist.");
							System.out.println(blnflag);
						}
					}

				} catch (Exception err) {
					if (actions.isTextPresence(strerrmsg[0], true)) {
						blnflag = true;
						System.out.println("Entered  number " + mi_num + " is already exist.");
						System.out.println(blnflag);
					}
				}

			} while (blnflag == true);

		} catch (Exception e) {

		}
		return mi_num;
	}
	// To generate the string of specific size

	public static String generateString(char c, Integer n) {
		StringBuilder b = new StringBuilder();
		for (Integer x = 0; x < n; x++)
			b.append(c);
		return b.toString();
	}

}
