package xtam.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_0170_SearchAddRemoveMI {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;
	private String strApplicationDate;
	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo, strNavigatetoAdmin;
	private String strOperation, strActivity, strLevel, strleveldetails, strUserID, strDBName,strExpectLevelDetails[],strExpectlevel[];
	// TODO: Declare test-data variables for other data-parameters

	private String strPriceSet;
	private String strNewPrice;
	private String strMessage;
	private String strAddRemoveMsg;

	private String strNewPrcSet;
	private String strPrcSet_copy;
	private String strResMessage;
	private String strPrcSetType;
	private String strTestPrc;
	private String strError_Eating;
	private String strError_Msg2;
	private String strFuturePrc;
	private String strNodeNum;

	public PRC_0170_SearchAddRemoveMI(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strActivity = mcd.GetTestData("DT_ACTIVITY");
		strLevel = mcd.GetTestData("DT_LEVEL");
		strDBName = mcd.GetTestData("DT_DBNAME");
		strUserID = mcd.GetTestData("DT_USER_NAME");
		strleveldetails = mcd.GetTestData("DT_LevelDetails");
		// TODO: GetTestData for other data-parameters
		strExpectlevel = strLevel.split("#");
		strExpectLevelDetails = strleveldetails.split("#");

		strPriceSet = mcd.GetTestData("PriceSet");
		strNewPrice = mcd.GetTestData("NewPrice");
		strMessage = mcd.GetTestData("Message");
		strAddRemoveMsg = mcd.GetTestData("AddRemoveMsg");

		strNewPrcSet = mcd.GetTestData("PriceSet_Name");
		strPrcSet_copy = mcd.GetTestData("CopyFromPS_Name");
		strResMessage = mcd.GetTestData("Result_Message");
		strPrcSetType = mcd.GetTestData("PriceSetType");
		strTestPrc = mcd.GetTestData("TestPrc");
		strError_Eating = mcd.GetTestData("Error_Eating");
		strError_Msg2 = mcd.GetTestData("Error_Msg2");
		strFuturePrc = mcd.GetTestData("FuturePrc");
		strNodeNum = mcd.GetTestData("NodeNum");
		strNavigatetoAdmin = mcd.GetTestData("DT_Admin_Navigation");

	}

	@Test
	public void PRC_0170_SearchAddRemoveMI() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(
					"Verify Search and Add/Remove Operations on the Menu Items present in the Price Set and Verify the functionality of Activate Selected Menu Items Checkbox.");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Selection menu option **/
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow
			// Create Active price Set
			actions.click("PriceSets.NewPriceSetBtn");
			mcd.waitAndSwitch("New Price Sets");
			strPriceSet = mcd.fn_GetRndName("PriceSet");
			actions.clear("NewPriceSets.TextBox");
			actions.setValue("NewPriceSets.TextBox", strPriceSet);
			actions.click("AddNewDayPartSet.SelectBtn");
			mcd.waitAndSwitch("Select Node");
			actions.WaitForElementPresent("SelectNodeRest.SearchTextField", 180);
			mcd.Selectrestnode_JavaScriptClk("RFMSelectNode.SelectNodeTable", strNodeNum);
			mcd.waitAndSwitch("New Price Sets");
			actions.click("MassSetAssignment.MASelectRestNextbtn");
			mcd.SwitchToWindow("@Price Sets : Common Menu Item Selector");

			/** adding the menu item now */
			actions.WaitForElementPresent("CommonMenuItemSelector.ViewFullListBtn", 180);
			actions.click("CommonMenuItemSelector.ViewFullListBtn");
			actions.smartWait(180);
			actions.setValue("AddRemoveMenu.Availability", "Available");
			actions.smartWait(180);
			actions.setValue("AddRemoveMI.FilterStatus", "Active");
			actions.smartWait(180);

			/** Selecting the record & saving it */
			WebElement elem_checkbox = mcd.GetTableCellElement("AddRemoveComponent.webtable", 6, "Add", "input");
			actions.javaScriptClick(elem_checkbox);
			WebElement elem_checkbox1 = mcd.GetTableCellElement("AddRemoveComponent.webtable", 7, "Add", "input");
			actions.javaScriptClick(elem_checkbox1);
			actions.WaitForElementPresent("RFM.SaveBtn", 180);
			actions.click("RFM.SaveBtn");
			actions.smartWait(180);
			actions.click("RFM.CancelButton");
			actions.smartWait(180);

			// // setting the value for the search type and set the price set
			// name
			actions.setValue("RFMPriceSets.dropdownSearchList", "Base");
			actions.smartWait(10);
			actions.setValue("PriceSet.SearchBox", strPriceSet);

			// clicking on the search button
			actions.keyboardEnter("PriceSet.SearchBtn");
			actions.smartWait(180);

			// Clicking the first record from the list now
			WebElement BSP_1 = mcd.GetTableCellElement("RFM.WebTable", 1, "Name", "a");
			String strRestNode = mcd.GetTableCellValue("RFM.WebTable", 1, "Node", "", "");
			actions.keyboardEnter(BSP_1);
			mcd.SwitchToWindow("#Title");

			// Add the menu items
			actions.smartWait(10);
			actions.click("PriceSet.ADDRemoveBtn");
			mcd.waitAndSwitch("Price Sets : Common Menu Item Selector");
			actions.WaitForElementPresent("CommonMenuItemSelector.ViewFullListBtn", 180);
			actions.click("CommonMenuItemSelector.ViewFullListBtn");
			actions.smartWait(180);
			actions.setValue("AddRemoveMenu.Availability", "Available");
			actions.smartWait(180);
			actions.setValue("AddRemoveMI.FilterStatus", "Active");
			actions.smartWait(180);
			WebElement elem_checkbox2 = mcd.GetTableCellElement("AddRemoveComponent.webtable", 1, "Add", "input");
			actions.javaScriptClick(elem_checkbox2);
			WebElement elem_checkbox3 = mcd.GetTableCellElement("AddRemoveComponent.webtable", 2, "Add", "input");
			actions.javaScriptClick(elem_checkbox3);
			actions.WaitForElementPresent("RFM.SaveBtn", 180);
			actions.click("RFM.SaveBtn");
			mcd.SwitchToWindow("@Title");
			actions.smartWait(50);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			// Create price set
			actions.click("PriceSets.NewPriceSetBtn");
			mcd.waitAndSwitch("New Price Sets");
			String PriceSet = mcd.fn_GetRndName("Price");
			actions.clear("NewPriceSets.TextBox");
			actions.setValue("NewPriceSets.TextBox", PriceSet);
			actions.click("AddNewDayPartSet.SelectBtn");
			mcd.waitAndSwitch("Select Node");
			actions.WaitForElementPresent("SelectNodeRest.SearchTextField", 180);
			mcd.Selectrestnode_JavaScriptClk("RFMSelectNode.SelectNodeTable", strNodeNum);
			mcd.waitAndSwitch("New Price Sets");
			actions.click("MassSetAssignment.MASelectRestNextbtn");
			mcd.SwitchToWindow("@Price Sets : Common Menu Item Selector");

			/** adding the menu item now */
			actions.WaitForElementPresent("CommonMenuItemSelector.ViewFullListBtn", 180);
			actions.click("CommonMenuItemSelector.ViewFullListBtn");
			actions.smartWait(180);
			actions.setValue("AddRemoveMenu.Availability", "Available");
			actions.smartWait(180);
			actions.setValue("AddRemoveMI.FilterStatus", "Active");
			actions.smartWait(180);
			WebElement add = mcd.GetTableCellElement("AddRemoveComponent.webtable", 1, "Add", "input");
			actions.javaScriptClick(add);
			WebElement add1 = mcd.GetTableCellElement("AddRemoveComponent.webtable", 2, "Add", "input");
			actions.javaScriptClick(add1);
			actions.click("RFM.SaveBtn");
			actions.smartWait(180);
			actions.click("RFM.CancelButton");
			actions.smartWait(180);

			// // setting the value for the search type and set the price set
			// name
			actions.setValue("RFMPriceSets.dropdownSearchList", "Base");
			actions.smartWait(10);
			actions.setValue("PriceSet.SearchBox", PriceSet);

			// clicking on the search button
			actions.keyboardEnter("PriceSet.SearchBtn");
			actions.smartWait(180);

			// Clicking the first record from the list now
			WebElement BSP = mcd.GetTableCellElement("RFM.WebTable", 1, "Name", "a");
			strRestNode = mcd.GetTableCellValue("RFM.WebTable", 1, "Node", "", "");
			actions.keyboardEnter(BSP);
			mcd.SwitchToWindow("#Title");

			// Remove the menu items
			actions.smartWait(10);
			actions.click("PriceSet.ADDRemoveBtn");
			mcd.waitAndSwitch("Price Sets : Common Menu Item Selector");
			actions.smartWait(40);
			WebElement Remove = mcd.GetTableCellElement("AddRemoveComponent.webtable", 1, "Remove", "input");
			actions.javaScriptClick(Remove);
			actions.WaitForElementPresent("RFM.SaveBtn", 180);
			actions.click("RFM.SaveBtn");
			mcd.VerifyAlertMessageDisplayed("WArningMessage",
					"One or more restaurant might lose the price information on removing the menu item from this set.Do you want to continue?",
					true, AlertPopupButton.OK_BUTTON);
			mcd.SwitchToWindow("@Title");
			actions.smartWait(50);

			// Verify Audit log details
			boolean AuditlogCorrectValuesDisplayed = rfm.VerifyAuditLog_Entry(strOperation, strActivity,
					strExpectlevel[0]);

			if (AuditlogCorrectValuesDisplayed) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation," + "ActivityValue,Level",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation," + "ActivityValue,Level",
						"Correct values are not displayed", "Fail");
			}

			String AuditDesc = "Current Setting for Price Set " + PriceSet + " has been updated.";

			boolean isAuditlogCorrectValuesDisplayed = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID,
					strOperation, strActivity, strExpectlevel[1], strExpectLevelDetails[0], AuditDesc);

			if (isAuditlogCorrectValuesDisplayed) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are not displayed", "Fail");
			}
//----------------------------------------------------------------------------------
			/*
			 * strPriceSet = RFM_PRC_Create_PromotionalBase_PrcSet(strNewPrcSet,
			 * strPrcSet_copy, strPrcSetType, strResMessage, strTestPrc,
			 * strError_Eating, strError_Msg2, strFuturePrc, strNodeNum,
			 * strNavigateTo);
			 * 
			 * // Navigate once again
			 *//** Select Menu Option */
			/*
			 * System.out.println("> Navigate to :: " + strNavigateTo);
			 * actions.select_menu("RFMHome.Navigation", strNavigateTo);
			 * Thread.sleep(2000); actions.waitForPageToLoad(120);
			 * 
			 *//** Update title of new Page *//*
												 * mcd.SwitchToWindow("#Title");
												 * 
												 * RFM_PRC_SearchAddRemove_MenuItem
												 * (strPriceSet, strNewPrice,
												 * strMessage, strAddRemoveMsg);
												 */
			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			// Reporter.log("Test Failed :: " + e.getCause() + " - " +
			// e.getMessage());
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	public String RFM_PRC_Create_PromotionalBase_PrcSet(String strNewPrcSet, String strPrcSet_copy,
			String strPrcSetType, String strResMessage, String strTestPrc, String strError_Eating, String strError_Msg2,
			String strFuturePrc, String strNodeNum, String strNavigateTo) throws Exception {

		actions.WaitForElementPresent("PriceSet.NewBtn", 180);
		/** Get application time */
		WebElement apptime = mcd.getdate();
		String strApplicationDate = apptime.getText();

		int iTemp = 0;

		actions.click("PriceSet.NewBtn");
		Thread.sleep(2000);

		// Switch to New Price Sets
		mcd.SwitchToWindow("New Price Sets");

		// Generate unique strNewPrcSet for Base/Promotion Price Set

		switch (strPrcSetType) {
		case "Base":
			// Base Price
			strNewPrcSet = mcd.fn_GetRndName("Base");
			break;
		case "Promotion":
			strNewPrcSet = mcd.fn_GetRndName("Prom");
			break;
		default:
			// System.out.println("Please enter correct Price Set Type
			// (Base/Promotion)");
			actions.reportCreateFAIL("Verfiy data", "Enter correct price set name", "Incorrect data", "FAIL");
			break;
		}

		// Enter new price set name :
		actions.setValue("NewPriceSet.Name", strNewPrcSet);
		Thread.sleep(500);

		actions.click("NewPriceSet.SelectNode");
		Thread.sleep(1000);

		// Switch to Select Node Window - Title - Select Node
		mcd.waitAndSwitch("Select Node");

		actions.click("SelectNode.ExactMtchRadiobtn");
		Thread.sleep(500);
		// actions.setValue("SelectNode.SearchBox", strNodeNum);
		driver.findElement(By.xpath(actions.getLocator("SelectNode.SearchBox"))).sendKeys(strNodeNum);
		Thread.sleep(500);

		actions.keyboardEnter("SelectNode.SearchButton");
		Thread.sleep(1000);
		actions.waitForPageToLoad(120);

		Boolean Node_chk = mcd.Selectrestnode("SelectNode.NodeTable", strNodeNum);
		Thread.sleep(2000);

		mcd.SwitchToWindow("New Price Sets");

		switch (strPrcSetType) {
		case "Base":

			// Base Price
			actions.keyboardEnter("NewPriceSet.BaseRadioBtn");
			Thread.sleep(1000);

			break;
		case "Promotion":

			// Promotion Price
			// actions.keyboardEnter("NewPriceSet.PromRadioBtn");
			actions.javaScriptClick("NewPriceSet.PromRadioBtn");
			Thread.sleep(1000);

			driver.findElement(By.xpath(actions.getLocator("NewPriceSet.StartDate"))).click();
			// mcd.select_date("25", "current", "NewPriceSet.StartDate");
			mcd.sel_current_date("NewPriceSet.StartDate", strApplicationDate);

			// driver.findElement(By.xpath("//*[@id='endDateAnchor'][@src='/rfm2OnlineApp/images/cal.jpg'][@name='endDateAnchor']")).click();
			driver.findElement(By.xpath(actions.getLocator("NewPriceSet.EndDate"))).click();
			// mcd.select_date("30", "current", "NewPriceSet.EndDate");
			mcd.Get_future_date(3, "close", strApplicationDate);

			break;
		default:
			System.out.println("Please enter correct Price Set Type (Base/Promotion)");
			break;
		}

		// actions.click("NewPriceSet.CopyYesRadioBtn");
		actions.javaScriptClick("NewPriceSet.CopyYesRadioBtn");

		Thread.sleep(1000);

		// Select Price Set to copy
		actions.keyboardEnter("NewPriceSet.SelectPrcSet");

		Thread.sleep(1000);

		// Switch to price sets
		mcd.waitAndSwitch("Price Sets");

		actions.keyboardEnter("PriceSetList.ViewFullList");
		Thread.sleep(1000);
		actions.smartWait(120);

		try {
			// Select the first price set
			mcd.GetTableCellElement("RFM.WebTable", 1, "Name", "a").click();
			Thread.sleep(1000);

			/// Switch back
			mcd.SwitchToWindow("New Price Sets");
		} catch (Exception err) {
			actions.reportCreateFAIL("No Price Sets present to copy", "No Price Sets present to copy",
					"No Price Sets present to copy", "FAIL");
		}

		// Click Next
		actions.keyboardEnter("NewPriceSet.Next");

		// Switch to updated window -
		// driver.switchTo().window("");

		mcd.waitAndSwitch("@Price Sets");

		// Based on instance >> Switch to Manage Price set window. Applicable to
		// US

		// if(mcd.GetGlobalData("Instance").trim().toLowerCase().contains("us")){
		try {
			if (mcd.GetGlobalData("Instance").trim().toLowerCase().contains("us")) {
				mcd.waitAndSwitch("Manage Price Set");
				actions.keyboardEnter("RFM.Okbtn");

				mcd.waitAndSwitch("Price Sets");
			}
		}
		// }else{
		catch (Exception err) {
			// try{
			// mcd.SwitchToWindow("Manage Price Set");
			// }catch(Exception err){
			System.out.println("No window - Manage Price Set");

		}
		// }

		actions.WaitForElementPresent("ManagePS.QuickToolApply", 180);

		// Verify result message
		actions.verifyTextPresence(strResMessage, true);

		// Verify Screen header
		String CreatedPS_msg = null;
		CreatedPS_msg = "Manage Price Set : " + strNewPrcSet;
		actions.verifyTextPresence(CreatedPS_msg, true);

		// Validations - Common to Base / Promotional

		// For all price field
		driver.findElement(By.xpath(actions.getLocator("ManagePS.AllPrice"))).clear();
		actions.clear("ManagePS.AllPrice");
		Thread.sleep(500);
		actions.setValue("ManagePS.AllPrice", strTestPrc);
		Thread.sleep(500);
		actions.click("ManagePS.QuickToolApply");
		Thread.sleep(2000);

		Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strError_Msg2, true,
				AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg) {
			actions.reportCreatePASS("Verify price fields",
					"All Prices fields should accept values upto 2 decimal places only.",
					"All Prices fields accepts values upto 2 decimal places only.", "PASS");
		} else {
			actions.reportCreatePASS("Verify price fields",
					"All Prices fields should accept values upto 2 decimal places only.",
					"All Prices fields accepts values more than 2 decimal places.", "FAIL");
		}

		// For Eating/TO/Other price field
		actions.click("ManagePS.RestRadio");
		Thread.sleep(1000);

		actions.clear("ManagePS.EatPrice");
		actions.setValue("ManagePS.EatPrice", strTestPrc);

		actions.clear("ManagePS.TkOutPrice");
		actions.setValue("ManagePS.TkOutPrice", strTestPrc);

		actions.clear("ManagePS.OtherPrice");
		actions.setValue("ManagePS.OtherPrice", strTestPrc);
		actions.click("ManagePS.QuickToolApply");
		Thread.sleep(3000);

		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strError_Msg2, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg) {
			actions.reportCreatePASS("Verify price fields",
					"All Eating/TO/Other fields should accept values upto 2 decimal places only.",
					"All Eating/TO/Other fields accepts values upto 2 decimal places only.", "PASS");
		} else {
			actions.reportCreatePASS("Verify price fields",
					"All Eating/TO/Other fields should accept values upto 2 decimal places only.",
					"All Eating/TO/Other fields accepts values more than 2 decimal places.", "FAIL");
		}

		// Handled the situation where in based on the price value >> the price
		// fields can be displayed as expanded or collapsed.
		// So the validations are done accordingly
		try {
			WebElement eleItemExpand = driver.findElement(By.xpath(actions.getLocator("PriceSet.FrstMIExpandIcon")));
			eleItemExpand.click();
			System.out.println("Whether expand/collapse = " + eleItemExpand.getAttribute("style").trim());
			// if style = "" , Price fields are expanded
			if (!(eleItemExpand.getAttribute("style").trim().equalsIgnoreCase(""))) {
				actions.smartWait(180);

				actions.clear("ManagePS.ItemEatPrice");
				actions.setValue("ManagePS.ItemEatPrice", strTestPrc);

				actions.clear("ManagePS.ItemTOPrice");
				actions.setValue("ManagePS.ItemTOPrice", strTestPrc);

				actions.clear("ManagePS.ItemOtherPrice");
				actions.setValue("ManagePS.ItemOtherPrice", strTestPrc);

				actions.click("ManagePS.ALLApply");
				Thread.sleep(2000);

				VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strError_Msg2, true,
						AlertPopupButton.OK_BUTTON);
				if (VerifyPopUpMsg) {
					actions.reportCreatePASS("Verify price fields",
							"All Eating/TO/Other fields should accept values upto 2 decimal places only.",
							"All Eating/TO/Other fields accepts values upto 2 decimal places only.", "PASS");
				} else {
					actions.reportCreatePASS("Verify price fields",
							"All Eating/TO/Other fields should accept values upto 2 decimal places only.",
							"All Eating/TO/Other fields accepts values more than 2 decimal places.", "FAIL");
				}

			} else {
				// if style = "display:none" , Price fields are collapsed
				actions.smartWait(180);
				actions.clear("ManagePS.ItemAllPriceTextBox");
				actions.clear("ManagePS.ItemAllPriceTextBox");
				actions.setValue("ManagePS.ItemAllPriceTextBox", strTestPrc);

				actions.click("ManagePS.ALLApply");
				Thread.sleep(2000);

				VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strError_Msg2, true,
						AlertPopupButton.OK_BUTTON);
				if (VerifyPopUpMsg) {
					actions.reportCreatePASS("Verify price fields",
							"All Prices fields should accept values upto 2 decimal places only.",
							"All Prices fields accepts values upto 2 decimal places only.", "PASS");
				} else {
					actions.reportCreatePASS("Verify price fields",
							"All Prices fields should accept values upto 2 decimal places only.",
							"All Prices fields accepts values more than 2 decimal places.", "FAIL");
				}
			}
		} catch (Exception err) {
			// if style = "display:none" , Price fields are collapsed
			actions.smartWait(180);

			actions.clear("ManagePS.ItemEatPrice");
			actions.setValue("ManagePS.ItemEatPrice", strTestPrc);

			actions.clear("ManagePS.ItemTOPrice");
			actions.setValue("ManagePS.ItemTOPrice", strTestPrc);

			actions.clear("ManagePS.ItemOtherPrice");
			actions.setValue("ManagePS.ItemOtherPrice", strTestPrc);

			actions.click("ManagePS.ALLApply");
			Thread.sleep(2000);

			VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strError_Msg2, true, AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Verify price fields",
						"All Eating/TO/Other fields should accept values upto 2 decimal places only.",
						"All Eating/TO/Other fields accepts values upto 2 decimal places only.", "PASS");
			} else {
				actions.reportCreatePASS("Verify price fields",
						"All Eating/TO/Other fields should accept values upto 2 decimal places only.",
						"All Eating/TO/Other fields accepts values more than 2 decimal places.", "FAIL");
			}

		}
		actions.smartWait(10);

		// Click on cancel to close the page
		actions.click("NewPriceSet.Cancel");
		Thread.sleep(3000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error",
				"Unsaved data will be lost. Are you sure you want to proceed?", true, AlertPopupButton.CANCEL_BUTTON);
		if (VerifyPopUpMsg) {
			// Reporter.log("Unsaved record message PASS");
			actions.reportCreatePASS("Verify Unsaved warning", "Unsaved warning should be displayed",
					"Unsaved warning is displayed", "PASS");
		} else {
			// Reporter.log("Unsaved record message FAILED");
			actions.reportCreateFAIL("Verify Unsaved warning", "Unsaved warning should be displayed",
					"Unsaved warning is not displayed", "FAIL");
		}

		// enter correct price and save
		actions.smartWait(180);
		actions.WaitForElementPresent("ManagePS.EatPrice", 180);
		actions.clear("ManagePS.EatPrice");
		actions.setValue("ManagePS.EatPrice", Integer.toString(Integer.parseInt(strFuturePrc)));

		actions.clear("ManagePS.TkOutPrice");
		actions.setValue("ManagePS.TkOutPrice", Integer.toString(Integer.parseInt(strFuturePrc)));

		actions.clear("ManagePS.OtherPrice");
		actions.setValue("ManagePS.OtherPrice", Integer.toString(Integer.parseInt(strFuturePrc)));
		actions.click("ManagePS.QuickToolApply");
		Thread.sleep(3000);
		actions.smartWait(120);
		actions.click("ManagePS.ALLApply");
		Thread.sleep(3000);
		actions.smartWait(120);

		// Click on cancel to close the page
		actions.click("NewPriceSet.Cancel");
		Thread.sleep(2000);

		// Creating Future Settings for newly created price set
		mcd.SwitchToWindow("#Title");
		actions.smartWait(180);

		// Enter Price Set name to search
		actions.setValue("PriceSet.SearchBox", strNewPrcSet);
		Thread.sleep(500);
		actions.keyboardEnter("PriceSet.SearchBtn");
		Thread.sleep(1000);
		actions.smartWait(120);

		// Click on fetched PS
		mcd.GetTableCellElement("RFM.WebTable", 1, "Name", "a").click();

		Thread.sleep(1000);
		mcd.SwitchToWindow("#Title");

		if (strPrcSetType.equals("Base")) {
			mcd.SelectDate_OpenCalender("10", "next");
			Thread.sleep(1000);
			actions.smartWait(120);
		} else {
			int d = 10;

			mcd.SelectDate_OpenCalender(Integer.toString(d), "next");
			Thread.sleep(1000);
			actions.smartWait(120);
			mcd.SelectDate_OpenCalender(Integer.toString(d + 2), "current");
			Thread.sleep(1000);
			actions.smartWait(120);
		}

		// Enter future price setting
		actions.clear("ManagePS.AllPrice");
		Thread.sleep(500);
		actions.setValue("ManagePS.AllPrice", strFuturePrc);
		Thread.sleep(500);
		actions.click("ManagePS.QuickToolApply");
		Thread.sleep(2000);
		try {
			driver.switchTo().alert().accept();
		} catch (Exception exptnPopUp) {

		}
		actions.click("FutureSettings.Apply");
		try {
			driver.switchTo().alert().accept();
		} catch (Exception exptnPopUp) {

		}
		actions.smartWait(120);
		Thread.sleep(10000);

		try {
			if (mcd.GetGlobalData("Instance").trim().toLowerCase().contains("us")) {
				driver.switchTo().alert().accept();
			}
		} catch (Exception e1) {

		}
		actions.smartWait(120);
		try {
			// Verify Success message
			// actions.verifyTextPresence("Your changes have been saved.",
			// false);
			String text = "Your changes have been saved.";
			WebDriver webDriver = null;
			String pageText = webDriver.getPageSource();
			if (pageText.contains(text.toString())) {
				// pass("Verify Text Presence '" + text + "'", text.toString(),
				// "Page contains '" + text.toString() + "'");
				actions.reportCreatePASS("Verify if Text Message is displayed ",
						"The 'Your changes have been saved.' message should get displayed",
						"The 'Your changes have been saved.' message is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify if Text Message is displayed ",
						"The 'Your changes have been saved.' message should get displayed",
						"The 'Your changes have been saved.' message is not displayed", "Fail");
			}
			actions.reportCreatePASS("Verify Future Settings",
					"Future settings for new price set should be done successfully",
					"Future settings for new price set done successfully", "PASS");
		} catch (Exception e12) {

		}
		return strNewPrcSet;
	}

	public void RFM_PRC_SearchAddRemove_MenuItem(String strPriceSet, String strNewPrice, String strMessage,
			String strAddRemoveMsg) throws Exception {

		// Variable Declaration
		int iTemp = 0;
		String Searchd_PrcSet = null;
		String Search_Str = "";
		String ItemName;
		String[] MI_Arr;
		String[] Add_Arr = null;
		String Item_Name;
		Boolean VerifyPopUpMsg;
		Boolean StrCheck = false;
		String OutputMsg;

		// Enter Price Set name to search

		actions.setValue("PriceSet.SearchBox", strPriceSet);
		actions.keyboardEnter("PriceSet.SearchBtn");
		Thread.sleep(1000);
		actions.smartWait(180);
		// Get row count of number of price sets fetched

		int rw_cnt = mcd.GetTableRowCount("PriceSet.Table");

		List<WebElement> PrcSet_List = driver.findElements(By.xpath("//*[@id='currentLink']"));

		// Click on desired Price set
		for (int i = 0; i <= rw_cnt; i++) {
			try {

				String temp_str = PrcSet_List.get(i).getText();
				if (temp_str.equals(strPriceSet)) {
					PrcSet_List.get(i).sendKeys(Keys.ENTER);
					// PrcSet_List.get(i).click();
					iTemp = 0;
					break;
				} else {
					iTemp = iTemp + 1;
				}
			} catch (Exception e) {
				// System.out.println("This price set is not attached to any
				// restaurant");
			}
		}

		Thread.sleep(1000);
		actions.waitForPageToLoad(120);
		if (iTemp == 0) {
			actions.reportCreatePASS("Verify Price Set selection", "Price Set should be selected",
					strPriceSet + " fetched and clicked", "PASS");
			// Reporter.log(strPriceSet+" fetched and clicked - PASS");
		} else {
			actions.reportCreateFAIL("Verify Price Set selection", "Price Set should be selected",
					strPriceSet + " not found", "FAIL");
			// Reporter.log(strPriceSet+" not found - FAIL");
		}

		Thread.sleep(1000);
		actions.waitForPageToLoad(120);

		// Verify Page navigated to Manager Price Set window
		/** Verify Page Header */
		// System.out.println("> Verify Page Heading");

		// String New_Heading = "Manage Price Set : " + strPriceSet + "\n" + "[
		// Base Price ]";
		// mcd.VerifyPageHeading(New_Heading, "SubHeading");
		// mcd.VerifyPageTitle(New_Heading);

		// Get count of number of Menu Items in selected price set
		int MIrw_cnt = mcd.GetTableRowCount("ManagePS.MITable");

		Thread.sleep(1000);

		// Get all the names of menu items present
		List<WebElement> MI_lists = driver
				.findElements(By.xpath("//table[@class = \"SmallHeading\"]/tbody/tr[1]/td[@class = \"padLeft5\"][1]"));

		// Get few menu items words to search. Create the search string
		if (MI_lists.size() == 1) {
			ItemName = MI_lists.get(0).getText();
			MI_Arr = ItemName.split("-");
			Item_Name = MI_Arr[1].trim();
			Search_Str = Item_Name.split(" ")[0];

		} else if (MI_lists.size() > 1) {
			for (int k = 0; k < MI_lists.size(); k++) {
				ItemName = MI_lists.get(k).getText();
				MI_Arr = ItemName.split("-");
				Item_Name = MI_Arr[1].trim();
				if (k == 5) {
					System.out.println("Search String created using 3 menu items");
					break;
				}
				Search_Str = Search_Str + Item_Name.split(" ")[0] + "+";
				System.out.println(Search_Str);
			}

		}

		Search_Str = Search_Str.substring(0, (Search_Str.length() - 1));

		actions.setValue("ManagePS.SearchBox", Search_Str);
		Thread.sleep(500);
		actions.keyboardEnter("ManagePS.SearchBtn");
		Thread.sleep(1000);
		actions.smartWait(180);
		// Verify Search Happened successfully
		// Get all the names of menu items present

		List<WebElement> Srch_lists = driver
				.findElements(By.xpath("//table[@class = 'SmallHeading']/tbody/tr[1]/td[@class = 'padLeft5'][1]"));

		String[] NewArr = Search_Str.split("\\W");
		for (int m = 0; m < Srch_lists.size(); m++) {
			ItemName = Srch_lists.get(m).getText();
			for (int n = 0; n < NewArr.length; n++) {
				System.out.println(NewArr[n]);
				System.out.println(ItemName);
				if ((ItemName.toLowerCase()).contains(NewArr[n].toLowerCase())) {
					StrCheck = true;
					break;
				} else {
					StrCheck = false;
				}
			}
		}

		if (StrCheck) {
			System.out.println("Search - PASS");
		} else {
			System.out.println("Search - FAIL");
		}

		// Get all elements of delete icon.
		List<WebElement> icons = driver.findElements(By.xpath("//a[contains(@onclick,'deleteMenuItem')]"));

		// Click on delete icon against menu item 1
		icons.get(0).click();

		// Get all the names of menu items present
		List<WebElement> M_lists = driver
				.findElements(By.xpath("//table[@class = \"SmallHeading\"]/tbody/tr[1]/td[@class = \"padLeft5\"][1]"));

		// Get the name of menu item that is removed above
		String Modified_ItemName = M_lists.get(0).getText();
		String[] strArr = Modified_ItemName.split("-");
		String Item_Number = strArr[0].trim();
		String Name = strArr[1].trim();
		Modified_ItemName = Item_Number + "-" + Name;

		// Apply Changes
		actions.click("ManagePS.ApplyBtn");
		Thread.sleep(4000);
		// actions.smartWait(120);

		// Verify warning message
		String New_Msg = "The below listed menu item(s) will be removed from the price set." + "\n" + "\n"
				+ Modified_ItemName;
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", New_Msg, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg) {
			actions.reportCreatePASS("Verify warning message for deletion", "Correct warning should be displayed",
					"Correct warning displayed", "PASS");
			// Reporter.log("Warning message for Delete Item occured - PASS");
		} else {
			actions.reportCreateFAIL("Verify warning message for deletion", "Correct warning should be displayed",
					"Correct warning not displayed", "FAIL");
			// Reporter.log("No warning message before deletion of item occured
			// - FAIL");
		}

		Thread.sleep(1000);
		actions.smartWait(120);

		// Verify Success message
		OutputMsg = driver.findElement(By.xpath(actions.getLocator("ManagePS.ResultMsg"))).getText();
		if (OutputMsg.equals(strMessage)) {
			actions.reportCreatePASS("Verify Menu Item deletion", "Menu Item should be deleted successfully",
					"Menu Item deleted successfully", "PASS");
			// Reporter.log("Delete menu item done successfully - PASS");
		} else {
			actions.reportCreateFAIL("Verify Menu Item deletion", "Menu Item should be deleted successfully",
					"Menu Item not deleted successfully", "FAIL");
			// Reporter.log("Delete menu item not done successfully - FAIL");
		}

		Thread.sleep(2000);

		// Add/Remove Menu Item
		actions.click("ManagePS.AddRemoveMIBtn");
		Thread.sleep(1000);

		// Switch Window to //"Price Sets : Common Menu Item Selector"
		mcd.SwitchToWindow("Price Sets : Common Menu Item Selector");
		// String CurrHandle = driver.getWindowHandle();
		// actions.windowSwitch(CurrHandle, "Price Sets : Common Menu Item
		// Selector");
		// Thread.sleep(5000);
		// String NewHandle = driver.getWindowHandle();

		// ADD

		// Click on View Full List

		actions.keyboardEnter("CommonSelector.ViewFullBtn");
		Thread.sleep(1000);
		actions.smartWait(180);
		// Select Available from Availability drop down
		actions.setValue("CommonSelector.AvailabilityDrpDwn", "Available");
		Thread.sleep(1000);
		actions.smartWait(180);

		// Get Row Count
		// int Item_Counts = mcd.GetTableRowCount("CommonSelector.Table");

		List<WebElement> Add_Chkbox = driver
				.findElements(By.xpath(".//input[@type = 'checkbox'][contains(@onclick, 'addMenuItem')]"));
		int Item_Counts = Add_Chkbox.size();
		List<String> MnuItem_Names = new ArrayList<String>();

		// Check items and add accordingly

		int i_temp = 0;
		for (int n = 0; n <= Item_Counts; n++) {
			// Check whether enabled for Add or not
			if ((Add_Chkbox.get(n).isEnabled())) {
				// Check box enabled - Add Item
				Add_Chkbox.get(n).sendKeys(Keys.SPACE);

				// Get Item Name
				String p = Integer.toString(n + 1);
				String e = driver.findElement(By.xpath("//*[@id='commonTableBody']/tr[" + p + "]/td[4]")).getText();
				MnuItem_Names.add(e);

				i_temp++;
			} else {
				System.out.println("This MI is already added");
			}

			if (i_temp == 3) {
				System.out.println("Selected 3 items for Add MI");
				break;
			}
			Thread.sleep(1000);
		}

		actions.keyboardEnter("CommonSelector.Save");
		actions.smartWait(180);
		Thread.sleep(1000);

		// Switch back to Main Window- Title "Price Sets"
		mcd.SwitchToWindow("@Price Sets");

		// actions.windowSwitch(NewHandle, "Price Sets");
		// Thread.sleep(5000);

		// Menu Items have been Added/Removed successfully from the Price Set.

		OutputMsg = driver.findElement(By.xpath(actions.getLocator("ManagePS.AddRemoveMsg"))).getText();
		if (OutputMsg.equals(strAddRemoveMsg)) {
			actions.reportCreatePASS("Verify addition of MI to Price set", "Menu Item should be added",
					"Menu Item added", "PASS");
			// Reporter.log("Add Menu Item to price set - PASS");
		} else {
			actions.reportCreateFAIL("Verify addition of MI to Price set", "Menu Item should be added",
					"Menu Item not added", "FAIL");
			// Reporter.log("Add Menu Item to price set - FAIL");
		}

		// Check only added menu items are displayed
		// Get the list of items displayed
		List<WebElement> Added_Items = driver.findElements(By.xpath(actions.getLocator("ManagePS.ListofAddedMI")));
		// System.out.println(Added_Items.size());
		int AddItem_check = 0;

		for (int k = 0; k < Added_Items.size(); k++) {
			String Added_ItemName = Added_Items.get(k).getText().split("-")[1].trim();

			// Verify that the added items are same as displayed items
			if (Added_ItemName.equals(MnuItem_Names.get(k))) {
				AddItem_check++;
			} else {
				System.out.println("Check " + Added_ItemName);
				System.out.println("Check " + MnuItem_Names.get(k));
			}
		}

		if (AddItem_check == 3) {
			// Reporter.log("Only newly added menu items are displayed as
			// expected - PASS");
			actions.reportCreatePASS("Verify menu items displayed", "Only newly added items should be displayed",
					"Only newly added items are displayed", "PASS");
		} else {
			actions.reportCreateFAIL("Verify menu items displayed", "Only newly added items should be displayed",
					"Items are incorrectly displayed", "FAIL");
			// Reporter.log("More menu items than newly added menu items are
			// displayed - FAIL");
		}

		actions.waitForPageToLoad(180);
		// REMOVE

		// Add/Remove Menu Item
		actions.click("ManagePS.AddRemoveMIBtn");
		Thread.sleep(1000);

		// Switch Window to //"Price Sets : Common Menu Item Selector"
		// CurrHandle = driver.getWindowHandle();
		// actions.windowSwitch(CurrHandle, "Price Sets : Common Menu Item
		// Selector");
		// Thread.sleep(5000);
		// NewHandle = driver.getWindowHandle();

		mcd.SwitchToWindow("Price Sets : Common Menu Item Selector");

		// Select Assigned from Availability drop down
		actions.setValue("CommonSelector.AvailabilityDrpDwn", "Assigned");
		Thread.sleep(1000);
		actions.smartWait(180);

		// Get elements of Remove chkbox
		List<WebElement> Remove_Chkbox = driver
				.findElements(By.xpath(".//input[@type = 'checkbox'][contains(@onclick, 'removeMenuItem')]"));
		Thread.sleep(500);

		// Remove Check Box :
		Remove_Chkbox.get(0).sendKeys(Keys.SPACE);
		Thread.sleep(500);

		actions.keyboardEnter("CommonSelector.Save");
		Thread.sleep(3000);

		// One or more restaurant might lose the price information on removing
		// the menu item from this set. Do you want to continue?
		New_Msg = "One or more restaurant might lose the price information on removing the menu item from this set. Do you want to continue?";
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", New_Msg, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg) {
			actions.reportCreatePASS("Verify REMOVE warning message", "Correct warning should be displayed",
					"Correct message displayed", "PASS");

			// Reporter.log("Warning message for REMOVE Item occured - PASS");
		} else {
			actions.reportCreateFAIL("Verify REMOVE warning message", "Correct warning should be displayed",
					"Correct message not displayed", "FAIL");
			// Reporter.log("No warning message before REMOVE occured - FAIL");
		}
		actions.smartWait(180);
		Thread.sleep(2000);

		// Switch back to Main Window- Title "Price Sets"
		mcd.SwitchToWindow("Price Sets");
		// actions.windowSwitch(NewHandle, "Price Sets");
		// Thread.sleep(5000);

		// Menu Items have been Added/Removed successfully from the Price Set.

		OutputMsg = driver.findElement(By.xpath(actions.getLocator("ManagePS.AddRemoveMsg"))).getText();
		if (OutputMsg.equals(strAddRemoveMsg)) {
			// Reporter.log("Remove Menu Item from price set - PASS");
			actions.reportCreatePASS("Verify menu item removal", "Menu item should be removed", "Menu Item removed",
					"PASS");
		} else {
			// Reporter.log("Remove Menu Item from price set - FAIL");
			actions.reportCreateFAIL("Verify menu item removal", "Menu item should be removed", "Menu Item not removed",
					"FAIL");
		}

	}
}
