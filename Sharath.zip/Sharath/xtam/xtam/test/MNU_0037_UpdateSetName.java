
package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;

public class MNU_0037_UpdateSetName {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;

	// Declare test-data variables for other data-parameters
	private String strmsg, strfilterbynode, strNavigateToMUP;
	private String strNavigateToRP;

	public MNU_0037_UpdateSetName(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strfilterbynode = mcd.GetTestData("DT_FILTER");

		// GetTestData for other data-parameters
		strmsg = mcd.GetTestData("DT_MSG");
		strNavigateToMUP = mcd.GetTestData("DT_NAVIGATE_TO_MUP");
		strNavigateToRP = mcd.GetTestData("DT_NAVIGATE_TO_RP");
	}

	@Test
	public void test_MNU_0037_UpdateSetName() throws InterruptedException {
		String msg[] = strmsg.split("#");

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			/** Get application time */
			actions.setTestcaseDescription(
					"Verify updated menu item set name is reflected in Restaurant profile, pricing tab and POS.");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Navigating to Menu Item Set */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(3000);
			actions.waitForPageToLoad(120);

			/** Updating Menu Item Set Name */
			// Filter the records by country(region) node
			actions.setValue("MenuItemSets.Filters", strfilterbynode);
			Actions builder = new Actions(driver);
			builder.moveByOffset(500, 0).click().perform();
			actions.click("MenuItemSets.FilterBtn");
			mcd.smartsync(60);

			// Read and Select the first record from the table
			WebElement setname = mcd.GetTableCellElement("PackageSchedule.Table", 1, 1, "a");
			actions.click(setname);
			mcd.smartsync(60);

			// Updating the name of Menu Item Set by clearing and entering new
			String strNewSetName = mcd.fn_GetRndName("Auto");
			actions.clear("MenuItemSets.NameField");
			actions.setValue("MenuItemSets.NameField", strNewSetName);
			actions.click("MenuItemSets.UpdateSave");
			mcd.smartsync(60);
			boolean bln = actions.isTextPresence(msg[0], true);
			if (bln) {
				actions.reportCreatePASS("Verify updating Menu Item Set Nam ", "Menu Item Set Name should be updated",
						"Menu Item Set Name is updated", "Pass");
			} else {
				actions.reportCreatePASS("Verify updating Menu Item Set Nam ", "Menu Item Set Name should be updated",
						"Menu Item Set Name is not updated", "Fail");
			}

			actions.click("MenuItemSets.ReturnToSet");
			actions.smartWait(60);

			// Search the updated Menu Item Set Name and Validate if reflected
			// in Menu Item Sets Table
			actions.setValue("RFMPage.SearchSetName", strNewSetName);
			actions.keyboardEnter("RestaurantSet.Searchbtn");
			actions.smartWait(120);
			WebElement UpdatedSN = mcd.GetTableCellElement("PackageSchedule.Table", 1, 1, "a");
			String UpdatedSetName = UpdatedSN.getText();
			if (strNewSetName.equals(UpdatedSetName)) {
				actions.reportCreatePASS("Verify updated Menu Item Set Name reflected",
						"Updated Menu Item Set Name should be reflected", "Updated Menu Item Set Name is reflected",
						"Pass");
			} else {
				actions.reportCreateFAIL("Verify updated Menu Item Set Name reflected",
						"Updated Menu Item Set Name should be reflected", "Updated Menu Item Set Name is not reflected",
						"Fail");
			}

			/** Verify the updated set name in Mass Update Prices */
			// Navigate to Mass Update Price
			System.out.println("> Navigate to :: " + strNavigateToMUP);
			actions.select_menu("RFMHome.Navigation", strNavigateToMUP);
			actions.smartWait(120);
			actions.waitForPageToLoad(120);

			Boolean blnresult = mcd.fn_WebList_Verify_ListOptions_Exact("MassUpdatePrices.SetFilter", strNewSetName);
			if (blnresult) {
				actions.reportCreatePASS("Updated Menu item Set name-" + strNewSetName,
						"Updated Menu item Set name-" + strNewSetName + " should be reflected in Mass Update Prices",
						"Updated Menu item Set name-" + strNewSetName + " is reflected in Mass Update Prices", "Pass");
			} else {
				actions.reportCreateFAIL("Updated Menu item Set name-" + strNewSetName,
						"Updated Menu item Set name-" + strNewSetName + " should be reflected in Mass Update Prices",
						"Updated Menu item Set name-" + strNewSetName + " is not reflected in Mass Update Prices",
						"Fail");
			}
			Thread.sleep(2000);
			actions.setValue("MassUpdatePrices.SetFilter", strNewSetName);
			actions.smartWait(120);

			/** Verify the updated set name in restaurant profile */
			// Navigate to Restaurant Profile
			System.out.println("> Navigate to :: " + strNavigateToRP);
			actions.select_menu("RFMHome.Navigation", strNavigateToRP);
			actions.smartWait(200);
			actions.waitForPageToLoad(120);

			// Filtering the records by country(region) node
			actions.setValue("MenuItemSets.Filters", strfilterbynode);
			actions.smartWait(60);
			actions.click("MenuItemSets.FilterBtn");
			actions.smartWait(60);

			// Selecting an Active Restaurant and Navigate to Menu
			// Item/POS/Pricing Tab
			actions.setValue("RestaurantProfile.StatusFilter", "Active");
			Thread.sleep(3000);
			actions.smartWait(60);
			WebElement eleRestNumber = mcd.GetTableCellElement("RestaurantProfile.RestaurantProfileTable", 1, 1, "a");
			actions.click(eleRestNumber);
			actions.smartWait(60);
			actions.click("RestaurantProfile.MenuPOSPricing");
			actions.smartWait(60);

			// Selecting 'Menu Items' and Search for the Updated Menu Item Set
			actions.setValue("RestaurantProfile.ChooseSetType", "Menu Items");
			Thread.sleep(2000);
			actions.smartWait(60);
			actions.setValue("MenuItemSets.Searchfield", strNewSetName);
			Thread.sleep(2000);
			actions.keyboardEnter("UpdateRestaurant.Search");
			actions.smartWait(60);

			String strval = mcd.GetTableCellValue("UpdateRestaurant.AvailableTable", 1, 1, "", "");
			if (strval.equals(strNewSetName)) {
				actions.reportCreatePASS("Verify updated Menu Item set name displayed",
						"Updated Menu Item set name should be displayed",
						"Updated Menu Item set name is displayed succesfully in avialable list", "Pass");
			} else {
				actions.reportCreateFAIL("Verify updated Menu Item set name displayed",
						"Updated Menu Item set name should be displayed",
						"Updated Menu Item set name is not displayed in avialable list", "Fail");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}

}
