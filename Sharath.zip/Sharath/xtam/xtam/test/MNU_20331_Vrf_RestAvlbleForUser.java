package xtam.test;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;

public class MNU_20331_Vrf_RestAvlbleForUser {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;


	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String Mi;

	public MNU_20331_Vrf_RestAvlbleForUser(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
	}

	@Test
	public void test_MNU_20331_Vrf_RestAvlbleForUser() throws InterruptedException {
		try {						
		System.out.println(
					"********************************************************************** Test execution starts");
			
			actions.setTestcaseDescription("Verify only those restaurants in any hierarchy node/level that match's the user's level and node assignments are listed in the Available Restaurant list");
			
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			//click on view full list
			actions.keyboardEnter("RFM.SearchBtn");
			actions.smartWait(25);
			
			//Getting the name of menu item
			Mi = mcd.GetTableCellValue("MassStatusUpdate.LeftTable", 1, "| Name", "", "");

			//click on that particular element
			WebElement Element = mcd.GetTableCellElement("MassStatusUpdate.LeftTable", 1, "| Name", "");
			actions.click(Element);
	
			//click on right arrow button
			actions.click("RFM.RightArrowButton");
			actions.smartWait(5);
			
			//click on next button
			actions.click("MassStatusUpdate.KUNext");
			actions.smartWait(15);
			actions.keyboardEnter("RFM.ViewFullListButton");
			actions.smartWait(15);

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}