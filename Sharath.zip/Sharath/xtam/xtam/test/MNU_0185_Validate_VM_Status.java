package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.MasterMenuItem;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0185_Validate_VM_Status {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private MasterMenuItem mmi;
	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket, strApplicationDate, MIrange, pro_type, strmsg, strmenutype;
	private String strNavigateTo, strWM, menuItem, menuItem_num, menuItem_name, menuItem_status, popwin1, strmsgs,
			msg[], menu_name, status;
	private Boolean verifypopup;

	// TODO: Declare test-data variables for other data-parameters

	public MNU_0185_Validate_VM_Status(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		mmi = new MasterMenuItem(nodeDriver, actions, uiActions, inputData, mcd, rfm);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strWM = mcd.GetTestData("DT_WarningMessage");
		MIrange = mcd.GetTestData("DT_MIRANGE");
		pro_type = mcd.GetTestData("DT_MENUITEMCLASS");
		strmsg = mcd.GetTestData("DT_ERR_MSG");
		strmenutype = mcd.GetTestData("DT_MIPARAM");

	}

	@Test
	public void test_MNU_0185_Validate_VM_Status() throws InterruptedException {

		actions.setTestcaseDescription(
				"Verify that the Container Value Meal will be set to 'Inactive' before any of the composition item is inactivated.");

		try {
			System.out.println("******************** Test execution starts");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
			actions.waitForPageToLoad(180);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(180);
			actions.smartWait(60);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow

			// Select already created active menu item of class Container Value
			// Meal
			// Create New Menu Item with Menu item Class as Product.
			String[] strparam = strmenutype.split("#");
			int MenuNumber = mmi.RFM_MI_CreateMenuItem_updated(MIrange, pro_type, strmsg, strmenutype);
			String strMenuNumber = Integer.toString(MenuNumber);
			System.out.println("> > > >" + strMenuNumber);

			actions.setValue("MasterMenuItemList.srch_text", strMenuNumber);
			actions.click("NEWMIG.Exactrbtn");
			Thread.sleep(2000);
			actions.click("MasterMenuItemList.Searchbtn");
			actions.smartWait(180);
			WebElement rec_sel = mcd.GetTableCellElement("MasterMenuItemList.datatable", 1, "Number", "a");
			actions.click(rec_sel);
			actions.smartWait(180);

			// Navigate to component tab
			actions.click("ManageMenuItem.Component_act");
			actions.smartWait(180);

			// Add any Active Menu Item & Click on Continue Button
			actions.click("CurrentMenuItemDetails.AddRemove");
			mcd.SwitchToWindow("Common Menu Item Selector");
			actions.click("AddRemoveComponent.Searchbtn");
			actions.smartWait(180);
			if (strMarket.equals("Australasia")) {
				actions.setValue("AddRemoveMenu.Status", "Active");
			} else {
				actions.setValue("CommonMenuItemSelector.StatusFilter", "Approved");
			}
			actions.smartWait(180);
			actions.setValue("AddRemoveMenu.Availability", "Available");
			actions.smartWait(180);
			WebElement checkbox = mcd.GetTableCellElement("AddRemoveComponent.webtable", 1, "Add", "input");
			actions.javaScriptClick(checkbox);
			menuItem_num = mcd.GetTableCellValue("AddRemoveComponent.webtable", 1, 3, "", "");
			menuItem_status = mcd.GetTableCellValue("AddRemoveComponent.webtable", 1, 5, "", "");
			actions.click("CommonMenuItem.ContinueBtn");
			mcd.SwitchToWindow("@Manage Menu Items");

			// Click on Apply Button
			actions.click("CurrentMenuItemDetails.Apply");
			actions.smartWait(180);
			mcd.SwitchToWindow("Apply Changes Details");
			actions.click("ApplyChangesDetails.save");
			Thread.sleep(2000);
			mcd.SwitchToWindow("@Manage Menu Items");
			actions.waitForPageToLoad(20);
			actions.smartWait(20);

			// Click on Change Status button
			actions.keyboardEnter("ManageMenuItems.ChangeAprrovalStatusButton");
			if (strMarket.equals("Australasia")) {
				mcd.SwitchToWindow("Status Changes");
			} else {
				mcd.SwitchToWindow("Approval Status Changes");
			}

			// Remove any future status & Checking if future setting is already
			// present
			if (actions.isElementPresent("ApprovalStatusChanges.Delete")) {
				actions.click("ApprovalStatusChanges.Delete");
				verifypopup = mcd.VerifyAlertMessageDisplayed("WarningMsg",
						"Are you sure you want to delete the selected item?", true, AlertPopupButton.OK_BUTTON);
				if (verifypopup) {
					actions.reportCreatePASS("Delete Added Approval Status", "Delete Confirmation popup should appear",
							"Delete Confirmation popup is appearing", "PASS");
				} else {
					actions.reportCreateFAIL("Delete Added Approval Status", "Delete Confirmation popup should appear",
							"Delete Confirmation popup is not appearing", "FAIL");
				}

				actions.smartWait(15);
			}

			actions.WaitForElementPresent("ApprovalStatusChanges.AddButton", 100);

			// Click on Add approval status button & Select Current date
			actions.keyboardEnter("ApprovalStatusChanges.AddButton");
			actions.click("ApprovalStatusChanges.CalendarIconScnd");
			mcd.Get_future_date(0, "Close", strApplicationDate);

			// Click on Apply button
			if (strMarket.equals("Australasia")) {
				actions.click("RestaurantMenuItemList.ChangeStatus_Save");
				boolean booAlert = mcd.VerifyAlertMessageDisplayed("Warning Message", strWM, true,
						AlertPopupButton.OK_BUTTON);
				if (booAlert) {
					actions.reportCreatePASS("Verify Alert is Present", "Alert should be Present", "Alert is Present",
							"PASS");
				} else {
					actions.reportCreateFAIL("Verify Alert is Present", "Alert should be Present",
							"Alert is not Present", "FAIL");
				}
				actions.smartWait(20);
			} else {
				actions.click("IngredientGroups.save");
				Thread.sleep(2000);
			}

			mcd.waitAndSwitch("Run Menu Item Usage Report");
			actions.keyboardEnter("RecipeReport.CancelButton");

			// Click on Cancel button
			Thread.sleep(5000);
			if (mcd.GetGlobalData("Instance").equalsIgnoreCase("AP")) {
				mcd.SwitchToWindow("$Status Changes");
			} else {
				mcd.SwitchToWindow("$Approval Status Changes");
			}
			actions.smartWait(60);
			Thread.sleep(3000);
			actions.verifyTextPresence("Your changes have been saved.", true);
			if (strMarket.equals("Australasia")) {
				Thread.sleep(2000);
				actions.click("RestaurantMenuItemList.ChangeStatus_Cancel");
			} else {
				Thread.sleep(2000);
				actions.click("GlobalSettingsLookups.cancel");
			}
			Thread.sleep(3000);
			mcd.SwitchToWindow("@Manage Menu Items");

			/** Getting back to Menu Item main page */
			actions.click("GlobalSettingsLookups.cancel");
			actions.waitForPageToLoad(20);
			Thread.sleep(1000);

			// Search menu Item Of Active Component in another Menu Item
			actions.clear("MasterMenuItemList.srch_text");
			actions.setValue("MasterMenuItemList.srch_text", menuItem_num);
			actions.click("MasterMenuItemList.Searchbtn");
			actions.smartWait(180);
			rec_sel = mcd.GetTableCellElement("MasterMenuItemList.datatable", 1, "Number", "a");
			actions.keyboardEnter(rec_sel);
			actions.smartWait(180);

			// Verify status of component menu item (CMI1) is active.
			menu_name = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.prodname")))
					.getAttribute("value");
			status = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.prodstatus")))
					.getAttribute("value");

			if (status.equalsIgnoreCase(menuItem_status)) {
				actions.reportCreatePASS("Pass: Menu Item " + menu_name + " status is displayed Expected as:" + status,
						"Pass: Menu Item " + menu_name + " status is displayed Expected as:" + status,
						"Pass: Menu Item " + menu_name + " status is displayed Expected as:" + status, "PASS");
			} else {

				actions.reportCreateFAIL(
						"Fail: Menu Item " + menu_name + " status is displayed as:" + status + " Expected was Active",
						"Fail: Menu Item " + menu_name + " status is displayed as:" + status + " Expected was Active",
						"Fail: Menu Item " + menu_name + " status is displayed as:" + status + " Expected was Active",
						"FAIL");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}
