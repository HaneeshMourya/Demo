package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.thoughtworks.selenium.webdriven.commands.WaitForPageToLoad;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20491_SearchFunctionality {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strWM1;
	private String strRegion;
	private String strCoop;

	public MNU_20491_SearchFunctionality(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strWM1 = mcd.GetTestData("WarningMessage1");

		strRegion = mcd.GetTestData("DT_Region");
		strCoop = mcd.GetTestData("DT_Coop");
	}

	@Test
	public void test_MNU_20491_SearchFunctionality() throws InterruptedException {
		String strPageTitle = "Smart Reminder Sets";
		String strPageSubHeading = "Smart Reminder Sets";

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"Verify the Search functionality of Smart Reminder Set  using �Search Full List by Smart Reminder Set � field");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(180);

			/** Verify Page Header */
			System.out.println("> Verify Page Heading");
			mcd.VerifyPageTitle(strPageTitle);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			/** Click on Search Button */
			actions.smartWait(100);
			actions.WaitForElementPresent("RFMHome.SearchButton", 100);
			actions.keyboardEnter("RFMHome.SearchButton");
			actions.smartWait(50);

			// Enter invalid Smart Reminder Set in Search text field
			actions.setValue("SmartReminderSets.SearchTextBox", "invalid");
			actions.keyboardEnter("RFMHome.SearchButton");
			actions.smartWait(60);

			// Verify if Message 'Search returned no matching results.'
			// isDisplayed
			boolean booMsg = mcd.VerifyOnscreenMessage("RFMHome.NoSearchText", "Search returned no matching results.",
					true);
			System.out.println(booMsg);

			if (booMsg == true) {
				actions.reportCreatePASS("Message: 'Search returned no matching results.' is Displayed",
						"Message: 'Search returned no matching results.' should Displayed",
						"Message: 'Search returned no matching results.' is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Message: 'Search returned no matching results.' is Displayed",
						"Message: 'Search returned no matching results.' should Displayed",
						"Message: 'Search returned no matching results.' is not Displayed", "Fail");
			}

			// Enter valid Smart Reminder Set in Search text field
			actions.smartWait(10);
			actions.clear("SmartReminderSets.SearchTextBox");
			actions.keyboardEnter("RFMHome.SearchButton");
			actions.smartWait(50);

			String strValue = driver.findElement(By.xpath(actions.getLocator("SmartReminderSets.TableFirstValue")))
					.getText();
			System.out.println(strValue);
			actions.clear("SmartReminderSets.SearchTextBox");
			actions.setValue("SmartReminderSets.SearchTextBox", strValue);
			actions.keyboardEnter("RFMHome.SearchButton");
			actions.smartWait(100);
			String strValue1 = driver.findElement(By.xpath(actions.getLocator("SmartReminderSets.TableFirstValue")))
					.getText();
			System.out.println(strValue1);

			if (strValue.equals(strValue1)) {
				actions.reportCreatePASS("Search returned the expected value",
						"Search should returned the expected value", "Search returned the expected value", "Pass");
			} else {
				actions.reportCreateFAIL("Search returned the expected value",
						"Search should returned the expected value", "Search did not returned the expected value",
						"Fail");
			}

			// Validation inactive status
			actions.smartWait(30);
			actions.WaitForElementPresent("RFMHome.SearchButton");
			actions.clear("SmartReminderSets.SearchTextBox");
			actions.keyboardEnter("RFMHome.SearchButton");
			actions.smartWait(50);
			actions.setValue("SmartReminderSets.StatusFilter", "Inactive");
			actions.smartWait(50);
			strValue = driver.findElement(By.xpath(actions.getLocator("SmartReminderSets.TableFirstValue"))).getText();
			System.out.println(strValue);
			actions.clear("SmartReminderSets.SearchTextBox");
			actions.setValue("SmartReminderSets.SearchTextBox", strValue);

			/** Set Value in Status DropDown */
			actions.setValue("SmartReminderSets.SearchByStatus", "Active");
			actions.keyboardEnter("RFMHome.SearchButton");
			actions.smartWait(100);

			// Verify if Message 'Search returned no matching results.'
			// isDisplayed
			booMsg = mcd.VerifyOnscreenMessage("RFMHome.NoSearchText", "Search returned no matching results.", true);
			System.out.println(booMsg);

			if (booMsg == true) {
				actions.reportCreatePASS("Message: 'Search returned no matching results.' is Displayed",
						"Message: 'Search returned no matching results.' should Displayed",
						"Message: 'Search returned no matching results.' is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Message: 'Search returned no matching results.' is Displayed",
						"Message: 'Search returned no matching results.' should Displayed",
						"Message: 'Search returned no matching results.' is not Displayed", "Fail");
			}

			// Validation Active status
			actions.smartWait(50);
			actions.clear("SmartReminderSets.SearchTextBox");
			actions.keyboardEnter("RFMHome.SearchButton");
			actions.smartWait(50);
			actions.setValue("SmartReminderSets.StatusFilter", "Active");

			strValue = driver.findElement(By.xpath(actions.getLocator("SmartReminderSets.TableFirstValue"))).getText();
			System.out.println(strValue);
			actions.clear("SmartReminderSets.SearchTextBox");
			actions.setValue("SmartReminderSets.SearchTextBox", strValue);

			/** Set Value in Status DropDown */
			actions.setValue("SmartReminderSets.SearchByStatus", "Inactive");
			actions.smartWait(50);
			actions.keyboardEnter("RFMHome.SearchButton");
			actions.smartWait(50);

			// Verify if Message 'Search returned no matching results.'
			// isDisplayed
			booMsg = mcd.VerifyOnscreenMessage("RFMHome.NoSearchText", "Search returned no matching results.", true);
			System.out.println(booMsg);

			if (booMsg == true) {
				actions.reportCreatePASS("Message: 'Search returned no matching results.' is Displayed",
						"Message: 'Search returned no matching results.' should Displayed",
						"Message: 'Search returned no matching results.' is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Message: 'Search returned no matching results.' is Displayed",
						"Message: 'Search returned no matching results.' should Displayed",
						"Message: 'Search returned no matching results.' is not Displayed", "Fail");
			}

			// Validation Active/inactive status
			actions.smartWait(50);
			actions.clear("SmartReminderSets.SearchTextBox");
			actions.keyboardEnter("RFMHome.SearchButton");
			actions.smartWait(50);
			actions.setValue("SmartReminderSets.StatusFilter", "Inactive");
			actions.smartWait(50);

			strValue = driver.findElement(By.xpath(actions.getLocator("SmartReminderSets.TableFirstValue"))).getText();
			System.out.println(strValue);
			actions.clear("SmartReminderSets.SearchTextBox");
			actions.setValue("SmartReminderSets.SearchTextBox", strValue);

			/** Set Value in Status DropDown */
			actions.setValue("SmartReminderSets.SearchByStatus", "Active/Inactive");
			actions.keyboardEnter("RFMHome.SearchButton");
			actions.smartWait(50);
			strValue1 = driver.findElement(By.xpath(actions.getLocator("SmartReminderSets.TableFirstValue"))).getText();
			System.out.println(strValue1);
			if (strValue.equals(strValue1)) {
				actions.reportCreatePASS("Search returned the expected value",
						"Search should returned the expected value", "Search returned the expected value", "Pass");
			} else {
				actions.reportCreateFAIL("Search returned the expected value",
						"Search should returned the expected value", "Search did not returned the expected value",
						"Fail");
			}

			// Verify the Active and Active/Inactive
			actions.smartWait(50);
			actions.clear("SmartReminderSets.SearchTextBox");
			actions.keyboardEnter("RFMHome.SearchButton");
			actions.smartWait(50);
			actions.setValue("SmartReminderSets.StatusFilter", "Active");
			actions.smartWait(50);

			/** Get the Table First Value */
			strValue = driver.findElement(By.xpath(actions.getLocator("SmartReminderSets.TableFirstValue"))).getText();
			System.out.println(strValue);
			actions.clear("SmartReminderSets.SearchTextBox");
			actions.setValue("SmartReminderSets.SearchTextBox", strValue);

			/** Set Value in Status DropDown */
			actions.setValue("SmartReminderSets.SearchByStatus", "Active/Inactive");
			actions.smartWait(50);
			actions.keyboardEnter("RFMHome.SearchButton");
			actions.smartWait(50);

			/** Get the Table First Value */
			strValue1 = driver.findElement(By.xpath(actions.getLocator("SmartReminderSets.TableFirstValue"))).getText();
			System.out.println(strValue1);
			if (strValue.equals(strValue1)) {
				actions.reportCreatePASS("Search returned the expected value",
						"Search should returned the expected value", "Search returned the expected value", "Pass");
			} else {
				actions.reportCreateFAIL("Search returned the expected value",
						"Search should returned the expected value", "Search did not returned the expected value",
						"Fail");
			}

			// Verifu the status ddl
			actions.smartWait(50);
			actions.clear("SmartReminderSets.SearchTextBox");
			actions.keyboardEnter("RFMHome.SearchButton");
			actions.smartWait(50);

			/** Set Value in Status DropDown */
			actions.setValue("SmartReminderSets.StatusFilter", "Active");
			actions.smartWait(50);

			/** Get the Table First Value */
			strValue = driver.findElement(By.xpath(actions.getLocator("SmartReminderSets.TableFirstValue"))).getText();
			System.out.println(strValue);
			actions.clear("SmartReminderSets.SearchTextBox");
			actions.setValue("SmartReminderSets.SearchTextBox", strValue);

			/** Set Value in Status DropDown */
			actions.setValue("SmartReminderSets.SearchByStatus", "Active");
			actions.smartWait(50);
			actions.keyboardEnter("RFMHome.SearchButton");
			actions.smartWait(50);

			/** Get the Table First Value */
			strValue1 = driver.findElement(By.xpath(actions.getLocator("SmartReminderSets.TableFirstValue"))).getText();
			System.out.println(strValue1);
			if (strValue.equals(strValue1)) {
				actions.reportCreatePASS("Search returned the expected value",
						"Search should returned the expected value", "Search returned the expected value", "Pass");
			} else {
				actions.reportCreateFAIL("Search returned the expected value",
						"Search should returned the expected value", "Search did not returned the expected value",
						"Fail");
			}

			// Verify the status ddl
			actions.smartWait(50);
			actions.clear("SmartReminderSets.SearchTextBox");
			actions.keyboardEnter("RFMHome.SearchButton");
			actions.smartWait(50);

			/** Set Value in Status DropDown */
			actions.setValue("SmartReminderSets.StatusFilter", "Inactive");
			actions.smartWait(50);

			/** Get the Table First Value */
			strValue = driver.findElement(By.xpath(actions.getLocator("SmartReminderSets.TableFirstValue"))).getText();
			System.out.println(strValue);
			actions.clear("SmartReminderSets.SearchTextBox");
			actions.setValue("SmartReminderSets.SearchTextBox", strValue);
			actions.setValue("SmartReminderSets.SearchByStatus", "Inactive");
			actions.smartWait(50);
			actions.keyboardEnter("RFMHome.SearchButton");
			actions.smartWait(50);

			/** Get the Table First Value */
			strValue1 = driver.findElement(By.xpath(actions.getLocator("SmartReminderSets.TableFirstValue"))).getText();
			System.out.println(strValue1);
			if (strValue.equals(strValue1)) {
				actions.reportCreatePASS("Search returned the expected value",
						"Search should returned the expected value", "Search returned the expected value", "Pass");
			} else {
				actions.reportCreateFAIL("Search returned the expected value",
						"Search should returned the expected value", "Search did not returned the expected value",
						"Fail");
			}
			// Verify the status ddl
			actions.smartWait(50);
			actions.clear("SmartReminderSets.SearchTextBox");
			actions.keyboardEnter("RFMHome.SearchButton");
			actions.smartWait(50);

			/** Get the Table First Value */
			strValue = driver.findElement(By.xpath(actions.getLocator("SmartReminderSets.TableFirstValue"))).getText();
			System.out.println(strValue);
			actions.clear("SmartReminderSets.SearchTextBox");
			actions.setValue("SmartReminderSets.SearchTextBox", strValue);
			actions.setValue("SmartReminderSets.SearchByStatus", "Active/Inactive");
			actions.smartWait(50);
			actions.keyboardEnter("RFMHome.SearchButton");
			actions.smartWait(50);

			/** Get the Table First Value */
			strValue1 = driver.findElement(By.xpath(actions.getLocator("SmartReminderSets.TableFirstValue"))).getText();
			System.out.println(strValue1);
			if (strValue.equals(strValue1)) {
				actions.reportCreatePASS("Search returned the expected value",
						"Search should returned the expected value", "Search returned the expected value", "Pass");
			} else {
				actions.reportCreateFAIL("Search returned the expected value",
						"Search should returned the expected value", "Search did not returned the expected value",
						"Fail");
			}
			// ------------------------------------------------------------------------

			// Verify region
			actions.clear("SmartReminderSets.SearchTextBox");
			actions.keyboardEnter("RFMHome.SearchButton");
			actions.smartWait(50);

			/** Set Value in Filter */
			actions.setValue("SmartReminderSets.Filter", strRegion);
			actions.smartWait(50);

			/** Click on Filter Button */
			actions.keyboardEnter("SmartReminderSets.FilterButton");
			actions.smartWait(100);
			int rw_cnt = mcd.GetTableRowCount("SmartReminderSets.Table");
			for (int i = 1; i < rw_cnt; i++) {
				String strVal = mcd.GetTableCellValue("SmartReminderSets.Table", i, "Node", "", "");
				System.out.println(strValue);
				if (strValue.equals(strRegion)) {
					actions.reportCreatePASS("Region " + strVal + " is Present", "Region " + strVal + " should Present",
							"Region " + strVal + " is Present", "Pass");
					break;
				} else {
					actions.reportCreateFAIL("Region " + strVal + " is Present", "Region " + strVal + " should Present",
							"Region " + strVal + " is not Present", "Fail");
				}
			}

			// Verify region
			actions.clear("SmartReminderSets.SearchTextBox");
			actions.keyboardEnter("RFMHome.SearchButton");
			actions.smartWait(50);

			/** Set Value in Filter Region */
			actions.setValue("SmartReminderSets.Filter", strRegion);
			actions.smartWait(50);

			// added by Sunny
			String market1 = "US Country Office";
			if (strMarket.equals(market1)) {
				System.out.println(market1);
				/** Set Value in Filter Coop */
				actions.setValue("SmartReminderSets.FilterCoop", strCoop);
			}

			/** Click on Filter Button */
			actions.keyboardEnter("SmartReminderSets.FilterButton");
			actions.smartWait(100);
			rw_cnt = mcd.GetTableRowCount("SmartReminderSets.Table");
			for (int i = 1; i < rw_cnt; i++) {
				String strValue2 = mcd.GetTableCellValue("SmartReminderSets.Table", i, "Node", "", "");
				System.out.println(strValue);
				if (strValue.equals(strCoop)) {
					actions.reportCreatePASS("Region " + strValue2 + " is Present",
							"Region " + strValue2 + " should Present", "Region " + strValue2 + " is Present", "Pass");
					break;
				} else {
					actions.reportCreateFAIL("Region " + strValue2 + " is Present",
							"Region " + strValue2 + " should Present", "Region " + strValue2 + " is not Present",
							"Fail");
				}
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}
