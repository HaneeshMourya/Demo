package xtam.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0212_PostSearchFltr {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo, strstatus;
	// TODO: Declare test-data variables for other data-parameters
	private String strPageTitle, strTableElement;

	public MNU_0212_PostSearchFltr(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		strPageTitle = mcd.GetTestData("DT_TITLE");
		strTableElement = "MasterMenuItemList.datatable";

	}

	@Test
	public void test_MNU_0212_PostSearchFltr() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(
					"Verify the working of post search DDL on Update Multiple Menu Items: Copy Component Type screen  ");
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Verify Page Header */
			System.out.println("> Verify Page Heading");
			mcd.VerifyPageTitle(strPageTitle);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			// ------------------------------------------------------------------------
			// Actions specific to test-flow
			// Click on Search Button
			actions.keyboardEnter("MasterMenuItemList.Searchbtn");
			actions.smartWait(120);

			// Select "Approved" value in the Post Search Status DDL
			if (input.get("_rowId").toString().toUpperCase().contains("US")) {
				actions.smartWait(10);
				strstatus = "Approved";
				actions.setValue("RestaurantMenuItemList.ApprovalStatusDDL", strstatus);
				actions.smartWait(10);
				if (mcd.GetTableRowCount("RestaurantMenuItemList.MenuItemList") > 0) {

					String record_name = mcd.GetTableCellValue("RestaurantMenuItemList.MenuItemList", 1,
							"Approval Status", "", "");
					verify_search_result("contains", record_name, strstatus);
				}

			} else if (input.get("").toString().toUpperCase().contains("AP")) {
				strstatus = "Active";
				actions.setValue("RestaurantMenuItemList.FilterStatus", strstatus);
				actions.smartWait(10);
				if (mcd.GetTableRowCount("RestaurantMenuItemList.MenuItemList") > 0) {

					String record_name = mcd.GetTableCellValue("RestaurantMenuItemList.MenuItemList", 1, "Status", "",
							"");
					verify_search_result("contains", record_name, strstatus);
				}

			}

			// Select any Existing Menu item
			WebElement menuitem = mcd.GetTableCellElement("RestaurantMenuItemList.MenuItemList", 1, "Number", "a");
			actions.keyboardEnter(menuitem);
			actions.smartWait(10);
			actions.smartWait(10);
			mcd.SwitchToWindow("#Title");

			// Click on 'Component' tab
			actions.click("ManageMenuItem.Components");
			actions.smartWait(20);

			// Select any value from View Type DDL
			actions.WaitForElementPresent("MasterMenuItemList.ViewTypeDDL", 10);
			if (mcd.fn_VerifyWebelementEnableDisable("MasterMenuItemList.ViewTypeDDL")) {
				actions.reportCreatePASS("Verify whether View Type DDL is enabled or disabled",
						"View Type DDL is should be enabled", "View Type DDL is enabled", "Pass");
			} else {
				actions.reportCreateFAIL("Verify whether View Type DDL is enabled or disabled",
						"View Type DDL is should be enabled", "View Type DDL is not enabled", "Fail");
			}
			actions.setValue("MasterMenuItemList.ViewTypeDDL", "Can Adds");
			actions.smartWait(5);

			// selecting the check box for first element
			List<WebElement> Add_Chkbox = driver
					.findElements(By.xpath(actions.getLocator("MasterMenuItemList.CompTable")));
			int Item_Counts = Add_Chkbox.size();
			if (Item_Counts > 0) {
				actions.javaScriptClick(Add_Chkbox.get(0));
			}

			if (input.get("_rowId").toString().toUpperCase().contains("US")) {
				// Click on copy button
				actions.keyboardEnter("MasterMenuItemList.CopyBtn");
				Thread.sleep(1000);
				mcd.waitAndSwitch("Copy Components");

				// Search for any menu item number
				actions.smartWait(10);
				actions.javaScriptClick("CommonMenuItemSelector.ExactMatch");
				actions.clear("CommonMenuItemSelector.SearchTextBox");
				actions.setValue("CommonMenuItemSelector.SearchTextBox", "1");
				actions.setValue("UpdateComponent.PreFamilyGrpFilter", "BREAKFAST_ENTREE");
				actions.keyboardEnter("UpdateComponent.SearchBtn");
				actions.smartWait(10);
			} else if (input.get("_rowId").toString().toUpperCase().contains("AP")) {
				// Click on copy button
				actions.keyboardEnter("MasterMenuItemList.CopyBtn");
				mcd.waitAndSwitch("Copy Components");

				// Search for any menu item number
				actions.javaScriptClick("CommonMenuItemSelector.ExactMatch");
				actions.clear("CommonMenuItemSelector.SearchTextBox");
				actions.setValue("CommonMenuItemSelector.SearchTextBox", "1");
				actions.setValue("UpdateComponent.PreFamilyGrpFilter", "BREAKFAST_ENTREE");
				actions.keyboardEnter("UpdateComponent.SearchBtn");
				actions.smartWait(10);

			}

			// verifying the family group filter is enabled or disabled
			// if(!actions.isElementEnabled(sElement))
			if (!mcd.fn_VerifyWebelementEnableDisable("CopyComponents.AvailableMenu")) {
				actions.reportCreatePASS(
						"Verify Post search filter is dispalyed as Disabled after searching any value in search text field ",
						" Post search filter should be dispalyed as Disabled after searching any value in search text field",
						" Post search Family Group DDL is dispalyed as Disabled after searching any value in search text field",
						"Pass");
			} else {
				actions.reportCreateFAIL(
						"Verify Post search filter is dispalyed as Disabled after searching any value in search text field",
						" Post search filter should be dispalyed as Disabled after searching any value in search text field",
						" Post search Family Group DDL is dispalyed as Enabled after searching any value in search text field",
						"Fail");
			}

			// click on cancel button
			actions.keyboardEnter("DimensionGroup.CancelButton");
			mcd.SwitchToWindow("Manage Menu Items");
			actions.smartWait(15);
			actions.click("ManageMenuItem.Cancelbtn1");
			mcd.SwitchToWindow("#Title");

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	public void verify_search_result(String search_type, String record_name, String srchtxt) {
		switch (search_type) {

		case "max":
		case "invalid":
			break;
		case "null":
			break;
		case "contains":
			if (record_name.contains(srchtxt)) {
				actions.reportCreatePASS("Valdating the Search result with Special Character",
						"Should display Correct result", "Correct result is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Valdating the Search result", "Should display Correct result",
						"Correct results are not displayed", "Fail");
			}
			break;
		case "equal":
			if (record_name.equals(srchtxt)) {
				actions.reportCreatePASS("Valdating the Search result", "Should display Correct result" + srchtxt,
						"Correct result is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Valdating the Search result for" + srchtxt,
						"Should display Correct result for " + srchtxt, "Correct results are not displayed", "Fail");
			}
			break;
		case "filter":
			if (record_name.contains(srchtxt)) {

				actions.reportCreatePASS("Valdating the Search result with status filter",
						"Should display Correct result", "Correct results are displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Valdating the Search result with status filter",
						"Should display Correct result", "Correct results are not displayed", "Fail");
			}
			break;
		}

	}

}
