package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20472_Vrf_SNupdateAL {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String dtErrMsg;
	private String strErrMsg[];
	private int snCode;
	private String strSize, strSnCode, snDescription;
	private boolean flag;
	private String tcDescription, strUserID;
	private String auditMarket;

	public MNU_20472_Vrf_SNupdateAL(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		dtErrMsg = mcd.GetTestData("DT_ERR_MSG");
		tcDescription = mcd.GetTestData("DT_Description");
		strUserID = mcd.GetTestData("DT_USER_NAME");
		auditMarket = mcd.GetTestData("DT_AUDITLOG_MARKET");
	}

	@Test
	public void test_MNU_20472_Vrf_SNupdateAL() throws InterruptedException {
		String strPageTitle = "Substitution Names"; // TODO: Exact page-title
		String strPageSubHeading = ""; // TODO: Page Heading

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(tcDescription);
			
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
			actions.waitForPageToLoad(120);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");
			
			/** Get application time */
			WebElement apptime = mcd.getdate();
	        String app_date = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow

			//Update the Substitution Name
			System.out.println("Start");
			strErrMsg = dtErrMsg.split("#");

			snDescription = mcd.GetTableCellValue("DimensionName.Table", 1, "Description", "input", "value");

			snDescription = snDescription + "_U";

			mcd.SetTableCellValue("DimensionName.Table", 1, "Description", snDescription, "input", "value");

			actions.click("DimensionGroup.SaveButton");
			actions.smartWait(15);

			flag = mcd.VerifyOnscreenMessage("SubstitutionGroups.InfoMessage", strErrMsg[2], true);
			if (flag) {
				actions.reportCreatePASS("Verify the info message",
						"Message '" + strErrMsg[2] + "' should be displayed", "Expected message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the info message",
						"Message '" + strErrMsg[2] + "' should be displayed", "Expected message is not displayed",
						"FAIL");
			}

			// Verifying the audit logs

			boolean blnAudit = false;
			blnAudit = rfm.VerifyAuditLog_Entry(strPageTitle, "Update", auditMarket);

			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Entry for Update Substitution Names",
						"Audit log should be generated for Update Substitution Names",
						"Audit log generated for Update Substitution Names succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Entry for Update Substitution Names",
						"Audit log should be generated for Update Substitution Names",
						"Audit log not generated for Update Substitution Names succesfully", "FAIL");
			}

			blnAudit = rfm.RFM_VerifyAuditLog_Details("RFM2", strUserID, strPageTitle, "Update", auditMarket , strMarket,
					"Substitution Name has been updated.");
			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Details for Update Substitution Names",
						"Audit log details should be generated for Update Substitution Names",
						"Audit log details generated for Substitution Names succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Details for Update Substitution Names",
						"Audit log details should be generated for Update Substitution Names",
						"Audit log details not generated for Substitution Names item succesfully", "FAIL");
			}
			

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}
