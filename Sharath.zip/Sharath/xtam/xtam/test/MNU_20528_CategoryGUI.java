package xtam.test;

import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class MNU_20528_CategoryGUI {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String alrtTxt;
	private String strMsg[];

	public MNU_20528_CategoryGUI(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strMsg = mcd.GetTestData("DT_ALERTMSG").split("#");

	}

	@Test
	public void test_MNU_20528_CategoryGUI() throws InterruptedException {
		String strPageTitle = "";
		String strPageSubHeading = "Category";

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription("Verify the GUI of the category screen.");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Verify Page Header */
			System.out.println("> Verify Page Heading");
			mcd.VerifyPageHeading(strPageSubHeading, "SubHeading");

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow

			// waiting for element to be present

			actions.smartWait(100);
			actions.WaitForElementPresent("RFM.BeginsWithRadioButton", 100);

			// ** Verify if Begins With Radio Button is Present */

			Boolean booDisplayed1 = driver.findElement(By.xpath(actions.getLocator("RFM.BeginsWithRadioButton")))
					.isDisplayed();
			if (booDisplayed1 == true) {
				actions.reportCreatePASS("'Begins With' Radio Button is Displayed",
						"'Begins With' Radio Button should Displayed", "'Begins With' Radio Button is Displayed",
						"Pass");
			} else {
				actions.reportCreateFAIL("'Begins With' Radio Button is Displayed",
						"'Begins With' Radio Button should Displayed", "'Begins With' Radio Button is not Displayed",
						"Fail");
			}

			// ** Verify if Ends With Radio Button is Present */
			Boolean booDisplayed2 = driver.findElement(By.xpath(actions.getLocator("RFM.EndsWithRadioButton")))
					.isDisplayed();
			if (booDisplayed2 == true) {
				actions.reportCreatePASS("'Ends With' Radio Button is Displayed",
						"'Ends With' Radio Button should Displayed", "'Ends With' Radio Button is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("'Ends With' Radio Button is Displayed",
						"'Ends With' Radio Button should Displayed", "'Ends With' Radio Button is not Displayed",
						"Fail");
			}

			// ** Verify if Contains Radio Button is Present */
			Boolean booDisplayed3 = driver.findElement(By.xpath(actions.getLocator("RFM.ContainsRadioButton")))
					.isDisplayed();
			if (booDisplayed3 == true) {
				actions.reportCreatePASS("'Contains' Radio Button is Displayed",
						"'Contains' Radio Button should Displayed", "'Contains' Radio Button is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("'Contains' Radio Button is Displayed",
						"'Contains' Radio Button should Displayed", "'Contains' Radio Button is not Displayed", "Fail");
			}

			// ** Verify if Exact Match Radio Button is Present */

			Boolean booDisplayed4 = driver.findElement(By.xpath(actions.getLocator("RFM.ExactMatchRadioButton")))
					.isDisplayed();
			if (booDisplayed4 == true) {
				actions.reportCreatePASS("'Exact Match' Radio Button is Displayed",
						"'Exact Match' Radio Button should Displayed", "'Exact Match' Radio Button is Displayed",
						"Pass");
			} else {
				actions.reportCreateFAIL("'Exact Match' Radio Button is Displayed",
						"'Exact Match' Radio Button should Displayed", "'Exact Match' Radio Button is not Displayed",
						"Fail");
			}

			// ** Verify if Message 'Search Full List by Menu Item Number or
			// Name' is Displayed */

			Boolean booDisplayed5 = driver.findElement(By.xpath(actions.getLocator("Category.HintMessage")))
					.isDisplayed();
			if (booDisplayed5 == true) {
				actions.reportCreatePASS("Message 'Search Full List by Menu Item Number or Name' is Displayed",
						"Message 'Search Full List by Menu Item Number or Name' should Displayed",
						"Message 'Search Full List by Menu Item Number or Name' is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Message 'Search Full List by Menu Item Number or Name' is Displayed",
						"Message 'Search Full List by Menu Item Number or Name' should Displayed",
						"Message 'Search Full List by Menu Item Number or Name' is not Displayed", "Fail");
			}

			// ** Verify if Search TextBox is Present */

			Boolean booDisplayed6 = driver.findElement(By.xpath(actions.getLocator("SetAssignmentReport.SearchButton")))
					.isDisplayed();
			if (booDisplayed6 == true) {
				actions.reportCreatePASS("Search Text Box is Displayed", "Search Text Box should Displayed",
						"Search Text Box is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Search Text Box is Displayed", "Search Text Box should Displayed",
						"Search Text Box is not Displayed", "Fail");
			}

			// ** Verify if Search Button is Present */

			Boolean booDisplayed7 = driver.findElement(By.xpath(actions.getLocator("RFMHome.SearchButton")))
					.isDisplayed();
			if (booDisplayed7 == true) {
				actions.reportCreatePASS("Search Button is Displayed", "Search Button should Displayed",
						"Search Button is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Search Button is Displayed", "Search Button should Displayed",
						"Search Button is not Displayed", "Fail");
			}

			// ** Verify if Breakfast Menu Link is Present */

			Boolean booDisplayed8 = driver.findElement(By.xpath(actions.getLocator("Category.BreakfastMenuNew")))
					.isDisplayed();
			if (booDisplayed8 == true) {
				actions.reportCreatePASS("'Breakfast Menu English' is Displayed",
						"'Breakfast Menu English' should Displayed", "'Breakfast Menu English' is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("'Breakfast Menu English' is Displayed",
						"'Breakfast Menu English' should Displayed", "'Breakfast Menu English' is not Displayed",
						"Fail");
			}

			// ** Verify if Regular Menu Link is Present */

			Boolean booDisplayed9 = driver.findElement(By.xpath(actions.getLocator("Category.RegularMenuNew")))
					.isDisplayed();
			if (booDisplayed9 == true) {
				actions.reportCreatePASS("'Regular Menu English' is Displayed",
						"'Regular Menu English' should Displayed", "'Regular Menu English' is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("'Regular Menu English' is Displayed",
						"'Regular Menu English' should Displayed", "'Regular Menu English' is not Displayed", "Fail");
			}

			// ** Verify if Breakfast Menu Yellow Arrow is Present */

			Boolean booDisplayed10 = driver.findElement(By.xpath(actions.getLocator("Category.FirstYellowArrow")))
					.isDisplayed();
			if (booDisplayed10 == true) {
				actions.reportCreatePASS("Yellow Arrow is Displayed", "Yellow Arrow should Displayed",
						"Yellow Arrow is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Yellow Arrow is Displayed", "Yellow Arrow should Displayed",
						"Yellow Arrow is not Displayed", "Fail");
			}

			// ** Verify if Regular Menu Yellow Arrow is Present */
			Boolean booDisplayed11 = driver.findElement(By.xpath(actions.getLocator("Category.ScndYellowArrow")))
					.isDisplayed();
			if (booDisplayed11 == true) {
				actions.reportCreatePASS("Yellow Arrow is Displayed", "Yellow Arrow should Displayed",
						"Yellow Arrow is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Yellow Arrow is Displayed", "Yellow Arrow should Displayed",
						"Yellow Arrow is not Displayed", "Fail");
			}

			/** navigating from first level of category to second */

			// actions.WaitForElementPresent("Category.BreakfastMenuNew", 180);
			// actions.javaScriptClick("Category.BreakfastMenuNew");
			// mcd.waitAndSwitch("#Title");

			driver.findElement(By.xpath("//*[@id='categoryCatId_0']/img")).click();
			actions.smartWait(20);
			mcd.smartsync(180);

			/** verify if future date radio button is displayed. */

			boolean ftrDtBtn = driver.findElement(By.xpath(actions.getLocator("Category.futureradiobutton")))
					.isDisplayed();
			if (ftrDtBtn) {
				actions.reportCreatePASS("Future date radio button is Displayed",
						"Future date radio button should Displayed", "Future date radio button is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Future date radio button is Displayed",
						"Future date radio button should Displayed", "Future date radio button is not Displayed",
						"Fail");
			}

			mcd.smartsync(180);

			/** verify if Add button in future setting section is displayed. */

			boolean addBtnForFutr = driver.findElement(By.xpath(actions.getLocator("Category.firstAddBtn")))
					.isDisplayed();
			if (addBtnForFutr) {
				actions.reportCreatePASS("Add button in future setting section is Displayed",
						"Add button in future setting section should Displayed",
						"Add button in future setting section is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Add button in future setting section is Displayed",
						"Add button in future setting section should Displayed",
						"Add button in future setting section is not Displayed", "Fail");
			}

			// first add button

			actions.click("Category.firstAddBtn");

			String name1 = mcd.fn_GetRndName("auto");

			JavascriptExecutor jse;

			jse = (JavascriptExecutor) driver;
			List<WebElement> ele = driver.findElements(
					By.name("addCategoryDTO.productCategoryDTOList[0].categoryDescription[0].categoryDescription"));
			try {
				jse.executeScript("arguments[0].setAttribute('value', '" + name1 + "')", ele.get(0));
			} catch (Exception e) {

			}

			String name2 = mcd.fn_GetRndName("auto");
			List<WebElement> ele1 = driver.findElements(By.name("addCategoryDTO.productCategoryDTOList[0].imageName"));
			try {
				jse.executeScript("arguments[0].setAttribute('value', '" + name2 + "')", ele1.get(0));
			} catch (Exception e) {

			}

			// Second add button
			
			actions.click("Category.Addf_RN");
			String name3 = mcd.fn_GetRndName("auto");

			WebElement ele2 = driver.findElement(By.id("AF30181004_0_0"));
			try {
				jse.executeScript("arguments[0].setAttribute('value', '" + name3 + "')", ele2);
			} catch (Exception e) {

			}

			
			String name4 = mcd.fn_GetRndName("auto");

			WebElement ele4 = driver.findElement(By.name("addFutureCategoryDTO.productCategoryDTOList[0].imageName"));
			try {
				jse.executeScript("arguments[0].setAttribute('value', '" + name4 + "')", ele4);
			} catch (Exception e) {

			}
			
			//Checking future date radio button
			
			actions.click("Category.futureradiobutton");
			
			actions.click("Promotion.FromDate");
			
			//Selecting future date
			
			mcd.Get_future_date(3, "Close", strApplicationDate);
			actions.smartWait(50);
			
			
			//String name4 = mcd.fn_GetRndName("auto");
			//actions.setValue("Category.Image2", name4);

			
			actions.click("RFMQueueRoutingPopupPage.SaveButton");
			
			// ------------------------------------------------------------------------
			
			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}
