package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20516_FSFilterFunctnlty {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strFilterValue;
	private String strCoopValue;
	private String strWM1, strstatus;
	// TODO: Declare test-data variables for other data-parameters

	public MNU_20516_FSFilterFunctnlty(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strFilterValue = mcd.GetTestData("DT_FilterValue");
		strCoopValue = mcd.GetTestData("DT_CoopValue");
		strWM1 = mcd.GetTestData("WarningMessage1");
		strstatus = mcd.GetTestData("DT_Status");
	}

	@Test
	public void test_MNU_20516_FSFilterFunctnlty() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(
					"Verify that the search functionality for flavor set with Filter Functionality");
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			actions.WaitForElementPresent("FlavorSet.CountryFilter", 10);

			// verifying if the country filter is disabled
			String strEnabled = driver.findElement(By.xpath(actions.getLocator("FlavorSet.CountryFilter")))
					.getAttribute("disabled");
			System.out.println(strEnabled);
			if (strEnabled.equals("true")) {
				System.out.println("Present");
				actions.reportCreatePASS("Country Filter is Disabled", "Country Filter should be Disabled",
						"Country Filter is Disabled", "Pass");
			} else {
				actions.reportCreateFAIL("Country Filter is Disabled", "Country Filter should be Disabled",
						"Country Filter is not Disabled", "Fail");
			}

			// click on Search button
			actions.keyboardEnter("FlavorSet.SearchButton");
			actions.smartWait(100);

			// verifying country filter is enabled
			try {
				String strEnabled1 = driver.findElement(By.xpath(actions.getLocator("FlavorSet.CountryFilter")))
						.getAttribute("disabled");
				System.out.println(strEnabled1);
				if (strEnabled1.equals("null") || strEnabled1.equals("")) {
					System.out.println("Present");
					actions.reportCreatePASS("Country Filter is Enabled", "Country Filter should be Enabled",
							"Country Filter is Enabled", "Pass");
				} else {
					actions.reportCreateFAIL("Country Filter is Enabled", "Country Filter should be Enabled",
							"Country Filter is not Enabled", "Fail");
				}
			} catch (Exception e) {
				actions.reportCreatePASS("Country Filter is Enabled", "Country Filter should be Enabled",
						"Country Filter is Enabled", "Pass");
			}

			// setting country filter

			actions.setValue("FlavorSet.CountryFilter", strFilterValue);
			// click on filter button
			actions.keyboardEnter("FlavorSet.FilterButton");
			actions.smartWait(100);
			

			// getting row count for table
			int rw_cnt = mcd.GetTableRowCount("RFMHome.Table");
			System.out.println(rw_cnt);
			if (rw_cnt > 0) {
				for (int i = 1; i <= rw_cnt; i++) {
					String strValues = driver.findElement(By.xpath("//*[@id='Sess1']/tbody/tr[" + i + "]/td[2]/pre"))
							.getText();
					System.out.println(strValues);
					if (strMarket.equals("US Country Office")) {

						if (strValues.equals(strCoopValue)) {
							actions.reportCreatePASS(
									"Country Filter returns the '" + strValues + " 'value in the Table",
									"Country Filter should returns the '" + strValues + " 'value in the Table",
									"Country Filter returns the '" + strValues + " 'value in the Table", "Pass");
							break;
						} else {
							actions.reportCreateFAIL(
									"Country Filter returns the '" + strValues + " 'value in the Table",
									"Country Filter should returns the '" + strValues + " 'value in the Table",
									"Country Filter does not returns the '" + strValues + " 'value in the Table",
									"Fail");
						}

					} else {
						if (strValues.equals(strFilterValue)) {
							actions.reportCreatePASS(
									"Country Filter returns the '" + strValues + " 'value in the Table",
									"Country Filter should returns the '" + strValues + " 'value in the Table",
									"Country Filter returns the '" + strValues + " 'value in the Table", "Pass");
							break;
						} else {
							actions.reportCreateFAIL(
									"Country Filter returns the '" + strValues + " 'value in the Table",
									"Country Filter should returns the '" + strValues + " 'value in the Table",
									"Country Filter does not returns the '" + strValues + " 'value in the Table",
									"Fail");
						}
					}
				}
			}

			// Click Search Button
			actions.keyboardEnter("FlavorSet.SearchButton");
			actions.smartWait(20);

			// Get the Flavor Set Name
			String validset = driver.findElement(By.xpath(actions.getLocator("Routing.Number"))).getText();
			System.out.println(validset);

			// Enter search string more than 60 characters.
			String strVal2;
			strVal2 = generateString('c', 61);
			System.out.println(strVal2.length());
			actions.clear("FlavorSet.SearchTextBox");
			actions.setValue("FlavorSet.SearchTextBox", strVal2);
			String charc = driver.findElement(By.xpath(actions.getLocator("FlavorSet.SearchTextBox")))
					.getAttribute("value");
			System.out.println(charc.length());
			if (charc.length() >= 60) {
				actions.reportCreatePASS("verify the whether Flavor Set search box accepected more than 60 Characters",
						"Flavor Set search box should be accepected more than 60 Characters",
						"Flavor Set search box should not be accepected more than 60 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether group name box accepected 60 characters",
						"Flavor Set search box should be accepected more than 60 Characters ",
						"Flavor Set search box should be accepected more than 60 Characters", "FAIL");
			}

			// Enter valid search criteria.
			actions.clear("FlavorSet.SearchTextBox");
			actions.setValue("FlavorSet.SearchTextBox", validset);
			actions.keyboardEnter("FlavorSet.SearchButton");
			actions.smartWait(20);
			if (mcd.GetTableRowCount("MenuItemGroup.Datatable") > 0) {

				String record_name = mcd.GetTableCellValue("MenuItemGroup.Datatable", 1, "Name", "", "");
				verify_search_result("contains", record_name, validset);
			}

			// Don�t select any field in filter section in result grid and hit
			// Enter button
			actions.clear("FlavorSet.SearchTextBox");
			actions.keyboardEnter("FlavorSet.SearchButton");
			actions.smartWait(20);
			actions.keyboardEnter("DimensionNameSets.FilterButton");
			if (mcd.VerifyAlertMessageDisplayed("Information", strWM1, true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + strWM1 + " 'is Present or not",
						strWM1 + " should be present", strWM1 + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + strWM1 + " 'is Present or not",
						strWM1 + " should be present", strWM1 + " is not present", "Fail");
			}

			// Select Status filter as "active" from the Status DDL.
			actions.clear("FlavorSet.SearchTextBox");
			actions.keyboardEnter("FlavorSet.SearchButton");
			actions.smartWait(20);
			actions.setValue("FlavorSet.ActiveInStatus", strstatus);
			actions.smartWait(10);
			if (mcd.GetTableRowCount("MenuItemGroup.Datatable") > 0) {

				String record_name = mcd.GetTableCellValue("MenuItemGroup.Datatable", 1, "Status", "", "");
				verify_search_result("contains", record_name, strstatus);
			}

			// click on "search" button
			actions.clear("FlavorSet.SearchTextBox");
			actions.keyboardEnter("FlavorSet.SearchButton");
			actions.smartWait(20);

			// Click on filter button without selecting any criteria
			actions.keyboardEnter("DimensionNameSets.FilterButton");
			if (mcd.VerifyAlertMessageDisplayed("Information", strWM1, true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + strWM1 + " 'is Present or not",
						strWM1 + " should be present", strWM1 + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + strWM1 + " 'is Present or not",
						strWM1 + " should be present", strWM1 + " is not present", "Fail");
			}

			// Click on Search button
			actions.clear("FlavorSet.SearchTextBox");
			actions.keyboardEnter("FlavorSet.SearchButton");
			actions.smartWait(20);
			
			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
	// To generate the string of specific size

	public static String generateString(char c, Integer n) {
		StringBuilder b = new StringBuilder();
		for (Integer x = 0; x < n; x++)
			b.append(c);
		return b.toString();
	}

	public void verify_search_result(String search_type, String record_name, String srchtxt) {
		switch (search_type) {

		case "max":
		case "invalid":

			break;
		case "null":

			break;
		case "contains":
			if (record_name.contains(srchtxt)) {
				actions.reportCreatePASS("Valdating the Search result with Special Character",
						"Should display Correct result", "Correct result is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Valdating the Search result", "Should display Correct result",
						"Correct results are not displayed", "Fail");
			}
			break;
		case "equal":
			if (record_name.equals(srchtxt)) {
				actions.reportCreatePASS("Valdating the Search result", "Should display Correct result" + srchtxt,
						"Correct result is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Valdating the Search result for" + srchtxt,
						"Should display Correct result for " + srchtxt, "Correct results are not displayed", "Fail");
			}
			break;
		case "filter":
			if (record_name.contains(srchtxt)) {

				actions.reportCreatePASS("Valdating the Search result with status filter",
						"Should display Correct result", "Correct results are displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Valdating the Search result with status filter",
						"Should display Correct result", "Correct results are not displayed", "Fail");
			}
			break;
		}

	}

}
