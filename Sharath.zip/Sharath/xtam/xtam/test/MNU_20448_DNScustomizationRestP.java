/** JIRA ID : RFM-4519 **/
package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.CSVValidations;

public class MNU_20448_DNScustomizationRestP {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private CSVValidations csv;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strNavigateTo_1;
	// TODO: Declare test-data variables for other data-parameters
	private String strRest;
	private boolean flag;
	private String setName;
	private String strErrmsg[];
	private String dtErr;
	private String strUserID;

	public MNU_20448_DNScustomizationRestP(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();
		csv = new CSVValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strNavigateTo_1 = mcd.GetTestData("DT_NAVIGATE_TO_1");
		// TODO: GetTestData for other data-parameters
		strRest = mcd.GetTestData("DT_Node");
		dtErr = mcd.GetTestData("DT_ERR_MSG");
		strUserID = mcd.GetTestData("DT_USER_NAME");

	}

	@Test
	public void test_MNU_20448_DNScustomizationRestP() throws InterruptedException {
		String strPageTitle = "Restaurant Profile"; // TODO: Exact page-title
		String strPageSubHeading = ""; // TODO: Page Heading

		try {
			System.out
					.println("********************************************************************** Test execution starts");
			
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			// actions.select_menu("RFMHome.Navigation",strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			Thread.sleep(3000);
			// actions.smartWait(5);
			actions.smartWait(10);
			/** Verify Page Header */
			System.out.println("> Verify Page Heading");
			strPageSubHeading = mcd.GetTestData("DT_PAGE_TITLE");
			mcd.VerifyPageHeading(strPageSubHeading, "SubHeading");

			/** Update title of new Page */
			mcd.waitAndSwitch("#Title");
			actions.waitForPageToLoad(120);
			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			actions.setTestcaseDescription("Verify the Customization of Dimension Name Set at Restaurant Profile and verify the Audit Log.");
			// ------------------------------------------------------------------------
			// Actions specific to test-flow

			/**
			 * Navigate to "Dimension Name Set" under Menu Item and Create New
			 * Dimension Name Set
			 */

			System.out.println("Start");

			strErrmsg = dtErr.split("#");

			actions.click("DimensionNameSet.NewDimensionSetButton");
			Thread.sleep(2000);
			actions.smartWait(5);
			mcd.waitAndSwitch("Dimension Name Sets");
			actions.click("DimensionNameSet.SelectButton");
			Thread.sleep(2000);
			mcd.waitAndSwitch("Select Node");
			mcd.Selectrestnode("SelectNode.Table", strRest);
			mcd.waitAndSwitch("Dimension Name Sets");
			actions.smartWait(100);

			do {

				boolean blnWindow = false;
				setName = mcd.fn_GetRndName("Auto_DNS");

				actions.clear("DimensionNameSet.SetNameTextBox");
				actions.setValue("DimensionNameSet.SetNameTextBox", setName);
				actions.click("DimensionNameSet.NextButton");
				Thread.sleep(1000);

				try {
					blnWindow = mcd.waitAndSwitch("@Dimension Name Set");
					if (blnWindow) {
						System.out.println("Menu Name and Number is accepted successfully");
						flag = false;
					} else {
						mcd.waitAndSwitch("Dimension Name Sets");
						if (actions.isTextPresence(strErrmsg[0], true)) {
							flag = true;
							System.out.println("Entered  number " + setName + " is already exist.");
							System.out.println(flag);
						}
					}

				} catch (Exception e) {
					if (actions.isTextPresence(strErrmsg[0], true)) {
						flag = true;
						System.out.println("Entered  number " + setName + " is already exist.");
						System.out.println(flag);
					}

				}

			} while (flag);

			/** Select Menu Option ADMIN> Restaurant Profile */
			System.out.println("> Navigate to :: " + strNavigateTo_1);
			actions.select_menu("RFMHome.Navigate", strNavigateTo_1);
			actions.smartWait(15);
			mcd.waitAndSwitch("#Title");

			// actions.click("DimensionNameSet.ViewFullListButton");
			// actions.keyboardEnter("RFM.SearchButton");
			// actions.smartWait(15);

			String restNum = mcd.GetTableCellValue("DimensionName.Table", 1, "Number", "", "");
			String restName = mcd.GetTableCellValue("DimensionName.Table", 1, "Name", "", "");
			WebElement Element = mcd.GetTableCellElement("DimensionName.Table", 1, "Number", "a");
			Element.click();
			actions.smartWait(25);

			// Select Operation Details tab
			actions.click("RestaurantProfile.OperationsDetailsTab");
			actions.smartWait(25);

			// Select Dimension Name DDL and Dimension Name set should be
			// selected and displayed in Dimension Name DDL
			actions.setValue("DimensionNameSet.RestProfile", setName);
			System.out.println("##############Set Name : " + setName);

			// Select 'View/Edit Settings' button
			actions.click("RestaurantProfile.ViewEditSetting");
			actions.smartWait(10);
			Thread.sleep(2000);

			mcd.SwitchToWindow("Dimension Name Set");

			flag = false;
			flag = mcd.fn_VerifyWebObjectsDisplayed("DimensionNameSets.ResetToDefault");
			if (flag) {
				System.out.println("> > > Reset to Default button is available");
			} else {
				actions.click("DimensionNameSet.CustomizeSettingButton");
				Thread.sleep(2000);
			}

			// Update Size Order
			boolean flag1;
			do {
				flag1 = false;
				int dnCode = mcd.fn_GetRndNumInRange(1, 99);
				String strSize = Integer.toString(dnCode);

				// mcd.SetTableCellValue("DimensionName.Table", 1, "Size Order",
				// strSize, "input", "value");
				driver.findElement(By.id("sizeOrder0")).sendKeys(strSize);
				Thread.sleep(3000);
				actions.click("SubstitutionGroups.ApplyButton");
				Thread.sleep(2000);

				try {
					driver.switchTo().alert();
					Thread.sleep(1890);
					if (mcd.VerifyAlertMessageDisplayed(
							"Are you sure you want to save changes to the current settings?",
							"Are you sure you want to save changes to the current settings?", true,
							AlertPopupButton.OK_BUTTON)) {
						flag1 = false;

						Thread.sleep(2000);

						System.out.println("> Click on OK button of Alert Box");
					}
					// ---// Included on 12/08/2016 warning message 4
					// "No Changes have been made.""
					else if (mcd.VerifyAlertMessageDisplayed("No Changes have been made.",
							"No Changes have been made.", true, AlertPopupButton.OK_BUTTON)) {
						flag1 = true;
					}
				} catch (Exception e) {
					Thread.sleep(2000);
				}
			} while (flag1 == true);

			// /US Market ----
			try {
				mcd.SwitchToWindow("Apply Changes Details");

				actions.smartWait(10);
				actions.click("ApplyChangesDetails.Save");
				Thread.sleep(2000);

				mcd.SwitchToWindow("Dimension Name Set");

				actions.smartWait(10);
			} catch (Exception e) {
				actions.smartWait(10);
				for (String winHandle : driver.getWindowHandles()) {
					driver.switchTo().window(winHandle);
					System.out.println(driver.switchTo().window(winHandle).getTitle());
				}

			}

			try {
				boolean flag2;
				flag2 = false;
				Thread.sleep(1890);
				// "//span[contains(text(),"+strErrmsg[2]+")]"
				flag2 = mcd.VerifyOnscreenMessage("SubstitutionGroups.InfoMessage", strErrmsg[2], true);

				if (flag2) {
					actions.reportCreatePASS("Verify the action message on screen", "Message '" + strErrmsg[2]
							+ "' should be displayed", "Message '" + strErrmsg[2] + "' is displayed", "PASS");
				} else {
					actions.reportCreateFAIL("Verify the action message on screen", "Message '" + strErrmsg[2]
							+ "' should be displayed", "Message '" + strErrmsg[2] + "' is displayed", "FAIL");
				}
			} catch (Exception e) {

			}
			String Title2;
			Title2 = actions.getPageTitle();

			actions.javaScriptClick("DimensionNameSet.CancelButton");

			// Thread.sleep(1000);
			mcd.SwitchToWindow("Restaurant Profile");

			// Verifying Audit logs//Included If else statments to handle Level
			// details
			// for US and APPNEA Market respctvly..11,August,2016

			boolean blnAudit = false;

			switch (strMarket) {
			case "US Country Office":
				String LevelDet = "Store [" + restNum + ", " + restName + "]";
				String LevelDetails = restNum + ", " + restName;
				String Level = "Store";
				Thread.sleep(2000);
				blnAudit = rfm.VerifyAuditLog_Entry(strPageTitle, "Update", LevelDet);
				if (blnAudit) {
					actions.reportCreatePASS("Verify Audit Log Entry for Restaurant Profile",
							"Audit log should be generated for Update Restaurant Profile",
							"Audit log generated for Update Restaurant Profile succesfully", "PASS");
				} else {
					actions.reportCreateFAIL("Verify Audit Log Entry for Update Restaurant Profile",
							"Audit log should be generated for Update Restaurant Profile",
							"Audit log not generated for Update Restaurant Profile succesfully", "FAIL");
				}

				String Desc = "The Customized Dimension Name Set " + setName
						+ " in the Current Settings of the Restaurant Profile " + restName + "(" + restNum
						+ ") has been updated.";
				// Get window handle

				blnAudit = RFM_VerifyAuditLog_Details_RN("RFM2", strUserID, strPageTitle, "Update", Level,
						LevelDetails, Desc);
				if (blnAudit) {
					actions.reportCreatePASS("Verify Audit Log Details for Update Restaurant Profile",
							"Audit log details should be generated for Update Restaurant Profile",
							"Audit log details generated for Restaurant Profile succesfully", "PASS");
				} else {
					actions.reportCreateFAIL("Verify Audit Log Details for Update Restaurant Profile",
							"Audit log details should be generated for Update Restaurant Profile",
							"Audit log details not generated for Restaurant Profile item succesfully", "FAIL");
				}

				break;
			default:
				String LevelDet1 = "Restaurant [" + restNum + ", " + restName + "]";
				String LevelDetails1 = restNum + ", " + restName;
				String Level1 = "Restaurant";
				Thread.sleep(2000);
				blnAudit = rfm.VerifyAuditLog_Entry(strPageTitle, "Update", LevelDet1);
				if (blnAudit) {
					actions.reportCreatePASS("Verify Audit Log Entry for Restaurant Profile",
							"Audit log should be generated for Update Restaurant Profile",
							"Audit log generated for Update Restaurant Profile succesfully", "PASS");
				} else {
					actions.reportCreateFAIL("Verify Audit Log Entry for Update Restaurant Profile",
							"Audit log should be generated for Update Restaurant Profile",
							"Audit log not generated for Update Restaurant Profile succesfully", "FAIL");
				}

				String Desc1 = "The Customized Dimension Name Set " + setName
						+ " in the Current Settings of the Restaurant Profile " + restName + "(" + restNum
						+ ") has been updated.";
				blnAudit = RFM_VerifyAuditLog_Details_RN("RFM2", strUserID, strPageTitle, "Update", Level1,
						LevelDetails1, Desc1);
				if (blnAudit) {
					actions.reportCreatePASS("Verify Audit Log Details for Update Restaurant Profile",
							"Audit log details should be generated for Update Restaurant Profile",
							"Audit log details generated for Restaurant Profile succesfully", "PASS");
				} else {
					actions.reportCreateFAIL("Verify Audit Log Details for Update Restaurant Profile",
							"Audit log details should be generated for Update Restaurant Profile",
							"Audit log details not generated for Restaurant Profile item succesfully", "FAIL");
				}

			}

			// Verify Audit Log ID in CSV file for Create operation
			String AuditLogId = rfm.GetAuditLogID(strPageTitle);
			mcd.GetTableCellElement("RFMHomePage.AuditLog", "Operations", strPageTitle, "", "", "Id", "a").sendKeys(
					Keys.ENTER);
			Thread.sleep(1000);
			mcd.waitAndSwitch("Manage Audit Log");
			VerifyAuditLogPrint();
			VerifyAuditLogCSV(AuditLogId, "Update");

			// ------------------------------------------------------------------------

			/** Logout the application */
			actions.smartWait(10);
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	// --------------------------------------------------------------------------------------------------------------//
	public String GetAuditLogID_RN(String strOperation) throws Exception {
		String strAuditLogID = "";
		try {

			// Read Audit Log ID
			strAuditLogID = mcd.GetTableCellValue("RFMHomePage.AuditLog", "Operations", strOperation, "", "", "Id",
					"a", "");
			Thread.sleep(1890);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return strAuditLogID;
	}

	public boolean RFM_VerifyAuditLog_Details_RN(String strDBName, String strUserID, String strOperation,
			String strActivity, String strLevel, String strNodeName, String strDescription) throws Exception {
		boolean blnReturn = true;
		try {

			/**
			 * commenting the code for navigation as it has already on the home
			 * page & to get the audit log we no longer need to navigate again
			 */

			// Open Audit-Log details
			String AuditLogID = GetAuditLogID_RN(strOperation);
			Thread.sleep(4890);
			mcd.GetTableCellElement("RFMHomePage.AuditLog", "Operations", strOperation, "", "", "Id", "a").click();
			String pgTitle = actions.getPageTitle();
			if (pgTitle.equals("Package Status Report")) {
				actions.select_menu("RFMHomePage.MainMenu", "HOME");
				actions.WaitForElementPresent("RFMHomePage.AuditLogDuration", 120);
				// Selecting the Audit Log duration
				actions.setValue("RFMHomePage.AuditLogDuration", "Today");
				mcd.GetTableCellElement("RFMHomePage.AuditLog", "Operations", strOperation, "", "", "Id", "a").click();
			}
			Thread.sleep(1890);
			mcd.waitAndSwitch("Manage Audit Log");

			/** Verify log details */
			blnReturn = blnReturn
					&& mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#1", "Id :", "", "", "#2",
							AuditLogID, "", "", true);

			blnReturn = blnReturn
					&& mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#1", "DB Name :", "", "", "#2",
							strDBName, "", "", true);

			blnReturn = blnReturn
					&& mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#3", "User :", "", "", "#4",
							strUserID, "", "", false);

			blnReturn = blnReturn
					&& mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#1", "Operation :", "", "", "#2",
							strOperation, "", "", true);

			blnReturn = blnReturn
					&& mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#3", "Activity :", "", "", "#4",
							strActivity, "", "", true);

			blnReturn = blnReturn
					&& mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#1", "Level :", "", "", "#2",
							strLevel, "", "", true);

			blnReturn = blnReturn
					&& mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#3", "Level Details :", "", "",
							"#4", strNodeName, "", "", false);

			blnReturn = blnReturn
					&& mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#1", "Description :", "", "", "#2",
							strDescription, "", "", true);

			/** Close Audit-Log window */
			actions.keyboardEnter("RFMHomePage.AuditLogDetailsOKButton");
			Thread.sleep(3890);
			// actions.windowSwitch(winHndManageAuditLog, "RFM - Home");
			mcd.SwitchToWindow("RFM - Home");

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return blnReturn;
		// ----------------------------------------------------------------------------------------------------------------///
	}

	// Functions to Verify Audit log functionality for Print and Save as CSV
	// File

	public void VerifyAuditLogPrint() {

		// Click print button, Print popup should be displayed
		try {

			WebElement printBtn = driver.findElement(By.xpath("//a[contains(text(),'Print')]"));
			actions.keyboardEnter(printBtn);
			Thread.sleep(5000);
			Alert myAlert = driver.switchTo().alert();
			Thread.sleep(2000);
			actions.reportCreatePASS("Click Print button", "Print Window should be displayed.",
					"Print Window is displayed.", "PASS");
			myAlert.dismiss();

		} catch (Exception error1) {
			System.out.println("Print Alert is not displayed");
		}

	}

	public void VerifyAuditLogCSV(String AuditLogId, String strOperation) {

		// Click Save as CSV file button and verify that Audit log Id is
		// displayed in CSV
		try {
			WebElement SaveCSVBtn = driver.findElement(By.xpath("//a[contains(text(),'Save as CSV File')]"));
			actions.javaScriptClick(SaveCSVBtn);
			Thread.sleep(3000);

			actions.ieDownload();
			Thread.sleep(3000);

			WebElement OKBtn = driver.findElement(By.xpath("//a[contains(text(),'OK')]"));
			actions.javaScriptClick(OKBtn);

			String targetData = "{\"Id\":\"" + AuditLogId + "\"}";

			boolean csvFlag = csv.validateColumnsData("AuditLogDetail.CSV", "Id", AuditLogId, targetData, false, true);

			System.out.println("CSV field validation = " + csvFlag);

			if (csvFlag)
				actions.reportCreatePASS("Verify AuditLogDetail.CSV file for " + strOperation + " operation.",
						"Auditlog Id should be displayed in CSV file.", "Auditlog Id is displayed in CSV file.", "PASS");
			else
				actions.reportCreateFAIL("Verify AuditLogDetail.CSV file for " + strOperation + " operation.",
						"Auditlog Id should be displayed in CSV file.", "Auditlog Id is not displayed in CSV file.",
						"FAIL");

			mcd.waitAndSwitch("@RFM - Home");
		} catch (Exception error2) {
			System.out.println("Failed to verify CSV file...");
		}

	}

}
