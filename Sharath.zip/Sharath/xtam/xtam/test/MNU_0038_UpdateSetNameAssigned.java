package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0038_UpdateSetNameAssigned {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo2;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String strmsg, strfilterbynode;

	public MNU_0038_UpdateSetNameAssigned(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strNavigateTo2 = mcd.GetTestData("DT_NAVIGATE_TO_2");
		// TODO: GetTestData for other data-parameters
		strmsg = mcd.GetTestData("DT_MSG");
		strfilterbynode = mcd.GetTestData("DT_FILTER");
	}

	@Test
	public void test_MNU_0038_UpdateSetNameAssigned() throws InterruptedException {
		String strPageTitle = "Restaurant Profile"; // TODO: Exact page-title
		String strTableElement = "RestaurantProfile.RestaurantProfileTable";
		String strSearchColumns = "Future Settings";
		String strSetName = "";
		String UpdatedName = "";
		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);
			Thread.sleep(3000);
			actions.waitForPageToLoad(120);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
			Thread.sleep(3000);
			actions.waitForPageToLoad(120);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(3000);
			actions.waitForPageToLoad(120);

			/** Verify Page Header */
			System.out.println("> Verify Page Title");
			new WebDriverWait(driver, 30).until(ExpectedConditions.titleContains(strPageTitle));
			mcd.VerifyPageTitle(strPageTitle);

			// ------------------------------------------------------------------------
			// Actions specific to test-flow

			/** TODO: Read name of Assigned menu item set */
			actions.waitForPageToLoad(120);
			actions.smartWait(60);
			actions.setValue("RestaurantProfile.StatusFilter", "Active");
			actions.waitForPageToLoad(120);
			actions.smartWait(60);
			// select restaurant
			WebElement eleRestNumber = mcd.GetTableCellElement(strTableElement, "Future Settings", "", "", "", "Number",
					"a");
			Thread.sleep(3000);
			eleRestNumber.click();
			Thread.sleep(3000);
			actions.waitForPageToLoad(120);
			actions.smartWait(60);
			actions.waitForPageToLoad(120);
			Reporter.log("Selected restaurant number-" + eleRestNumber);
			Reporter.log("Navigate to Menu Item/POS/Pricing Tab");
			Thread.sleep(5000);
			actions.waitForPageToLoad(120);
			actions.click("RestaurantProfile.MenuPOSPricing");
			Thread.sleep(5000);
			actions.waitForPageToLoad(120);
			actions.smartWait(60);
			if (uiActions.elementPresent(
					actions.getwebDriverLocator(actions.getLocator("RestaurantProfile.ChooseSetType")))) {
				Reporter.log("Choose Set type drop down value is present");
				actions.setValue("RestaurantProfile.ChooseSetType", "Menu Items");
				actions.waitForPageToLoad(120);
				actions.smartWait(60);
				Reporter.log("Menu Item Set selected from set type");

			} else {
				Reporter.log("Choose Set type drop down value is not dispalyed");
			}
			actions.waitForPageToLoad(120);
			String strTableElement2 = "UpdateRestaurant.AssignedTable";
			int rcnt2 = mcd.GetTableRowCount(strTableElement2);
			if (rcnt2 > 0) {
				strSetName = mcd.GetTableCellValue(strTableElement2, 1, 1, "", "");
			}
			Reporter.log("Current Assigned Menu Item set name is -" + strSetName);

			/**
			 * TODO: Navigate to Menu Item Set and Update set name of assigned
			 * set
			 */
			Thread.sleep(1000);
			actions.select_menu("RFMHome.Navigation", strNavigateTo2);
			actions.smartWait(180);
			/* actions.setValue("MenuItemSets.Searchfield", strSetName); */
			actions.click("MenuItemSets.SearchButton_New");

			/* actions.click("Menuitemset.search"); */
			actions.smartWait(20);
			actions.keyboardEnter("MenuItemSets.TableFirstValue");
			actions.smartWait(40);
			String strrndname = mcd.fn_GetRndName("Auto");
			actions.clear("MenuItemSets.NameField");
			actions.setValue("MenuItemSets.NameField", strrndname);
			actions.click("MenuItemSets.UpdateSave");
			actions.smartWait(10);
			boolean bln = actions.isTextPresence(strmsg, true);
			if (bln) {
				Reporter.log("Menu Item Set name changed succesfully");
				System.out.println("Menu Item Set name changed succesfully");
			} else {
				Reporter.log("Menu Item Set name Not changed.");
				System.out.println("Menu Item Set name Not changed.");
			}
			Thread.sleep(2000);
			Reporter.log("Updated Set Name is- " + strrndname);
			actions.click("MenuItemSets.ReturnToSet");
			Thread.sleep(2000);
			actions.waitForPageToLoad(5000);
			actions.smartWait(60);

			/**
			 * TODO: Navigate back to Restaurant Profile and verify the assigned
			 * set name updated
			 */
			/* Navigate to Menu item/pos/pricing tab */

			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(5000);
			actions.waitForPageToLoad(120);
			actions.smartWait(60);
			actions.setValue("RestaurantProfile.StatusFilter", "Active");
			Thread.sleep(3000);
			actions.waitForPageToLoad(120);
			actions.smartWait(60);
			// select restaurant
			WebElement eleRestNumber1 = mcd.GetTableCellElement(strTableElement, "Future Settings", "", "", "",
					"Number", "a");
			Thread.sleep(3000);
			eleRestNumber1.click();
			Thread.sleep(3000);
			actions.waitForPageToLoad(120);
			actions.smartWait(60);
			Reporter.log("Selected restaurant number-" + eleRestNumber1);
			Reporter.log("Navigate to Menu Item/POS/Pricing Tab");
			Thread.sleep(5000);
			actions.waitForPageToLoad(120);
			actions.forceClick("RestaurantProfile.MenuPOSPricing");
			Thread.sleep(5000);
			actions.waitForPageToLoad(120);
			actions.smartWait(60);
			if (uiActions.elementPresent(
					actions.getwebDriverLocator(actions.getLocator("RestaurantProfile.ChooseSetType")))) {
				Reporter.log("Choose Set type drop down value is present");
				actions.setValue("RestaurantProfile.ChooseSetType", "Menu Items");
				actions.waitForPageToLoad(120);
				actions.smartWait(60);
				Reporter.log("Menu Item Set selected from set type");

			} else {
				Reporter.log("Choose Set type drop down value is not dispalyed");
			}
			Thread.sleep(5000);
			actions.waitForPageToLoad(120);
			String strTableElement3 = "UpdateRestaurant.AssignedTable";
			int rcnt3 = mcd.GetTableRowCount(strTableElement3);
			if (rcnt3 > 0) {
				UpdatedName = mcd.GetTableCellValue(strTableElement3, 1, 1, "", "");
				Reporter.log("Updated set name is " + UpdatedName);
			}

			if (UpdatedName.equals(strrndname)) {
				Reporter.log("Updated set name is reflected in assigned list box of restaurant profile");
			} else {
				Reporter.log("Updated set name is not reflected in assigned list box of restaurant profile");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			/* rfm.Logout(); */

		} catch (Exception e) {
			// Reporter.log("Test Failed :: " + e.getCause() + " - " +
			// e.getMessage());
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}
