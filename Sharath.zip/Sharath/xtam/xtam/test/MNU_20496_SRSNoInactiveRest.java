package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20496_SRSNoInactiveRest {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strNavigateTo1;
	private String strSRSValue;
	private String stropewm;
	private String strErrorMessage;
	private String strRestNum;
	private boolean flag;

	public MNU_20496_SRSNoInactiveRest(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strNavigateTo1 = mcd.GetTestData("DT_NAVIGATE_TO1");
		strSRSValue = mcd.GetTestData("SRSValue");
		stropewm = mcd.GetTestData("DT_OperationWarningMes");
		strErrorMessage = mcd.GetTestData("ErrorMessage");
		strRestNum = mcd.GetTestData("DT_RestNum");
	}

	@Test
	public void test_MNU_20496_SRSNoInactiveRest() throws InterruptedException {
		String strPageTitle = "";
		String strPageSubHeading1 = "Smart Reminder Sets";
		String strPageSubHeading2 = "Restaurant Profile";

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"Verify that Smart Reminder Set cannot be made Inactive if it assigned to one or more restaurants");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
			actions.waitForPageToLoad(120);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo1);
			actions.select_menu("RFMHome.Navigation", strNavigateTo1);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Verify Page Header */
			System.out.println("> Verify Page Heading");
			mcd.VerifyPageHeading(strPageSubHeading1, "SubHeading");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Verify the Smart Reminder Set Page

			// Verify the Search text box
			actions.WaitForElementPresent("SmartReminderSet.SearchTextField", 100);
			boolean booDisplayed = driver.findElement(By.xpath(actions.getLocator("SmartReminderSet.SearchTextField")))
					.isDisplayed();
			System.out.println(booDisplayed);
			if (booDisplayed == true) {
				System.out.println("Present");
				actions.reportCreatePASS("Smart Reminder Set Search TextBox is Present",
						"Smart Reminder Set Search TextBox should Present",
						"Smart Reminder Set Search TextBox is Present", "Pass");
			} else {
				actions.reportCreateFAIL("Flavor Set Search TextBox is Present",
						"Smart Reminder Set Search TextBox should Present",
						"Smart Reminder Set Search TextBox is not Present", "Fail");
			}
			
			

			// verifying the presence of text "Search Full List By Smart Reminder Set Name"
			boolean booDisplayed1 = driver.findElement(By.xpath(actions.getLocator("SmartReminderSets.TextBoxName")))
					.isDisplayed();
			System.out.println(booDisplayed1);
			if (booDisplayed1 == true) {
				System.out.println("Present");
				actions.reportCreatePASS("Text 'Search Full List By Smart Reminder Set Name' is Present",
						"Text 'Search Full List By Smart Reminder Set Name' should Present",
						"Text 'Search Full List By Smart Reminder Set Name' is Present", "Pass");
			} else {
				actions.reportCreateFAIL("Text 'Search Full List By Smart Reminder Set Name' is Present",
						"Text 'Search Full List By Smart Reminder Set Name' should Present",
						"Text 'Search Full List By Smart Reminder Set Name' is not Present", "Fail");
			}
			
			

			// Verifying 'Search within Status' Filter
			Boolean SearchStatus;
			Select selObj = new Select(
					driver.findElement(By.xpath(actions.getLocator("SmartReminderSets.SearchByStatus"))));
			SearchStatus = selObj.getFirstSelectedOption().getText().trim().equalsIgnoreCase("Active/Inactive");
			reporting_Pass_Fail(
					"Verify whether Search within Status Active/Inactive is selected by default for Status DDL",
					"Search within Status Active/Inactive should be selected by default",
					"Search within Status Active/Inactive is selected by default",
					"Search within Status Active/Inactive is not selected by default", SearchStatus);

			
			
			// Verifying presence of 'Search' Button
			Boolean Searchbutton;
			Searchbutton = actions.isElementPresent("SmartReminderSets.SearchBtn");
			reporting_Pass_Fail("Verify whether 'Search' Button is present", "'Search' Button should be present",
					"'Search' Button is present", "'Search' Button is not present", Searchbutton);

			
			
			// Verifying presence of 'New Smart Reminder' Button
			Boolean Newsmartbutton;
			Newsmartbutton = actions.isElementPresent("SmartReminderSets.NewSmartReminderSet");
			reporting_Pass_Fail("Verify whether 'New Smart Reminder' Button is present",
					"'New Smart Reminder' Button should be present", "'New Smart Reminder' Button is present",
					"'New Smart Reminder' Button is not present", Newsmartbutton);

			
			
			// verifying the presence of column headers i.e. name, node, status,delete
			boolean booDisplayed5 = mcd.RFM_VerifyTableColumns("RFMHome.Table", "Name,Node,Status,Delete");
			System.out.println(booDisplayed5);
			if (booDisplayed5 == true) {
				System.out.println("Present");
				actions.reportCreatePASS("Column Headers 'Name,Node,Status,Delete' is Displayed",
						"Column Headers 'Name,Node,Status,Delete' should Displayed",
						"Column Headers 'Name,Node,Status,Delete' is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Column Headers 'Name,Node,Status,Delete' is Displayed",
						"Column Headers 'Name,Node,Status,Delete' should Displayed",
						"Column Headers 'Name,Node,Status,Delete' is not Displayed", "Fail");
			}
			
			

			// Create Smart Reminder set
			actions.click("SmartReminderSets.NewSmartReminderSet");
			mcd.waitAndSwitch("Smart Reminder Set");

			String strRandName = mcd.fn_GetRndName("Auto");
			System.out.println(strRandName);
			actions.setValue("NewScreenSet.SetName", strRandName);

			actions.click("NewScreenSet.SelectBtn");
			mcd.waitAndSwitch("Select Node");
			mcd.Selectrestnode_JavaScriptClk("RFMSelectNode.SelectNodeTable", strMarket);
			mcd.SwitchToWindow("Smart Reminder Set");
			actions.javaScriptClick("NewScreenSet.NoRadioBtn");
			actions.click("NewScreenSet.NextBtn");
			mcd.SwitchToWindow("@Smart Reminder Sets");
			actions.smartWait(30);

			// Verify on - screen message
			flag = mcd.VerifyOnscreenMessage("UpdateSmartreminderset.infomes1", "Set created successfully.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Set created successfully.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Set created successfully.'",
						"Expected Message is not displayed", "FAIL");
			}
			
			

			// Navigate to Restaurant Profile
			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");
			

			/** Verify Page Header */
			System.out.println("> Verify Page Heading");
			mcd.VerifyPageHeading(strPageSubHeading2, "SubHeading");
			

			// Selecting any Exit Restaurant
			actions.clear("RestaurantProfile.SearchStringRestNumber");
			actions.setValue("RestaurantProfile.SearchStringRestNumber", strRestNum);
			actions.javaScriptClick("RestMIList.ExactRadiobtn");
			actions.click("RFMQueueManagementPage.SearchButton");
			actions.smartWait(50);
			WebElement fisrtrest = mcd.GetTableCellElement("RFMProductionRoutingSetPage.RoutingTable", 1, "Number",
					"a");
			actions.click(fisrtrest);
			mcd.smartsync(40);
			

			// Click on Operational Details and Set Value in Smart Reminder DropDown
			actions.WaitForElementPresent("RestaurantProfile.OperationalDetails", 50);
			actions.keyboardEnter("RestaurantProfile.OperationalDetails");
			actions.waitForPageToLoad(120);
			actions.smartWait(100);
			actions.setValue("RestaurantProfile.SmartReminderDDL", strRandName);
			
			

			// Click on Apply Button and verify the on - Screen Message
			actions.keyboardEnter("RFMHome.Apply");
			
			try{
			// Switch to Apply Change Details window
			mcd.waitAndSwitch("Apply Changes Details");
			actions.keyboardEnter("ApplyChangesDetails.saveExportOptionSet");
			mcd.SwitchToWindow("@Title");
			}catch (Exception e){
				
			}
			
			try {
				if (mcd.VerifyAlertMessageDisplayed("Information", stropewm, true, AlertPopupButton.OK_BUTTON)) {
					actions.reportCreatePASS("Veriyfing the '" + stropewm + " 'is Present or not",
							stropewm + " should be present", stropewm + " is present", "Pass");
				} else {
					actions.reportCreateFAIL("Veriyfing the '" + stropewm + " 'is Present or not",
							stropewm + " should be present", stropewm + " is not present", "Fail");
				}

			} catch (Exception e) {

			}
			actions.smartWait(15);
			flag = mcd.VerifyOnscreenMessage("UpdateRestaurant.InfoMess", "Your changes have been saved.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}
			
			
			

			// Navigate Smart Reminder Set
			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo1);
			actions.select_menu("RFMHome.Navigation", strNavigateTo1);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Verify Page Header */
			System.out.println("> Verify Page Heading");
			mcd.VerifyPageHeading(strPageSubHeading1, "SubHeading");
			
			

			// Open Exiting Set and change status active to inactive
			actions.clear("SmartReminderSet.SearchTextField");
			actions.setValue("SmartReminderSet.SearchTextField", strRandName);
			actions.click("SmartReminderSets.SearchBtn");
			actions.smartWait(80);
			actions.click("SmartReminderGroup.TableFirstValue");
			mcd.smartsync(40);
			actions.setValue("UpdateSmartReminderSets.Status", "Inactive");
			actions.smartWait(80);
			
			

			// Click on save button and verify the on - screen message
			actions.keyboardEnter("UpdateSmartReminderSets.SaveButton");
			actions.smartWait(10);
			flag = mcd.VerifyOnscreenMessage("UpdateSmartreminderset.infomes",
					"The Set you have chosen to deactivate is assigned to one or more Restaurants. You must remove the Set assignment from all the Restaurants in order to deactivate the Set.",
					true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message",
						"The Set you have chosen to deactivate is assigned to one or more Restaurants. You must remove the Set assignment from all the Restaurants in order to deactivate the Set.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message",
						"Message 'The Set you have chosen to deactivate is assigned to one or more Restaurants. You must remove the Set assignment from all the Restaurants in order to deactivate the Set.'",
						"Expected Message is not displayed", "FAIL");
			}
			actions.smartWait(20);
			
			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	// Function for Reporting Pass/Fail
	public void reporting_Pass_Fail(String Desc, String ExpRes, String ActRes_Pass, String ActRes_Fail,
			Boolean status) {
		if (status) {
			actions.reportCreatePASS(Desc, ExpRes, ActRes_Pass, "PASS");
		}

		if (!status) {
			actions.reportCreateFAIL(Desc, ExpRes, ActRes_Fail, "FAIL");
		}
	}
}
