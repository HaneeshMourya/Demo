package xtam.test;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class MNU_20461_Vrf_Deleting_SubstGrp {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// Declare test-data variables for other data-parameters
	private boolean flag;
	private String sgName;
	private String sgNameUpdated;
	private String sgName_Inactive, strMessage, strTestDescription;
	private String strOperation, strActivity, strLevel, strUID, strDBName;

	public MNU_20461_Vrf_Deleting_SubstGrp(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// GetTestData for other data-parameters
		strOperation = mcd.GetTestData("DT_OPERATION");
		strActivity = mcd.GetTestData("DT_ACTIVITY");
		strLevel = mcd.GetTestData("DT_LEVEL");
		strDBName = mcd.GetTestData("DT_DBNAME");
		strUID = mcd.GetTestData("DT_USERID");
		strMessage = mcd.GetTestData("DT_MESSAGE");
		strTestDescription = mcd.GetTestData("DT_Description");
	}

	@Test
	public void test_MNU_20461_Vrf_Deleting_SubstGrp() throws InterruptedException {

		try {
			System.out.println("********************************* Test execution starts");

			/** Get Test Case Description */
			actions.setTestcaseDescription(strTestDescription);

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Navigate to Substitution Groups */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			String[] strMsg = strMessage.split("#");

			// Select the first available Substitution Group to verify 'Unsaved
			// data' message
			actions.keyboardEnter("RestaurantSet.Searchbtn");
			mcd.smartsync(150);
			sgName = mcd.GetTableCellValue("SubstitutionGroups.Table", 1, "Group Name", "", "");
			System.out.println("> > > > >" + sgName);
			WebElement Element = mcd.GetTableCellElement("SubstitutionGroups.Table", 1, "Group Name", "a");
			actions.keyboardEnter(Element);
			mcd.smartsync(150);
			sgNameUpdated = mcd.fn_GetRndName("Auto_SG_Updt");
			actions.clear("SubstitutionGroups.SubstitutionGroupName");
			actions.setValue("SubstitutionGroups.SubstitutionGroupName", sgNameUpdated);
			actions.click("SubstitutionGroups.CancelButton");

			// Validating 'Unsaved data will be lost' message
			flag = mcd.VerifyAlertMessageDisplayed("Warning", strMsg[0], true, AlertPopupButton.CANCEL_BUTTON);
			if (flag) {
				actions.reportCreatePASS("Verify " + strMsg[0] + " message", strMsg[0] + " should be displayed",
						strMsg[0] + " is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify " + strMsg[0] + " message", strMsg[0] + " should be displayed",
						strMsg[0] + " is not displayed", "FAIL");
			}
			actions.click("SubstitutionGroups.CancelButton");
			boolean flag1;
			flag1 = mcd.VerifyAlertMessageDisplayed("Warning", strMsg[0], true, AlertPopupButton.OK_BUTTON);
			if (flag1) {
				actions.reportCreatePASS("Verify " + strMsg[0] + " message", strMsg[0] + " should be displayed",
						strMsg[0] + " is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify " + strMsg[0] + " message", strMsg[0] + " should be displayed",
						strMsg[0] + " is not displayed", "FAIL");
			}

			try {
				// Deleting an Inactive Substitution Group and also validating
				// 'confirmation alert message' for deleting
				actions.WaitForElementPresent("SubstitutionGroups.StatusDDL");
				actions.setValue("SubstitutionGroups.StatusDDL", "Inactive");
				mcd.smartsync(100);
				sgName_Inactive = mcd.GetTableCellValue("SubstitutionGroups.Table", 1, "Group Name", "", "");
				System.out.println("> > > > >" + sgName_Inactive);
				Element = mcd.GetTableCellElement("SubstitutionGroups.Table", 1, "Delete", "a");
				actions.click(Element);
				Thread.sleep(1000);
				flag = mcd.VerifyAlertMessageDisplayed("Warning", strMsg[1], true, AlertPopupButton.CANCEL_BUTTON);
				if (flag) {
					actions.reportCreatePASS("Verify " + strMsg[1] + " message", strMsg[1] + " should be displayed",
							strMsg[1] + " is displayed", "PASS");
				} else {
					actions.reportCreateFAIL("Verify " + strMsg[1] + " message", strMsg[1] + " should be displayed",
							strMsg[1] + " is not displayed", "FAIL");
				}

				actions.click(Element);
				boolean flag2;
				flag2 = mcd.VerifyAlertMessageDisplayed("Warning", strMsg[1], true, AlertPopupButton.OK_BUTTON);
				if (flag2) {
					actions.reportCreatePASS("Verify " + strMsg[1] + " message", strMsg[1] + " should be displayed",
							strMsg[1] + " is displayed", "PASS");
				} else {
					actions.reportCreateFAIL("Verify " + strMsg[1] + " message", strMsg[1] + " should be displayed",
							strMsg[1] + " is not displayed", "FAIL");
				}
				mcd.smartsync(180);

				// Validating Delete successful alert message
				boolean flag3;
				flag3 = mcd.VerifyOnscreenMessage("SubstitutionGroups.InfoMessage", strMsg[2], true);
				if (flag3) {
					actions.reportCreatePASS("Verify " + strMsg[2] + " message", strMsg[2] + " should be displayed",
							strMsg[2] + " is displayed", "PASS");
				} else {
					actions.reportCreateFAIL("Verify " + strMsg[2] + " message", strMsg[2] + " should be displayed",
							strMsg[2] + " is not displayed", "FAIL");
				}
			} catch (Exception e) {
				actions.reportCreateFAIL("Verify Inactive Substitution Groups in the application",
						"Inactive Substitution Groups should be available",
						"Inactive Substitution Groups are not available", "Fail");
			}

			// Verifying the audit logs for delete operation of Substitution
			// Groups
			boolean blnAudit = false;
			blnAudit = rfm.VerifyAuditLog_Entry(strOperation, strActivity, strLevel);
			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Entry for Delete Substitution Group",
						"Audit log should be generated for Delete Substitution group",
						"Audit log generated for Delete Substitution group succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Entry for Delete Substitution Group",
						"Audit log should be generated for Delete Substitution group",
						"Audit log not generated for Delete Substitution group succesfully", "FAIL");
			}

			blnAudit = rfm.RFM_VerifyAuditLog_Details(strDBName, strUID, strOperation, strActivity, strLevel, strMarket,
					"Substitution Group " + sgName_Inactive + " has been deleted.");
			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Details for delete Substitution Group",
						"Audit log details should be generated for delete Substitution group",
						"Audit log details generated for Substitution group item succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Details for delete Substitution Group",
						"Audit log details should be generated for delete Substitution group",
						"Audit log details not generated for Substitution group item succesfully", "FAIL");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			// reporting the Fail condition
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}
