package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Keywords.DialogType;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0257_DeleteFunctinalityOfIG {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// Declare test-data variables for other data-parameters
	private String strMinQty;
	private String strMaxQty;
	private String strMessage;
	private String strTestDescription;
	private String strOperation, strActivity, strLevel, strUID, strDBName;

	public MNU_0257_DeleteFunctinalityOfIG(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// GetTestData for other data-parameters
		strMinQty = mcd.GetTestData("DT_IG_MIN_QTY");
		strMaxQty = mcd.GetTestData("DT_IG_MAX_QTY");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strActivity = mcd.GetTestData("DT_ACTIVITY");
		strLevel = mcd.GetTestData("DT_LEVEL");
		strDBName = mcd.GetTestData("DT_DBNAME");
		strUID = mcd.GetTestData("DT_USERID");
		strTestDescription = mcd.GetTestData("DT_Description");
		strMessage = mcd.GetTestData("DT_MESSAGES");
	}

	@Test
	public void test_MNU_0257_DeleteFunctinalityOfIG() throws InterruptedException {

		try {
			System.out.println("******************************* Test execution starts");

			/** Get Test Case Description */
			actions.setTestcaseDescription(strTestDescription);

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Navigate to Ingredient Groups */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			String[] StrMsg = strMessage.split("#");
			boolean flag = false;
			String IG_Name = "";

			// Creating a New Ingredient to verify the delete functionality in
			// further steps
			actions.click("IngredientGroup.NewIngredientGroupButton");
			Thread.sleep(1000);
			WebElement EleIGName = mcd.GetTableCellElement("IngredientGroup.Table", 1, "Name", "input");
			WebElement EleSelect1 = mcd.GetTableCellElement("IngredientGroup.Table", 1, "Select Only 1", "input");
			EleSelect1.sendKeys(Keys.SPACE);
			// Enter Quantity
			List<WebElement> eleQuantfields = driver
					.findElements(By.xpath(actions.getLocator("IngredientGrp.QuantityFields")));
			// Enter Minimum Quantity
			WebElement eleIGQuantityMin = eleQuantfields.get(0);
			// Enter Maximum Quantity
			WebElement eleIGQuantityMax = eleQuantfields.get(1);
			eleIGQuantityMin.sendKeys(strMinQty);
			eleIGQuantityMax.sendKeys(strMaxQty);
			do {
				EleIGName.clear();
				IG_Name = mcd.fn_GetRndName("IG");
				IG_Name = IG_Name.replace("_", "");
				EleIGName.sendKeys(IG_Name);
				actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
				actions.keyboardEnter("IngredientGroup.SaveButton");
				mcd.smartsync(180);
				try {
					flag = mcd.VerifyAlertMessageDisplayed("Information", StrMsg[0], true, AlertPopupButton.OK_BUTTON);
				} catch (Exception e) {
					System.out.println("Name and Number accepted successfully");
					flag = false;
				}
			} while (flag);

			// Searching and deleting the newly created Ingredient Group
			List<WebElement> list = driver.findElements(By.xpath(actions.getLocator("IngredientGroup.TableRowsCount")));
			int rowCount = list.size();
			rowCount = rowCount - 2;
			String value = "";
			for (int i = 1; i <= rowCount; i++) {
				value = mcd.GetTableCellValue("IngredientGroup.Table", i, "Name", "input[6]", "value");
				if (value.equals(IG_Name)) {
					WebElement Element = mcd.GetTableCellElement("IngredientGroup.Table", i, "Delete", "a");
					actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
					Element.sendKeys(Keys.ENTER);
					Thread.sleep(5000);
					// Verifying the confirmation message for deleting the
					// Ingredient group
					flag = mcd.VerifyAlertMessageDisplayed("Warning", StrMsg[1], true, AlertPopupButton.OK_BUTTON);
					mcd.smartsync(180);
					break;
				} else {
					flag = false;
				}
			}
			// Validating the confirmation message for deleting the
			// Ingredient group
			if (flag) {
				actions.reportCreatePASS("Verify " + StrMsg[1], StrMsg[1] + " should be displayed",
						StrMsg[1] + " is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify " + StrMsg[1], StrMsg[1] + " should be displayed",
						StrMsg[1] + " is not displayed", "Fail");
			}

			// Validating the deletion successful message
			boolean flag1;
			flag1 = mcd.VerifyOnscreenMessage("IngredientGroup.InfoMessage", StrMsg[2], true);
			if (flag1) {
				actions.reportCreatePASS("Verify the onscreen message",
						"Message'Delete has been successfully completed.' should be displayed",
						"Delete Successful Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the onscreen message",
						"Message'Delete has been successfully completed.' should be displayed",
						"Delete Successful Message is not displayed", "FAIL");
			}

			// Verify Audit log for Deleting an Ingredient Group
			Boolean blnAudit = false;
			blnAudit = rfm.VerifyAuditLog_Entry(strOperation, strActivity, strLevel);
			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Entry for Delete Ingredient Group",
						"Audit log should be generated for Delete ingredient group",
						"Audit log generated for Delete ingredient group succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Entry for Delete Ingredient Group",
						"Audit log should be generated for Delete ingredient group",
						"Audit log not generated for Delete ingredient group succesfully", "FAIL");
			}
			blnAudit = rfm.RFM_VerifyAuditLog_Details(strDBName, strUID, strOperation, strActivity, strLevel, strMarket,
					"Ingredient Group " + IG_Name + " has been deleted.");
			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Details for Delete Ingredient Group",
						"Audit log details should be generated for deleted ingredient group",
						"Audit log details generated for ingredient group item succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Details for Create Ingredient Group",
						"Audit log details should be generated for created ingredient group",
						"Audit log details not generated for ingredient group item succesfully", "FAIL");
			}

			/** Logout the application */
			rfm.Logout();
		} catch (Exception e) {
			// reporting the Fail condition
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}
