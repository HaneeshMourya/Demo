package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20515_FSFieldSpecifitn {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters

	public MNU_20515_FSFieldSpecifitn(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
	}

	@Test
	public void test_MNU_20515_FSFieldSpecifitn() throws InterruptedException {
		String strPageTitle = ""; // TODO: Exact page-title
		String strPageSubHeading = "Flavor Set"; // TODO: Page Heading

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription("Verify the field specifications in the Flavor Set page");
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Verify Page Header */
			System.out.println("> Verify Page Heading");
			mcd.VerifyPageHeading(strPageSubHeading, "SubHeading");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// verifying if the search text box is displayed
			actions.WaitForElementPresent("FlavorSet.SearchTextBox", 100);
			boolean booDisplayed = driver.findElement(By.xpath(actions.getLocator("FlavorSet.SearchTextBox")))
					.isDisplayed();
			System.out.println(booDisplayed);
			if (booDisplayed == true) {
				System.out.println("Present");
				actions.reportCreatePASS("Flavor Set Search TextBox is Present",
						"Flavor Set Search TextBox should Present", "Flavor Set Search TextBox is Present", "Pass");
			} else {
				actions.reportCreateFAIL("Flavor Set Search TextBox is Present",
						"Flavor Set Search TextBox should Present", "Flavor Set Search TextBox is not Present", "Fail");
			}
			

			// verifying the presence of text "Search Full List by Flavor Set name"
			boolean booDisplayed1 = driver.findElement(By.xpath(actions.getLocator("FlavorSet.SearchHintMessage")))
					.isDisplayed();
			System.out.println(booDisplayed1);
			if (booDisplayed1 == true) {
				System.out.println("Present");
				actions.reportCreatePASS("Text 'Search Full List by Flavor Set Name' is Present",
						"Text 'Search Full List by Flavor Set Name' should Present",
						"Text 'Search Full List by Flavor Set Name' is Present", "Pass");
			} else {
				actions.reportCreateFAIL("Text 'Search Full List by Flavor Set Name' is Present",
						"Text 'Search Full List by Flavor Set Name' should Present",
						"Text 'Search Full List by Flavor Set Name' is not Present", "Fail");
			}
			

			// verifying the presence of Search button
			boolean booDisplayed2 = driver.findElement(By.xpath(actions.getLocator("FlavorSet.SearchButton")))
					.isDisplayed();
			System.out.println(booDisplayed2);
			if (booDisplayed2 == true) {
				System.out.println("Present");
				actions.reportCreatePASS("Search Button is Present", "Search Button should Present",
						"Search Button is Present", "Pass");
			} else {
				actions.reportCreateFAIL("Search Button is Present", "Search Button should Present",
						"Search Button is not Present", "Fail");
			}
			

			// Verifying 'Search within Status' Filter
			Boolean SearchStatus;
			Select selObj = new Select(driver.findElement(By.xpath(actions.getLocator("FlavorSet.Status"))));
			SearchStatus = selObj.getFirstSelectedOption().getText().trim().equalsIgnoreCase("Active/Inactive");
			reporting_Pass_Fail(
					"Verify whether Search within Status Active/Inactive is selected by default for Status DDL",
					"Search within Status Active/Inactive should be selected by default",
					"Search within Status Active/Inactive is selected by default",
					"Search within Status Active/Inactive is not selected by default", SearchStatus);
			

			// Verify the Status Dropdown should be disabled
			if (!(actions.isElementEnabled("FlavorSet.ActiveInStatus"))) {
				actions.reportCreatePASS("verify the 'Status Dropdown' is disable",
						"Status Dropdown is disable",
						"Status Dropdown should be disable", "Pass");

			} else {

				actions.reportCreateFAIL("verify the 'Status Dropdown' is disable",
						"Status Dropdown is disable",
						"Status Dropdown should not be disable", "Fail");
			}
			

			// verifying the presence of new flavor button
			boolean booDisplayed4 = driver.findElement(By.xpath(actions.getLocator("FlavorSet.NewFlavorSet")))
					.isDisplayed();
			System.out.println(booDisplayed4);
			if (booDisplayed4 == true) {
				System.out.println("Present");
				actions.reportCreatePASS("New Flavor Set Button is Present", "New Flavor Set Button should Present",
						"New Flavor Set Button is Present", "Pass");
			} else {
				actions.reportCreateFAIL("New Flavor Set Button is Present", "New Flavor Set Button should Present",
						"New Flavor Set Button is not Present", "Fail");
			}
			

			// verifying the presence of column headers i.e. name, node, status, delete
			boolean booDisplayed5 = mcd.RFM_VerifyTableColumns("RFMHome.Table", "Name,Node,Status,Delete");
			System.out.println(booDisplayed5);
			if (booDisplayed5 == true) {
				System.out.println("Present");
				actions.reportCreatePASS("Column Headers 'Name,Node,Status,Delete' is Displayed",
						"Column Headers 'Name,Node,Status,Delete' should Displayed",
						"Column Headers 'Name,Node,Status,Delete' is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Column Headers 'Name,Node,Status,Delete' is Displayed",
						"Column Headers 'Name,Node,Status,Delete' should Displayed",
						"Column Headers 'Name,Node,Status,Delete' is not Displayed", "Fail");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	// Function for Reporting Pass/Fail
	public void reporting_Pass_Fail(String Desc, String ExpRes, String ActRes_Pass, String ActRes_Fail,
			Boolean status) {
		if (status) {
			actions.reportCreatePASS(Desc, ExpRes, ActRes_Pass, "PASS");
		}

		if (!status) {
			actions.reportCreateFAIL(Desc, ExpRes, ActRes_Fail, "FAIL");
		}
	}
}
