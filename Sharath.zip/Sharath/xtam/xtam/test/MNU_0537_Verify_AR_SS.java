package xtam.test;

import java.util.List;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.openqa.selenium.WebElement;

import crossbrowser.library.Keywords;
import crossbrowser.library.PackageValidation;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.XMLValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0537_Verify_AR_SS {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strNavigateMMIL;
	private String strwm, ExpectWM[];
	private boolean flag;
	private String strOperation, StrActivity, StrLevel, StrLevedetails, strDBName, strUserID;
	// TODO: Declare test-data variables for other data-parameters

	public MNU_0537_Verify_AR_SS(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strwm = mcd.GetTestData("DT_WarningMessages");
		StrLevel = mcd.GetTestData("DT_LEVEL");
		StrLevedetails = mcd.GetTestData("DT_LevelDetails");
		StrActivity = mcd.GetTestData("DT_ACTIVITY");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strDBName = mcd.GetTestData("DT_DBNAME");
		strUserID = mcd.GetTestData("DT_USER_NAME");
		strNavigateMMIL = mcd.GetTestData("DT_NaviagteMMIL");
		// TODO: GetTestData for other data-parameters
		ExpectWM = strwm.split("#");
	}

	@Test
	public void test_MNU_0537_Verify_AR_SS() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(
					"Verify the functionality of Remove association on Add/Remove Secondary screen.");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Click on remove icon for any menu item which is not a part of
			// promotion association.
			actions.click("Category.FirstYellowArrow");
			actions.smartWait(10);
			actions.click("Category.TableFirstRowThirdLevelArrowNew");
			actions.smartWait(10);
			actions.click("Category.TableFirstRowThirdLevelLink");
			actions.smartWait(10);
			actions.click("Category.MenuitemDlt");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[0], true, AlertPopupButton.CANCEL_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[0] + " 'is Present or not",
						ExpectWM[0] + " should be present", ExpectWM[0] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[0] + " 'is Present or not",
						ExpectWM[0] + " should be present", ExpectWM[0] + " is not present", "Fail");
			}
			actions.smartWait(5);
			actions.click("Category.MenuitemDlt");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[0], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[0] + " 'is Present or not",
						ExpectWM[0] + " should be present", ExpectWM[0] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[0] + " 'is Present or not",
						ExpectWM[0] + " should be present", ExpectWM[0] + " is not present", "Fail");
			}
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[1], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[1] + " 'is Present or not",
						ExpectWM[1] + " should be present", ExpectWM[1] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[1] + " 'is Present or not",
						ExpectWM[1] + " should be present", ExpectWM[1] + " is not present", "Fail");
			}

			// Verify the on-screen message
			actions.smartWait(5);
			flag = mcd.VerifyOnscreenMessage("Category.SaveMessage", "Your changes have been saved.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Click on Cancel Button
			actions.smartWait(5);
			List<WebElement> Cancel = driver.findElements(By.xpath(actions.getLocator("ManageMenuItem.Cancelbtn1")));
			actions.keyboardEnter(Cancel.get(0));
			actions.smartWait(10);

			// Click on remove icon for any menu item which is not a part of
			// promotion association.
			actions.click("Category.FirstYellowArrow");
			actions.smartWait(10);
			actions.click("Category.TableFirstRowThirdLevelArrowNew");
			actions.smartWait(10);
			actions.click("Category.TableFirstRowThirdLevelLink");
			actions.smartWait(10);
			String Menuitem = driver.findElement(By.xpath(actions.getLocator("Category.MenuItemText"))).getText();
			System.out.println(Menuitem);
			actions.click("Category.MenuitemDlt");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[0], true, AlertPopupButton.CANCEL_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[0] + " 'is Present or not",
						ExpectWM[0] + " should be present", ExpectWM[0] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[0] + " 'is Present or not",
						ExpectWM[0] + " should be present", ExpectWM[0] + " is not present", "Fail");
			}
			actions.smartWait(5);
			actions.click("Category.MenuitemDlt");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[0], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[0] + " 'is Present or not",
						ExpectWM[0] + " should be present", ExpectWM[0] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[0] + " 'is Present or not",
						ExpectWM[0] + " should be present", ExpectWM[0] + " is not present", "Fail");
			}
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[1], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[1] + " 'is Present or not",
						ExpectWM[1] + " should be present", ExpectWM[1] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[1] + " 'is Present or not",
						ExpectWM[1] + " should be present", ExpectWM[1] + " is not present", "Fail");
			}

			// Verify the on-screen message
			actions.smartWait(5);
			flag = mcd.VerifyOnscreenMessage("Category.SaveMessage", "Your changes have been saved.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Click on Cancel Button
			actions.smartWait(5);
			List<WebElement> Cancell = driver.findElements(By.xpath(actions.getLocator("ManageMenuItem.Cancelbtn1")));
			actions.keyboardEnter(Cancell.get(0));
			actions.smartWait(10);

			// Verify the Audit log Details
			boolean AuditlogCorrectValuesDisplayed1 = rfm.VerifyAuditLog_Entry(strOperation, StrActivity, StrLevel);

			if (AuditlogCorrectValuesDisplayed1) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "strExpectActivity[1],Level",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation," + "ActivityValue,Level",
						"Correct values are not displayed", "Fail");
			}

			String AuditDescc = "Associated Menu Item has been DELETED.";

			boolean isAuditlogCorrectValuesDisplayed1 = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID,
					strOperation, StrActivity, StrLevel, StrLevedetails, AuditDescc);

			if (isAuditlogCorrectValuesDisplayed1) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are not displayed", "Fail");
			}

			// Navigate Category
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			// Click on remove icon for any menu item which is not a part of
			// promotion association.
			actions.click("Category.FirstYellowArrow");
			actions.smartWait(10);
			actions.click("Category.TableFirstRowThirdLevelArrowNew");
			actions.smartWait(10);
			actions.click("Category.TableFirstRowThirdLevelLink");
			actions.smartWait(10);
			String Menuitemnum = driver.findElement(By.xpath(actions.getLocator("Category.MenuItemText"))).getText();
			System.out.println(Menuitemnum);
			actions.click("Category.MenuitemDlt");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[0], true, AlertPopupButton.CANCEL_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[0] + " 'is Present or not",
						ExpectWM[0] + " should be present", ExpectWM[0] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[0] + " 'is Present or not",
						ExpectWM[0] + " should be present", ExpectWM[0] + " is not present", "Fail");
			}
			actions.smartWait(5);
			actions.click("Category.MenuitemDlt");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[0], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[0] + " 'is Present or not",
						ExpectWM[0] + " should be present", ExpectWM[0] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[0] + " 'is Present or not",
						ExpectWM[0] + " should be present", ExpectWM[0] + " is not present", "Fail");
			}
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[1], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[1] + " 'is Present or not",
						ExpectWM[1] + " should be present", ExpectWM[1] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[1] + " 'is Present or not",
						ExpectWM[1] + " should be present", ExpectWM[1] + " is not present", "Fail");
			}

			// Verify the on-screen message
			actions.smartWait(5);
			flag = mcd.VerifyOnscreenMessage("Category.SaveMessage", "Your changes have been saved.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}
			
			// Click on Cancel Button
			actions.smartWait(5);
			List<WebElement> Cancel1 = driver.findElements(By.xpath(actions.getLocator("ManageMenuItem.Cancelbtn1")));
			actions.keyboardEnter(Cancel1.get(0));
			actions.smartWait(10);

			// Navigate to Master Menu Item List
			mcd.SwitchToWindow("#Title");
			System.out.println("> Navigate to :: " + strNavigateMMIL);
			actions.select_menu("RFMHome.Navigation", strNavigateMMIL);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");
			
			// Search and select the menu item which one deleted at the category page
			actions.clear("ManageMenuItems.SearchText");
			actions.setValue("ManageMenuItems.SearchText", Menuitemnum.split(" ")[0]);
			actions.keyboardEnter("ManageMenuItem.searchButton");
			actions.smartWait(20);
			WebElement menuitemnu = mcd.GetTableCellElement("ManageMenuItemCurrentMenuItemDetails.tableListPara", 1, "Number", "a");
			actions.keyboardEnter(menuitemnu);
			actions.smartWait(20);
			
			// Navigate Promotion Association Tab
			actions.keyboardEnter("ManageMenuItem.PromoAsso");
			actions.smartWait(10);
			Thread.sleep(1000);
			
			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}
