package xtam.test;

import java.util.Map;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.MasterMenuItem;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0197_Copy_ExistingMI {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private MasterMenuItem mmi;
	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo, strprotype, strMIrange, strmsg, strparam, pro_type[], strtitle, mirange[], ermsg[];
	// TODO: Declare test-data variables for other data-parameters

	private int created_menunumber;

	public MNU_0197_Copy_ExistingMI(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		mmi = new MasterMenuItem(driver, actions, uiActions, inputData, mcd, rfm);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");

		// TODO: GetTestData for other data-parameters
		strtitle = mcd.GetTestData("DT_PageTitle");
		strprotype = mcd.GetTestData("DT_MENUITEMCLASS");
		strMIrange = mcd.GetTestData("DT_MIRANGE");
		strmsg = mcd.GetTestData("DT_ERR_MSG");
		strparam = mcd.GetTestData("DT_MIPARAM");

		pro_type = strprotype.split("#");
		mirange = strMIrange.split("#");
		ermsg = strmsg.split("#");

	}

	@Test
	public void test_MNU_0197_Copy_ExistingMI() throws InterruptedException {
		boolean blnflag = false;
		String description = "Create a menu item by using copy settings from existing functionality";

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			// setting the description now
			actions.setTestcaseDescription(description);

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			actions.smartWait(30); // added as after menu selection we need to
									// handle loading

			// switching the window
			mcd.SwitchToWindow("#Title");

			// Getting the all records
			actions.click("MasterMenuItemList.Searchbtn");

			// waiting for the list to load in the data table
			actions.smartWait(180);

			// reading the first menu item name
			String menu_name = mcd.GetTableCellValue("MasterMenuItemList.datatable", 1, "Name", "", "");

			// clicking on the Add new button
			actions.click("MasterMenuItemList.AddNew");

			// switching to new window
			mcd.SwitchToWindow("Add New Menu Item");

			// Copying the menu Item number now
			actions.click("AddNewMI.Yes_rbtn");

			// clicking on the select button
			actions.click("AddNewMI.selectbtn");

			// Switching to NMew Pop up window
			mcd.SwitchToWindow("Copy Settings From Existing Menu Item");

			// searching for the specific Menu item
			actions.click("COPYMI.exactrbtn");
			actions.setValue("COPYMI.searchtextbox", menu_name);
			actions.click("COPYMI.searchbtn");
			actions.smartWait(180);

			// Select web table record now
			WebElement record = mcd.GetTableCellElement("COPYMI.datatable_2_12", 1, "Number", "a");
			actions.click(record);

			// switching to back to previous window
			mcd.SwitchToWindow("$Add New Menu Item");

			// Entering Name and number in the fields
			actions.setValue("AddNewMI.MenuItemName", "VM_" + RandomStringUtils.randomAlphabetic(5));

			int mi_start = Integer.parseInt(mirange[4]); /// Getting the random
															/// number
			int mi_end = Integer.parseInt(mirange[5]); ////

			do {
				actions.clear("AddNewMI.MenuItemNumber");
				actions.setValue("AddNewMI.MenuItemNumber", mcd.fn_GetRndNumInRange(mi_start, mi_end));

				// reading value from the text box
				String menu_num = actions.getValue("AddNewMI.MenuItemNumber");
				actions.click("AddNewMI.Next");
				Thread.sleep(5000);
				actions.waitForPageToLoad(180);

				boolean blnWindow = false;
				try {
					blnWindow = mcd.SwitchToWindow("@Manage Menu Items");
					if (blnWindow) {
						System.out.println("Menu Name and Number is accepted successfully");
						blnflag = false;
					} else {
						mcd.SwitchToWindow("Add New Menu Item");
						if (driver.getPageSource().contains(ermsg[0].trim())) {
							blnflag = true;
							System.out.println("Entered  number " + menu_num + " is already exist.");
							System.out.println(blnflag);
						}
					}
				} catch (Exception e) {
					if (actions.isTextPresence(ermsg[0], true)) {
						blnflag = true;
						System.out.println("Entered  number " + menu_num + " is already exist.");
						System.out.println(blnflag);
					}
				}
			} while (blnflag == true);

			// ===Switching to New Window
			actions.waitForPageToLoad(180);
			actions.WaitForElementPresent("ManageMenuItem.ApplySavebtn");
			actions.click("ManageMenuItem.ApplySavebtn");

			actions.smartWait(180);

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

}
