package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0195 {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String strPageTitle, strTableElement, val, strmsg, forcecomp, strUserID, strerrmsg[];
	boolean flag;
	private String tcDesc;
	private String strMI;
	private String strLevel;

	public MNU_0195(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strLevel = mcd.GetTestData("DT_LEVEL");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		strPageTitle = mcd.GetTestData("DT_TITLE");
		strTableElement = "MasterMenuItemList.datatable";
		strmsg = mcd.GetTestData("DT_ERR_MSG");
		forcecomp = mcd.GetTestData("DT_FORCE_COMP");
		strUserID = mcd.GetTestData("DT_AUDIT_USER");
		tcDesc = mcd.GetTestData("DT_Description");
		strerrmsg = strmsg.split("#");

	}

	@Test
	public void test_MNU_0162_CompNoChngMsg() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(tcDesc);
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			actions.smartWait(15);
			Thread.sleep(2000);
			actions.waitForPageToLoad(10);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** TODO: Step 1 */
			actions.click("MasterMenuItemList.Searchbtn");
			actions.smartWait(20);

			WebElement ws = mcd.GetTableCellElement(strTableElement, "Future Settings", "", "", "", "Number", "a");
			ws.click();
			actions.smartWait(20);
			mcd.SwitchToWindow("#Title");
			actions.click("MasterMenuItemList.NavComptab");
			actions.smartWait(120);

			driver.findElement(By.xpath(actions.getLocator("AddRemoveComponent.AddCompbtn"))).click();
			actions.smartWait(100);
			mcd.SwitchToWindow("Common Menu Item Selector");
			actions.keyboardEnter("AddRemoveComponent.Searchbtn");
			actions.smartWait(20);
			actions.setValue("CMIS.Availabilitydrpdwn", "Assigned");
			actions.smartWait(20);

			List<WebElement> Rem_Chkbox = driver
					.findElements(By.xpath(".//input[@type = 'checkbox'][contains(@onclick, 'removeMenuItem')]"));
			for (int i = 0; i < 1; i++) {
				if (Rem_Chkbox.get(i).isEnabled()) {
					actions.keyboardEnter(Rem_Chkbox.get(i));

				} else {
					System.out.println("This MI is already added");
				}
			}
			actions.keyboardEnter("ManageMenuItem.ViewSettingbtn");
			// actions.smartWait(120);
			mcd.SwitchToWindow("Manage Menu Items");
			// actions.smartWait(80);

			actions.keyboardEnter("AddRemoveComponent.AddCompbtn");
			actions.smartWait(120);
			driver.findElement(By.xpath(actions.getLocator("AddRemoveComponent.AddCompbtn"))).click();
			actions.smartWait(120);
			mcd.SwitchToWindow("Common Menu Item Selector");
			actions.smartWait(120);
			List<WebElement> Rem2_Chkbox = driver
					.findElements(By.xpath(".//input[@type = 'checkbox'][contains(@onclick, 'removeMenuItem')]"));
			for (int j = 0; j < 1; j++) {
				if (Rem2_Chkbox.get(j).isEnabled()) {
					actions.keyboardEnter(Rem2_Chkbox.get(j));
				} else {
					System.out.println("This MI is already added");
				}
			}

			actions.keyboardEnter("ManageMenuItem.ViewSettingbtn");
			// actions.smartWait(120);
			mcd.SwitchToWindow("Manage Menu Items");

			actions.javaScriptClick("CurrentMenuItemDetails.Apply");
			// actions.smartWait(120);
			if (mcd.VerifyAlertMessageDisplayed("Alert Message", strerrmsg[0], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Verify message as-" + strerrmsg[0] + " is displayed",
						"Message as-" + strmsg + " should be displayed",
						"Message is displayed as-" + strmsg + "is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify message as-" + strerrmsg[0] + " is displayed",
						"Message as-" + strmsg + " should be displayed", "Message -" + strmsg + " is not displayed",
						"Fail");
			}

			// Audit log verification

			flag = rfm.VerifyAuditLog_Entry(strPageTitle, "Update", strLevel);
			if (flag) {
				actions.reportCreatePASS("Verify Audit Log for is generated for updated activity",
						"Audit log should be generated for updated activity",
						"Audit log generated for updated activity succesfully", "Pass");
			} else {
				actions.reportCreateFAIL("Verify Audit Log for is generated for updated activity",
						"Audit log should be generated for updated activity",
						"Audit log generated for updated activity succesfully", "Fail");
			}

			flag = rfm.RFM_VerifyAuditLog_Details("RFM2", strUserID, strPageTitle, "Update", strLevel, strMarket,
					"Current Setting for Menu Item " + strMI + " has been updated.");
			if (flag) {
				actions.reportCreatePASS("Verify Audit Log details for created menu item",
						"Audit log details should be generated for created menu item",
						"Audit log details generated for created menu item succesfully", "Pass");
			} else {
				actions.reportCreateFAIL("Verify Audit Log details for created menu item",
						"Audit log details should be generated for created menu item",
						"Audit log details not generated for created menu item succesfully", "Fail");
			}
			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

			Thread.sleep(2000);
		} catch (Exception e) {
			// Reporter.log("Test Failed :: " + e.getCause() + " - " +
			// e.getMessage());
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}
