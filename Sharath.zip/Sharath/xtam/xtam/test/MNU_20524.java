package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

//import com.sun.accessibility.internal.resources.accessibility;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20524 {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strWM1;
	private String strWM2;
	private String strWM3;
	private String strNavigateToReport, strNavigateToView, strNavigateToAdmin, strNavigateToHOME, strNavigateToQM;
	private String strDBName, strUserID, strOperation, strActivity, strLevel, strNodeName, strDescription,
			strSuccessMsg, strActivity1, strActivity2;
	boolean AuditEntry;
	String AuditDesc;
	boolean AuditDetail;

	// TODO: Declare test-data variables for other data-parameters
	public MNU_20524(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strWM1 = mcd.GetTestData("WarningMessage1");
		strWM2 = mcd.GetTestData("WarningMessage2");
		strWM3 = mcd.GetTestData("WarningMessage3");

		strDBName = mcd.GetTestData("DT_DB_NAME");
		strUserID = mcd.GetTestData("DT_USER_ID");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strActivity = mcd.GetTestData("DT_ACTIVITY");
		strLevel = mcd.GetTestData("DT_LEVEL");
		strNodeName = mcd.GetTestData("DT_NODE_NAME");
		strActivity1 = mcd.GetTestData("DT_ACTIVITY1");
		strActivity2 = mcd.GetTestData("DT_ACTIVITY2");

		// TODO: GetTestData for other data-parameters
	}

	@Test
	public void test_MNU_20523_CreateFlavorSet() throws InterruptedException {
		String strPageTitle = ""; // TODO: Exact page-title
		String strPageSubHeading = "Flavor Set"; // TODO: Page Heading

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Verify Page Header */
			System.out.println("> Verify Page Heading");
			mcd.VerifyPageHeading(strPageSubHeading, "SubHeading");

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow
			// wait for element to be present
			actions.WaitForElementPresent("SetAssignmentReport.SearchButton", 100);
			// click on view full list
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			// wait
			actions.smartWait(10);
			// getting the first element name
			String strFirstNameValue = driver.findElement(By.xpath(actions.getLocator("FlavorSet.TableNameValue")))
					.getText();
			System.out.println(strFirstNameValue);
			// click on new flavour set
			actions.keyboardEnter("FlavorSet.NewFlavorSet");
			// switching to new window
			mcd.SwitchToWindow("Add New Flavor Set");
			// waiting for element present
			actions.WaitForElementPresent("AddNewFlavorSet.Next", 100);
			// click on next button
			actions.keyboardEnter("AddNewFlavorSet.Next");
			// verifying alert message
			System.out.println("> Click on OK button of Alert Box");
			mcd.VerifyAlertMessageDisplayed("Warning Message", strWM1, true, AlertPopupButton.OK_BUTTON);
			// setting values in set name
			actions.setValue("AddNewFlavorSet.FlavorSetName", strFirstNameValue);
			// click on select node button
			actions.keyboardEnter("AddNewFlavorSet.SelectNodeButton");
			// wait
			Thread.sleep(3000);
			// switching window
			mcd.waitAndSwitch("Select Node");

			// Selecting first element from the node
			if (strMarket.equals("US Country Office")) {
				List<WebElement> listEle1 = driver.findElements(By.xpath("//span[@id = 'data2']"));
				String strValue1 = listEle1.get(0).getText().toString();
				System.out.println(strValue1);
				listEle1.get(0).click();
			} else {
				List<WebElement> listEle1 = driver.findElements(By.xpath("//span[@id = 'data1']"));
				String strValue1 = listEle1.get(0).getText().toString();
				System.out.println(strValue1);
				listEle1.get(0).click();
			}

			// System.out.println(strValue1);
			// listEle1.get(0).click();
			// switching to new window
			mcd.SwitchToWindow("Add New Flavor Set");
			// click on next button
			actions.keyboardEnter("AddNewFlavorSet.Next");
			// verifying error message
			String strErrorMessage = driver.findElement(By.xpath(actions.getLocator("AddNewFlavorSet.ErrorMessage")))
					.getText();
			System.out.println(strErrorMessage);

			if (strErrorMessage.equals(strWM2)) {
				System.out.println("Present");
				actions.reportCreatePASS("Error Message: '" + strErrorMessage + "' is Displayed",
						"Error Message: '" + strErrorMessage + "' should Displayed",
						"Error Message: '" + strErrorMessage + "' is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Error Message: '" + strErrorMessage + "' is Displayed",
						"Error Message: '" + strErrorMessage + "' should Displayed",
						"Error Message: '" + strErrorMessage + "' is not Displayed", "Fail");
			}
			// clearing flavor set name text box
			actions.smartWait(100);
			actions.clear("AddNewFlavorSet.FlavorSetName");
			// generating random name
			String name = mcd.fn_GetRndName("Auto");
			System.out.println(name);
			// set value for flavor
			actions.setValue("AddNewFlavorSet.FlavorSetName", name);
			// copy existing data to no
			actions.click("AddNewFlavorSet.CopyExistingNo");
			// click on cancel button
			actions.keyboardEnter("RFMHome.Cancel");
			// verifying alert message
			System.out.println("> Click on OK button of Alert Box");
			mcd.VerifyAlertMessageDisplayed("Warning Message", strWM3, true, AlertPopupButton.CANCEL_BUTTON);
			// click on next button
			actions.keyboardEnter("AddNewFlavorSet.Next");
			// wait
			Thread.sleep(7000);
			// switching to new window
			mcd.SwitchToWindow("Flavor Set");

			//
			String strValue = driver.findElement(By.xpath(actions.getLocator("FlavorSet.FlavorSetName")))
					.getAttribute("value");
			if (strValue.equals(name)) {
				System.out.println("Present");
				actions.reportCreatePASS(strValue + " : Present in Flavor Set Name Text Box",
						strValue + " : Should present in Flavor Set Name Text Box",
						strValue + " : Present in Flavor Set Name Text Box", "Pass");
			} else {
				actions.reportCreateFAIL(strValue + " : Present in Flavor Set Name Text Box",
						strValue + " : Should present in Flavor Set Name Text Box",
						strValue + " : does not Present in Flavor Set Name Text Box", "Fail");
			}
			// click on save button
			actions.keyboardEnter("FlavorSet.SavelButton");
			// wait
			actions.smartWait(100);
			// verifying audit log
			AuditEntry = rfm.VerifyAuditLog_Entry(strOperation, strActivity, strLevel);
			System.out.println(AuditEntry);
			AuditDesc = "Queue Side [" + name + "] has been created.";
			AuditDetail = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID, strOperation, strActivity, strLevel,
					strNodeName, AuditDesc);
			System.out.println(AuditDetail);

			// ----------------------------
			// renavigating
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			actions.WaitForElementPresent("FlavorSet.SearchTextBox", 100);

			actions.setValue("FlavorSet.SearchTextBox", name);

			actions.keyboardEnter("FlavorSet.SearchButton");

			actions.smartWait(100);

			actions.click("FlavorSet.TableNameValue");

			actions.smartWait(100);

			actions.WaitForElementPresent("FlavorSet.CustomizeButton", 100);

			actions.click("FlavorSet.CustomizeButton");

			System.out.println(strValue);
			strValue = strValue + 1;
			System.out.println(strValue);

			actions.clear("FlavorSet.FlavorSetName");

			actions.setValue("FlavorSet.FlavorSetName", strValue);

			actions.setValue("FlavorSet.FlavorSetStatus", "Inactive");

			actions.keyboardEnter("FlavorSet.CancelButton");

			System.out.println("> Click on OK button of Alert Box");
			mcd.VerifyAlertMessageDisplayed("Warning Message", strWM3, true, AlertPopupButton.CANCEL_BUTTON);

			actions.keyboardEnter("FlavorSet.SavelButton");

			actions.smartWait(100);

			AuditEntry = rfm.VerifyAuditLog_Entry(strOperation, strActivity1, strLevel);
			System.out.println(AuditEntry);
			AuditDesc = "Queue Side [" + name + "] has been created.";
			AuditDetail = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID, strOperation, strActivity1, strLevel,
					strNodeName, AuditDesc);
			System.out.println(AuditDetail);

			// ------------------------------

			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			actions.WaitForElementPresent("FlavorSet.SearchTextBox", 100);

			actions.setValue("FlavorSet.SearchTextBox", name);
			Thread.sleep(1890);
			actions.keyboardEnter("FlavorSet.SearchButton");

			actions.smartWait(200);

			driver.findElement(By.xpath(actions.getLocator("FlavorSet.TableDeleteIconFirstValue"))).click();

			System.out.println("> Click on OK button of Alert Box");
			mcd.VerifyAlertMessageDisplayed("Warning Message", strWM1, true, AlertPopupButton.CANCEL_BUTTON);
			// click on table first delete icon
			actions.keyboardEnter("FlavorSet.TableDeleteIconFirstValue");

			System.out.println("> Click on OK button of Alert Box");
			mcd.VerifyAlertMessageDisplayed("Warning Message", strWM1, true, AlertPopupButton.OK_BUTTON);

			Thread.sleep(5000);
			// verifying audit log
			AuditEntry = rfm.VerifyAuditLog_Entry(strOperation, strActivity2, strLevel);
			System.out.println(AuditEntry);
			AuditDesc = "Queue Side [" + name + "] has been created.";
			AuditDetail = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID, strOperation, strActivity2, strLevel,
					strNodeName, AuditDesc);
			System.out.println(AuditDetail);

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}
