package xtam.test;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.MenuItemSets;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0012_BasicUpdateMenu {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo, timeStamp, strApplicationDate;
	private MenuItemSets mis;
	// TODO: Declare test-data variables for other data-parameters
	private String strPageTitle, strTableElement, strrfmmsg, strmsg[], strDBName, strUserID, strval, strLevel, strset,
			strMenuItem;

	public MNU_0012_BasicUpdateMenu(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		mis = new MenuItemSets(driver, actions, uiActions, inputData, mcd, rfm);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		strPageTitle = mcd.GetTestData("DT_TITLE");
		strTableElement = "RFM.Table";
		strrfmmsg = mcd.GetTestData("DT_MSG");
		strmsg = strrfmmsg.split("#");
		strDBName = "RFM2";
		strUserID = mcd.GetTestData("DT_USER_NAME");
	}

	@Test
	public void test_MNU_0012_BasicUpdateMenu() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"Verify Update Menu Item Details View Future/Current Settings functionality");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
			actions.waitForPageToLoad(20);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			actions.waitForPageToLoad(180);
			mcd.SwitchToWindow("#Title");

			// Create new Menu Item Set
			actions.click("MenuItemSet.NewMISbutton");
			mcd.waitAndSwitch("Add New Menu Item Set");
			String strSetName = mcd.fn_GetRndName("Auto");
			actions.setValue("NewMenuItemSet.SetName", strSetName);
			System.out.println("Menu item Set Name:" + strSetName);
			actions.keyboardEnter("NewMenuItemSet.SelectBtn");
			mcd.waitAndSwitch("Select Node");
			mcd.Selectrestnode("SelectNode.Tree", strMarket);
			mcd.SwitchToWindow("Add New Menu Item Set");
			actions.keyboardEnter("NewMenuItemSet.NextBtn");
			mcd.SwitchToWindow("@Manage Menu Item Set : Common Menu Item Selector");
			actions.smartWait(10);
			actions.clickAndVerify("CommonMenuItem.SearchBtn", "CommonMenuItemSelector.AddCheckBox");
			actions.smartWait(50);
			actions.javaScriptClick("CommonMenuItemSelector.AddCheckBox");
			actions.keyboardEnter("CommonMenuItemSelector.SaveBtn");
			actions.smartWait(180);
			actions.verifyTextPresence("Your changes have been saved.", true);

			// Click on Return to menu items set
			actions.keyboardEnter("MenuItemSets.ReturnToSet");
			mcd.SwitchToWindow("#Title");

			// Verifying New Menu Item Set button
			if (actions.isElementPresent("MenuItemSet.NewMISbutton")) {
				actions.reportCreatePASS("Verify New Menu Item Set button", "New Menu Item Set button should present",
						"New Menu Item Set button is present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify New Menu Item Set button", "New Menu Item Set button should present",
						"New Menu Item Set button is NOT  present", "FAIL");
			}

			// Verifying filter list of Market
			if (!actions.isElementEnabled("MenuItemSets.Marketdrp")) {
				actions.reportCreatePASS("Verify Filter Market dropdown", "Filter Market dropdown should disable",
						"Filter Market dropdown is disable", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Filter Market dropdown", "Filter Market dropdown should disable",
						"Filter Market dropdown is NOT disable", "FAIL");
			}

			// Verifying Country drop down
			if (actions.isElementEnabled("ScreenSet.FilterListRegionDD")) {
				actions.reportCreatePASS("Verify Country drop down", "Country drop down should enable",
						"Country drop down is enable", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Country drop down", "Country drop down should enable",
						"Country drop down is not enable", "FAIL");
			}

			/*
			 * if(strMarket.equals("US Country Office")) {
			 * actions.isElementEnabled(sElement) actions.reportCreatePASS(
			 * "Verify Filter button", "Filter button should enable",
			 * "Filter button is enable", "PASS"); }else{
			 * actions.reportCreatePASS("Verify Filter button",
			 * "Filter button should enable", "Filter button is enable",
			 * "PASS"); }
			 * 
			 * 
			 * i
			 */

			// Verify table columns
			verifyTablecolumnsPresent("FieldPermissions.Table", "Name");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Node");

			// Searching for menu item set
			actions.clear("CopyScreenSet.CopySearchTextBox");
			actions.setValue("CopyScreenSet.CopySearchTextBox", strSetName);
			List<WebElement> ele1 = driver.findElements(By.xpath("//*[@id='menuItemSetSearchForm_']"));
			actions.click(ele1.get(0));
			actions.smartWait(180);
			actions.click("MenuItemSets.TableFirstValue");
			actions.smartWait(180);

			// Checking future settings is there or not
			String future_Setting = driver.findElement(By.xpath(actions.getLocator("ManageMenuItemSet.FutureSettings")))
					.getText();
			if (future_Setting.equals("")) {
				actions.click("MasterMenuItemList.MenuItemNumber");
				actions.smartWait(180);
				rfm.SelectCustOrResetButton("Are you sure you want to Reset the Default values to the Menu Item?",
						"MenuItemSets.Custbtn", "MenuItemSets.Resetbtn");
				actions.clear("ManageMenuItems.SummaryMonitorName");
				actions.setValue("ManageMenuItems.SummaryMonitorName", "AA");
				actions.keyboardEnter("RFMMMIL.Applybtn");
				mcd.SwitchToWindow("Apply Changes Details");
				actions.click("FeeSet.FutureRadioBtn");
				actions.click("MenuItemSets.FutureCal");
				mcd.Get_future_date(2, "Close", strApplicationDate);
				actions.keyboardEnter("ApplyChangesDetails.Save");
				mcd.SwitchToWindow("@Manage Menu Items");
				actions.smartWait(180);

			} else {
				actions.click("MasterMenuItemList.MenuItemNumber");
				actions.smartWait(180);
			}

			// Click on cancel button
			actions.keyboardEnter("RFM.CancelBtn");
			mcd.SwitchToWindow("@Manage Menu Item Set : Manage Menu Items");
			actions.click("MasterMenuItemList.MenuItemNumber");
			actions.smartWait(180);

			// Click on View future settings button
			actions.keyboardEnter("RFMQueueRoutingPopupPage.SaveButton");
			mcd.SwitchToWindow("Manage Menu Items");

			// Verify General Settings link
			if (actions.isElementPresent("MasterMenuItemList.NavGeneralTab")) {
				actions.reportCreatePASS("Verify General Settings tab", "General Settings tab should Present",
						"General Settings tab  is present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify General Settings tab", "General Settings tab should Present",
						"General Settings tab  is not present", "FAIL");
			}

			// Verifying POS/KVS Settings
			if (actions.isElementPresent("RestMIList.POSKVStab")) {
				actions.reportCreatePASS("Verify POS/KVS Settings tab", "POS/KVS Settings tab should Present",
						"POS/KVS Settings tab  is present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify POS/KVS Settings tab", "POS/KVS Settings tab should Present",
						"POS/KVS Settings tab  is not present", "FAIL");
			}

			// Verifying Presentation Settings
			if (actions.isElementPresent("RestMIList.PresentationTab")) {
				actions.reportCreatePASS("Verify Presentation Settings tab", "Presentation Settings tab should Present",
						"Presentation Settings tab  is present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Presentation Settings tab", "Presentation Settings tab should Present",
						"Presentation Settings tab  is not present", "FAIL");
			}

			// Verifying Components
			if (actions.isElementPresent("ManageMenuItem.ComponentsTab")) {
				actions.reportCreatePASS("Verify 	Components  tab", "Components  tab should Present",
						"Components  tab  is present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify 	Components  tab", "Components  tab should Present",
						"Components  tab  is not present", "FAIL");
			}

			// Verifying Parameters
			if (actions.isElementPresent("ManageMenuItems.Parameters")) {
				actions.reportCreatePASS("Verify 	Parameters  tab", "Parameters  tab should Present",
						"Parameters  tab  is present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify 	Parameters  tab", "Parameters  tab should Present",
						"Parameters  tab  is not present", "FAIL");
			}

			// Verifying ABS Settings
			if (actions.isElementPresent("RestMIList.ABSSettingStab")) {
				actions.reportCreatePASS("Verify 	ABS Settings  tab", "ABS Settings  tab should Present",
						"ABS Settings  tab  is present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify 	ABS Settings  tab", "ABS Settings  tab should Present",
						"ABS Settings  tab  is not present", "FAIL");
			}

			if (strMarket.equals("Australasia")) {// Verifying red circle is
													// displayed
				if (actions.isElementPresent("ManageMenuItems.Circle")) {
					actions.reportCreatePASS("Verify Circle ", "Circle should Present", "Circle  is present", "PASS");
				} else {
					actions.reportCreateFAIL("Verify Circle", "Circle should Present", "Circle  is not present",
							"FAIL");
				}
			} else {
				if (actions.isElementPresent("ManageMenuItems.CircleUs")) {
					actions.reportCreatePASS("Verify Circle ", "Circle should Present", "Circle  is present", "PASS");
				} else {
					actions.reportCreateFAIL("Verify Circle", "Circle should Present", "Circle  is not present",
							"FAIL");
				}
			}

			// Click on ok button
			actions.keyboardEnter("RFMHomePage.AuditLogDetailsOKButton");
			mcd.SwitchToWindow("@Manage Menu Items");
			actions.keyboardEnter("RFM.CancelBtn");
			actions.smartWait(180);

			// Select Future setting hyperlink of a menu item
			WebElement Ele = mcd.GetTableCellElement("ViewGeneratedReport.ReportTable", 1, "Future Settings", "a");
			actions.click(Ele);
			actions.smartWait(180);

			// Click on current view settings button
			actions.keyboardEnter("RFMQueueRoutingPopupPage.SaveButton");
			mcd.SwitchToWindow("Manage Menu Items");
			// -----------------same code is done in above----------------

			// Click on ok button
			actions.keyboardEnter("RFMHomePage.AuditLogDetailsOKButton");
			mcd.SwitchToWindow("@Manage Menu Items");
			actions.keyboardEnter("RFM.CancelBtn");
			actions.smartWait(180);

			// Click on menu item number link and Click on component tab
			actions.click("MasterMenuItemList.MenuItemNumber");
			actions.smartWait(180);
			actions.click("ManageMenuItem.ComponentsTab");
			actions.smartWait(180);

			// Click on view type drop down
			actions.setValue("ManagePackagesPackagesReport.viewType", "Can Adds");
			actions.smartWait(180);
			rfm.SelectCustOrResetButton("Are you sure you want to Reset the Default values to the Menu Item?",
					"MenuItemSets.Custbtn", "MenuItemSets.Resetbtn");

			// Click on check box and Click on apply
			if (strMarket.equals("Australasia")) {
				actions.javaScriptClick("ManageMenuItems.Check");
			} else {
				actions.javaScriptClick("ManageMenuItems.CheckUs");
			}
			actions.keyboardEnter("RFMMMIL.Applybtn");

			// Verifying warning message
			mcd.VerifyAlertMessageDisplayed("Warning",
					"Once the components are customized, the Order Sequencing will no longer be inherited from the parent level",
					true, AlertPopupButton.OK_BUTTON);

			boolean mess2 = mcd.VerifyAlertMessageDisplayed("Warning",
					"Are you sure you want to save changes to the current settings?", true, AlertPopupButton.OK_BUTTON);

			// Click on reset to default button with cancel button
			actions.keyboardEnter("PMIGImageSet.ResetToDefault");
			boolean mess3 = mcd.VerifyAlertMessageDisplayed("Warning",
					"Are you sure you want to Reset the Default values to the Menu Item?", true,
					AlertPopupButton.CANCEL_BUTTON);
			if (mess3) {
				actions.reportCreatePASS("Verify alert message", "Alert message should disply",
						"Alert is displayed as expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verify alert message", "Alert message should disply",
						"Alert is displayed not  as expected", "FAIL");
			}

			// Click on reset to default button with ok button
			actions.keyboardEnter("PMIGImageSet.ResetToDefault");
			boolean mess4 = mcd.VerifyAlertMessageDisplayed("Warning",
					"Are you sure you want to Reset the Default values to the Menu Item?", true,
					AlertPopupButton.OK_BUTTON);
			if (mess4) {
				actions.reportCreatePASS("Verify alert message", "Alert message should disply",
						"Alert is displayed as expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verify alert message", "Alert message should disply",
						"Alert is displayed not  as expected", "FAIL");
			}
			actions.smartWait(180);

			// Verify customize settings button
			if (actions.isElementPresent("ManageMenuItems.CustomizeSettings")) {
				actions.reportCreatePASS("Verify customize settings button", "customize settings button should Present",
						"customize settings button  is present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify customize settings button", "customize settings button should Present",
						"customize settings button  is not present", "FAIL");
			}

			// Verifying Apply button
			String apply = driver.findElement(By.xpath(actions.getLocator("RFMMMIL.Applybtn"))).getAttribute("class");
			if (apply.contains("disable")) {
				actions.reportCreatePASS("Verify Apply button", "Apply button should disable",
						"Apply button is disable", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Apply button", "Apply button should disable",
						"Apply button is NOT disable", "FAIL");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			// Reporter.log("Test Failed :: " + e.getCause() + " - " +
			// e.getMessage());
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {

			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}

	// VERIFYING TABLE COLUMS CODE
	public void verifyTablecolumnsPresent(String tableLocator, String colName) {

		boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

		if (iscolPresent) {
			actions.reportCreatePASS("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is present in table", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is NOT present in table",
					"Fail");
		}
	}
}
