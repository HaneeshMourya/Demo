package xtam.test;

import java.util.Map;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Keywords.DialogType;
import crossbrowser.library.MasterMenuItem;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0264_NewDrinkVolInNGABSVol {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private MasterMenuItem mmi;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo, strrange, strerrmsg, strParam;
	// TODO: Declare test-data variables for other data-parameters
	private String strMsg;
	private String[] errMsg;
	private String strNavigateTo_1;
	private String name;
	private String code;
	private int i;

	public MNU_0264_NewDrinkVolInNGABSVol(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		mmi = new MasterMenuItem(driver, actions, uiActions, inputData, mcd, rfm);
		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strNavigateTo_1 = mcd.GetTestData("DT_NAVIGATE_TO_1");
		strrange = mcd.GetTestData("DT_RANGE");
		strerrmsg = mcd.GetTestData("DT_ERMSG");
		strParam = mcd.GetTestData("DT_PARAM");
		// TODO: GetTestData for other data-parameters
		strMsg = mcd.GetTestData("DT_DrinkVolume_ERR_Msg");
		errMsg = strMsg.split("#");
	}

	@Test
	public void test_MNU_0264_NewDrinkVolInNGABSVol() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription("Verify that all the Drink volume names that were added using Drink volume screen are been displayed in NGABSVolume drop-down  and user is able to select the value while creating/Updating a menu item at Master menu item list level.");
			
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			// Navigate to drink volume
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			actions.smartWait(100);

			// Click on new drink volume button
			actions.keyboardEnter("DrinkVolume.NewDrinkVolumeButton");
			Thread.sleep(2000);

			// Adding a new drink volume
			WebElement DrinkVol_txt = mcd.GetTableCellElement("DrinkVolume.Table", 1, "Name", "input");
			WebElement DrinkVol_code = mcd.GetTableCellElement("DrinkVolume.Table", 1, "Code", "input");

			boolean flag = false;

			do {
				DrinkVol_txt.clear();

				DrinkVol_txt.sendKeys("DV" + RandomStringUtils.randomAlphabetic(5));

				DrinkVol_code.clear();
				int dvcode = mcd.fn_GetRndNumInRange(10, 999);
				DrinkVol_code.sendKeys(Integer.toString(dvcode));

				// Getting the name and code
				name = DrinkVol_txt.getAttribute("value");
				code = DrinkVol_code.getAttribute("value");

				// clicking on the save btn
				actions.click("DrinkVolume.SaveButton");
				actions.smartWait(100);

				try {
					// Verify that confirmation popup is displayed
					Alert popup = driver.switchTo().alert();

					// Verify the message displayed
					String strActualMsg = popup.getText().trim();
					popup.accept();
					flag = true;
					if (strActualMsg.contains("Name")) {

						actions.reportCreatePASS("Verify the alert", "Message'" + errMsg[0] + "' should be displayed",
								"Message'" + errMsg[0] + "' is displayed", "PASS");
					} else {

						actions.reportCreatePASS("Verify the alert", "Message'" + errMsg[1] + "' should be displayed",
								"Message'" + errMsg[1] + "' is displayed", "PASS");

					}
				} catch (Exception e) {
					System.out.println("Name and Number accepted successfully");
					flag = false;

				}
			} while (flag == true);
			actions.smartWait(10);

			// Navigate to Master menu item list
			System.out.println("> Navigate to :: " + strNavigateTo_1);
			actions.select_menu("RFMHome.Navigate", strNavigateTo_1);
			actions.smartWait(100);
			actions.waitForPageToLoad(120);

			// Creating new menu item with NON_FOOD_PRODUCT
			int MI_Pro = RFM_MI_CreateMenuItem_updated1(strrange, "NON_FOOD_PRODUCT", strerrmsg, strParam);
			actions.javaScriptClick("RecipeReport.ExactMatchBtn");
			actions.clear("MasterMenuItemList.SearchTextBox");
			actions.setValue("MasterMenuItemList.SearchTextBox", MI_Pro);
			actions.click("MasterMenuItemList.SearchButton");
			actions.smartWait(100);
			String MenuItemNumber = mcd.GetTableCellValue("MasterMenuItemList.TableID", 1, "Number", "", "");
			WebElement Element = mcd.GetTableCellElement("MasterMenuItemList.TableID", 1, "Number", "a");
			actions.click(Element);
			actions.smartWait(100);
			mcd.SwitchToWindow("#Title");

			// Status change button is enable
			if (actions.isElementEnabled("RestMIList.ChangeStatusBtn")) {
				actions.reportCreatePASS("Verifying Change Status button", "Change Status button should enable",
						"Change Status button is enabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Change Status button", "Change Status button should enable",
						"Change Status button is not enabled", "FAIL");
			}

			// Verifying Apply button
			if (actions.isElementPresent("RFMMMIL.Applybtn")) {
				actions.reportCreatePASS("Verifying Apply button", "Apply button should display",
						"Apply button is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Apply button", "Apply button should display",
						"Apply button is not displayed", "FAIL");
			}

			// Verifying Parameter tab
			if (actions.isElementEnabled("ManageMenuItemCurrentMenuItemDetails.Parameters")) {
				actions.reportCreatePASS("Verifying Parameter tab", "Parameter tab should enable",
						"Parameter tab is enabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Parameter tab", "Parameter tab should enable",
						"Parameter tab is not enabled", "FAIL");
			}
			// click on ABS Settings
			actions.click("ManageMenuItems.ABSSettings");
			actions.smartWait(100);

			String DefaultValue = actions.getValue("ManageMenuItem.NGABSDDL");
			String DDLValue = mcd.getdropdownvalues("ManageMenuItem.NGABSDDL");
			String[] DDLList = DDLValue.split(",");

			flag = false;
			for (i = 0; i < DDLList.length; i++) {
				if (DDLList[i].equals(name)) {
					flag = true;
					break;
				}
			}
			// Verifying the added Drink volume in NGABS Volume DDL
			if (flag) {
				actions.reportCreatePASS("Verify the added Drink volume in NGABS Volume DDL",
						"New Drink volume should be displayed in NGABS Volume DDL",
						"New Drink volume is displayed in NGABS Volume DDL", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the added Drink volume in NGABS Volume DDL",
						"New Drink volume should be displayed in NGABS Volume DDL",
						"New Drink volume is not displayed in NGABS Volume DDL", "FAIL");
			}
			actions.setValue("ManageMenuItems.NGABSVolumeDDL", DDLList[i]);

			// Click on save button
			actions.click("ManageMenuItem.ApplySavebtn");
			//actions.smartWait(100);
			mcd.SwitchToWindow("Apply Changes Details");
			actions.keyboardEnter("ApplyChangesDetails.SaveButton_1");
			//actions.smartWait(180);
			mcd.SwitchToWindow("Manage Menu Items");
			actions.smartWait(180);
			actions.verifyTextPresence("Your changes have been saved.", true);

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	public int RFM_MI_CreateMenuItem_updated1(String MIrange, String pro_type, String strmsg, String strmenutype) {
		boolean blnflag = false;
		String[] strparam = strmenutype.split("#");
		String[] strrange = MIrange.split("#");
		String strerrmsg[] = strmsg.split("#");
		String s = "";
		int mi_num = 0, mi_start = 0, mi_end = 0;
		try {
			boolean flag = false;

			System.out.println(
					"********************************************************************** Start Test-Steps executions");

			// String MainWindow_NewMenuItem = driver.getWindowHandle();
			// WebElement ws=driver.findElement(By.xpath("//*[@class='button
			// button'][contains(text(),'Add New')]"));
			// actions.click(ws);
			actions.keyboardEnter("MMIL.AddNewBtn");

			// actions.windowSwitch(MainWindow_NewMenuItem,"Add New Menu Item");
			mcd.SwitchToWindow("Add New Menu Item");

			switch (pro_type) {
			case "CONTAINER_VALUE_MEAL":
				s = "Auto_CVM_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "PRODUCT":
				s = "Auto_Pro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "VALUE_MEAL":
				s = "Auto_VM_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "CHOICE":
				s = "Auto_Choice_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[0]);
				mi_end = Integer.parseInt(strrange[1]);
				break;
			case "CHOICE_EVM":
				s = mcd.fn_GetRndName("Auto_ChoiceEVM");
				mi_start = Integer.parseInt(strrange[0]);
				mi_end = Integer.parseInt(strrange[1]);
				break;
			case "CHECK CATEGORY":
				s = "Auto_Check_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[2]);
				mi_end = Integer.parseInt(strrange[3]);
				break;
			case "NON_FOOD_PRODUCT":
				s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "RAW_ITEM":
				s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "EVM":
				s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "COMMENT":
				s = "Auto_CMNT_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[6]);
				mi_end = Integer.parseInt(strrange[7]);
				break;
			default:
				break;
			}

			System.out.println("product name:" + s);
			actions.setValue("AddNewMI.MenuItemName", s);

			do {
				mi_num = mcd.fn_GetRndNumInRange(mi_start, mi_end);
				actions.clear("AddNewMI.MenuItemNumber");
				actions.setValue("AddNewMI.MenuItemNumber", mi_num);
				actions.keyboardEnter("AddNewMI.Next");
				Thread.sleep(3000);
				actions.waitForPageToLoad(180);
				boolean blnWindow = false;

				try {
					blnWindow = mcd.SwitchToWindow("@Manage Menu Items");
					if (blnWindow) {
						System.out.println("Menu Name and Number is accepted successfully");
						blnflag = false;
					} else {
						mcd.SwitchToWindow("Add New Menu Item");
						if (actions.isTextPresence(strerrmsg[0], true)) {
							blnflag = true;
							System.out.println("Entered  number " + mi_num + " is already exist.");
							System.out.println(blnflag);
						}
					}

				} catch (Exception err) {
					if (actions.isTextPresence(strerrmsg[0], true)) {
						blnflag = true;
						System.out.println("Entered  number " + mi_num + " is already exist.");
						System.out.println(blnflag);
					}
				}

			} while (blnflag == true);

			// SETTING THE VALUE OF THE MANDATORY FIELDS
			String instance = mcd.GetGlobalData("Instance");
			if (instance.equalsIgnoreCase("AP") || instance.equalsIgnoreCase("QMAP")
					|| instance.equalsIgnoreCase("EU")) {
				actions.setValue("ManageMenuItemCurrentMenuItemDetails.MenuItemType", "SMI");
			}
			actions.setValue("ManageMenuItem.ProductClass", pro_type);
			// actions.setValue("ManageMenuItem.ProductCategory", );
			actions.setValue("ManageMenuItem.ProductCategory", "DRINK TYPE");
			actions.setValue("ManageMenuItem.FamilyGroup", strparam[1]);
			Select select = new Select(driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.DayPartCode"))));
			select.selectByIndex(1);
			actions.setValue("ManageMenuItem.ProductLName", s + "LN");
			actions.setValue("ManageMenuItem.ProductSName", s + "SN");
			actions.setValue("ManageMenuItem.ProductDTName", s + "DN");
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.click("ManageMenuItem.ApplySavebtn");
			actions.smartWait(180);

			if (pro_type.equals("CHOICE") || pro_type.equals("CHOICE_EVM") || pro_type.equals("CHECK CATEGORY")) {
				mcd.VerifyAlertMessageDisplayed(strerrmsg[4], strerrmsg[4], true, AlertPopupButton.OK_BUTTON);
				flag = true;
			}
			actions.verifyTextPresence(strerrmsg[2], true);
			if (flag == false) {
				actions.reportCreatePASS("Verify creation of Menu Item",
						"Menu Item of '" + pro_type + "' should be created",
						"Menu Item of '" + pro_type + "' is created", "Pass");
			}

			// CLICKING CANCEL BUTTON TO NAVIGATE TO MAIN PAGE
			actions.click("ManageMenuItem.Cancelbtn1");
			actions.smartWait(180);

		} catch (Exception e) {
			actions.reportCreateFAIL("Verify creation of Menu Item",
					"Menu Item of '" + pro_type + "' should be created",
					"Menu Item of '" + pro_type + "' is not created", "Fail");
		}
		return mi_num;
	}
}
