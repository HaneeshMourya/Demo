/*
 * JIRA id covered: RFM-4238,RFM-4239
 */

package xtam.test;

import java.util.Map;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.CSVValidations;
import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class MNU_20507_CancelFunctnlty {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private CSVValidations csv;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strWM1;
	private String strDBName, strUserID, strOperation, strActivity, strLevel, strNodeName, strDescription,
			strSuccessMsg;
	boolean AuditEntry;
	String AuditDesc;
	boolean AuditDetail;

	// TODO: Declare test-data variables for other data-parameters

	public MNU_20507_CancelFunctnlty(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		csv = new CSVValidations();

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strWM1 = mcd.GetTestData("WarningMessage1");
		// TODO: GetTestData for other data-parameters

		strDBName = mcd.GetTestData("DT_DB_NAME");
		strUserID = mcd.GetTestData("DT_USER_ID");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strActivity = mcd.GetTestData("DT_ACTIVITY");
		strLevel = mcd.GetTestData("DT_LEVEL");
		strNodeName = mcd.GetTestData("DT_NODE_NAME");

	}

	@Test
	public void test_MNU_20507_CancelFunctnlty() throws InterruptedException {
		String strPageTitle = ""; // TODO: Exact page-title
		String strPageSubHeading = "Master Flavors"; // TODO: Page Heading

		try {
			System.out
					.println("********************************************************************** Test execution starts");
			actions.setTestcaseDescription("Verify that the user is able to update a existing Flavor. Verify that the user is able to delete an existing Flavor");
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow
				// RFM-4238 - Verify that the user is able to update a existing
				// Flavor
				int i = 1;
				int rw_cnt = mcd.GetTableRowCount("RFMHome.Table");
				System.out.println("Master Flavor row count: " + rw_cnt);
	
				// if No Master flavor exists in system then first create and then
				// update
				if (rw_cnt <= i) {
					// Click on 'New Flavor' button
					actions.keyboardEnter("MasterFlavors.NewFlavor");
					driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[2]/td[1]/input[1]")).sendKeys(
							"Auto_DelMF1234");
					driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[2]/td[2]/input[1]")).sendKeys("99");
					// Click on Save button
					actions.keyboardEnter("MasterFlavors.SaveButton");
					Thread.sleep(3000);
					try {
						actions.verifyTextPresence("Your changes have been saved.", true);
					} catch (Exception e) {
						System.out.println(">> Your changes have been saved. message is not displayed...");
					}
				}
	
			rw_cnt = mcd.GetTableRowCount("RFMHome.Table");
			System.out.println("Master Flavor row count: " + i);

			String strTableValues = driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[" + i + "]/td[1]/input[1]"))
					.getAttribute("value");
			System.out.println("Flavor Name " + i + ":" + strTableValues);

			String strTableNozal = driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[" + i + "]/td[2]/input[1]"))
					.getAttribute("value");
			System.out.println("Nozzle Id " + i + ":" + strTableNozal);

			strTableValues = strTableValues + 1;
			driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[" + i + "]/td[1]/input[1]")).clear();
			actions.smartWait(5);
			driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[" + i + "]/td[1]/input[1]"))
					.sendKeys(strTableValues);

			// Enter alphabets in the Nozzle Id field and verify error
			driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[" + i + "]/td[2]/input[1]")).clear();
			driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[" + i + "]/td[2]/input[1]")).sendKeys("AC");

			actions.click("MasterFlavors.SaveButton");

			boolean booMsg3 = mcd.VerifyAlertMessageDisplayed("Warning Message",
					"Please enter numeric value, greater than or equal to 0(zero).", true, AlertPopupButton.OK_BUTTON);

			System.out.println(booMsg3);

			if (booMsg3 == true) {
				actions.reportCreatePASS("Enter alphabets in the Nozzle Id field",
						"Message: 'Please enter numeric value, greater than or equal to 0(zero).' should Displayed",
						"Message: 'Please enter numeric value, greater than or equal to 0(zero).' is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Enter alphabets in the Nozzle Id field",
						"Message: 'Please enter numeric value, greater than or equal to 0(zero).' should Displayed",
						"Message: 'Please enter numeric value, greater than or equal to 0(zero).' is not Displayed",
						"Fail");
			}

			// Enter -1 in the Nozzle Id field and verify error
			driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[" + i + "]/td[2]/input[1]")).clear();
			driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[" + i + "]/td[2]/input[1]")).sendKeys("-1");

			actions.click("MasterFlavors.SaveButton");

			boolean booMsg = mcd.VerifyAlertMessageDisplayed("Warning Message",
					"Please enter numeric value, greater than or equal to 0(zero).", true, AlertPopupButton.OK_BUTTON);

			System.out.println(booMsg);

			if (booMsg == true)
				actions.reportCreatePASS("Enter -1 in the Nozzle Id field",
						"Message: 'Please enter numeric value, greater than or equal to 0(zero).' should Displayed",
						"Message: 'Please enter numeric value, greater than or equal to 0(zero).' is Displayed", "Pass");
			 else
				actions.reportCreateFAIL("Message: 'Enter -1 in the Nozzle Id field",
						"Message: 'Please enter numeric value, greater than or equal to 0(zero).' should Displayed",
						"Message: 'Please enter numeric value, greater than or equal to 0(zero).' is not Displayed",
						"Fail");

			// Enter unique Nozzle id and click Save to Update existing Master Flavor

			driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[" + i + "]/td[2]/input[1]")).clear();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[" + i + "]/td[2]/input[1]")).sendKeys(strTableNozal);

			// Click on Save button
			actions.keyboardEnter("MasterFlavors.SaveButton");
			Thread.sleep(3000);
			try {
				actions.verifyTextPresence("Your changes have been saved.", true);
			} catch (Exception e) {
				System.out.println(">> Your changes have been saved. message is not displayed...");
			}
	
			// Navigate to Home page and verify the Audit log details
			AuditEntry = rfm.VerifyAuditLog_Entry(strOperation, "Update", strLevel);
			System.out.println(AuditEntry);
	
			AuditDesc = "Master Flavors has been updated.";
			AuditDetail = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID, strOperation, "Update", strLevel,
					strNodeName, AuditDesc);
			System.out.println(AuditDetail);
	
			// Verify Audit Log ID in CSV file for Create operation
			String AuditLogId = rfm.GetAuditLogID(strOperation);
			mcd.GetTableCellElement("RFMHomePage.AuditLog", "Operations", strOperation, "", "", "Id", "a").sendKeys(
					Keys.ENTER);
			Thread.sleep(1000);
			mcd.waitAndSwitch("Manage Audit Log");
			VerifyAuditLogPrint();
			VerifyAuditLogCSV(AuditLogId, "Update");
	
			// RFM-4239 - Verify that the user is able to delete an existing
			// Flavor
	
			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
	
			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");
	
			rw_cnt = mcd.GetTableRowCount("RFMHome.Table");
			System.out.println(rw_cnt);
			
			String strDelMF = driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[" + rw_cnt + "]/td[1]/input[1]"))
					.getAttribute("value");
			System.out.println("Delete Flavor Name " + rw_cnt + ":" + strDelMF);

	
			driver.findElement(By.xpath("//*[@id='taxTypeData']/tr[" + rw_cnt + "]/td[3]/a/img")).click();
			mcd.VerifyAlertMessageDisplayed("Warning Message", "Are you sure you want to delete the selected item?",
					true, AlertPopupButton.OK_BUTTON);
	
			actions.smartWait(100);
	
			try {
				actions.verifyTextPresence("Delete has been successfully completed.", true);
			} catch (Exception e) {
				System.out.println(">> Delete has been successfully completed. message is not displayed...");
			}
	
			// Navigate to Home page and verify the Audit log details
			AuditEntry = rfm.VerifyAuditLog_Entry(strOperation, "Delete", strLevel);
			System.out.println(AuditEntry);
	
			AuditDesc = "Master Flavors " + strDelMF + " has been deleted.";
			AuditDetail = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID, strOperation, "Delete", strLevel,
					strNodeName, AuditDesc);
			System.out.println(AuditDetail);
	
			// Verify Audit Log ID in CSV file for Create operation
			String AuditLogIdD = rfm.GetAuditLogID(strOperation);
			mcd.GetTableCellElement("RFMHomePage.AuditLog", "Operations", strOperation, "", "", "Id", "a").sendKeys(
					Keys.ENTER);
			Thread.sleep(1000);
			mcd.waitAndSwitch("Manage Audit Log");
			VerifyAuditLogPrint();
			VerifyAuditLogCSV(AuditLogIdD, "Delete");

		// ------------------------------------------------------------------------

		/** Logout the application */
		driver.switchTo().window("");
		rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	// Functions to Verify Audit log functionality for Print and Save as CSV
	// File

	public void VerifyAuditLogPrint() {

		// Click print button, Print popup should be displayed
		try {

			WebElement printBtn = driver.findElement(By.xpath("//a[contains(text(),'Print')]"));
			actions.keyboardEnter(printBtn);
			Thread.sleep(5000);
			Alert myAlert = driver.switchTo().alert();
			Thread.sleep(2000);
			actions.reportCreatePASS("Click Print button", "Print Window should be displayed.",
					"Print Window is displayed.", "PASS");
			myAlert.dismiss();

		} catch (Exception error1) {
			System.out.println("Print Alert is not displayed");
		}

	}

	public void VerifyAuditLogCSV(String AuditLogId, String strOperation) {

		// Click Save as CSV file button and verify that Audit log Id is
		// displayed in CSV
		try {
			WebElement SaveCSVBtn = driver.findElement(By.xpath("//a[contains(text(),'Save as CSV File')]"));
			actions.javaScriptClick(SaveCSVBtn);
			Thread.sleep(3000);

			actions.ieDownload();
			Thread.sleep(3000);

			WebElement OKBtn = driver.findElement(By.xpath("//a[contains(text(),'OK')]"));
			actions.javaScriptClick(OKBtn);

			String targetData = "{\"Id\":\"" + AuditLogId + "\"}";

			boolean csvFlag = csv.validateColumnsData("AuditLogDetail.CSV", "Id", AuditLogId, targetData, false, true);

			System.out.println("CSV field validation = " + csvFlag);

			if (csvFlag)
				actions.reportCreatePASS("Verify AuditLogDetail.CSV file for " + strOperation + " operation.",
						"Auditlog Id should be displayed in CSV file.", "Auditlog Id is displayed in CSV file.", "PASS");
			else
				actions.reportCreateFAIL("Verify AuditLogDetail.CSV file for " + strOperation + " operation.",
						"Auditlog Id should be displayed in CSV file.", "Auditlog Id is not displayed in CSV file.",
						"FALSE");

			mcd.waitAndSwitch("@RFM - Home");
		} catch (Exception error2) {
			System.out.println("Failed to verify CSV file...");
		}

	}
}
