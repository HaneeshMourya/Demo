package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Keywords.DialogType;
import crossbrowser.library.MasterMenuItem;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0227 {

	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private MasterMenuItem mmi;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo, strpagetitle, mainwindow, strexp, strApplicationDate, strNavigateTo1, strNavigateTo2,
			strNavigateTo3, strrest;
	private int Col_cnt;
	private String strerrmsg, strParam, strrange, strwmessage, strWMUNSD;
	// TODO: Declare test-data variables for other data-parameters

	public MNU_0227(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		mmi = new MasterMenuItem(driver, actions, uiActions, inputData, mcd, rfm);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strpagetitle = mcd.GetTestData("DT_PageTitle");
		strexp = mcd.GetTestData("DT_Expmsg");
		// TODO: GetTestData for other data-parameters
		strerrmsg = mcd.GetTestData("DT_ERMSG");
		strParam = mcd.GetTestData("DT_PARAM");
		strrange = mcd.GetTestData("DT_RANGE");
		strNavigateTo1 = mcd.GetTestData("DT_NAVIGATE1");
		strNavigateTo2 = mcd.GetTestData("DT_NAVIGATE2");
		strrest = mcd.GetTestData("DT_REST");
		strwmessage = mcd.GetTestData("DT_Warning_Message");
		strWMUNSD = mcd.GetTestData("DT_Warning_MsgUnsaved");
		strNavigateTo3 = mcd.GetTestData("DT_NAVIGATE3");

	}

	@Test
	public void test_MNU_0227() throws InterruptedException {

		try {
			System.out.println("************************** Test execution starts");

			/** setting the test case description */
			actions.setTestcaseDescription(
					"Verify Promotion Range tab is disabled at Master Menu Item List if Promotional Menu Item flag and Promotional Choice flag is 'NO' for a Menu Item and also Verify the Inheritance of Promotion range tab");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
			actions.waitForPageToLoad(120);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(4000);
			actions.waitForPageToLoad(120);
			actions.smartWait(60);

			// ** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// Verifying menu items in master menu item list
			actions.click("MasterMenuItemList.Searchbtn");
			actions.smartWait(180);
			int master_table_rc = mcd.GetTableRowCount("FieldPermissions.Table");
			if (master_table_rc > 0) {
				actions.reportCreatePASS("Verifying All menu items", "All menu items should display",
						"All menu items are displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying All menu items", "All menu items should display",
						"All menu items are  NOT displayed", "FAIL");
			}

			// Creating the menu item with Product class & choice class *//*
			int MI_Choice = mmi.RFM_MI_CreateMenuItem_updated(strrange, "CHOICE", strerrmsg, strParam);
			int MI_Pro = mmi.RFM_MI_CreateMenuItem_updated(strrange, "PRODUCT", strerrmsg, strParam);

			// Searching Product menu item
			actions.setValue("MasterMenuItemList.srch_text", MI_Pro);
			actions.click("MasterMenuItemList.Searchbtn");
			actions.smartWait(180);

			// Selecting Product menu item
			WebElement rec_sel = mcd.GetTableCellElement("MasterMenuItemList.datatable", 1, "Number", "a");
			actions.click(rec_sel);
			actions.smartWait(180);

			// Checking for promotion range is disable
			if (ISAttribtuePresent("RestMIList.DisabledPromotionRangeTab", "disabled")) {
				actions.reportCreatePASS("Promotion range status", "Promotion range is disabled as Expected",
						"Promotion range is disabled as Expected", "PASS");
			} else {
				actions.reportCreateFAIL("Promotion range status", "Promotion range is disabled as Expected",
						"Promotion range is not disabled as Expected", "Fail");
			}

			// Checking for the Promotion choice settings components
			if (ISAttribtuePresent("ManageMenuItem.ProCh_Yes", "disabled")
					&& ISAttribtuePresent("ManageMenuItem.ProCh_No", "disabled")) {

				actions.reportCreatePASS("Promotional Choice Settings are disabled as Expected",
						"Promotional Choice Settings are disabled as Expected",
						"Promotional Choice Settings are disabled as Expected", "PASS");
			} else {

				actions.reportCreateFAIL("Promotional Choice Settings are not disabled as Expected",
						"Promotional Choice Settings are not disabled as Expected",
						"Promotional Choice Settings are not disabled as Expected", "FAIL");
			}

			/// Verify promotion choice is set to No by default
			if (ISAttribtuePresent("ManageMenuItem.ProCh_No", "checked")) {
				WebElement elem = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.ProCh_No")));
				String value = elem.getAttribute("checked");
				if (value.equals("true")) {
					actions.reportCreatePASS("By Default the Promotional Choice setting is set to NO ",
							"By Default the Promotional Choice setting is set to NO ",
							"By Default the Promotional Choice setting is set to NO ", "PASS");
				}

			} else {
				actions.reportCreateFAIL("Fail:Promotional Choice Setting is not displayed as expected.",
						"Promotional Choice Setting is not displayed as expected.",
						"Fail:Promotional Choice Setting is not displayed as expected.", "FAIL");
			}

			// verifying Promotional Menu item flags
			if (!ISAttribtuePresent("ManageMenuItem.ProMI_Yes", "disabled")
					&& !ISAttribtuePresent("ManageMenuItem.ProMI_No", "disabled")) {
				actions.reportCreatePASS("Promotional Menu Item Settings are Enabled as Expected",
						"Promotional Menu Item Settings are Enabled as Expected",
						"Promotional Menu Item Settings are Enabled as Expected", "PASS");
			} else {
				actions.reportCreateFAIL("Fail:Promotional Menu Item Settings are disabled",
						"Fail:Promotional Menu Item Settings are disabled",
						"Fail:Promotional Menu Item Settings are disabled", "FAIL");
			}

			// Changing Promotional menu item flag to yes and click on save
			// button
			actions.click("ManageMenuItem.ProMI_Yes");
			actions.click("ManageMenuItem.ApplySavebtn");
			mcd.SwitchToWindow("Apply Changes Details");
			actions.click("ApplyChangesDetails.save");
			mcd.SwitchToWindow("@Manage Menu Items");
			actions.smartWait(180);

			// Checking for promotion range is enable
			if (!ISAttribtuePresent("ManageMenuItem.PromRngtab", "disabled")) {
				actions.reportCreatePASS("Promotion range status", "Promotion range is enabled as Expected",
						"Promotion range is enabled as Expected", "PASS");
			} else {
				actions.reportCreateFAIL("Promotion range status", "Promotion range is enabled as Expected",
						"Promotion range is not enabled as Expected", "Fail");
			}

			// navigating to the master menu item list page
			actions.click("ManageMenuItem.Cancelbtn1");
			actions.smartWait(180);

			// Searching for Choice menu item
			actions.clear("MasterMenuItemList.srch_text");
			actions.setValue("MasterMenuItemList.srch_text", MI_Choice);
			actions.click("MasterMenuItemList.Searchbtn");
			actions.smartWait(180);

			// Click on menu item
			rec_sel = mcd.GetTableCellElement("MasterMenuItemList.datatable", 1, "Number", "a");
			actions.click(rec_sel);
			actions.smartWait(180);

			// Checking for Promotional menu item flags
			if (ISAttribtuePresent("ManageMenuItem.ProMI_Yes", "disabled")
					&& ISAttribtuePresent("ManageMenuItem.ProMI_No", "disabled")) {
				actions.reportCreatePASS("Verify Promotional Menu Item Settings are disabled or not",
						"Promotional Menu Item Settings should be disabled",
						"Promotional Menu Item Settings are disabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Promotional Menu Item Settings are disabled or not",
						"Promotional Menu Item Settings should be disabled",
						"Promotional Menu Item Settings are not disabled", "Fail");
			}

			// Verify the by default selection of the promotion choice is set to
			// NO
			if (ISAttribtuePresent("ManageMenuItem.ProMI_No", "checked")) {
				WebElement elem = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.ProMI_No")));
				String value = elem.getAttribute("checked");
				if (value.equals("true")) {
					Reporter.log("By Default the Promotional Menu Item setting is set to NO ");
					actions.reportCreatePASS("Validating Promotional Menu Item setting is set to NO by default",
							"Promotional Menu Item setting should set to NO by default",
							"Promotional Menu Item setting is set to NO", "PASS");
				}

			} else {
				actions.reportCreateFAIL("Validating Promotional Menu Item setting is set to NO by default",
						"Promotional Menu Item setting should set to NO by default",
						"Promotional Menu Item setting is not set to NO", "Fail");
			}

			// Verifying the Promotional Choice Yes radio button status
			if (!ISAttribtuePresent("ManageMenuItem.ProCh_Yes", "disabled")
					&& !ISAttribtuePresent("ManageMenuItem.ProCh_No", "disabled")) {
				actions.reportCreatePASS("Validating Promotional Choice Settings status",
						"Promotional Choice Settings should not disabled",
						"Promotional Choice Settings are not disabled", "Pass");
			} else {

				actions.reportCreateFAIL("Validating Promotional Choice Settings status",
						"Promotional Choice Settings should not disabled", "Promotional Choice Settings are disabled",
						"Fail");
			}

			// ** Verify the by default selection of the promotion choice is set
			// to NO
			if (ISAttribtuePresent("ManageMenuItem.ProCh_No", "checked")) {
				WebElement elem = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.ProCh_No")));
				String value = elem.getAttribute("checked");
				if (value.equals("true")) {

					actions.reportCreatePASS("Validating Promotional Choice No radio button status",
							"Promotional Choice No radio button should not disabled",
							"Promotional Choice No radio button are not disabled", "Pass");
				} else {

					actions.reportCreateFAIL("Validating Promotional Choice No radio button status",
							"Promotional Choice No radio button should not disabled",
							"Promotional Choice No radio button are disabled", "Fail");
				}
			}

			// Click on promotional choice flag to yes radio button and click on
			// save button
			actions.click("ManageMenuItem.ProCh_Yes");
			actions.click("ManageMenuItem.ApplySavebtn");
			mcd.SwitchToWindow("Apply Changes Details");
			actions.click("ApplyChangesDetails.save");
			mcd.SwitchToWindow("@Manage Menu Item");
			actions.smartWait(180);

			// Checking for promotion range is enable
			if (!ISAttribtuePresent("ManageMenuItem.PromRngtab", "disabled")) {
				actions.reportCreatePASS("Promotion range is enabled as Expected",
						"Promotion range is enabled as Expected", "Promotion range is enabled as Expected", "PASS");
			} else {
				actions.reportCreateFAIL("Promotion range is not displayed as Expected",
						"Promotion range is not displayed as Expected", "Promotion range is not displayed as Expected",
						"FAIL");
			}

			// Navigate to Master menu item list
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(4000);
			actions.waitForPageToLoad(120);
			actions.smartWait(60);

			// Click on menu item M1 and click on search button
			actions.setValue("MasterMenuItemList.srch_text", MI_Pro);
			actions.click("MasterMenuItemList.Searchbtn");
			actions.smartWait(180);
			String menuitem = driver.findElement(By.xpath(actions.getLocator("MasterMenuItemList.MenuItemNumber")))
					.getText();
			WebElement rec_sel1 = mcd.GetTableCellElement("MasterMenuItemList.datatable", 1, "Number", "a");
			actions.click(rec_sel1);
			actions.smartWait(180);

			// Click on Promotion range tab
			actions.click("ManageMenuItem.PromRngtab");
			actions.smartWait(180);

			// Click on start calendar
			actions.click("ManageMenuItems.StartDate");
			mcd.Get_future_date(2, "Close", strApplicationDate);
			actions.smartWait(20);

			// Click on end calendar
			actions.click("ManageMenuItems.EndDate");
			mcd.Get_future_date(2, "Close", strApplicationDate);
			actions.smartWait(20);

			// Enter text in promotion text and click on apply button
			actions.setValue("ManageMenuItem.PromoText", "English");
			actions.click("ManageMenuItem.ApplySavebtn");
			mcd.SwitchToWindow("Apply Changes Details");
			actions.click("ApplyChangesDetails.save");
			mcd.SwitchToWindow("@Manage Menu Items");
			actions.smartWait(180);
			actions.verifyTextPresence("Your changes have been saved.", true);

			// Storing updated data
			String start_date = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.PRStDate")))
					.getAttribute("value");
			String end_date = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.PREndDate")))
					.getAttribute("value");
			String promotion = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.PromoText")))
					.getAttribute("value");

			// Navigate to MENU ITEMS SET
			System.out.println("> Navigate to :: " + strNavigateTo1);
			actions.select_menu("RFMHome.Navigation", strNavigateTo1);
			Thread.sleep(4000);
			actions.waitForPageToLoad(120);
			actions.smartWait(60);

			// Create new Menu Item Set
			actions.click("MenuItemSet.NewMISbutton");
			mcd.waitAndSwitch("Add New Menu Item Set");
			String strSetName = mcd.fn_GetRndName("Auto");
			actions.setValue("NewMenuItemSet.SetName", strSetName);
			System.out.println("Menu item Set Name:" + strSetName);
			actions.keyboardEnter("NewMenuItemSet.SelectBtn");
			mcd.waitAndSwitch("Select Node");
			mcd.Selectrestnode("SelectNode.Tree", strMarket);
			mcd.SwitchToWindow("Add New Menu Item Set");
			actions.keyboardEnter("NewMenuItemSet.NextBtn");
			mcd.SwitchToWindow("@Manage Menu Item Set : Common Menu Item Selector");
			actions.keyboardEnter("CommonMenuItem.SearchBtn");
			actions.smartWait(50);
			actions.javaScriptClick("CommonMenuItemSelector.AddCheckBox");
			actions.smartWait(30);
			actions.keyboardEnter("CommonMenuItemSelector.SaveBtn");
			actions.smartWait(180);
			actions.verifyTextPresence("Your changes have been saved.", true);

			// Click on Return to menu items set
			actions.keyboardEnter("MenuItemSets.ReturnToSet");
			mcd.SwitchToWindow("#Title");

			// Searching for menu item set
			actions.clear("CopyScreenSet.CopySearchTextBox");
			actions.setValue("CopyScreenSet.CopySearchTextBox", strSetName);
			List<WebElement> ele1 = driver.findElements(By.xpath("//*[@id='menuItemSetSearchForm_']"));
			actions.click(ele1.get(0));
			actions.smartWait(180);

			// Click on menu item set link
			actions.click("MenuItemSets.TableFirstValue");
			actions.smartWait(180);

			// Click on add/remove button for adding product menu item
			actions.keyboardEnter("ManageMenuItemSet.AddRemoveBtn");
			actions.javaScriptClick("CopyComponents.SearchExactMatch");
			actions.setValue("CommonMenuItemSelector.SearchTextBox", MI_Pro);
			List<WebElement> search = driver.findElements(By.xpath("//*[@class='button'][contains(text(),'Search')]"));
			actions.click(search.get(1));
			actions.smartWait(180);
			WebElement checkbox = mcd.GetTableCellElement("AddRemoveComponent.webtable", 1, "Add", "input");
			actions.javaScriptClick(checkbox);
			actions.keyboardEnter("RFMQueueRoutingPopupPage.SaveButton");
			mcd.SwitchToWindow("@Manage Menu Item Set : Manage Menu Items");
			actions.setValue("ProductionRouting.SearchTextField", menuitem);
			actions.javaScriptClick("RecipeReport.ExactMatchBtn");
			List<WebElement> ele = driver.findElements(By.xpath("//*[@class='button'][contains(text(),'Search')]"));
			actions.click(ele.get(1));
			actions.smartWait(180);
			actions.click("MasterMenuItemList.MenuItemNumber");
			actions.smartWait(180);

			// Click on promotion rang tab
			actions.keyboardEnter("RestMIList.PromotionRangeTab");
			actions.smartWait(180);

			String start_date_set = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.PRStDate")))
					.getAttribute("value");
			String end_date_set = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.PREndDate")))
					.getAttribute("value");
			String promotion_set = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.PromoText")))
					.getAttribute("value");

			// Verifying updated values in promotion tang tap
			if (start_date.equals(start_date_set)) {
				actions.reportCreatePASS("Verifying Start date in Menu item set",
						"Start date in Menu item set should display as expected",
						"Start date in Menu item set is displayed as expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Start date in Menu item set",
						"Start date in Menu item set should display as expected",
						"Start date in Menu item set is not displayed as expected", "FAIL");
			}

			if (end_date.equals(end_date_set)) {
				actions.reportCreatePASS("Verifying End date in Menu item set",
						"End date in Menu item set should display as expected",
						"End date in Menu item set is displayed as expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying End date in Menu item set",
						"End date in Menu item set should display as expected",
						"End date in Menu item set is not displayed as expected", "FAIL");
			}

			if (promotion.equals(promotion_set)) {
				actions.reportCreatePASS("Verifying Promotion text Menu item set",
						"Promotion text in Menu item set should display as expected",
						"Promotion text in Menu item set is displayed as expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Promotion text in Menu item set",
						"Promotion text in Menu item set should display as expected",
						"Promotion text in Menu item set is not displayed as expected", "FAIL");
			}

			// Navigate Restaurant menu item list
			System.out.println("> Navigate to :: " + strNavigateTo2);
			actions.select_menu("RFMHome.Navigation", strNavigateTo2);
			Thread.sleep(4000);
			actions.waitForPageToLoad(120);
			actions.smartWait(60);
			mcd.SwitchToWindow("#Title");

			// Select Restaurant
			actions.javaScriptClick("RestaurantProfile.ExactMatchRadioButton");
			actions.clear("RestaurantUpdt.SearchRestro");
			actions.setValue("RestaurantUpdt.SearchRestro", strrest);
			actions.keyboardEnter("RestaurantProfile.searchbutton");
			actions.keyboardEnter("RestaurantProfile.TableFirstValue");
			actions.smartWait(180);

			// Click on 'Menu Item / POS / Pricing' tab and Select Set Type
			actions.click("RestaurantProfile.MIPOSPricing");
			actions.smartWait(180);
			actions.setValue("RestaurantProfile.ChooseSetTypeDDL", "Menu Items");
			actions.smartWait(180);
			actions.setValue("RestaurantUpdt.SrchSetType", strSetName);
			actions.keyboardEnter("RestaurantProfile.MuSearchbtn");
			actions.smartWait(180);
			WebElement menuset = mcd.GetTableCellElement("SelectNode.Tree", 1, "Set Name", "td");
			actions.click(menuset);
			actions.smartWait(180);
			actions.click("RecipeReport.NextBtn");
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("RestaurantProfile.ApplyButton");

			try {
				System.out.println("<<<<<<       : " + strwmessage);
				mcd.VerifyAlertMessageDisplayed("Warning Message", strwmessage, true, AlertPopupButton.OK_BUTTON);
			} catch (Exception e) {

			}

			try {
				Thread.sleep(2000);
				System.out.println("<<<<<<       : " + strWMUNSD);
				mcd.VerifyAlertMessageDisplayed("Warning Message", strWMUNSD, true, AlertPopupButton.OK_BUTTON);

			} catch (Exception e) {

			}

			try {
				actions.waitForPageToLoad(120);
				mcd.SwitchToWindow("Apply Changes Details");
				mcd.smartsync(180);
				actions.WaitForElementPresent("ApplyChangesDetails.SaveBtn", 120);
				actions.keyboardEnter("ApplyChangesDetails.SaveBtn");

				// Switch to Main window
				mcd.SwitchToWindow("$Restaurant Profile");
				actions.smartWait(180);
				actions.waitForPageToLoad(120);

			} catch (Exception e) {

			}

			try {
				Thread.sleep(2000);

				mcd.waitAndSwitch("Run Validation Report");
				System.out.println(driver.getTitle());
				WebElement okbtn = driver.findElement(By.xpath("//*[@class='button'][contains(text(),'OK')]"));
				actions.click(okbtn);

				// Switch to Main window
				mcd.SwitchToWindow("$Restaurant Profile");
				actions.smartWait(180);
			} catch (Exception e) {

			}

			// Navigate to restaurant menu item list
			actions.select_menu("RFMHome.Navigation", strNavigateTo3);
			actions.waitForPageToLoad(120);
			actions.smartWait(60);

			// Selecting restaurant
			actions.keyboardEnter("RestMIList.SelectRestBtn");
			mcd.SwitchToWindow(" Select a Restaurant");
			mcd.Selectrestnode_JavaScriptClk("RestaurantMenuItemList.SelectNodeTree", strrest);
			mcd.SwitchToWindow("@Menu Item ListRestaurant");

			// Selecting menu item from restaurant list and click on search
			// button
			actions.javaScriptClick("RecipeReport.ExactMatchBtn");
			actions.clear("ProductionRouting.SearchTextField");
			actions.setValue("ProductionRouting.SearchTextField", MI_Pro);
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			actions.smartWait(180);

			// Clicking menu item number
			actions.keyboardEnter("MasterMenuItemList.MenuItemNumber");
			actions.smartWait(180);

			// Click on promotion rang tab
			actions.keyboardEnter("RestMIList.PromotionRangeTab");
			actions.smartWait(180);

			String start_date_set_rest = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.PRStDate")))
					.getAttribute("value");
			String end_date_set_rest = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.PREndDate")))
					.getAttribute("value");
			String promotion_set_rest = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.PromoText")))
					.getAttribute("value");

			// Verifying updated values in promotion tang tap
			if (start_date.equals(start_date_set_rest)) {
				actions.reportCreatePASS("Verifying Start date in Menu item set",
						"Start date in Menu item set should display as expected",
						"Start date in Menu item set is displayed as expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Start date in Menu item set",
						"Start date in Menu item set should display as expected",
						"Start date in Menu item set is not displayed as expected", "FAIL");
			}

			if (end_date.equals(end_date_set_rest)) {
				actions.reportCreatePASS("Verifying End date in Menu item set",
						"End date in Menu item set should display as expected",
						"End date in Menu item set is displayed as expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying End date in Menu item set",
						"End date in Menu item set should display as expected",
						"End date in Menu item set is not displayed as expected", "FAIL");
			}

			if (promotion.equals(promotion_set_rest)) {
				actions.reportCreatePASS("Verifying Promotion text Menu item set",
						"Promotion text in Menu item set should display as expected",
						"Promotion text in Menu item set is displayed as expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Promotion text in Menu item set",
						"Promotion text in Menu item set should display as expected",
						"Promotion text in Menu item set is not displayed as expected", "FAIL");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}

	}

	public boolean ISAttribtuePresent(String sElement, String attribute) {
		Boolean result = false;
		try {
			WebElement element = driver.findElement(By.xpath(actions.getLocator(sElement)));
			String value = element.getAttribute(attribute);
			if (value != null) {
				result = true;
			}
		} catch (Exception e) {

			// Reporter.log(e.getMessage());
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());

		}

		return result;
	}
}