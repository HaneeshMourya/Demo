package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.MasterMenuItem;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20131_ChngApprovalStsDate {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private boolean flag;
	private boolean flag1;
	private MasterMenuItem mmi;
	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo, strWM;
	private String strWM1;
	private String msg;
	private String strStatus;
	private String MIrange;
	private String pro_type;
	private String strmsg;
	private String strmenutype;
	// TODO: Declare test-data variables for other data-parameters

	public MNU_20131_ChngApprovalStsDate(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		mmi = new MasterMenuItem(driver, actions, uiActions, inputData, mcd, rfm);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		msg = mcd.GetTestData("DT_MSG");
		strStatus = mcd.GetTestData("DT_Status1");
		strWM = mcd.GetTestData("DT_WarningMessage");
		MIrange = mcd.GetTestData("DT_MIRANGE");
		pro_type = mcd.GetTestData("DT_MENUITEMCLASS");
		strmsg = mcd.GetTestData("DT_ERR_MSG");
		strmenutype = mcd.GetTestData("DT_MIPARAM");
	}

	@Test
	public void test_MNU_20131_ChngApprovalStsDate() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription("Verify the Status change-Type 2 market (Also verify Status change-Date).");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow
			// Create New Menu Item with Menu item Class as Product.
			String[] strparam = strmenutype.split("#");
			int MenuNumber = mmi.RFM_MI_CreateMenuItem_updated(MIrange, pro_type, strmsg, strmenutype);
			String strMenuNumber = Integer.toString(MenuNumber);
			System.out.println("> > > >" + strMenuNumber);

			// Click on search button & Select any menu item
			actions.setValue("ManageMenuItems.SearchText", strMenuNumber);
			actions.click("MenuItemSets.SearchButton");
			actions.smartWait(20);
			actions.waitForPageToLoad(10000);
			actions.keyboardEnter("MasterMenuItemList.NumberLink");
			actions.smartWait(20);
			actions.waitForPageToLoad(10000);
			actions.WaitForElementPresent("ManageMenuItems.ChangeAprrovalStatusButton", 100);

			// Click on Change approval status button & Click on Cancel Button
			actions.keyboardEnter("ManageMenuItems.ChangeAprrovalStatusButton");
			if (strMarket.equals("Australasia")) {
				mcd.SwitchToWindow("Status Changes");
			} else {
				mcd.SwitchToWindow("Approval Status Changes");
			}
			actions.WaitForElementPresent("ApprovalStatusChanges.AddButton", 100);
			if (strMarket.equals("Australasia")) {
				Thread.sleep(2000);
				actions.click("RestaurantMenuItemList.ChangeStatus_Cancel");
			} else {
				Thread.sleep(2000);
				actions.click("GlobalSettingsLookups.cancel");
			}

			// User is navigated to Master Menu Item List search screen
			mcd.SwitchToWindow("@Manage Menu Items");
			actions.click("MenuItemGroup.Cancelbtn");
			actions.smartWait(20);
			actions.waitForPageToLoad(20);

			// Select any menu item with active status & Click on Change status
			// button
			actions.clear("ManageMenuItems.SearchText");
			actions.setValue("ManageMenuItems.SearchText", strMenuNumber);
			actions.click("MenuItemSets.SearchButton");
			actions.smartWait(20);
			actions.waitForPageToLoad(10000);
			actions.keyboardEnter("MasterMenuItemList.NumberLink");
			actions.smartWait(20);
			actions.waitForPageToLoad(10000);
			actions.WaitForElementPresent("ManageMenuItems.ChangeAprrovalStatusButton", 100);

			// Click on Change status button
			actions.keyboardEnter("ManageMenuItems.ChangeAprrovalStatusButton");
			if (strMarket.equals("Australasia")) {
				mcd.SwitchToWindow("Status Changes");
			} else {
				mcd.SwitchToWindow("Approval Status Changes");
			}
			actions.WaitForElementPresent("ApprovalStatusChanges.AddButton", 100);

			// Click on Add approval status button & Select Current date
			actions.keyboardEnter("ApprovalStatusChanges.AddButton");
			actions.click("ApprovalStatusChanges.CalendarIconScnd");
			mcd.Get_future_date(0, "Close", strApplicationDate);

			// Click on Save Button & Cancel Pop Message, Again OK POP Message
			if (strMarket.equals("Australasia")) {
				actions.click("RestaurantMenuItemList.ChangeStatus_Save");
				boolean booAlert3 = mcd.VerifyAlertMessageDisplayed("Warning Message", strWM, true,
						AlertPopupButton.CANCEL_BUTTON);
				if (booAlert3) {
					actions.reportCreatePASS("Verify Alert is Present", "Alert should be Present", "Alert is Present",
							"PASS");
				} else {
					actions.reportCreateFAIL("Verify Alert is Present", "Alert should be Present",
							"Alert is not Present", "FAIL");
				}
				actions.click("RestaurantMenuItemList.ChangeStatus_Save");
				boolean booAlert = mcd.VerifyAlertMessageDisplayed("Warning Message", strWM, true,
						AlertPopupButton.OK_BUTTON);
				if (booAlert) {
					actions.reportCreatePASS("Verify Alert is Present", "Alert should be Present", "Alert is Present",
							"PASS");
				} else {
					actions.reportCreateFAIL("Verify Alert is Present", "Alert should be Present",
							"Alert is not Present", "FAIL");
				}
				Thread.sleep(5000);
			} else {
				actions.click("IngredientGroups.save");
				Thread.sleep(5000);
			}
			mcd.waitAndSwitch("Run Menu Item Usage Report");
			actions.keyboardEnter("RecipeReport.CancelButton");
			// Click on Cancel button
			if (mcd.GetGlobalData("Instance").equalsIgnoreCase("AP")) {
				mcd.waitAndSwitch("$Status Changes");
				actions.smartWait(180);
			} else {
				mcd.waitAndSwitch("$Approval Status Changes");
				actions.smartWait(180);
			}

			actions.verifyTextPresence("Your changes have been saved.", true);

			if (strMarket.equals("Australasia")) {
				Thread.sleep(2000);
				actions.click("RestaurantMenuItemList.ChangeStatus_Cancel");
			} else {
				Thread.sleep(2000);
				actions.click("GlobalSettingsLookups.cancel");
			}
			mcd.SwitchToWindow("@Manage Menu Items");

			// Click on Change status button
			actions.keyboardEnter("ManageMenuItems.ChangeAprrovalStatusButton");
			if (strMarket.equals("Australasia")) {
				mcd.SwitchToWindow("Status Changes");
			} else {
				mcd.SwitchToWindow("Approval Status Changes");
			}

			// Click on Add approval status button & Select Future date
			actions.keyboardEnter("ApprovalStatusChanges.AddButton");
			actions.click("ApprovalStatusChanges.CalendarIconScnd");
			mcd.Get_future_date(1, "Close", strApplicationDate);

			// Click on Save Button & Verify Message
			if (strMarket.equals("Australasia")) {
				actions.keyboardEnter("RestaurantMenuItemList.ChangeStatus_Save");
				Thread.sleep(5000);
			} else {
				actions.keyboardEnter("IngredientGroups.save");
				Thread.sleep(5000);
			}
//			mcd.waitAndSwitch("Run Menu Item Usage Report");
//			actions.keyboardEnter("RecipeReport.CancelButton");
			actions.verifyTextPresence("Your changes have been saved.", true);
			if (strMarket.equals("Australasia")) {
				Thread.sleep(2000);
				actions.click("RestaurantMenuItemList.ChangeStatus_Cancel");
			} else {
				Thread.sleep(2000);
				actions.click("GlobalSettingsLookups.cancel");
			}

			mcd.SwitchToWindow("@Manage Menu Items");
			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}
