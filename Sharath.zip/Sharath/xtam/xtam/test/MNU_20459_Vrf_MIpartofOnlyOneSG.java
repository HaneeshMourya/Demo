package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20459_Vrf_MIpartofOnlyOneSG {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String sgName;
	private String miName_1;
	private boolean flag;
	private String strErr;

	public MNU_20459_Vrf_MIpartofOnlyOneSG(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strErr = mcd.GetTestData("DT_ERR_MSG");

		// TODO: GetTestData for other data-parameters
	}

	@Test
	public void test_MNU_20459_Vrf_MIpartofOnlyOneSG() throws InterruptedException {
		String strPageTitle = ""; // TODO: Exact page-title
		String strPageSubHeading = ""; // TODO: Page Heading

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(
					"Verify that a Menu Item can be part of one and only one Substitution Group");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			String app_date = apptime.getText();

			// ------------------------------------------------------------------------
			// Verify the Substitution Group Page

			// Verify Search Field Editable
			boolean SearchTextField1 = driver.findElement(By.xpath(actions.getLocator("SubstitutionGroups.SearchBox")))
					.isEnabled();
			System.out.println(SearchTextField1);
			if (SearchTextField1 == true) {
				System.out.println("Search Text Field is Enabled");
				actions.reportCreatePASS("Verify SearchTextField1 Text Field is Enabled",
						"SearchTextField1 Text Field should Enabled", "SearchTextField1 Text Field is Enabled", "Pass");
				actions.setValue("SubstitutionGroups.SearchBox", "Search TextBox is in Enabled State");
			} else {
				System.out.println("SearchTextField1 Text Field is Disabled");
				actions.reportCreateFAIL("Verify SearchTextField1 Text Field is Enabled",
						"SearchTextField1 Text Field should Enabled", "SearchTextField1 Text Field is not Enabled",
						"Fail");
			}
			

			// Verifying presence of 'Search' Button
			Boolean Searchbutton;
			Searchbutton = actions.isElementPresent("SubstitutionGroups.SearchButton");
			reporting_Pass_Fail("Verify whether 'Search' Button is present", "'Search' Button should be present",
					"'Search' Button is present", "'Search' Button is not present", Searchbutton);
			
			
			// Verifying 'Search within Status' Filter
			Boolean SearchStatus;
			Select selObj = new Select(
					driver.findElement(By.xpath(actions.getLocator("SubstitutionGroups.SearchWithinStatus"))));
			SearchStatus = selObj.getFirstSelectedOption().getText().trim().equalsIgnoreCase("Active/Inactive");
			reporting_Pass_Fail(
					"Verify whether Search within Status Active/Inactive is selected by default for Status DDL",
					"Search within Status Active/Inactive should be selected by default",
					"Search within Status Active/Inactive is selected by default",
					"Search within Status Active/Inactive is not selected by default", SearchStatus);

			
			
			// Verifying 'Status' Filter
			Boolean Status;
			Select selObj1 = new Select(
					driver.findElement(By.xpath(actions.getLocator("SubstitutionGroups.StatusDDL"))));
			Status = selObj1.getFirstSelectedOption().getText().trim().equalsIgnoreCase("Active/Inactive");
			reporting_Pass_Fail("Verify whether Status Active/Inactive is selected by default for Status DDL",
					"Status Active/Inactive should be selected by default",
					"Status Active/Inactive is selected by default",
					"Status Active/Inactive is not selected by default", Status);
			
			
			
			// Verifying presence of 'Cancel' Button
			Boolean Cancelbutton;
			Cancelbutton = actions.isElementPresent("RFMPresentationRoutingSetPage.CancelButton");
			reporting_Pass_Fail("Verify whether 'Cancel' Button is present", "'Cancel' Button should be present",
					"'Cancel' Button is present", "'Cancel' Button is not present", Cancelbutton);
			
			
			
			// Verifying presence of 'Save' Button
			Boolean Savebutton;
			Savebutton = actions.isElementPresent("GlobalSettingsGblLookupUpdate.save");
			reporting_Pass_Fail("Verify whether 'Save' Button is present", "'Save' Button should be present",
					"'Save' Button is present", "'Save' Button is not present", Savebutton);
			
			
			// Select exiting Substitution Group
			actions.clear("SubstitutionGroups.SearchBox");
			actions.keyboardEnter("SubstitutionGroups.SearchButton");
			actions.smartWait(100);
			WebElement substitution = mcd.GetTableCellElement("SubstitutionGroups.Table", 1, "Group Name", "a");
			actions.click(substitution);
			actions.smartWait(100);
			
			
			//Get the menu item number
			String menitemnum = driver.findElement(By.xpath(".//*[@id='Sess1']/tbody/tr[1]/td[1]")).getText();
			System.out.println(menitemnum);
			
			
			// Again Selecting another exiting Substitution Group
			actions.click("UpdateSubstitutionGroup.CancelBtn");
			actions.smartWait(100);
			WebElement substitution2 = mcd.GetTableCellElement("SubstitutionGroups.Table", 2, "Group Name", "a");
			actions.click(substitution2);
			actions.smartWait(100);
			
			
			//Click on Add/Remove Button
			actions.click("DimensionGroup.AddMenuItemButton");
			mcd.waitAndSwitch("Common Menu Item Selector");
			actions.smartWait(15);
			
			
			//Verify the Substitution group1 menu item number disable on Substitution Group2
			actions.clear("CommonMenuItemSelector.SearchTextBox");
			actions.setValue("CommonMenuItemSelector.SearchTextBox", menitemnum);
			actions.javaScriptClick("CommonMenuItemSelector.ExactMacth");
			actions.keyboardEnter("AddRemoveComponent.Searchbtn");
			actions.smartWait(100);
			
			
			//Verify the on-screen message
			flag = mcd.VerifyOnscreenMessage("SubstitutionGroups.InfoMessage", "Search returned no matching results.",
					true);
			
			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message",
						"Message 'Search returned no matching results.'", "Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message",
						"Message 'Search returned no matching results.'", "Expected Message is not displayed", "FAIL");
			}
			
			
			//Click on Cancel button and verify the pop message
			actions.click("CommonMenuItemSelector.Cancel");
			if (mcd.VerifyAlertMessageDisplayed("Information", strErr, true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + strErr + " 'is Present or not",
						strErr + " should be present", strErr + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + strErr + " 'is Present or not",
						strErr + " should be present", strErr + " is not present", "Fail");
			}
			
			mcd.SwitchToWindow("@Title");
			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	// Function for Reporting Pass/Fail
	public void reporting_Pass_Fail(String Desc, String ExpRes, String ActRes_Pass, String ActRes_Fail,
			Boolean status) {
		if (status) {
			actions.reportCreatePASS(Desc, ExpRes, ActRes_Pass, "PASS");
		}

		if (!status) {
			actions.reportCreateFAIL(Desc, ExpRes, ActRes_Fail, "FAIL");
		}
	}

}
