package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class MNU_20463_Vrf_AuditLogWhnSNUpdt {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strUserID;
	private String auditMarket;
	private String strTestDescription, strMessage;

	// Declare test-data variables for other data-parameters
	private String sgName;
	private boolean flag;
	private String strOperation, strActivity, strLevel, strUID, strDBName;

	public MNU_20463_Vrf_AuditLogWhnSNUpdt(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// GetTestData for other data-parameters
		strTestDescription = mcd.GetTestData("DT_Description");
		strMessage = mcd.GetTestData("DT_MESSAGES");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strActivity = mcd.GetTestData("DT_ACTIVITY");
		strLevel = mcd.GetTestData("DT_LEVEL");
		strDBName = mcd.GetTestData("DT_DBNAME");
		strUID = mcd.GetTestData("DT_USERID");
	}

	@Test
	public void test_MNU_20463_Vrf_AuditLogWhnSNUpdt() throws InterruptedException {

		try {
			System.out.println("********************************** Test execution starts");

			/** Get Test Case Description */
			actions.setTestcaseDescription(strTestDescription);

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			String[] strMsg = strMessage.split("#");
			mcd.smartsync(10);

			// Validating for 'No changes have been made.'
			actions.checkElement(actions.getLocator("RestaurantSet.Searchbtn"), 180);
			actions.click("RestaurantSet.Searchbtn");
			mcd.smartsync(180);
			sgName = mcd.GetTableCellValue("SubstitutionGroups.Table", 1, "Group Name", "", "");
			System.out.println("> > > > >" + sgName);
			WebElement Element = mcd.GetTableCellElement("SubstitutionGroups.Table", 1, "Group Name", "a");
			actions.keyboardEnter(Element);
			mcd.smartsync(180);
			actions.keyboardEnter("TenderTypeSet.ApplyButton");
			mcd.VerifyAlertMessageDisplayed("Alert", strMsg[0], true, AlertPopupButton.OK_BUTTON);

			// Verifying Cancel button functionality by navigating back to main
			// page
			actions.keyboardEnter("RestaurantSet.Cancelbtn");
			mcd.smartsync(180);

			// Verifying Cancel functionality and confirmation alert for unsaved
			// data
			Element = mcd.GetTableCellElement("SubstitutionGroups.Table", 1, "Group Name", "a");
			actions.keyboardEnter(Element);
			mcd.smartsync(180);
			actions.WaitForElementPresent("SubstitutionGroups.SubstitutionGroupName", 120);
			actions.clear("SubstitutionGroups.SubstitutionGroupName");
			sgName = mcd.fn_GetRndName("AutoUD");
			actions.setValue("SubstitutionGroups.SubstitutionGroupName", sgName);
			actions.keyboardEnter("RestaurantSet.Cancelbtn");
			mcd.VerifyAlertMessageDisplayed("Alert", strMsg[1], true, AlertPopupButton.CANCEL_BUTTON);
			actions.keyboardEnter("RestaurantSet.Cancelbtn");
			mcd.VerifyAlertMessageDisplayed("Alert", strMsg[1], true, AlertPopupButton.OK_BUTTON);
			Thread.sleep(2000);
			mcd.smartsync(180);

			// Verifying the confirmation message for deleting a selected Menu
			// Item
			Element = mcd.GetTableCellElement("SubstitutionGroups.Table", 1, "Group Name", "a");
			actions.keyboardEnter(Element);
			mcd.smartsync(180);

			// If there is no single Menu Item also adding a MI
			int iRows = mcd.GetTableRowCount("CopyRole.table");
			if (iRows == 0) {
				actions.keyboardEnter("SubstitutionGroups.AddMenuItemButton");
				mcd.waitAndSwitch("Common Menu Item Selector");
				actions.WaitForElementPresent("RestaurantSet.Searchbtn", 120);
				actions.keyboardEnter("RestaurantSet.Searchbtn");
				mcd.smartsync(180);
				int iMIRows = mcd.GetTableRowCount("Deposit.AddDepositTable");
				for (int i = 1; i < iMIRows; i++) {
					WebElement chk_box = mcd.GetTableCellElement("Deposit.AddDepositTable", i, 1, "input");
					if (chk_box.isEnabled()) {
						actions.javaScriptClick(chk_box);
						break;
					}
				}
				actions.keyboardEnter("RFM.ContinueButton");
				mcd.waitAndSwitch("Substitution Groups");
				Select subddl = new Select(
						driver.findElement(By.xpath(actions.getLocator("UpdateSubstitutionGroup.SubstitutionDDL"))));
				subddl.selectByIndex(1);
				actions.javaScriptClick("SubstitutionGroups.ApplyButton");
				mcd.smartsync(180);
			}

			WebElement DeleteIcon = mcd.GetTableCellElement("CopyRole.table", 1, "Delete", "a/img");
			actions.click(DeleteIcon);
			mcd.VerifyAlertMessageDisplayed("Alert", strMsg[2], true, AlertPopupButton.CANCEL_BUTTON);

			// Updating the Substitution Group Name and Applying
			actions.WaitForElementPresent("SubstitutionGroups.SubstitutionGroupName", 120);
			actions.clear("SubstitutionGroups.SubstitutionGroupName");
			String sgName1 = mcd.fn_GetRndName("AutoUD");
			actions.setValue("SubstitutionGroups.SubstitutionGroupName", sgName1);
			actions.javaScriptClick("SubstitutionGroups.ApplyButton");
			mcd.smartsync(180);

			// Validating Update success message
			flag = mcd.VerifyOnscreenMessage("SubstitutionGroups.InfoMessage", strMsg[3], true);
			if (flag) {
				actions.reportCreatePASS("Verify Update functionality of substitution Name and success message",
						"Substitution Name should get updated",
						"Substitution Name is updated and success message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Update functionality of substitution Name and success message",
						"Substitution Name should get updated",
						"Substitution Name is not updated and no success message is displayed", "FAIL");
			}

			// Verifying the audit log for Updating Substitution Group Name
			boolean blnAudit = false;
			blnAudit = rfm.VerifyAuditLog_Entry(strOperation, strActivity, strLevel);
			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Entry for Update Substitution Group Name",
						"Audit log should be generated for Update Substitution group Name",
						"Audit log generated for Update Substitution group Name succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Entry for Update Substitution Group Name",
						"Audit log should be generated for Update Substitution group Name",
						"Audit log not generated for Update Substitution group Name", "FAIL");
			}
			blnAudit = rfm.RFM_VerifyAuditLog_Details(strDBName, strUID, strOperation, strActivity, strLevel, strMarket,
					"Substitution Group " + sgName1 + " has been updated.");
			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Details for update Substitution Group Name",
						"Audit log details should be generated for update Substitution group name",
						"Audit log details generated for Substitution group name succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Details for update Substitution Group Name",
						"Audit log details should be generated for update Substitution group name",
						"Audit log details not generated for Substitution group name", "FAIL");
			}

			/** Logout the application */
			rfm.Logout();
		} catch (Exception e) {
			// reporting the Fail condition
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}
