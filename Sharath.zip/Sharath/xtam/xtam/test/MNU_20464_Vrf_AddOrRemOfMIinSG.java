package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20464_Vrf_AddOrRemOfMIinSG {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strdeletmsg;
	// TODO: Declare test-data variables for other data-parameters
	private String sgName;
	private boolean flag;
	private String miName_1;
	private String strUserID;
	private String auditMarket;

	public MNU_20464_Vrf_AddOrRemOfMIinSG(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		strUserID = mcd.GetTestData("DT_USER_NAME");
		auditMarket = mcd.GetTestData("DT_AUDITLOG_MARKET");
		strdeletmsg = mcd.GetTestData("DT_DeleteWarningMessage");
	}

	@Test
	public void test_MNU_20464_Vrf_AddOrRemOfMIinSG() throws InterruptedException {
		String strPageTitle = "Substitution Groups"; // TODO: Exact page-title
		String strPageSubHeading = ""; // TODO: Page Heading

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"Verify the audit log when adding/removing menu items, Status while updating Substitution Group");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");

			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			// actions.select_menu("RFMHome.Navigation",strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			String app_date = apptime.getText();

			// ------------------------------------------------------------------------
			//Adding Menu item in Substitution Group
			System.out.println("Start");
			System.out.println("Start");
			actions.click("SubstitutionGroups.NewSGButton");
			do {
				sgName = mcd.fn_GetRndName("Auto_SG");
				actions.clear("SubstitutionGroups.SubstitutionGroupName");
				actions.setValue("SubstitutionGroups.SubstitutionGroupName", sgName);
				actions.setValue("SubstitutionGroups.SetStatusDDL", "Inactive");
				actions.smartWait(100);
				actions.click("SubstitutionGroups.SaveButton");
				flag = mcd.VerifyOnscreenMessage("SubstitutionGroups.InfoMessage", "Your changes have been saved.",
						true);
			} while (!(flag));

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}
			actions.click("DimensionGroup.AddMenuItemButton");
			mcd.waitAndSwitch("Common Menu Item Selector");
			actions.smartWait(15);
			actions.keyboardEnter("AddRemoveComponent.Searchbtn");
			actions.smartWait(100);
			actions.setValue("CommonMenuItemSelector.AvailabilityFilter", "Available");
			actions.smartWait(30);
			if (strMarket.equals("Australasia")) {
				actions.setValue("CommonMenuItemSelector.StatusFilterDDL", "Inactive");
			} else {
				actions.setValue("CommonMenuItemSelector.StatusFilterDDL", "Approved");
			}
			actions.smartWait(15);
			WebElement Element = mcd.GetTableCellElement("CommonMenuItemSelector.table", 1, "Add", "input[1]");
			actions.javaScriptClick(Element);
			actions.click("CommonMenuItemSelector.ContinueButton");
			mcd.SwitchToWindow("Substitution Groups");
			String Default;
			Element = mcd.GetTableCellElement("DimensionGroups.Table", 1, "Substitution", "select");
			Default = Element.getText();
			Select selectOption = new Select(Element);
			
			List<WebElement> values = Element.findElements(By.xpath(".//option"));
			if (Default.equals((values.get(0).getText()))) {
				selectOption.selectByVisibleText(values.get(1).getText().toString());
			} else {
				selectOption.selectByVisibleText(values.get(2).getText().toString());
			}
			
			actions.click("SubstitutionGroups.ApplyButton");
			actions.smartWait(15);
			flag = mcd.VerifyOnscreenMessage("SubstitutionGroups.InfoMessage", "Your changes have been saved.", true);
			if (flag) {
				actions.reportCreatePASS("Verify the alert message", "Message 'Your changes have been saved.' ",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the alert message", "Message 'Your changes have been saved.' ",
						"Expected Message is not displayed", "FAIL");
			}
			actions.click("SubstitutionGroups.CancelButton");
			actions.smartWait(50);
			

			// Verifying the audit logs:
			boolean blnAudit = false;
			blnAudit = rfm.VerifyAuditLog_Entry(strPageTitle, "Update", auditMarket);

			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Entry for create Substitution Group",
						"Audit log should be generated for Create Substitution group",
						"Audit log generated for Create Substitution group succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Entry for create Substitution Group",
						"Audit log should be generated for Create Substitution group",
						"Audit log not generated for create Substitution group succesfully", "FAIL");
			}

			blnAudit = rfm.RFM_VerifyAuditLog_Details("RFM2", strUserID, strPageTitle, "Update", auditMarket, strMarket,
					"Substitution Group " + sgName + " has been updated.");
			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Details for update Substitution Group",
						"Audit log details should be generated for update Substitution group",
						"Audit log details generated for Substitution group item succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Details for update Substitution Group",
						"Audit log details should be generated for update Substitution group",
						"Audit log details not generated for Substitution group item succesfully", "FAIL");
			}
			

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			//Delete the menu item 
			actions.clear("SubstitutionGroups.SearchBox");
			actions.setValue("SubstitutionGroups.SearchBox", sgName);
			actions.click("SubstitutionGroups.SearchButton");
			actions.smartWait(15);

			Element = mcd.GetTableCellElement("SubstitutionGroups.Table", 1, "Group Name", "a");
			actions.keyboardEnter(Element);
			actions.smartWait(15);

			/*Element = mcd.GetTableCellElement("DimensionGroups.Table", 1, "Delete", "a");
			actions.keyboardEnter(Element);*/
			actions.click("SubstitutionGroup.DeletMenuitem");
			if (mcd.VerifyAlertMessageDisplayed("Information", strdeletmsg, true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + strdeletmsg + " 'is Present or not",
						strdeletmsg + " should be present", strdeletmsg + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + strdeletmsg + " 'is Present or not",
						strdeletmsg + " should be present", strdeletmsg + " is not present", "Fail");
			}
			mcd.VerifyOnscreenMessage("DimensionGroups.DeleteInfoMessage", "Delete has been successfully completed.",
					true);

			
			// Verifying the audit logs:
			blnAudit = false;
			blnAudit = rfm.VerifyAuditLog_Entry(strPageTitle, "Update", auditMarket);

			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Entry for create Substitution Group",
						"Audit log should be generated for Create Substitution group",
						"Audit log generated for Create Substitution group succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Entry for create Substitution Group",
						"Audit log should be generated for Create Substitution group",
						"Audit log not generated for create Substitution group succesfully", "FAIL");
			}

			blnAudit = rfm.RFM_VerifyAuditLog_Details("RFM2", strUserID, strPageTitle, "Update", auditMarket, strMarket,
					"Substitution Group " + sgName + " has been updated.");
			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Details for update Substitution Group",
						"Audit log details should be generated for update Substitution group",
						"Audit log details generated for Substitution group item succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Details for update Substitution Group",
						"Audit log details should be generated for update Substitution group",
						"Audit log details not generated for Substitution group item succesfully", "FAIL");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}
