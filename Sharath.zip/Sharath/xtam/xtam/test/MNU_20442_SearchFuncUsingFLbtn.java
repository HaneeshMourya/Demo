package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20442_SearchFuncUsingFLbtn {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String strRest;
	private boolean flag;
	private String setName;
	private String strErrmsg[];
	private String dtErr;
	private String strUserID;
	private String strFilterType;
	private String tcDescription;

	public MNU_20442_SearchFuncUsingFLbtn(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		strRest = mcd.GetTestData("DT_Node");
		dtErr = mcd.GetTestData("DT_ERR_MSG");
		strFilterType = mcd.GetTestData("DT_FilterType");
		strErrmsg = dtErr.split("#");

	}

	@Test
	public void test_MNU_20442_SearchFuncUsingFLbtn() throws InterruptedException {

		try {

			actions.setTestcaseDescription(
					"Verify the Search functionality of Dimension Name Set using �Filter List� section");

			System.out.println(
					"********************************************************************** Test execution starts");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			actions.smartWait(15);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Verify Dimension Name Set Page all fields
			verifyTablecolumnsPresent("ViewGeneratedReport.ReportTable", "Name");
			verifyTablecolumnsPresent("ViewGeneratedReport.ReportTable", "Node");
			verifyTablecolumnsPresent("ViewGeneratedReport.ReportTable", "Status");
			verifyTablecolumnsPresent("ViewGeneratedReport.ReportTable", "Delete");

			if (!actions.isElementEnabled("PMIGImageSet.MarketTextBox")) {
				actions.reportCreatePASS("Verify Market DropDown", "Market DropDown should be disabled",
						"Market DropDown is disabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Market DropDown", "Market DropDown should be disabled",
						"Market DropDown is not disabled", "FAIL");
			}
			if (!actions.isElementEnabled("PMIGImageSet.CountryDDL")) {
				actions.reportCreatePASS("Verify Country DropDown", "Country DropDown should be disabled",
						"Country DropDown is disabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Country DropDown", "Country DropDown should be disabled",
						"Country DropDown is not disabled", "FAIL");
			}
			String ele = driver.findElement(By.xpath(actions.getLocator("PMIGImageSet.FilterButton")))
					.getAttribute("class");
			if (ele.contains("disableButton")) {
				actions.reportCreatePASS("Verify Filter Button", "Filter Button should be disabled",
						"Filter Button is disabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Filter Button", "Filter Button should be disabled",
						"Filter Button is not disabled", "FAIL");
			}
			if (!actions.isElementEnabled("RestMIList.MIStatusDrpdwn")) {
				actions.reportCreatePASS("Verify Status Filter", "Status Filter should be disabled",
						"Status Filter is disabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Status Filter", "Status Filter should be disabled",
						"Status Filter is not disabled", "FAIL");
			}

			// Create New Dimension Group Set
			actions.click("DimensionNameSet.NewDimensionSetButton");
			actions.smartWait(5);
			mcd.SwitchToWindow("Dimension Name Sets");
			actions.click("DimensionNameSet.SelectButton");
			actions.smartWait(5);
			mcd.SwitchToWindow("Select Node");
			mcd.Selectrestnode("SelectNode.Table", strRest);
			mcd.SwitchToWindow("Dimension Name Sets");
			boolean blnWindow = false;
			setName = mcd.fn_GetRndName("Auto_DNS");
			actions.clear("DimensionNameSet.SetNameTextBox");
			actions.setValue("DimensionNameSet.SetNameTextBox", setName);
			actions.getWebElement("DimensionNameSet.NextButton").sendKeys(Keys.ENTER);
			mcd.SwitchToWindow("@Dimension Name Set");
			mcd.SwitchToWindow("#Title");
			actions.click("DimensionNameSet.CancelButton");
			actions.smartWait(15);

			// Click on Search Button & Click on Filter Button ,Verify Alert
			// Message
			actions.keyboardEnter("DimensionNameSets.Searchbtn");
			actions.smartWait(15);
			actions.click("DimensionNameSets.FilterButton");
			Boolean flag = mcd.VerifyAlertMessageDisplayed("Warning Message", strErrmsg[4], true,
					AlertPopupButton.OK_BUTTON);
			reporting_Pass_Fail("Verify Alert is Present", "Expected Message:Please select a filter criteria",
					"Alert is Present as Except", "Alert is not Present as Except", flag);

			// Select any country which doesn't contain dimension set name &
			// Verify Message
			actions.setValue("DimensionNameSet.FilterDDL", strFilterType);
			actions.click("DimensionNameSets.FilterButton");
			actions.verifyTextPresence(strErrmsg[5], true);

			// Select any country which exist in the Dimension Set Name & Verify
			// Message
			actions.keyboardEnter("DimensionNameSets.Searchbtn");
			actions.smartWait(15);
			actions.setValue("DimensionNameSet.FilterDDL", strRest);
			actions.click("DimensionNameSets.FilterButton");
			actions.smartWait(15);
			String node = mcd.GetTableCellValue("DimensionName.Table", 1, "Node", "", "");
			if (node.equalsIgnoreCase(strRest)) {
				actions.reportCreatePASS("Verify that the filter function",
						"Search results should display only respective filtered node",
						"Search results is displayed only respective filtered node", "PASS");
			} else {
				actions.reportCreateFAIL("Verify that the filter function",
						"Search results should display only respective filtered node",
						"Search results is not displayed only respective filtered node", "FAIL");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	// Function for Reporting Pass/Fail
	public void reporting_Pass_Fail(String Desc, String ExpRes, String ActRes_Pass, String ActRes_Fail,
			Boolean status) {
		if (status) {
			actions.reportCreatePASS(Desc, ExpRes, ActRes_Pass, "PASS");
		}

		if (!status) {
			actions.reportCreateFAIL(Desc, ExpRes, ActRes_Fail, "FAIL");
		}
	}

	// Verify Table Header Fields
	public void verifyTablecolumnsPresent(String tableLocator, String colName) {

		boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

		if (iscolPresent) {
			actions.reportCreatePASS("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is present in table", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is NOT present in table",
					"Fail");
		}
	}
}
