package xtam.test;

import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.openqa.selenium.WebElement;

import crossbrowser.library.Keywords;
import crossbrowser.library.PackageValidation;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.XMLValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20449_VrfDNSetDifMrkt {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private XMLValidations xmlValidation;
	private PackageValidation pkg;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strMarket1, strdelwm;
	private String dtErr, strErrmsg[];
	private boolean flag;
	// TODO: Declare test-data variables for other data-parameters

	public MNU_20449_VrfDNSetDifMrkt(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		pkg = new PackageValidation(driver, actions, uiActions, inputData, mcd, rfm);
		xmlValidation = new XMLValidations();

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		dtErr = mcd.GetTestData("DT_ERR_MSG");
		strMarket1 = mcd.GetTestData("DT_Market1");
		strdelwm = mcd.GetTestData("DT_DeleteWarning");
		// TODO: GetTestData for other data-parameters
		strErrmsg = dtErr.split("#");
	}

	@Test
	public void test_MNU_20449_VrfDNSetDifMrkt() throws InterruptedException {
		String strPageTitle = ""; // TODO: Exact page-title
		String strPageSubHeading = ""; // TODO: Page Heading

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"Verify that if set with same name exists in multiple markets, and if a set from one market is deleted, it doesn�t get deleted from other market.");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Create Dimension Name Set
			actions.click("DimensionNameSet.NewDimensionSetButton");
			mcd.waitAndSwitch("Dimension Name Sets");
			actions.click("DimensionNameSet.SelectButton");
			mcd.SwitchToWindow("Select Node");
			mcd.Selectrestnode("SelectNode.Table", strMarket);
			mcd.SwitchToWindow("Dimension Name Sets");
			String setName = null;
			do {

				boolean blnWindow = false;
				setName = mcd.fn_GetRndName("DimensionSet");
				actions.clear("DimensionNameSet.SetNameTextBox");
				actions.setValue("DimensionNameSet.SetNameTextBox", setName);
				actions.click("DimensionNameSet.NextButton");
				try {
					blnWindow = mcd.SwitchToWindow("@Dimension Name Set");
					if (blnWindow) {
						System.out.println("Menu Name and Number is accepted successfully");
						flag = false;
					} else {
						mcd.SwitchToWindow("Dimension Name Sets");
						if (actions.isTextPresence(strErrmsg[0], true)) {
							flag = true;
							System.out.println("Entered  number " + setName + " is already exist.");
							System.out.println(flag);
						}
					}

				} catch (Exception e) {
					if (actions.isTextPresence(strErrmsg[0], true)) {
						flag = true;
						System.out.println("Entered  number " + setName + " is already exist.");
						System.out.println(flag);
					}

				}

			} while (flag);

			// Change the status as inactive
			mcd.SwitchToWindow("#Title");
			actions.setValue("DimensionNameSet.StatusDropDown", "Inactive");
			actions.smartWait(5);
			actions.click("DimensionNameSet.SaveButton");
			actions.smartWait(10);

			// Verify the on-screen message
			flag = mcd.VerifyOnscreenMessage("DimensionNameSets.InfoMessage", "Your changes have been saved.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Change The Market
			actions.select_menu("RFMHome.Navigation", "HOME");
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");
			actions.keyboardEnter("RFMHomePage.ChangeMarket");
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket1);

			// Navigate to Dimension Name Set
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			// Create Dimension Name Set
			actions.click("DimensionNameSet.NewDimensionSetButton");
			mcd.waitAndSwitch("Dimension Name Sets");
			actions.clear("DimensionNameSet.SetNameTextBox");
			actions.setValue("DimensionNameSet.SetNameTextBox", setName);
			actions.click("DimensionNameSet.SelectButton");
			mcd.SwitchToWindow("Select Node");
			mcd.Selectrestnode("SelectNode.Table", strMarket1);
			mcd.SwitchToWindow("Dimension Name Sets");
			actions.click("DimensionNameSet.NextButton");

			// Change the status as inactive
			mcd.SwitchToWindow("Dimension Name Set");
			actions.setValue("DimensionNameSet.StatusDropDown", "Inactive");
			actions.smartWait(5);
			actions.click("DimensionNameSet.SaveButton");
			actions.smartWait(10);

			// Verify the on-screen message
			flag = mcd.VerifyOnscreenMessage("DimensionNameSets.InfoMessage", "Your changes have been saved.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Click on Cancel Button
			actions.click("DimensionNameSet.CancelButton");
			actions.smartWait(5);
			mcd.SwitchToWindow("#Title");

			// Select Delete trash icon for an Inactive Dimension name set
			actions.clear("DimensionNameSet.SearchSetTextbox");
			actions.setValue("DimensionNameSet.SearchSetTextbox", setName);
			actions.keyboardEnter("ManageDimensionGroup.SearchButton");
			actions.smartWait(10);
			actions.keyboardEnter("ScreenSet.SearchedValueFutureSettings");
			if (mcd.VerifyAlertMessageDisplayed("Information", strdelwm, true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + strdelwm + " 'is Present or not",
						strdelwm + " should be present", strdelwm + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + strdelwm + " 'is Present or not",
						strdelwm + " should be present", strdelwm + " is not present", "Fail");
			}

			// Verify the on-screen message
			flag = mcd.VerifyOnscreenMessage("BunBufferConfiguration.SKOnScreenMessage",
					"Delete has been successfully completed.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message",
						"Message 'Delete has been successfully completed.'", "Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message",
						"Message 'Delete has been successfully completed.'", "Expected Message is not displayed",
						"FAIL");
			}

			// Change The Market
			actions.select_menu("RFMHome.Navigation", "HOME");
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");
			actions.keyboardEnter("RFMHomePage.ChangeMarket");
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			// Navigate to Dimension Name Set
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			// Search the Dimension Name set which one deleted in the other
			// market
			actions.clear("DimensionNameSet.SearchSetTextbox");
			actions.setValue("DimensionNameSet.SearchSetTextbox", setName);
			actions.keyboardEnter("ManageDimensionGroup.SearchButton");
			actions.smartWait(10);

			String Val = mcd.GetTableCellValue("DimensionName.Table", 1, "Name", "", "");

			if (Val.equals(setName)) {
				actions.reportCreatePASS(
						"Verify that Dimension Name Set is exists in this market even after deleting the DNS with same name on other market",
						"Dimension Name Set should be available in this market",
						"Dimension Name Set is available in this market", "PASS");
			} else {
				actions.reportCreateFAIL(
						"Verify that Dimension Name Set is exists in this market even after deleting the DNS with same name on other market",
						"Dimension Name Set should be available in this market",
						"Dimension Name Set is not available in this market", "FAIL");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}
