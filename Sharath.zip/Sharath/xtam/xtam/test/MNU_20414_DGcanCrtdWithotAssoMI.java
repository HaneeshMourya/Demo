package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20414_DGcanCrtdWithotAssoMI {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String strUserID;
	private boolean flag = false;
	private String dgName = "";
	private String miName;
	private boolean flag_1;
	private String tcDescription;
	private String strAuditMarkt;

	public MNU_20414_DGcanCrtdWithotAssoMI(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strUserID = mcd.GetTestData("DT_USER_NAME");
		tcDescription = mcd.GetTestData("DT_Description");
		// TODO: GetTestData for other data-parameters
		strAuditMarkt = mcd.GetTestData("DT_AUDITLOG_MARKET");
	}

	@Test
	public void test_MNU_20414_DGcanCrtdWithotAssoMI() throws InterruptedException {
		String strPageTitle = "Dimension Groups"; // TODO: Exact page-title

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(
					"RFM-4151---Verify the addition of Menu Item in Dimension Group,RFM-4159----Verify Audit Log when Menu Item is added in already created Dimension Group");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			actions.smartWait(150);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// SELECTING DEFAULT VALUE IN DROP DOWN LIST USING ONE METHOED

			Boolean resultStatus;
			Select selObj = new Select(
					driver.findElement(By.xpath(actions.getLocator("ManageDimensionGroup.STSearchWithInStatus"))));
			resultStatus = selObj.getFirstSelectedOption().getText().trim().equalsIgnoreCase("Active/Inactive");
			reporting_Pass_Fail("Verify whether Status Active/Inactive is selected by default for Status DDL",
					"Status Active/Inactive should be selected by default",
					"Status Active/Inactive is selected by default",
					"Status Active/Inactive is not selected by default", resultStatus);

			// Verifying Status drop down
			Boolean resultStatus1;
			Select selObj1 = new Select(driver.findElement(By.xpath(actions.getLocator("PricingSets.StatusFilter"))));
			resultStatus1 = selObj1.getFirstSelectedOption().getText().trim().equalsIgnoreCase("Active/Inactive");
			reporting_Pass_Fail("Verify whether  Status Active/Inactive is selected by default for Status DDL",
					"Search within Status Active/Inactive should be selected by default",
					" Status Active/Inactive is selected by default",
					"Status Active/Inactive is not selected by default", resultStatus1);

			// Verifying Save button
			if (actions.isElementPresent("RFMQueueRoutingPopupPage.SaveButton")) {
				actions.reportCreatePASS("Verify Save button", "Save button should display", "Save page is displayed",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Save button", "Save button should display",
						"Save page is not displayed", "FAIL");
			}
			// Verifying Cancel button
			if (actions.isElementPresent("RFMQueueManagementPage.CancelButton")) {
				actions.reportCreatePASS("Verify Cancel button", "Cancel button should display", "Cancel  is displayed",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Cancel button", "Cancel button should display",
						"Cancel  is not displayed", "FAIL");
			}

			// Verify table columns
			/*
			 * verifyTablecolumnsPresent("AccessControlbyRole(s).Table",
			 * "Group Name");
			 * verifyTablecolumnsPresent("AccessControlbyRole(s).Table",
			 * "Status");
			 * verifyTablecolumnsPresent("AccessControlbyRole(s).Table",
			 * "Delete");
			 */

			// Creating new dimension group
			actions.click("DimensionGroup.NewDimensionGroupButton");
			actions.smartWait(15);

			do {

				dgName = mcd.fn_GetRndName("Auto_DG");
				actions.clear("DimensionGroup.DimensionGroupName");
				actions.setValue("DimensionGroup.DimensionGroupName", dgName);
				actions.click("DimensionGroup.SaveButton");

				flag = mcd.VerifyOnscreenMessage("DimensionGroup.InfoMessage", "Your changes have been saved.", true);

			} while (!(flag));

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Verify Audit log for create
			boolean blnAudit = false;
			blnAudit = rfm.VerifyAuditLog_Entry(strPageTitle, "Create", strAuditMarkt);

			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Entry for Create Dimension Group",
						"Audit log should be generated for create Dimension group",
						"Audit log generated for create Dimension group succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Entry for Create Dimension Group",
						"Audit log should be generated for create Dimension group",
						"Audit log not generated for create Dimension group succesfully", "FAIL");
			}

			// Verify Audit log details for create
			blnAudit = rfm.RFM_VerifyAuditLog_Details("RFM2", strUserID, strPageTitle, "Create", strAuditMarkt,
					strMarket, "Dimension Group " + dgName + " has been created.");
			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Details for Create Dimension Group",
						"Audit log details should be generated for created Dimension group",
						"Audit log details generated for Dimension group item succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Details for Create Dimension Group",
						"Audit log details should be generated for created Dimension group",
						"Audit log details not generated for Dimension group item succesfully", "FAIL");
			}

			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			actions.smartWait(15);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			// Adding a menu Item in the Dimension Group
			actions.clear("DimensionGroup.SearchField");
			actions.setValue("DimensionGroup.SearchField", dgName);
			actions.click("ManageDimensionGroup.SearchButton");
			actions.smartWait(15);

			// Clicking on the Dimension Group
			WebElement Element = mcd.GetTableCellElement("DimensionGroup.Table", 1, "Group Name", "a/pre");
			Element.click();
			actions.smartWait(15);
			mcd.SwitchToWindow("#Title");

			// Click on add menu item button for adding menu items
			actions.click("DimensionGroup.AddMenuItemButton");
			actions.smartWait(5);
			mcd.SwitchToWindow("Common Menu Item Selector");
			actions.smartWait(15);
			actions.click("SetAssignmentReport.SearchButton");
			//actions.smartWait(180);
			mcd.smartsync(180);
			Element = mcd.GetTableCellElement("CommonMenuItemSelector.Table", 1, "Add", "input");
			Element.sendKeys(Keys.SPACE);
			miName = mcd.GetTableCellValue("CommonMenuItemSelector.Table", 1, "Name", "", "");
			actions.click("CommonMenuItemSelector.ContinueButton");
			mcd.SwitchToWindow("Dimension Groups");

			// Selecting dimension drop down for add menu items
			String Default = actions.getValue("DimensionGroups.DimensionDDlist");
			String DDlist = mcd.getdropdownvalues("DimensionGroups.DimensionDDlist");
			String[] DDValues = DDlist.split(",");

			if (Default.equals(DDValues[0])) {
				actions.setValue("DimensionGroups.DimensionDDlist", DDValues[1]);
			} else {
				actions.setValue("DimensionGroups.DimensionDDlist", DDValues[2]);
			}

			// Click on cancel button and verify pop up message
			actions.keyboardEnter("RFM.CancelBtn");
			boolean flag2 = mcd.VerifyAlertMessageDisplayed("Warning",
					"Unsaved data will be lost. Are you sure you want to proceed?", true,
					AlertPopupButton.CANCEL_BUTTON);
			if (flag2) {
				actions.reportCreatePASS("Verify the on-screen message",
						"Message 'Unsaved data will be lost. Are you sure you want to proceed?'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message",
						"Message 'Unsaved data will be lost. Are you sure you want to proceed?'",
						"Expected Message is not displayed", "FAIL");
			}

			// Click on save button and verify on screen message
			actions.click("DimensionGroups.ApplyButton");
			actions.smartWait(15);

			flag = false;
			flag = mcd.VerifyOnscreenMessage("DimensionGroup.InfoMessage", "Your changes have been saved.", true);
			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Verify Audit log for update
			boolean blnAudit1 = false;
			blnAudit = rfm.VerifyAuditLog_Entry(strPageTitle, "Update", strAuditMarkt);

			if (blnAudit1) {
				actions.reportCreatePASS("Verify Audit Log Entry for Create Dimension Group",
						"Audit log should be generated for create Dimension group",
						"Audit log generated for create Dimension group succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Entry for Create Dimension Group",
						"Audit log should be generated for create Dimension group",
						"Audit log not generated for create Dimension group succesfully", "FAIL");
			}

			// Verify Audit log details for update
			blnAudit1 = rfm.RFM_VerifyAuditLog_Details("RFM2", strUserID, strPageTitle, "Update", strAuditMarkt,
					strMarket, "Dimension Group " + dgName + " has been updated.");
			if (blnAudit1) {
				actions.reportCreatePASS("Verify Audit Log Details for Create Dimension Group",
						"Audit log details should be generated for created Dimension group",
						"Audit log details generated for Dimension group item succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Details for Create Dimension Group",
						"Audit log details should be generated for created Dimension group",
						"Audit log details not generated for Dimension group item succesfully", "FAIL");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}

	}

	/////// METHOD WE HAVE TO USE FOR THIS
	public void reporting_Pass_Fail(String Desc, String ExpRes, String ActRes_Pass, String ActRes_Fail,
			Boolean status) {
		if (status) {
			actions.reportCreatePASS(Desc, ExpRes, ActRes_Pass, "PASS");
		}

		if (!status) {
			actions.reportCreateFAIL(Desc, ExpRes, ActRes_Fail, "FAIL");
		}
	}

	// VERIFYING TABLE COLUMS CODE
	public void verifyTablecolumnsPresent(String tableLocator, String colName) {

		boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

		if (iscolPresent) {
			actions.reportCreatePASS("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is present in table", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is NOT present in table",
					"Fail");
		}
	}

}
