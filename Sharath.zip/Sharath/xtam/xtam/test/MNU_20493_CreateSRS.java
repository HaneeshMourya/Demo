package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20493_CreateSRS {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strWM1;
	private String strWM2;
	private String strWM3;
	private String strWM4;
	private String strActivity, strActivity1, strActivity2;
	private String strDBName, strUserID, strOperation, strLevel;
	boolean AuditEntry;
	String AuditDesc;
	boolean AuditDetail;

	public MNU_20493_CreateSRS(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strWM1 = mcd.GetTestData("WarningMessage1");
		strWM2 = mcd.GetTestData("WarningMessage2");
		strWM3 = mcd.GetTestData("WarningMessage3");
		strWM4 = mcd.GetTestData("WarningMessage4");
		strDBName = mcd.GetTestData("DT_DB_NAME");
		strUserID = mcd.GetTestData("DT_USER_ID");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strActivity = mcd.GetTestData("DT_ACTIVITY");
		strActivity1 = mcd.GetTestData("DT_ACTIVITY1");
		strActivity2 = mcd.GetTestData("DT_ACTIVITY2");
		strLevel = mcd.GetTestData("DT_LEVEL");
	}

	@Test
	public void test_MNU_20493_CreateSRS() throws InterruptedException {

		try {
			System.out.println("******************************** Test execution starts");

			actions.setTestcaseDescription("Audit Log for Create, Update and Delete of Smart Reminder Set");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			// Creating a New Smart Reminder Set to perform Update and Delete
			// operations
			actions.WaitForElementPresent("SmartReminderSets.NewSmartReminderSet", 100);
			actions.keyboardEnter("SmartReminderSets.NewSmartReminderSet");
			mcd.SwitchToWindow("Smart Reminder Set");
			actions.keyboardEnter("RFMHome.Next");

			// verify 'Please enter Smart Reminder Set Name' alert message
			mcd.VerifyAlertMessageDisplayed("Warning", strWM1, true, AlertPopupButton.OK_BUTTON);
			String strRandName = mcd.fn_GetRndName("Auto");
			actions.setValue("NewSmartReminderSets.SmartReminderSetName", strRandName);
			actions.keyboardEnter("RFMHome.Next");

			// Verifying 'Please select a node' alert message
			mcd.VerifyAlertMessageDisplayed("Warning", strWM2, true, AlertPopupButton.OK_BUTTON);

			// Selecting a node
			driver.findElement(By.xpath(actions.getLocator("NewSmartReminderSets.SelectButton"))).click();
			mcd.waitAndSwitch("Select Node");
			actions.WaitForElementPresent("SmartReminderSetsSelectNode.SelectRest", 100);
			actions.click("SmartReminderSetsSelectNode.SelectRest");
			mcd.SwitchToWindow("Smart Reminder Set");
			actions.keyboardEnter("RFMHome.Next");
			mcd.SwitchToWindow("Smart Reminder Sets");
			actions.keyboardEnter("UpdateSmartReminderSets.SaveButton");

			// Verifying 'No changes have been made.' alert message
			mcd.VerifyAlertMessageDisplayed("Warning", strWM3, true, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("UpdateSmartReminderSets.CancelButton");
			mcd.smartsync(100);

			// Verifying Audit log for Create operation of Smart Reminder Set
			AuditEntry = rfm.VerifyAuditLog_Entry(strOperation, strActivity, strLevel);
			System.out.println(AuditEntry);
			if (AuditEntry) {
				actions.reportCreatePASS("Verify Audit Log Entry for create Smart Reminder Set",
						"Audit log should be generated for create Smart Reminder Set",
						"Audit log generated for creating Smart Reminder Set succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Entry for create Smart Reminder Set",
						"Audit log should be generated for create Smart Reminder Set",
						"Audit log not generated for creating Smart Reminder Set", "FAIL");
			}
			AuditDesc = "Smart Reminder Set " + strRandName + " has been created at Node " + strMarket + ".";
			AuditDetail = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID, strOperation, strActivity, strLevel,
					strMarket, AuditDesc);
			System.out.println(AuditDetail);
			if (AuditDetail) {
				actions.reportCreatePASS("Verify Audit Log Details for create Smart Reminder Set",
						"Audit log details should be generated for create Smart Reminder Set",
						"Audit log details generated for creating Smart Reminder Set succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Details for create Smart Reminder Set",
						"Audit log details should be generated for create Smart Reminder Set",
						"Audit log details not generated for creating Smart Reminder Set", "FAIL");
			}

			/**
			 * Navigating to Smart Reminder Set again to perform Update
			 * operation
			 */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			// Searching for the newly created Smart Reminder Set for updating
			actions.WaitForElementPresent("SmartReminderSets.SearchTextBox", 100);
			actions.setValue("SmartReminderSets.SearchTextBox", strRandName);
			actions.keyboardEnter("RFMHome.SearchButton");
			mcd.smartsync(100);
			/** Click on Table First Value */
			actions.click("SmartReminderSets.TableFirstValue");
			mcd.smartsync(100);
			/** Set Value in Status DropDown */
			actions.setValue("UpdateSmartReminderSets.Status", "Inactive");
			actions.keyboardEnter("UpdateSmartReminderSets.SaveButton");
			mcd.smartsync(100);

			// Validating update action success
			boolean booMsg1;
			String strMessage = "Your changes have been saved.";
			booMsg1 = mcd.VerifyOnscreenMessage("ManageMenuItems.SaveMessage", strMessage, true);
			System.out.println(booMsg1);
			if (booMsg1 == true) {
				actions.reportCreatePASS("Message: 'Your changes have been saved.' is Displayed",
						"Message: 'Your changes have been saved.' should Displayed",
						"Message: 'Your changes have been saved.' is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Message: 'Your changes have been saved.' is Displayed",
						"Message: 'Your changes have been saved.' should Displayed",
						"Message: 'Your changes have been saved.' is not Displayed", "Fail");
			}

			// Audit Log verification for update operation of Smart Reminder Set
			AuditEntry = rfm.VerifyAuditLog_Entry(strOperation, strActivity1, strLevel);
			System.out.println(AuditEntry);
			if (AuditEntry) {
				actions.reportCreatePASS("Verify Audit Log Entry for update Smart Reminder Set",
						"Audit log should be generated for update Smart Reminder Set",
						"Audit log generated for updating Smart Reminder Set succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Entry for update Smart Reminder Set",
						"Audit log should be generated for update Smart Reminder Set",
						"Audit log not generated for updating Smart Reminder Set", "FAIL");
			}
			AuditDesc = "Smart Reminder Set " + strRandName + " has been updated.";
			AuditDetail = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID, strOperation, strActivity1, strLevel,
					strMarket, AuditDesc);
			System.out.println(AuditDetail);
			if (AuditDetail) {
				actions.reportCreatePASS("Verify Audit Log Details for update Smart Reminder Set",
						"Audit log details should be generated for update Smart Reminder Set",
						"Audit log details generated for updating Smart Reminder Set succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Details for update Smart Reminder Set",
						"Audit log details should be generated for update Smart Reminder Set",
						"Audit log details not generated for updating Smart Reminder Set", "FAIL");
			}

			/**
			 * Navigate to Smart Reminder Set again to perform delete operation
			 */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			// Search for the updated Smart Reminder Set and delete it
			actions.WaitForElementPresent("SmartReminderSets.SearchTextBox", 100);
			/** Set Value in Search Text Box */
			actions.setValue("SmartReminderSets.SearchTextBox", strRandName);
			actions.keyboardEnter("RFMHome.SearchButton");
			mcd.smartsync(100);
			/** Click on First Delete Icon */
			actions.click("SmartReminderSets.FirstDeleteIcon");

			// confirm delete action
			mcd.VerifyAlertMessageDisplayed("Warning", strWM4, true, AlertPopupButton.OK_BUTTON);
			mcd.smartsync(100);

			// Audit Log verification for delete action of Smart Reminder Set
			AuditEntry = rfm.VerifyAuditLog_Entry(strOperation, strActivity2, strLevel);
			System.out.println(AuditEntry);
			if (AuditEntry) {
				actions.reportCreatePASS("Verify Audit Log Entry for Delete Smart Reminder Set",
						"Audit log should be generated for Delete Smart Reminder Set",
						"Audit log generated for Delete Smart Reminder Set succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Entry for Delete Smart Reminder Set",
						"Audit log should be generated for Delete Smart Reminder Set",
						"Audit log not generated for Delete Smart Reminder Set", "FAIL");
			}
			AuditDesc = "Smart Reminder Set " + strRandName + " has been deleted.";
			AuditDetail = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID, strOperation, strActivity2, strLevel,
					strMarket, AuditDesc);
			System.out.println(AuditDetail);
			if (AuditDetail) {
				actions.reportCreatePASS("Verify Audit Log Details for delete Smart Reminder Set",
						"Audit log details should be generated for delete Smart Reminder Set",
						"Audit log details generated for Smart Reminder Set succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Details for delete Smart Reminder Set",
						"Audit log details should be generated for delete Smart Reminder Set",
						"Audit log details not generated for Smart Reminder Set", "FAIL");
			}

			/** Logout the application */
			rfm.Logout();
		} catch (Exception e) {
			// reporting the Fail condition
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}
