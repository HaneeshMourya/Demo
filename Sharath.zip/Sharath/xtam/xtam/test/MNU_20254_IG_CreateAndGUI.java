package xtam.test;

import java.util.Calendar;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.galenframework.api.PageDump.Element;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20254_IG_CreateAndGUI {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strPreRest;
	private String strWM;
	private String strWM1;
	private String strNavigateTo1;
	private String strMsg;
	private String menuItem, strrest;
	private String test;
	private boolean blnDisplay = false;

	// TODO: Declare test-data variables for other data-parameters

	public MNU_20254_IG_CreateAndGUI(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strNavigateTo1 = mcd.GetTestData("DT_NAVIGATE_TO1");
		strPreRest = mcd.GetTestData("PreReq_Rest");
		strWM = mcd.GetTestData("WarningMessage");
		strWM1 = mcd.GetTestData("WarningMessage1");
		strMsg = mcd.GetTestData("Message");
		menuItem = mcd.GetTestData("DT_MenuItem");
		strrest = mcd.GetTestData("DT_REST");

		// test = "//label[@id='data3840']";

		// TODO: GetTestData for other data-parameters
	}

	@Test
	public void test_MNU_20254_IG_CreateAndGUI() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"Verify that the Ingredient group can be customized for a Restaurant and a single restaurant level user will not be able to customize ingredient groups when it is not customized for the restaurant.");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(180);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// actions.smartWait(100);

			// Verifying Ingredient group table columns
			boolean booHeader = mcd.RFM_VerifyTableColumns("IngredientGroups.Table",
					"Name,Select Only 1,Min,Max,Delete");
			System.out.println(booHeader);
			if (booHeader) {
				actions.reportCreatePASS("Column Headers 'Name,Select Only 1,Min,Max,Delete' is Displayed",
						"Column Headers 'Name,Select Only 1,Min,Max,Delete' should Displayed",
						"Column Headers 'Name,Select Only 1,Min,Max,Delete' is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Column Headers 'Name,Select Only 1,Min,Max,Delete' is Displayed",
						"Column Headers 'Name,Select Only 1,Min,Max,Delete' should Displayed",
						"Column Headers 'Name,Select Only 1,Min,Max,Delete' is not Displayed", "Fail");
			}

			// Verifying restaurant button
			boolean booDisplayed1 = driver.findElement(By.xpath(actions.getLocator("IngredientGroups.ConfigForRest")))
					.isDisplayed();
			System.out.println(booDisplayed1);
			if (booDisplayed1 == true) {
				System.out.println("Present");
				actions.reportCreatePASS("Configure for Restaurant Button is Present",
						"Configure for Restaurant Button should Present", "Configure for Restaurant Button is Present",
						"Pass");
			} else {
				actions.reportCreateFAIL("Configure for Restaurant Button is Present",
						"Configure for Restaurant Button should Present",
						"Configure for Restaurant Button is not Present", "Fail");
			}

			// Verifying Ingredient group button
			boolean booDisplayed2 = driver
					.findElement(By.xpath(actions.getLocator("IngredientGroups.NewIngredientGroups"))).isDisplayed();
			System.out.println(booDisplayed2);
			if (booDisplayed2 == true) {
				System.out.println("Present");
				actions.reportCreatePASS("New Ingredient Group Button is Present",
						"New Ingredient Group Button should Present", "New Ingredient Group Button is Present", "Pass");
			} else {
				actions.reportCreateFAIL("New Ingredient Group Button is Present",
						"New Ingredient Group Button should Present", "New Ingredient Group Button is not Present",
						"Fail");
			}

			actions.keyboardEnter("IngredientGroups.NewIngredientGroups");

			String strName = fn_GetRndName("Auto");
			actions.setValue("IngredientGroups.FirstName", strName);
			actions.click("IngredientGroups.FirstCheckBox");
			actions.setValue("IngredientGroups.FirstMax", "1");
			actions.keyboardEnter("RFMHome.Save");
			actions.smartWait(100);
			actions.keyboardEnter("IngredientGroups.ConfigForRest");
			Thread.sleep(10000);
			mcd.SwitchToWindow("Select a Restaurant");
			actions.waitForPageToLoad(1000);

			// Select market and verify pop up message
			mcd.Selectrestnode("RFMHome.LeftTable", strMarket);
			boolean flag = mcd.VerifyAlertMessageDisplayed("Warning", "Only Restaurant can be selected.", true,
					AlertPopupButton.OK_BUTTON);
			if (flag) {
				actions.reportCreatePASS("Verifying Pop up message", "Pop up message should displasy",
						"Pop up message is displayed as expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Pop up message", "Pop up message should display",
						"Pop up message is not displayed as expected", "FAIL");
			}

			// Close select restaurant window and verify pop up message
			actions.closeWindow();
			try {
				//Thread.sleep(4000);
				//driver.getTitle();
				if(actions.isSafari())
				{
					boolean flag1 = mcd.VerifyAlertMessageDisplayed("Warning", "Restaurant is not selected.", true,
							AlertPopupButton.OK_BUTTON);
					if (flag1) {
						actions.reportCreatePASS("Verifying Pop up message", "Pop up message should displasy",
								"Pop up message is displayed as expected", "PASS");
					} else {
						actions.reportCreateFAIL("Verifying Pop up message", "Pop up message should display",
								"Pop up message is not displayed as expected", "FAIL");
					}
					mcd.SwitchToWindow("Ingredient Groups");
				}else{
					
				
				driver.switchTo().window("");
				//driver.getTitle()
				Thread.sleep(4000);
				boolean flag1 = mcd.VerifyAlertMessageDisplayed("Warning", "Restaurant is not selected.", true,
						AlertPopupButton.OK_BUTTON);
				if (flag1) {
					actions.reportCreatePASS("Verifying Pop up message", "Pop up message should displasy",
							"Pop up message is displayed as expected", "PASS");
				} else {
					actions.reportCreateFAIL("Verifying Pop up message", "Pop up message should display",
							"Pop up message is not displayed as expected", "FAIL");
				}
				mcd.SwitchToWindow("Ingredient Groups");
			}
			} catch (Exception e) {

			}
			
			Thread.sleep(4000);

			

			// Click on customize setting restaurant button
			actions.click("IngredientGroups.ConfigForRest");
			mcd.SwitchToWindow("Select a Restaurant");
			actions.waitForPageToLoad(1000);
			
			//Selecting restaurant 
			actions.javaScriptClick("MenuItemUsageReport.ExactMatch");
			actions.setValue("MenuItemUsageReport.SearchTextTreeBox", strrest);
			actions.keyboardEnter("MenuItemUsageReport.SearchTextTree");
			actions.waitForPageToLoad(1000);
			String strXPath = "//*[contains(text(),'" + strrest + "')]";
			WebElement element = actions.getwebDriverLocator(strXPath);
			actions.javaScriptClick(element);
			mcd.SwitchToWindow("Ingredient Groups");
			
			if(actions.isElementPresent("IngredientGroup.ReInheritSettingButton"))
			{
			
			actions.keyboardEnter("IngredientGroup.ReInheritSettingButton");
			mcd.VerifyAlertMessageDisplayed("Warning", "Are you sure you want to Reset to Default", true,
					AlertPopupButton.CANCEL_BUTTON);
			}else{
				actions.click("IngredientGrp.CustomizeBtn");
			}
			
			//Click on any menu item check box
			actions.click("IngredientGroups.SelectOnlyOne");
			actions.keyboardEnter("RFMHome.Save");
			actions.smartWait(180);
			
			//Verify on screen message
			actions.verifyTextPresence("Your changes have been saved.", true);

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	public String fn_GetRndName(String strPrefix) {
		Calendar cal = Calendar.getInstance();
		int milliSeconds = cal.get(Calendar.MILLISECOND);
		int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
		int month = cal.get(Calendar.MONTH);
		int currentHour = cal.get(Calendar.HOUR_OF_DAY);
		int currentMinute = cal.get(Calendar.MINUTE);

		String strRndName = strPrefix + String.valueOf(milliSeconds) + String.valueOf(currentMinute)
				+ String.valueOf(dayOfMonth) + String.valueOf(month) + String.valueOf(currentHour);

		return strRndName;
	}
}

	



