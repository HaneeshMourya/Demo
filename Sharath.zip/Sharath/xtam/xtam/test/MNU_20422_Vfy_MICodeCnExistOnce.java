package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20422_Vfy_MICodeCnExistOnce {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String dgName;
	private boolean flag;
	private String miName_1;
	private String miName_2, msg1, msg2, msg3;

	public MNU_20422_Vfy_MICodeCnExistOnce(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		msg1 = mcd.GetTestData("DT_MS1");
		msg2 = mcd.GetTestData("DT_MS2");
		msg3 = mcd.GetTestData("DT_MS3");

		// TODO: GetTestData for other data-parameters
	}

	@Test
	public void test_MNU_20422_Vfy_MICodeCnExistOnce() throws InterruptedException {
		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(
					"Verify that A menu item code can only exist once across all Dimension Groups");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// Verifying Search Full List by Dimension Group Name text box
			String textbox = driver.findElement(By.xpath(actions.getLocator("ProductionRouting.SearchTextField")))
					.getAttribute("type");
			if (textbox.equals("text")) {
				actions.reportCreatePASS("Verifying Search Full List by Dimension Group Name text box",
						"Verifying Search Full List by Dimension Group Name text box should display",
						"Verifying Search Full List by Dimension Group Name text box is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Search Full List by Dimension Group Name text box",
						"Verifying Search Full List by Dimension Group Name text box should display",
						"Verifying Search Full List by Dimension Group Name text box is NOT displayed", "FAIL");

			}

			// Verifying Search within Status DDL
			if (actions.isElementEnabled("ManageDimensionGroup.STSearchWithInStatus")) {
				actions.reportCreatePASS("Verifying Search within Status DDL", "Search within Status DDL should enable",
						"Search within Status DDL is enable", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Search within Status DDL", "Search within Status DDL should enable",
						"Search within Status DDL is not enable", "FAIL");

			}

			// Verifying search button
			if (actions.isElementPresent("SetAssignmentReport.SearchButton")) {
				actions.reportCreatePASS("Verify Search button", "Search button should display",
						"Search button is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Search button", "Search button should display",
						"Search button is not displayed", "FAIL");
			}

			// Verifying New dimension group button
			if (actions.isElementPresent("DimensionGroup.NewDimensionGroupButton")) {
				actions.reportCreatePASS("Verify New Dimension Group button",
						"New Dimension Group button should display", "New Dimension Group button is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify New Dimension Group button",
						"New Dimension Group button should display", "New Dimension Group button is not displayed",
						"FAIL");
			}

			// Verifying save button
			if (actions.isElementPresent("RFMQueueRoutingPopupPage.SaveButton")) {
				actions.reportCreatePASS("Verify Save button", "Save button should display", "Save button is displayed",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Save button", "Save button should display",
						"Save button is not displayed", "FAIL");
			}

			// Verifying CANCEL button
			if (actions.isElementPresent("RFMQueueManagementPage.CancelButton")) {
				actions.reportCreatePASS("Verify Cancel button", "Cancel button should display",
						"Cancel button is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Cancel button", "Cancel button should display",
						"Cancel button is not displayed", "FAIL");
			}

			// Verifying columns code,description,size order and delete
			verifyTablecolumnsPresent("UpdateTaxType.TaxBreakTable", "Group Name");
			verifyTablecolumnsPresent("UpdateTaxType.TaxBreakTable", "Status");
			verifyTablecolumnsPresent("UpdateTaxType.TaxBreakTable", "Delete");

			// Creating inactive dimension group
			actions.click("DimensionGroup.NewDimensionGroupButton");
			actions.smartWait(15);
			mcd.SwitchToWindow("#Title");
			actions.setValue("DimensionGroups.StatusDDL", "Inactive");

			do {
				dgName = mcd.fn_GetRndName("Auto_DG");
				actions.clear("DimensionGroup.DimensionGroupName");
				actions.setValue("DimensionGroup.DimensionGroupName", dgName);
				actions.click("DimensionGroup.SaveButton");
				flag = mcd.VerifyOnscreenMessage("DimensionGroup.InfoMessage", msg1, true);
			} while (!(flag));

			// Verifying on screen message
			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", msg1,
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", msg1,
						"Expected Message is not displayed", "FAIL");
			}

			// Adding menu item to dimension group
			actions.click("DimensionGroup.AddMenuItemButton");
			actions.smartWait(5);
			mcd.SwitchToWindow("Common Menu Item Selector");
			actions.smartWait(15);
			actions.javaScriptClick("RFMPresentationRoutingSetSelectNodePage.SearchButton");
			actions.smartWait(40);
			WebElement Element = mcd.GetTableCellElement("CommonMenuItemSelector.Table", 1, "Add", "input");
			Element.sendKeys(Keys.SPACE);
			miName_1 = mcd.GetTableCellValue("CommonMenuItemSelector.Table", 1, "Number", "", "");
			Element = mcd.GetTableCellElement("CommonMenuItemSelector.Table", 2, "Add", "input");
			Element.sendKeys(Keys.SPACE);
			miName_2 = mcd.GetTableCellValue("CommonMenuItemSelector.Table", 2, "Number", "", "");
			actions.click("CommonMenuItemSelector.ContinueButton");
			mcd.SwitchToWindow("Dimension Groups");

			// Selecting ddl of menu item dimesion
			String Default;
			Element = mcd.GetTableCellElement("DimensionGroups.Table", 1, "Dimension", "select");
			Default = Element.getText();
			Select selectOption = new Select(Element);
			List<WebElement> values = Element.findElements(By.xpath(".//option"));
			if (Default.equals((values.get(0).getText()))) {
				selectOption.selectByVisibleText(values.get(1).getText().toString());
			} else {
				selectOption.selectByVisibleText(values.get(2).getText().toString());
			}

			Element = mcd.GetTableCellElement("DimensionGroups.Table", 2, "Dimension", "select");
			Default = Element.getText();
			selectOption = new Select(Element);
			List<WebElement> values_1 = Element.findElements(By.xpath(".//option"));
			selectOption.selectByVisibleText(values_1.get(3).getText().toString());
			actions.click("DimensionGroups.ApplyButton");
			actions.smartWait(15);

			// Verifying on screen message
			flag = false;
			flag = mcd.VerifyOnscreenMessage("DimensionGroup.InfoMessage", msg1, true);
			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", msg1,
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", msg1,
						"Expected Message is not displayed", "FAIL");
			}
			actions.click("DimensionGroup.CancelButton");
			mcd.SwitchToWindow("#Title");

			// Creating New Dimension group2
			actions.click("DimensionGroup.NewDimensionGroupButton");
			actions.smartWait(15);

			do {

				dgName = mcd.fn_GetRndName("Auto_DG");
				actions.clear("DimensionGroup.DimensionGroupName");
				actions.setValue("DimensionGroup.DimensionGroupName", dgName);
				actions.click("DimensionGroup.SaveButton");
				flag = mcd.VerifyOnscreenMessage("DimensionGroup.InfoMessage", msg1, true);
			} while (!(flag));

			// Verify on screen message
			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", msg1,
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", msg1,
						"Expected Message is not displayed", "FAIL");
			}

			// Adding menu items to dimension group2
			actions.click("DimensionGroup.AddMenuItemButton");
			Thread.sleep(5000);
			mcd.SwitchToWindow("Common Menu Item Selector");
			actions.smartWait(15);

			actions.clear("CommonMenuItemSelector.SearchTextBox");
			actions.javaScriptClick("CopyComponents.SearchExactMatch");
			actions.setValue("CommonMenuItemSelector.SearchTextBox", miName_1);
			// added below code line in rework

			// actions.checkElement(actions.getLocator("CommonMenuItemSelector.SearchButton"),
			// 180);
			actions.click("CommonMenuItemSelector.SearchButton");
			actions.smartWait(180);
			flag = mcd.VerifyOnscreenMessage("CommonMenuItemSelector.InfoMessage", msg2, true);

			// Verifying message on screeen
			if (flag) {
				actions.reportCreatePASS(
						"Verify that Menu items  are not available which are already present in another dimension group",
						msg2 , "Expected message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL(
						"Verify that Menu items  are not available which are already present in another dimension group",
						msg2, "Expected message is not displayed", "FAIL");
			}

			// Selecting second meni item and searching results
			actions.clear("CommonMenuItemSelector.SearchTextBox");
			actions.javaScriptClick("CopyComponents.SearchExactMatch");
			actions.setValue("CommonMenuItemSelector.SearchTextBox", miName_2);
			// added below code line in rework
			// actions.checkElement(actions.getLocator("CommonMenuItemSelector.SearchButton"),
			// 180);
			actions.click("CommonMenuItemSelector.SearchButton");
			actions.smartWait(15);

			// Verifying message on screeen
			flag = mcd.VerifyOnscreenMessage("CommonMenuItemSelector.InfoMessage",
					msg2, true);
			if (flag) {
				actions.reportCreatePASS(
						"Verify that Menu items  are not available which are already present in another dimension group",
						msg2, "Expected message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL(
						"Verify that Menu items  are not available which are already present in another dimension group",
						msg2, "Expected message is not displayed", "FAIL");
			}
			actions.click("CommonMenuItemSelector.CancelButton");

			// Going back to dimension group window
			mcd.VerifyAlertMessageDisplayed("Warning Message", msg3, true, AlertPopupButton.OK_BUTTON);
			mcd.SwitchToWindow("Dimension Groups");

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	public void verifyTablecolumnsPresent(String tableLocator, String colName) {

		boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

		if (iscolPresent) {
			actions.reportCreatePASS("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is present in table", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is NOT present in table",
					"Fail");
		}
	}
}
