package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.MasterMenuItem;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0222_Verify_Promotionflags {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private MasterMenuItem mmi;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo, mainwindow;
	private int Col_cnt;
	private String strerrmsg, strParam, strrange;

	// TODO: Declare test-data variables for other data-parameters

	public MNU_0222_Verify_Promotionflags(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		mmi = new MasterMenuItem(driver, actions, uiActions, inputData, mcd, rfm);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");

		// TODO: GetTestData for other data-parameters
		strerrmsg = mcd.GetTestData("DT_ERMSG");
		strParam = mcd.GetTestData("DT_PARAM");
		strrange = mcd.GetTestData("DT_RANGE");

	}

	@Test
	public void test_MNU_0222_Verify_Promotionflags() throws InterruptedException {

		try {
			System.out.println("************************** Test execution starts");

			/** setting the test case description */
			actions.setTestcaseDescription(
					"Verify that Promotional Menu Item flag and Promotional Choice flag is added on General Settings tab at Master Level i)for already existing Menu Item ii)while Menu Item creation without Copy option iii)while Menu Item creation using Copy option");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
			actions.waitForPageToLoad(120);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(4000);
			actions.smartWait(60);

			// Creating menu item
			int MI_Pro = mmi.RFM_MI_CreateMenuItem_updated(strrange, "PRODUCT", strerrmsg, strParam);

			// Creating menu item2
			int MI_Pro2 = mmi.RFM_MI_CreateMenuItem_updated(strrange, "PRODUCT", strerrmsg, strParam);

			// Converting integer to string
			String menuitemnumber = Integer.toString(MI_Pro);

			// Searching for the menu item
			actions.setValue("MasterMenuItemList.srch_text", MI_Pro);
			actions.click("MasterMenuItemList.Searchbtn");
			actions.smartWait(180);

			// Clicking on menu item
			WebElement rec_sel = mcd.GetTableCellElement("MasterMenuItemList.datatable", 1, "Number", "a");
			actions.keyboardEnter(rec_sel);
			actions.smartWait(180);

			// Checking for the Promotion choice radio buttons
			if (ISAttribtuePresent("ManageMenuItem.ProCh_Yes", "disabled")
					&& ISAttribtuePresent("ManageMenuItem.ProCh_No", "disabled")) {

				actions.reportCreatePASS("Promotional Choice Settings are disabled as Expected",
						"Promotional Choice Settings are disabled as Expected",
						"Promotional Choice Settings are disabled as Expected", "PASS");
			} else {

				actions.reportCreateFAIL("Promotional Choice Settings are not disabled as Expected",
						"Promotional Choice Settings are not disabled as Expected",
						"Promotional Choice Settings are not disabled as Expected", "FAIL");
			}

			/// Verify the by default selection of the promotion choice is set
			/// to No
			if (ISAttribtuePresent("ManageMenuItem.ProCh_No", "checked")) {
				WebElement elem = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.ProCh_No")));
				String value = elem.getAttribute("checked");
				if (value.equals("true")) {
					actions.reportCreatePASS("By Default the Promotional Choice setting is set to NO ",
							"By Default the Promotional Choice setting is set to NO ",
							"By Default the Promotional Choice setting is set to NO ", "PASS");
				}

			} else {
				actions.reportCreateFAIL("Fail:Promotional Choice Setting is not displayed as expected.",
						"Promotional Choice Setting is not displayed as expected.",
						"Fail:Promotional Choice Setting is not displayed as expected.", "FAIL");
			}

			// verifying promotional Menu item radio button
			if (!ISAttribtuePresent("ManageMenuItem.ProMI_Yes", "disabled")
					&& !ISAttribtuePresent("ManageMenuItem.ProMI_No", "disabled")) {
				actions.reportCreatePASS("Promotional Menu Item Settings are Enabled as Expected",
						"Promotional Menu Item Settings are Enabled as Expected",
						"Promotional Menu Item Settings are Enabled as Expected", "PASS");
			} else {
				actions.reportCreateFAIL("Fail:Promotional Menu Item Settings are disabled",
						"Fail:Promotional Menu Item Settings are disabled",
						"Fail:Promotional Menu Item Settings are disabled", "FAIL");
			}

			// Verify the by default selection of the promotion choice is set to
			// NO
			if (ISAttribtuePresent("ManageMenuItem.ProMI_No", "checked")) {
				WebElement elem = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.ProMI_No")));
				String value = elem.getAttribute("checked");
				if (value.equals("true")) {
					actions.reportCreatePASS("By Default the Menu Item setting is set to NO ",
							"By Default the Menu Item setting should set to NO ",
							"By Default the Menu Item setting is set to NO ", "PASS");
				}

			} else {
				actions.reportCreateFAIL("By Default the Menu Item setting is set to NO ",
						"By Default the Menu Item setting should set to NO ",
						"Fail: Menu item Setting is not displayed as expected.", "FAIL");
			}

			// Selecting promotional menu item radio button to yes
			actions.click("ManageMenuItem.ProMI_Yes");
			actions.click("ManageMenuItem.ApplySavebtn");
			mcd.SwitchToWindow("Apply Changes Details");
			actions.click("ApplyChangesDetails.save");
			mcd.SwitchToWindow("@Manage Menu Items");
			actions.smartWait(180);

			// checking for the attribute present or not for promotion range tab
			if (!ISAttribtuePresent("ManageMenuItem.PromRngtab", "disabled")) {
				actions.reportCreatePASS("Promotion range status", "Promotion range is enabled as Expected",
						"Promotion range is enabled as Expected", "PASS");
			} else {
				actions.reportCreateFAIL("Promotion range status", "Promotion range is enabled as Expected",
						"Promotion range is not enabled as Expected", "Fail");
			}

			// navigating to the master menu item list page
			actions.click("ManageMenuItem.Cancelbtn1");
			actions.smartWait(180);

			// Click on search button
			actions.clear("MasterMenuItemList.srch_text");
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			actions.smartWait(180);
			actions.keyboardEnter("MasterMenuItemList.MenuItemNumber");
			actions.smartWait(180);

			// Verifying promotional menu item flag and choice flag is displayed

			if (actions.isElementPresent("ManageMenuItems.PromotionalMenuitem")) {
				actions.reportCreatePASS("Verifying Promotional Menu Item flag",
						"Promotional Menu Item flag should display", "Promotional Menu Item flag is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Promotional Menu Item flag",
						"Promotional Menu Item flag should display", "Promotional Menu Item flag is not displayed",
						"FAIL");
			}

			// Verifying promotional choice flag is displayed

			if (actions.isElementPresent("ManageMenuItems.PromotionalChoice")) {
				actions.reportCreatePASS("Verifying Promotional CHOICE flag", "Promotional CHOICE flag should display",
						"Promotional CHOICE flag is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Promotional CHOICE flag", "Promotional CHOICE flag should display",
						"Promotional CHOICE flag is not displayed", "FAIL");
			}

			// navigating to the master menu item list page
			actions.click("ManageMenuItem.Cancelbtn1");
			actions.smartWait(180);

			// Search for menu item2
			actions.clear("MasterMenuItemList.srch_text");
			actions.setValue("MasterMenuItemList.srch_text", MI_Pro2);
			actions.click("MasterMenuItemList.Searchbtn");
			actions.smartWait(180);

			// Clicking on menu item2
			rec_sel = mcd.GetTableCellElement("MasterMenuItemList.datatable", 1, "Number", "a");
			actions.click(rec_sel);
			actions.smartWait(180);

			// Checking for the Promotion choice radio buttons
			if (ISAttribtuePresent("ManageMenuItem.ProCh_Yes", "disabled")
					&& ISAttribtuePresent("ManageMenuItem.ProCh_No", "disabled")) {

				actions.reportCreatePASS("Promotional Choice Settings are disabled as Expected",
						"Promotional Choice Settings are disabled as Expected",
						"Promotional Choice Settings are disabled as Expected", "PASS");
			} else {

				actions.reportCreateFAIL("Promotional Choice Settings are not disabled as Expected",
						"Promotional Choice Settings are not disabled as Expected",
						"Promotional Choice Settings are not disabled as Expected", "FAIL");
			}

			/// Verify the by default selection of the promotion choice is set
			/// to No
			if (ISAttribtuePresent("ManageMenuItem.ProCh_No", "checked")) {
				WebElement elem = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.ProCh_No")));
				String value = elem.getAttribute("checked");
				if (value.equals("true")) {
					actions.reportCreatePASS("By Default the Promotional Choice setting is set to NO ",
							"By Default the Promotional Choice setting is set to NO ",
							"By Default the Promotional Choice setting is set to NO ", "PASS");
				}

			} else {
				actions.reportCreateFAIL("Fail:Promotional Choice Setting is not displayed as expected.",
						"Promotional Choice Setting is not displayed as expected.",
						"Fail:Promotional Choice Setting is not displayed as expected.", "FAIL");
			}

			// verifying promotional Menu item radiio button
			if (!ISAttribtuePresent("ManageMenuItem.ProMI_Yes", "disabled")
					&& !ISAttribtuePresent("ManageMenuItem.ProMI_No", "disabled")) {
				actions.reportCreatePASS("Promotional Menu Item Settings are Enabled as Expected",
						"Promotional Menu Item Settings are Enabled as Expected",
						"Promotional Menu Item Settings are Enabled as Expected", "PASS");
			} else {
				actions.reportCreateFAIL("Fail:Promotional Menu Item Settings are disabled",
						"Fail:Promotional Menu Item Settings are disabled",
						"Fail:Promotional Menu Item Settings are disabled", "FAIL");
			}

			// Verify the by default selection of the promotion choice is set to
			// NO
			if (ISAttribtuePresent("ManageMenuItem.ProMI_No", "checked")) {
				WebElement elem = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.ProMI_No")));
				String value = elem.getAttribute("checked");
				if (value.equals("true")) {
					actions.reportCreatePASS("By Default the Menu Item setting is set to NO ",
							"By Default the Menu Item setting should set to NO ",
							"By Default the Menu Item setting is set to NO ", "PASS");
				}

			} else {
				actions.reportCreateFAIL("By Default the Menu Item setting is set to NO ",
						"By Default the Menu Item setting should set to NO ",
						"Fail: Menu item Setting is not displayed as expected.", "FAIL");
			}

			// **clicking on the cancel button*//*
			actions.click("RFM.Cancelbtn");
			actions.smartWait(120);

			// Click on add new button
			WebElement ws = driver.findElement(By.xpath("//*[@class='button button'][contains(text(),'Add New')]"));
			actions.click(ws);
			mcd.SwitchToWindow("Add New Menu Item");

			// Creating menu item with copying of existing menu item
			existingMI(strrange, menuitemnumber, strerrmsg, true);

			// Verifying PROMOTIONAL menu item yes radio button
			String pro_yes = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.PromotionalMenuItemYes")))
					.getAttribute("checked");
			if (pro_yes.equals("true")) {
				actions.reportCreatePASS("Verifying Promotional menu item Yes radio button",
						"Promotional menu item Yes radio button should selet",
						"Promotional menu item Yes radio button is selected", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Promotional menu item Yes radio button",
						"Promotional menu item Yes radio button should selet",
						"Promotional menu item Yes radio button is NOT selected", "FAIL");
			}

			// Verifying PROMOTIONAL choice yes radio button
			String cho_NO = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.ProCh_No")))
					.getAttribute("checked");
			if (cho_NO.equals("true")) {
				actions.reportCreatePASS("Verifying Promotional choice No radio button",
						"Promotional choice No radio button should selet",
						"Promotional choice No radio button is selected", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Promotional choice No radio button",
						"Promotional choice No radio button should selet",
						"Promotional choice No radio button is NOT selected", "FAIL");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	public boolean ISAttribtuePresent(String sElement, String attribute) {
		Boolean result = false;
		try {
			WebElement element = driver.findElement(By.xpath(actions.getLocator(sElement)));
			String value = element.getAttribute(attribute);
			if (value != null) {
				result = true;
			}
		} catch (Exception e) {

			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());

		}

		return result;
	}

	// Creating menu item while copying existing menu item
	public void existingMI(String MIrange, String mi_num, String strmsg, boolean blnflag) throws Exception {

		String[] strrange = MIrange.split("#");
		String[] ermsg = strmsg.split("#");

		actions.click("AddNewMI.Yes_rbtn");
		Thread.sleep(2000);
		actions.click("AddNewMI.selectbtn");
		Thread.sleep(1000);
		mcd.SwitchToWindow("Copy Settings From Existing Menu Item");
		actions.click("COPYMI.exactrbtn");
		actions.setValue("COPYMI.searchtextbox", mi_num);
		actions.click("COPYMI.searchbtn");
		Thread.sleep(1000);
		actions.waitForPageToLoad(120);

		WebElement record = mcd.GetTableCellElement("FieldPermissions.Table", 1, "Number", "a");
		record.click();
		Thread.sleep(2000);
		mcd.SwitchToWindow("Add New Menu Item");
		actions.setValue("AddNewMI.MenuItemName", mcd.fn_GetRndName("VM_"));

		do {
			int mi_num2 = mcd.fn_GetRndNumInRange(10000, 10099);
			boolean blnWindow = false;
			actions.clear("AddNewMI.MenuItemNumber");
			actions.setValue("AddNewMI.MenuItemNumber", mi_num2);
			actions.click("AddNewMI.Next");
			Thread.sleep(2000);
			/* blnWindow = mcd.SwitchToWindow("@Manage Menu Items"); */
			actions.smartWait(180);
			actions.waitForPageToLoad(180);
			/* boolean blnWindow = false; */

			try {
				blnWindow = mcd.SwitchToWindow("@Manage Menu Items");
				if (blnWindow) {
					System.out.println("Menu Name and Number is accepted successfully");
					blnflag = false;
				} else {
					mcd.SwitchToWindow("Add New Menu Item");
					if (actions.isTextPresence(ermsg[0], true)) {
						blnflag = true;
						System.out.println("Entered  number " + mi_num + " is already exist.");
						System.out.println(blnflag);
					}
				}

			} catch (Exception err) {
				if (actions.isTextPresence(ermsg[0], true)) {
					blnflag = true;
					System.out.println("Entered  number " + mi_num + " is already exist.");
					System.out.println(blnflag);
				}
			}

		} while (blnflag == true);

	}

}
