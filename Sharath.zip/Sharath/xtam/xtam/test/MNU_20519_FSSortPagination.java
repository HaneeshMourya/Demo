package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20519_FSSortPagination {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters

	public MNU_20519_FSSortPagination(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
	}

	@Test
	public void test_MNU_20519_FSSortPagination() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription("Verify the sort and pagination functionality for Flavor set.");
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow
			// Click on Search Button
			actions.WaitForElementPresent("FlavorSet.SearchButton", 50);
			actions.keyboardEnter("FlavorSet.SearchButton");
			actions.smartWait(20);

			// function for sorting the rows of table with respect to name
			Verify_Sorting_String("FlavorSet.TableRows", "FlavorSet.NameArrow", "FlavorSet.NameLink", "Name", 1);

			// Click on Search Button
			actions.smartWait(10);
			actions.keyboardEnter("FlavorSet.SearchButton");
			actions.smartWait(20);

			// click on node link
			actions.checkElement(actions.getLocator("FlavorSet.NodeLink"), 30);
			actions.javaScriptClick("FlavorSet.NodeLink");
			actions.smartWait(20);

			// function for sorting the rows of table with respect to node
			Verify_Sorting_String("FlavorSet.TableRows", "FlavorSet.NodeArrow", "FlavorSet.NodeLink", "Node", 2);

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	public void Verify_Sorting_String(String elemTableRow, String elemSortOrder, String elemHeader, String Name,
			int integer) throws InterruptedException {
		String strSortOrderValue = "";
		String TableXpath = actions.getLocator(elemTableRow);
		// Verify SORTING

		List<WebElement> eleRws = driver.findElements(By.xpath(TableXpath));
		int iNewMIRwCnt = eleRws.size();

		// Take 1st two elements for comparison by Name
		String MI_Num1 = eleRws.get(0).findElement(By.xpath("./td[" + integer + "]")).getText();
		String MI_Num2 = eleRws.get(1).findElement(By.xpath("./td[" + integer + "]")).getText();

		String strSortOrder = null;
		strSortOrderValue = driver.findElement(By.xpath(actions.getLocator(elemSortOrder))).getAttribute("src");
		if (strSortOrderValue.contains("up")) {
			strSortOrder = "Ascending";
			int ReturnNumber = MI_Num1.toUpperCase().compareTo(MI_Num2.toUpperCase());
			if (ReturnNumber <= 0) {
				actions.reportCreatePASS("Verify Ascending Sorting according to " + Name,
						"List should be sorted(Ascending)correctly", "List is sorted(Ascending) correctly", "PASS");
				// System.out.println("sorted ascending correct");
			} else {
				actions.reportCreateFAIL("Verify Ascending Sorting according to " + Name,
						"List should be sorted(Ascending) correctly", "List is not sorted(Ascending) correctly",
						"FAIL");
				// System.out.println("sorted ascending incorrect");
			}
		} else {
			actions.reportCreateFAIL("Verify Ascending Sorting according to " + Name,
					"List should be sorted(Ascending) correctly", "List is not sorted(Ascending) correctly", "FAIL");

		}
		Thread.sleep(2000);
		actions.keyboardEnter(elemHeader);
		Thread.sleep(2000);

		List<WebElement> eleRws1 = driver.findElements(By.xpath(TableXpath));
		int iNewMIRwCnt1 = eleRws.size();
		String MI_Num3 = eleRws1.get(0).findElement(By.xpath("./td[" + integer + "]")).getText();
		String MI_Num4 = eleRws1.get(1).findElement(By.xpath("./td[" + integer + "]")).getText();

		strSortOrderValue = driver.findElement(By.xpath(actions.getLocator(elemSortOrder))).getAttribute("src");
		if (strSortOrderValue.contains("down")) {
			strSortOrder = "Descending";
			int ReturnNumber = MI_Num3.toUpperCase().compareTo(MI_Num4.toUpperCase());
			if (ReturnNumber >= 0) {
				actions.reportCreatePASS("Verify Descending Sorting according to " + Name,
						"List should be sorted(Descending) correctly", "List is sorted correctly(Descending)", "PASS");
				// System.out.println("sorted descending correct");
			} else {
				actions.reportCreateFAIL("Verify Descending Sorting according to " + Name,
						"List should be sorted(Descending) correctly", "List is not sorted(Descending) correctly",
						"FAIL");
				// System.out.println("sorted descending incorrect");
			}
		} else {
			actions.reportCreateFAIL("Verify Descending Sorting according to " + Name,
					"List should be sorted(Descending) correctly", "List is not sorted(Descending) correctly", "FAIL");
		}

	}
}
