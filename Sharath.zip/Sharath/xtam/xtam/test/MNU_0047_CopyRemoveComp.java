package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Keywords.DialogType;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0047_CopyRemoveComp {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// Declare test-data variables for other data-parameters
	private String strmsg, strerrmsg[];
	private String tcDesc;

	public MNU_0047_CopyRemoveComp(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// GetTestData for other data-parameters
		strmsg = mcd.GetTestData("DT_MSG");
		strerrmsg = strmsg.split("#");
		tcDesc = mcd.GetTestData("DT_Description");
	}

	@Test
	public void test_MNU_0047_CopyRemoveComp() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(tcDesc);
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Navigate to Menu Item Sets */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			Actions builder = new Actions(driver);
			builder.moveByOffset(500, 0).click().perform();

			// Selecting the First Menu Item Set
			WebElement FirstLink = mcd.GetTableCellElement("RestaurantSet.Table", 1, 1, "a");
			actions.click(FirstLink);
			actions.smartWait(100);
			mcd.SwitchToWindow("#Title");

			// Checking whether Future Settings is available for the First Menu
			// Item, if not, creating a Future Settings and selecting Future
			// Settings
			WebElement FutSetlink = mcd.GetTableCellElement("RestaurantSet.Table", 1, "Future Settings", "a");
			String FutSetlinkText = FutSetlink.getText();
			if (!FutSetlinkText.equals("")) {
				WebElement Tbl_ele = mcd.GetTableCellElement("RestaurantSet.Table", 1, "Future Settings", "a");
				actions.keyboardEnter(Tbl_ele);
				actions.smartWait(100);
				mcd.SwitchToWindow("#Title");
			} else {

				// Selecting First Menu Item
				WebElement Tbl_ele = mcd.GetTableCellElement("RestaurantSet.Table", 1, 1, "a");
				actions.keyboardEnter(Tbl_ele);
				actions.smartWait(180);
				;
				mcd.SwitchToWindow("#Title");

				// Customize Settings
				rfm.SelectCustOrResetButton(strerrmsg[0], "MenuItemSets.Custbtn", "MenuItemSets.Resetbtn");

				// Creating Future Settings by Updating Long Name
				actions.clear("ManageMenuItems.LongName");
				String strLongName = mcd.fn_GetRndName("LN");
				actions.setValue("ManageMenuItems.LongName", strLongName);
				actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
				actions.keyboardEnter("ManageMenuItem.ApplySavebtn");

				if (actions.isSafari()) {

				} else {
					try {
						String AlertText = driver.switchTo().alert().getText();
						if (AlertText.contains("Unsaved")) {
							actions.acceptAlert();
						} else {
							mcd.SwitchToWindow("Apply Changes Details");
							mcd.smartsync(180);
							actions.click("MenuItemSets.FutureDate");
							actions.click("MenuItemSets.FutureCal");
							mcd.Get_future_date(1, "Close", strApplicationDate);
							actions.WaitForElementPresent("MenuItemSets.ApplyChangeSave");
							actions.keyboardEnter("MenuItemSets.ApplyChangeSave");
							mcd.SwitchToWindow("Manage Menu Items");
							mcd.smartsync(180);
							actions.verifyTextPresence(strerrmsg[1], true);
						}
					}

					catch (Exception e) {
					}
				}

				// Navigate to Components tab
				actions.keyboardEnter("ManageMenuItems.Components");
				actions.smartWait(100);
				rfm.SelectCustOrResetButton(strerrmsg[0], "MenuItemSets.Custbtn", "MenuItemSets.Resetbtn");

				try {
					// Selecting 'Composition' from View Type DDL
					Select viewtype = new Select(
							driver.findElement(By.xpath(actions.getLocator("MenuItemSets.ViewTypeDDL"))));
					viewtype.selectByVisibleText("Composition");
					actions.smartWait(180);
				} catch (Exception e) {
				}

				// Checking some components are added in Components table if not
				// Adding some
				int iRows = mcd.GetTableRowCount("ManageMenuItem.ComponentsTable");
				if (iRows < 4) {
					rfm.SelectCustOrResetButton(strerrmsg[0], "MenuItemSets.Custbtn", "MenuItemSets.Resetbtn");
					actions.keyboardEnter("ManageMenuItem.AddRemoveComp");
					mcd.waitAndSwitch("Common Menu Item Selector");
					actions.keyboardEnter("ScreenSet.searchbutton");
					actions.smartWait(180);
					int Added_EleNum = 0;
					int rowNum = mcd.GetTableRowCount("AddTenderType.Table");
					for (int i = 1; i < rowNum; i++) {
						WebElement chkbox = mcd.GetTableCellElement("AddTenderType.Table", i, 1, "input");
						if (chkbox.isEnabled()) {
							actions.click(chkbox);
							Added_EleNum++;
						}
						if (Added_EleNum > 3) {
							break;
						}
					}
					actions.keyboardEnter("RFM.ContinueButton");
					mcd.SwitchToWindow("Manage Menu Items");

					actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
					actions.keyboardEnter("ManageMenuItem.ApplySavebtn");

					try {
						driver.switchTo().alert().accept();
					} catch (Exception e) {
					}

					try {
						driver.switchTo().alert().accept();
					} catch (Exception e) {
					}
					mcd.smartsync(180);
				}

				/**
				 * Verify Copy button on component tab is disabled for future
				 * settings
				 */
				if (this.ISAttributePresent("MenuItemSets.CopyBtn", "disabled")) {
					actions.reportCreatePASS("Verify Copy button on component tab is disabled for future settings",
							"Copy button on component tab should be disabled for future settings",
							"Copy button on component tab is disabled for future settings", "Pass");
				} else {
					actions.reportCreateFAIL("Verify Copy button on component tab is disabled for future settings",
							"Copy button on component tab should be disabled for future settings",
							"Copy button on component tab is enabled for future settings", "Fail");
				}

				/**
				 * Verify Remove button on component tab is disabled for future
				 * settings
				 */
				if (this.ISAttributePresent("MenuItemSets.RemoveBtn", "disabled")) {
					actions.reportCreatePASS("Verify Remove button on component tab is disabled for future settings",
							"Remove button on component tab should be disabled for future settings",
							"Remove button on component tab is disabled for future settings", "Pass");
				} else {
					actions.reportCreateFAIL("Verify Remove button on component tab is disabled for future settings",
							"Remove button on component tab should be disabled for future settings",
							"Remove button on component tab is enabled for future settings", "Fail");
				}

				/** Logout the application */
				/* rfm.Logout(); */

			}
		} catch (Exception e) {
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}

	// Function to verify particular Attribute is present or not
	public boolean ISAttributePresent(String elemlocator, String status) {
		boolean blnrslt = false;
		try {
			WebElement elem = driver.findElement(By.xpath(actions.getLocator(elemlocator)));
			String is_disabled = elem.getAttribute(status);
			if (is_disabled.equals("true")) {
				blnrslt = true;
			} else {
				blnrslt = false;
			}
		} catch (Exception e) {
			Reporter.log(e.getMessage());
			blnrslt = false;
		}
		return blnrslt;
	}
}
