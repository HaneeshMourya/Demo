package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Keywords.DialogType;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class MNU_0162_211U_MMIL_CompMsg {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// Declare test-data variables for other data-parameters
	private String strmsg, forcecomp;
	private boolean flag;
	private String strMI;
	private String strDBName;
	private String strUserID;
	private String strOperation;
	private String strActivity;
	private String strLevel;
	private String strTestDescription;

	public MNU_0162_211U_MMIL_CompMsg(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");

		// GetTestData for other data-parameters
		strmsg = mcd.GetTestData("DT_ERR_MSG");
		forcecomp = mcd.GetTestData("DT_FORCE_COMP");
		strUserID = mcd.GetTestData("DT_AUDIT_USER");

		strDBName = mcd.GetTestData("DT_DB_NAME");
		strUserID = mcd.GetTestData("DT_USER_ID");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strActivity = mcd.GetTestData("DT_ACTIVITY");
		strLevel = mcd.GetTestData("DT_LEVEL");
	}

	@Test
	public void test_MNU_0162_211U_MMIL_CompMsg() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(mcd.GetTestData("DT_Description"));

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			// test-flow
			String strerrmsg[] = strmsg.split("#");

			// Click Search button on Master Menu Item List Page to view all the
			// MI's
			actions.click("MasterMenuItemList.Searchbtn");
			actions.waitForPageToLoad(4000);

			// Searching for the first Menu Item and selecting
			strMI = driver.findElement(By.xpath(actions.getLocator("MasterMenuItemList.selectmenuitem1"))).getText();
			actions.WaitForElementPresent("Category.SearchTextFieldAssociate", 180);
			actions.setValue("Category.SearchTextFieldAssociate", strMI);
			actions.click("MasterMenuItemList.Searchbtn");
			actions.waitForPageToLoad(4000);
			actions.click("MasterMenuItemList.TableFirstValue");
			mcd.SwitchToWindow("#Title");
			
			actions.WaitForElementPresent("MasterMenuItemList.NavComptab", 180);

			// Navigate to Component tab
			actions.keyboardEnter("MasterMenuItemList.NavComptab");
			Thread.sleep(3000);

			// Checking some components are added in Components table if not
			// Adding some
			int iRows = mcd.GetTableRowCount("ManageMenuItem.ComponentsTable");
			if (iRows < 4) {
				Thread.sleep(1000);
				actions.keyboardEnter("ManageMenuItem.AddRemoveComp");
				mcd.waitAndSwitch("Common Menu Item Selector");
				actions.keyboardEnter("ScreenSet.searchbutton");
				mcd.smartsync(180);
				int Added_EleNum = 0;
				int rowNum = mcd.GetTableRowCount("AddTenderType.Table");
				for (int i = 1; i < rowNum; i++) {
					WebElement chkbox = mcd.GetTableCellElement("AddTenderType.Table", i, 1, "input");
					if (chkbox.isEnabled()) {
						actions.click(chkbox);
						Added_EleNum++;
					}
					if (Added_EleNum > 3) {
						break;
					}
				}
				actions.keyboardEnter("RFM.ContinueButton");
				mcd.SwitchToWindow("Manage Menu Items");
				actions.keyboardEnter("ManageMenuItem.ApplySavebtn");
				try {
					mcd.SwitchToWindow("Apply Changes Details");
					mcd.smartsync(180);
					actions.WaitForElementPresent("MenuItemSets.ApplyChangeSave");
					actions.keyboardEnter("MenuItemSets.ApplyChangeSave");
					mcd.SwitchToWindow("Manage Menu Items");
					mcd.smartsync(180);
				} catch (Exception e) {
				}
				try {
					driver.switchTo().alert().accept();
				} catch (Exception e) {
				}

				try {
					driver.switchTo().alert().accept();
				} catch (Exception e) {
				}
				mcd.smartsync(180);
			}
			actions.WaitForElementPresent("AddRemoveComponent.AddCompbtn", 180);

			// To Verify 'No changes have been made.' alert message
			// Select one 'Assigned' MI by checking remove check box
			actions.keyboardEnter("AddRemoveComponent.AddCompbtn");
			actions.smartWait(60);
			mcd.SwitchToWindow("Common Menu Item Selector");
			actions.WaitForElementPresent("RestaurantSet.Searchbtn", 180);
			WebElement chkboxRemove = mcd.GetTableCellElement("AddTenderType.Table", 1, 2, "input");
			actions.click(chkboxRemove);

			actions.keyboardEnter("ManageMenuItem.cancelbutton");
			mcd.SwitchToWindow("Manage Menu Items");
			actions.WaitForElementPresent("AddRemoveComponent.AddCompbtn", 180);

			// again Deselect the already checked MI by un-checking remove check
			// box
			actions.keyboardEnter("AddRemoveComponent.AddCompbtn");
			mcd.smartsync(180);
			mcd.SwitchToWindow("Common Menu Item Selector");
			mcd.smartsync(180);
			WebElement chkboxRemove1 = mcd.GetTableCellElement("AddTenderType.Table", 1, 2, "input");
			actions.click(chkboxRemove1);
			actions.click("ManageMenuItem.cancelbutton");
			mcd.SwitchToWindow("Manage Menu Items");
			actions.WaitForElementPresent("CurrentMenuItemDetails.Apply", 180);
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("CurrentMenuItemDetails.Apply");
			

			// Validating for 'No changes have been made.'
			flag = mcd.VerifyAlertMessageDisplayed("Alert", strerrmsg[0], true, AlertPopupButton.OK_BUTTON);

			if (flag) {
				actions.reportCreatePASS("Verify message as-" + strerrmsg[0] + " is displayed",
						"Message as-" + strerrmsg[0] + " should be displayed",
						"Message is displayed as-" + strerrmsg[0] + "is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify message as-" + strerrmsg[0] + " is displayed",
						"Message as-" + strerrmsg[0] + " should be displayed",
						"Message -" + strerrmsg[0] + " is not displayed", "Fail");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}
