package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20522_FSCreateCopy {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo, strwm, ExpectWm[];
	private boolean flag;
	private String strOperation, StrActivity, StrLevel, StrLevedetails, strDBName, strUserID;
	private String strExpectlevel[], strExpectActivity[], strExpectLevelDetails[];

	// TODO: Declare test-data variables for other data-parameters

	public MNU_20522_FSCreateCopy(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strwm = mcd.GetTestData("DT_WarningMessage");
		StrLevel = mcd.GetTestData("DT_LEVEL");
		StrLevedetails = mcd.GetTestData("DT_LevelDetails");
		StrActivity = mcd.GetTestData("DT_ACTIVITY");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strDBName = mcd.GetTestData("DT_DBNAME");
		strUserID = mcd.GetTestData("DT_USER_NAME");
		// TODO: GetTestData for other data-parameters

		ExpectWm = strwm.split("#");
		strExpectActivity = StrActivity.split("#");
		strExpectlevel = StrLevel.split("#");
		strExpectLevelDetails = StrLevedetails.split("#");
	}

	@Test
	public void test_MNU_20522_FSCreateCopy() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"Verify the create new/copy flavor set functionality with copy existing Flavor set.");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow

			// Click on Search Button
			actions.click("FlavorSet.SearchButton");
			actions.smartWait(100);
			String flavorsetName = driver.findElement(By.xpath(actions.getLocator("FlavorSet.TableNameValue")))
					.getText();
			System.out.println(flavorsetName);

			// Create a flavor set with exiting flavor set
			actions.click("FlavorSet.NewFlavorSet");
			mcd.waitAndSwitch("Add New Flavor Set");

			// Searching for the max string
			String strVal2;
			strVal2 = generateString('c', 61);
			System.out.println(strVal2.length());
			actions.clear("AddNewFlavorSet.FlavorSetName");
			actions.setValue("AddNewFlavorSet.FlavorSetName", strVal2);
			actions.smartWait(50);
			String newflavorsetname = driver.findElement(By.xpath(actions.getLocator("AddNewFlavorSet.FlavorSetName")))
					.getAttribute("value");
			System.out.println(newflavorsetname.length());
			if (newflavorsetname.length() <= 60) {
				actions.reportCreatePASS("verify the whether search box accepected more than 60 Characters",
						"search box should be accepected more than 60 Characters",
						"search box should not be accepected more than 60 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether Search box accepected 60 characters",
						"search box should be accepected more than 60 Characters ",
						"search box should be accepected more than 60 Characters", "FAIL");
			}

			// Keep the Flavor set name as blank and click on "Next" button
			actions.smartWait(10);
			actions.clear("AddNewFlavorSet.FlavorSetName");
			actions.click("AddNewFlavorSet.Next");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWm[0], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWm[0] + " 'is Present or not",
						ExpectWm[0] + " should be present", ExpectWm[0] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWm[0] + " 'is Present or not",
						ExpectWm[0] + " should be present", ExpectWm[0] + " is not present", "Fail");
			}

			// Enter a flavor set name which already exists in database.
			actions.smartWait(10);
			actions.clear("AddNewFlavorSet.FlavorSetName");
			actions.setValue("AddNewFlavorSet.FlavorSetName", flavorsetName);
			actions.click("AddNewFlavorSet.SelectNodeButton");
			mcd.waitAndSwitch("Select Node");
			actions.WaitForElementPresent("SelectNodeRest.SearchTextField", 180);
			mcd.Selectrestnode_JavaScriptClk("RFMSelectNode.SelectNodeTable", strMarket);
			mcd.SwitchToWindow("Add New Flavor Set");
			actions.smartWait(10);
			actions.click("AddNewFlavorSet.Next");
			actions.smartWait(10);

			// Verify the on-screen message
			flag = mcd.VerifyOnscreenMessage("AddNewFlavorSet.ErrorMessage",
					"Flavor Set Name already exists, please enter a different Flavor Set Name.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message",
						"Message 'Flavor Set Name already exists, please enter a different Flavor Set Name.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message",
						"Message 'Flavor Set Name already exists, please enter a different Flavor Set Name.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Enter valid Flavor set name in the text box and click on next
			// button
			actions.smartWait(10);
			actions.closeWindow();
			mcd.SwitchToWindow("@Title");
			actions.smartWait(10);
			actions.click("FlavorSet.NewFlavorSet");
			mcd.waitAndSwitch("Add New Flavor Set");
			String strFlavorSetName = mcd.fn_GetRndName("FlavorSet");
			System.out.println(strFlavorSetName);
			actions.clear("AddNewFlavorSet.FlavorSetName");
			actions.setValue("AddNewFlavorSet.FlavorSetName", strFlavorSetName);
			actions.click("AddNewFlavorSet.Next");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWm[1], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWm[1] + " 'is Present or not",
						ExpectWm[1] + " should be present", ExpectWm[1] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWm[1] + " 'is Present or not",
						ExpectWm[1] + " should be present", ExpectWm[1] + " is not present", "Fail");
			}

			// Select a node and Select the exiting Flavor Set
			actions.click("AddNewFlavorSet.SelectNodeButton");
			mcd.waitAndSwitch("Select Node");
			actions.WaitForElementPresent("SelectNodeRest.SearchTextField", 180);
			mcd.Selectrestnode_JavaScriptClk("RFMSelectNode.SelectNodeTable", strMarket);
			mcd.SwitchToWindow("Add New Flavor Set");
			actions.javaScriptClick("AddNewFlavorSet.CopyExistingYes");
			actions.click("AddNewFlavorSet.CopyFlavorSelectBtn");
			mcd.waitAndSwitch("Select Flavor Set To Copy");
			actions.click("CopyExistingScreenSets.SearchButton");
			actions.smartWait(30);
			actions.click("FlavorSet.TableNameValue");
			mcd.SwitchToWindow("Add New Flavor Set");
			actions.smartWait(20);
			actions.click("AddNewFlavorSet.Cancel");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWm[2], true, AlertPopupButton.CANCEL_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWm[2] + " 'is Present or not",
						ExpectWm[2] + " should be present", ExpectWm[2] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWm[2] + " 'is Present or not",
						ExpectWm[2] + " should be present", ExpectWm[2] + " is not present", "Fail");
			}
			actions.smartWait(10);
			actions.click("AddNewFlavorSet.Next");
			mcd.SwitchToWindow("@Flavor Set");
			actions.smartWait(10);

			// Verify the on-screen message
			flag = mcd.VerifyOnscreenMessage("FlavorSet.InfoMessage", "Your changes have been saved.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Verify the Audit log Details
			boolean AuditlogCorrectValuesDisplayed1 = rfm.VerifyAuditLog_Entry(strOperation, strExpectActivity[0],
					strExpectlevel[0]);

			if (AuditlogCorrectValuesDisplayed1) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "strExpectActivity[1],Level",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation," + "ActivityValue,Level",
						"Correct values are not displayed", "Fail");
			}

			String AuditDescc = "Flavor Set " + strFlavorSetName + " has been created at Node " + strMarket+".";

			boolean isAuditlogCorrectValuesDisplayed1 = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID,
					strOperation, strExpectActivity[0], strExpectlevel[0], strExpectLevelDetails[0], AuditDescc);

			if (isAuditlogCorrectValuesDisplayed1) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are not displayed", "Fail");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
	// To generate the string of specific size

	public static String generateString(char c, Integer n) {
		StringBuilder b = new StringBuilder();
		for (Integer x = 0; x < n; x++)
			b.append(c);
		return b.toString();
	}
}
