package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.MasterMenuItem;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class MNU_0001_MenuItemSet {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();
	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private MasterMenuItem mmi;

	// Test Data variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket, strmsg, strmenuname, strrest, strNavigateTo, strSearchValue;

	public MNU_0001_MenuItemSet(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();
		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		mmi = new MasterMenuItem(driver, actions, uiActions, inputData, mcd, rfm);
		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strmsg = mcd.GetTestData("DT_ERR_MSG");
		strmenuname = mcd.GetTestData("DT_MENUNAME");
		strrest = mcd.GetTestData("DT_Rest");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
	}

	@Test
	public void test_MNU_0001_MenuItemSet() throws InterruptedException {

		try {

			System.out.println("*************************** Start Test-Steps executions");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
			actions.waitForPageToLoad(120);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.smartsync(60);

			// Create menu item set using copy settings from existing set as
			// NO-MNU_0001
			actions.WaitForElementPresent("MenuItemSet.NewMISbutton", 15);
			actions.keyboardEnter("MenuItemSet.NewMISbutton");

			// switch to Add New Menu Item Set window
			mcd.smartsync(120);
			mcd.SwitchToWindow("Add New Menu Item Set");

			// Enter menu item set name
			String strMenuItemSetName = "";
			strMenuItemSetName = mcd.fn_GetRndName("Auto");
			actions.setValue("MenuItemSets.BTMenuItemSetNameTextBox", strMenuItemSetName);
			actions.keyboardEnter("MenuItemSets.Selectbtn");
			mcd.smartsync(120);

			// Selecting a Node
			mcd.SwitchToWindow("Select Node");
			mcd.Selectrestnode("MenuItemSets.LeftTable", mcd.GetTestData("DT_MARKET"));
			mcd.waitAndSwitch("Add New Menu Item Set");
			actions.WaitForElementPresent("MenuItemSets.Nextbtn");
			actions.click("MenuItemSets.Nextbtn");

			// Add 'Available' Menu items to The Menu Item Set
			mcd.waitAndSwitch("@Manage Menu Item Set : Common Menu Item Selector");
			actions.WaitForElementPresent("RFMCommonMenuItemSelector.Search", 15);
			actions.keyboardEnter("RFMCommonMenuItemSelector.Search");
			mcd.smartsync(100);
			actions.WaitForElementPresent("AddRemoveMenu.Availability", 15);
			actions.setValue("AddRemoveMenu.Availability", "Available");
			Thread.sleep(8000);
			List<WebElement> Add_Chkbox = driver
					.findElements(By.xpath(".//input[@type = 'checkbox'][contains(@onclick, 'addMenuItem')]"));
			int Item_Counts = Add_Chkbox.size();
			int i_temp = 0;
			for (int n = 0; n < Item_Counts; n++) {
				// Check whether enabled for Add or not
				if ((Add_Chkbox.get(n).isEnabled())) {
					// Check box enabled - Add Item
					Add_Chkbox.get(n).sendKeys(Keys.SPACE);
					i_temp++;
				} else {
					System.out.println("This MI is already added");
				}

				if (i_temp == 2) {
					System.out.println("Selected 2 items for Add MI");
					break;
				}
			}
			actions.WaitForElementPresent("AddRemoveMenu.Savebtn", 15);
			actions.keyboardEnter("AddRemoveMenu.Savebtn");
			Thread.sleep(4000);
			mcd.smartsync(180);
			// Verify 'Your changes have been saved.'
			String SuccessMsg = "Your changes have been saved.";
			boolean BlnSuccessMsg;
			BlnSuccessMsg = mcd.VerifyOnscreenMessage("DimensionGroups.DeleteInfoMessage", SuccessMsg, true);
			if (BlnSuccessMsg) {
				actions.reportCreatePASS("Verify creation of menu item set with copy settings as No",
						"Menu item set should be created with copy settings as No",
						"Menu item set is created with copy settings as No", "Pass");
			} else {
				actions.reportCreateFAIL("Verify creation of menu item set with copy settings as No",
						"Menu item set should be created with copy settings as No",
						"Menu item set is not created with copy settings as No", "Fail");
			}
			actions.keyboardEnter("MenuItemSets.ReturnToSet");
			mcd.smartsync(120);

			mcd.SwitchToWindow("#Title");
			actions.reportCreatePASS("Newly created menu item set is-" + strMenuItemSetName,
					"Newly menu item set -" + strMenuItemSetName + " should be created",
					"Newly created menu item set is-" + strMenuItemSetName, "PASS");
			System.out.println("Newly created menu item set is-" + strMenuItemSetName);
			actions.waitForPageToLoad(120);

			// Field validation while creating menu item set -MNU_0003
			MNU_0003_MenuItemSetFieldValidation(strmsg, strrest);
			Thread.sleep(2000);

			// Create menu item set using copy settings from existing set as YES
			// -MNU_0002
			String MIS = MNU_0002_CreateMenuItemSet(strmenuname, strrest, strmsg);
			System.out.println("Newly created menu item set with copy settings as Yes is-" + MIS);

			mcd.smartsync(60);
			actions.WaitForElementPresent("RFMHomePage.Logout");
			rfm.Logout();

		} catch (Exception e) {
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}

	public void MNU_0003_MenuItemSetFieldValidation(String strmsg, String strrest) throws Exception {

		String[] errmsg = strmsg.split("#");
		actions.keyboardEnter("RestaurantSet.Searchbtn");
		actions.smartWait(60);

		// Verify sorting for Menu Item Set Name
		// Verify descending order for Menu ITem Set Name column and validate
		// the same

		actions.keyboardEnter("MenuItemSets.SortName");
		actions.smartWait(60);
		actions.waitForPageToLoad(40);
		boolean blnflag = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.SortNameDownImage");
		if (blnflag) {
			actions.reportCreatePASS("Verify Down Sort arrow on Menu item set", "Down Sort arrow should be displayed",
					"Down Sort arrow is displayed", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Down Sort arrow on Menu item set", "Down Sort arrow should be displayed",
					"Down Sort arrow is not displayed", "FAIL");
		}

		// Verify ascending order for Menu ITem Set Name column and validate the
		// same
		actions.keyboardEnter("MenuItemSets.SortName");
		mcd.smartsync(180);
		actions.waitForPageToLoad(40);

		boolean blnflag2 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.SortNameUpImage");
		if (blnflag2) {
			actions.reportCreatePASS("Verify Up Sort arrow on Menu item set", "Up Sort arrow should be displayed",
					"Up Sort arrow is displayed", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Up Sort arrow on Menu item set", "Up Sort arrow should be displayed",
					"Up Sort arrow is not displayed", "FAIL");
		}

		// Verify ascending order for Node column and validate the same
		actions.keyboardEnter("MenuItemSets.SortNode");
		mcd.smartsync(180);
		actions.waitForPageToLoad(40);
		boolean blnflag3 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.SortNodeUpImage");
		if (blnflag3) {
			actions.reportCreatePASS("Verify Up Sort arrow on Node Name", "Up Sort arrow should be displayed",
					"Up Sort arrow is displayed", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Up Sort arrow on Node Name", "Up Sort arrow should be displayed",
					"Up Sort arrow is not displayed", "FAIL");
		}

		// Verify descending order for Node column and validate the same
		actions.keyboardEnter("MenuItemSets.SortNode");
		mcd.smartsync(180);
		boolean blnflag4 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.SortNodeDownImage");
		if (blnflag4) {
			actions.reportCreatePASS("Verify Down Sort arrow on Node Name", "Down Sort arrow should be displayed",
					"Down Sort arrow is displayed", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Down Sort arrow on Node Name", "Down Sort arrow should be displayed",
					"Down Sort arrow is not displayed", "FAIL");
		}
		// Verify pagination
		// Verify navigating to 'Next' page and validate the same
		if (mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.pagnext")) {
			actions.reportCreatePASS("Verify Next pagination link", "Next pagination link should be displayed",
					"Next pagination link is displayed", "PASS");
			actions.keyboardEnter("MenuItemSets.pagnext");
			mcd.smartsync(180);
		} else {
			actions.reportCreatePASS("Verify Next pagination link", "Next pagination link should be displayed",
					"Sufficient records not present for next pagination link to be displayed", "PASS");
		}

		// Verify navigating to 'Previous' page and validate the same
		if (mcd.fn_VerifyWebObjectsDisplayed("MenuItemSet.PreviousPageLink")) {
			actions.reportCreatePASS("Verify Previous pagination link", "Previous pagination link should be displayed",
					"Previous pagination link is displayed", "PASS");
			actions.keyboardEnter("MenuItemSet.PreviousPageLink");
			actions.smartWait(40);
		} else {
			actions.reportCreatePASS("Verify Previous pagination link", "Previous pagination link should be displayed",
					"Sufficient records not present for previous pagination link to be displayed", "FAIL");
		}

		// Verify 'Please enter a valid criteria '
		actions.keyboardEnter("RFMHome.SearchButton");
		mcd.VerifyAlertMessageDisplayed("Error Message", errmsg[5], true, AlertPopupButton.OK_BUTTON);
		actions.WaitForElementPresent("MenuItemSets.Searchfield");
		actions.clear("MenuItemSets.Searchfield");

		// Verify 'Search returned no matching results.'
		((JavascriptExecutor) driver).executeScript("arguments[0].setAttribute('value','$$$$$$');",
				actions.getWebElement("MenuItemSets.Searchfield"));
		actions.keyboardEnter("RFMHome.SearchButton");
		actions.smartWait(20);
		actions.waitForPageToLoad(40);
		actions.verifyTextPresence("Search returned no matching results.", true);

		// Search an existing Menu Item Set
		actions.clear("MenuItemSets.Searchfield");
		actions.keyboardEnter("ScreenSet.searchbutton");
		actions.smartWait(40);
		String existingMISname = mcd.GetTableCellElement("PackageSchedule.Table", 1, 1, "a").getText();
		actions.setValue("MenuItemSets.Searchfield", existingMISname);
		actions.keyboardEnter("ScreenSet.searchbutton");
		actions.smartWait(40);

		// Verifying error Messages in further steps
		//WebElement newmis = driver.findElement(By.xpath("//*[@class='button'][contains(text(),'New Menu Item Set')]"));
		//actions.keyboardEnter(MenuItemSets.SearchButton_Ne);
		List<WebElement> newmis = driver.findElements(By.xpath(actions.getLocator("MenuItemSets.SearchButton_New")));
		actions.keyboardEnter(newmis.get(1));
		actions.smartWait(40);
		actions.waitForPageToLoad(40);

		// Switch to New Menu Item Set window
		try {
			mcd.SwitchToWindow("Add New Menu Item Set");
		} catch (Exception e) {
			e.printStackTrace();
		}

		actions.waitForPageToLoad(120);
		actions.keyboardEnter("MenuItemSets.Nextbtn");
		mcd.VerifyAlertMessageDisplayed("Error", errmsg[0], true, AlertPopupButton.OK_BUTTON);
		actions.smartWait(40);
		actions.setValue("MenuItemSets.BTMenuItemSetNameTextBox", existingMISname);
		actions.keyboardEnter("MenuItemSets.Nextbtn");
		actions.smartWait(40);
		mcd.VerifyAlertMessageDisplayed("Error", errmsg[2], true, AlertPopupButton.OK_BUTTON);

		actions.keyboardEnter("MenuItemSets.Selectbtn");

		try {
			mcd.waitAndSwitch("Select Node");
		} catch (Exception e) {
			e.printStackTrace();
		}

		mcd.Selectrestnode("MenuItemSets.LeftTable", strrest);
		Thread.sleep(3000);
		mcd.waitAndSwitch("Add New Menu Item Set");
		actions.keyboardEnter("MenuItemSets.Nextbtn");

		actions.waitForPageToLoad(100);
		if (actions.isElementPresent("AddNewMenuItemSet.BTErrorMessageDuplicateName")) {
			actions.reportCreatePASS("Verify Error Message Displayed",
					"Error message: Menu Item Set Name already exists, please enter a different Menu Item Set Name. should be displayed",
					"Error message: Menu Item Set Name already exists, please enter a different Menu Item Set Name. is displayed",
					"PASS");
		} else {
			actions.reportCreatePASS("Verify Error Message Displayed",
					"Error message: Menu Item Set Name already exists, please enter a different Menu Item Set Name. should be displayed",
					"Error message: Menu Item Set Name already exists, please enter a different Menu Item Set Name. is not displayed",
					"FAIL");
		}

		actions.setValue("MenuItemSets.CopyYes", "Yes");
		actions.keyboardEnter("MenuItemSets.Nextbtn");
		Thread.sleep(3000);

		// Verify 'Please select a Node.'
		boolean BlnSelectNode, BlnCopyMIS;
		BlnSelectNode = mcd.VerifyAlertMessageDisplayed("Error", errmsg[3], true, AlertPopupButton.OK_BUTTON);
		if (BlnSelectNode) {
			actions.reportCreatePASS("Verify " + errmsg[3], errmsg[3] + " should be displayed",
					errmsg[3] + " is displayed", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + errmsg[3], errmsg[3] + " should be displayed",
					errmsg[3] + " is not displayed", "Fail");
		}
		actions.keyboardEnter("MenuItemSets.Cancelbtn");
		Thread.sleep(3000);

		// Verify 'Please select Copy Menu Item Set.'
		BlnCopyMIS = mcd.VerifyAlertMessageDisplayed("Confirmation", errmsg[4], true, AlertPopupButton.OK_BUTTON);
		if (BlnCopyMIS) {
			actions.reportCreatePASS("Verify " + errmsg[4], errmsg[4] + " should be displayed",
					errmsg[4] + " is displayed", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + errmsg[4], errmsg[4] + " should be displayed",
					errmsg[4] + " is not displayed", "Fail");
		}

		mcd.waitAndSwitch("Menu Item Sets");
	}

	// Creating Menu Item Set with Copy Existing Settings
	public String MNU_0002_CreateMenuItemSet(String strmenuname, String strrest, String strmsg)
			throws InterruptedException {
		String str = "";
		try {

			// Creating New Menu Item Set
			String[] msg = strmsg.split("#");
			actions.keyboardEnter("MenuItemSet.NewMISbutton");
			actions.smartWait(20);

			// switch to new menu item set window
			mcd.waitAndSwitch("Add New Menu Item Set");

			// Entering Menu Item Set Name
			str = mcd.fn_GetRndName("Auto");
			actions.setValue("MenuItemSets.BTMenuItemSetNameTextBox", str);

			// Selec The Node
			actions.keyboardEnter("MenuItemSets.Selectbtn");
			mcd.waitAndSwitch("Select Node");
			mcd.Selectrestnode("MenuItemSets.LeftTable", strrest);

			mcd.waitAndSwitch("Add New Menu Item Set");

			// select copy from existing menu item set as Yes
			actions.setValue("MenuItemSets.CopyYes", "Yes");
			actions.keyboardEnter("MenuItemSets.SelectCopybtn");
			actions.smartWait(40);

			mcd.waitAndSwitch("Select Menu Item Set to Copy");

			// Search with 'a'
			actions.WaitForElementPresent("MenuItemSets.Searchfield");
			actions.setValue("MenuItemSets.Searchfield", strmenuname);
			actions.keyboardEnter("MenuItemPriceandTaxByRestaurant.NBSearchButton");
			actions.waitForPageToLoad(120);
			actions.WaitForElementPresent("MenuItemSets.TableFirstValue");
			actions.click("MenuItemSets.TableFirstValue");

			mcd.waitAndSwitch("Add New Menu Item Set");
			actions.keyboardEnter("MenuItemSets.Nextbtn");
			actions.smartWait(40);
			

			mcd.waitAndSwitch("@Manage Menu Item Set : Manage Menu Items");
			mcd.smartsync(60);

			// Verify 'Your changes have been saved.'
			boolean BlnSuccessMsg;
			BlnSuccessMsg = mcd.VerifyOnscreenMessage("DimensionGroups.DeleteInfoMessage", msg[6], true);
			if (BlnSuccessMsg) {
				actions.reportCreatePASS("Verify creation of menu item set with copy settings as Yes",
						"Menu item set should be created with copy settings as Yes",
						"Menu item set is created with copy settings as Yes", "PASS");
			} else {
				actions.reportCreateFAIL("Verify creation of menu item set with copy settings as Yes",
						"Menu item set should be created with copy settings as Yes",
						"Menu item set is not created with copy settings as Yes", "Fail");
			}

			actions.WaitForElementPresent("MenuItemSets.ReturnToSet");
			actions.keyboardEnter("MenuItemSets.ReturnToSet");
			actions.waitForPageToLoad(180);
			return str;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return str;
	}
}
