package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20471_Vrf_SNcreationAL {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String dtErrMsg;
	private String strErrMsg[];
	private int snCode;
	private String strSize, strSnCode, snDescription;
	private boolean flag;
	private String tcDescription,strUserID;
	private String auditMarket;

	public MNU_20471_Vrf_SNcreationAL(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		dtErrMsg = mcd.GetTestData("DT_ERR_MSG");
		tcDescription = mcd.GetTestData("DT_Description");
		strUserID = mcd.GetTestData("DT_USER_NAME");
		auditMarket = mcd.GetTestData("DT_AUDITLOG_MARKET");
	}

	@Test
	public void test_MNU_20471_Vrf_SNcreationAL() throws InterruptedException {
		String strPageTitle = "Substitution Names"; // TODO: Exact page-title
		String strPageSubHeading = ""; // TODO: Page Heading

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			
			actions.setTestcaseDescription(tcDescription);
			
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");
			
			/** Get application time */
			WebElement apptime = mcd.getdate();
	        String app_date = apptime.getText();


			// ------------------------------------------------------------------------
			// Actions specific to test-flow
	        
	        //Create Substitution Name
			System.out.println("Start");
			strErrMsg = dtErrMsg.split("#");
			actions.click("SubstitutionNames.NewSNbutton");
			Thread.sleep(1000);
			int rowCount = mcd.GetTableRowCount("DimensionName.Table");
			System.out.println("> > > > RowCount:" + rowCount);

			do {
				snCode = mcd.fn_GetRndNumInRange(1, 9999);
				strSnCode = Integer.toString(snCode);
				snDescription = mcd.fn_GetRndName("Auto_DN");

				mcd.SetTableCellValue("DimensionName.Table", rowCount, "Description", snDescription, "input", "value");
				mcd.SetTableCellValue("DimensionName.Table", rowCount, "Code", strSnCode, "input", "value");
				actions.click("DimensionGroup.SaveButton");
				Thread.sleep(2000);

				try {

					flag = mcd.VerifyAlertMessageDisplayed("Warning Message", strErrMsg[0], true,
							AlertPopupButton.OK_BUTTON);
					actions.click("DimensionGroup.SaveButton");
					if (!flag) {
						flag = mcd.VerifyAlertMessageDisplayed("Warning Message", strErrMsg[1], true,
								AlertPopupButton.OK_BUTTON);
					} else {
						flag = mcd.VerifyAlertMessageDisplayed("Warning Message", strErrMsg[0], true,
								AlertPopupButton.OK_BUTTON);
					}
					flag = true;

				} catch (Exception f) {
					flag = false;
					actions.smartWait(15);

				}

			} while (flag);

			flag = mcd.VerifyOnscreenMessage("SubstitutionGroups.InfoMessage", strErrMsg[2], true);
			if (flag) {
				actions.reportCreatePASS("Verify the info message",
						"Message '" + strErrMsg[2] + "' should be displayed", "Expected message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the info message",
						"Message '" + strErrMsg[2] + "' should be displayed", "Expected message is not displayed","FAIL");
			}
			
			

			// Verifying audit log for create operation

   			boolean blnAudit = false;
   			blnAudit = rfm.VerifyAuditLog_Entry(strPageTitle, "Create", auditMarket);

   			if (blnAudit) {
   				actions.reportCreatePASS("Verify Audit Log Entry for Create Substitution Names",
   						"Audit log should be generated for Create Substitution Names",
   						"Audit log generated for Create Substitution Names succesfully", "PASS");
   			} else {
   				actions.reportCreateFAIL("Verify Audit Log Entry for Create Substitution Names ",
   						"Audit log should be generated for Create Substitution Names ",
   						"Audit log not generated for Create Substitution Names succesfully", "FAIL");
   			}

   			blnAudit = rfm.RFM_VerifyAuditLog_Details("RFM2", strUserID, strPageTitle, "Create", auditMarket , strMarket,
   					"Substitution Name " + snDescription + " has been created.");
   			
   			if (blnAudit) {
   				actions.reportCreatePASS("Verify Audit Log Details for Create Substitution Names",
   						"Audit log details should be generated for Create Substitution Names",
   						"Audit log details generated for Substitution Names succesfully", "PASS");
   			} else {
   				actions.reportCreateFAIL("Verify Audit Log Details for Create Substitution Names ",
   						"Audit log details should be generated for Create Substitution Names ",
   						"Audit log details not generated for Substitution Names item succesfully", "FAIL");
   			}
   			
   			
			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}
