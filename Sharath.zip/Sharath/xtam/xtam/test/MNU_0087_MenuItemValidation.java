package xtam.test;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.MasterMenuItem;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0087_MenuItemValidation {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();
	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private MasterMenuItem mmi;

	// Test Data variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strmsg;
	private String strApplicationDate;

	public MNU_0087_MenuItemValidation(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();
		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		mmi = new MasterMenuItem(driver, actions, uiActions, inputData, mcd, rfm);
		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strmsg = mcd.GetTestData("DT_MSG");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
	}

	@Test

	public void MNU_0087_MenuItemValidation() throws InterruptedException {

		try {

        	actions.setTestcaseDescription(
					"Search by Menu Item Number and Name and Verify error messages for invalid and blank search.");

			System.out.println(
					"********************************************************************** Test execution starts");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow

			// Search Menu Item Name with all options and Search Menu Item
			// Number with all options
			mmi.MI_SearchMenuitem();

			// Select Exact Match Radio Button,Enter Menu Item Name in Search
			// Text & Click On Search Button
			actions.clear("MasterMenuItemList.Searchfield");
			actions.keyboardEnter("MasterMenuItemList.Searchbtn");
			actions.smartWait(20);
			String ele6 = driver.findElement(By.xpath(actions.getLocator("DepositSet.FirstData"))).getText();
			actions.setValue("MasterMenuItemList.Searchfield", ele6);
			actions.javaScriptClick("MasterMenuItemList.exactbtn");
			actions.keyboardEnter("MasterMenuItemList.Searchbtn");
			actions.smartWait(20);
			String ele7 = driver.findElement(By.xpath(actions.getLocator("DepositSet.FirstData"))).getText();
			if (ele6.equalsIgnoreCase(ele7)) {
				actions.reportCreatePASS("Verify Menu Item Name is Present or not",
						"Menu Item Name Should be Present as Expected", "Menu Item Name is Present as Expected",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Menu Item Name is Present or not",
						"Menu Item Name Should be Present as Expected", "Menu Item Name is Present as Expected",
						"FAIL");
			}
			// Select Exact Match Radio Button,Enter Menu Item Number in Search
			// Text & Click On Search Button
			actions.clear("MasterMenuItemList.Searchfield");
			actions.keyboardEnter("MasterMenuItemList.Searchbtn");
			actions.smartWait(20);
			String ele8 = driver.findElement(By.xpath(actions.getLocator("MasterDeposit.FirstData"))).getText();
			actions.setValue("MasterMenuItemList.Searchfield", ele8);
			actions.javaScriptClick("MasterMenuItemList.exactbtn");
			actions.keyboardEnter("MasterMenuItemList.Searchbtn");
			actions.smartWait(20);
			String ele9 = driver.findElement(By.xpath(actions.getLocator("MasterDeposit.FirstData"))).getText();
			if (ele8.equalsIgnoreCase(ele9)) {
				actions.reportCreatePASS("Verify Menu Item Number is Present or not",
						"Menu Item Number Should be Present as Expected", "Menu Item Number is Present as Expected",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Menu Item Number is Present or not",
						"Menu Item Number Should be Present as Expected", "Menu Item Number is Present as Expected",
						"FAIL");
			}
			// Enter invalid word/letter/number which does not exist in menu
			// name or number & Click on Search Button ,Verify Message
			actions.clear("MasterMenuItemList.Searchfield");
			actions.keyboardEnter("MasterMenuItemList.Searchbtn");
			actions.smartWait(20);
			String ele = mcd.generateString('c', 5);
			actions.setValue("MasterMenuItemList.Searchfield", ele);
			actions.keyboardEnter("MasterMenuItemList.Searchbtn");
			actions.smartWait(20);
			actions.verifyTextPresence(strmsg, true);

			// Enter a valid menu item name or number & Click on Search Button
			// ,Verify Message
			actions.clear("MasterMenuItemList.Searchfield");
			actions.keyboardEnter("MasterMenuItemList.Searchbtn");
			actions.smartWait(20);
			String ele2 = driver.findElement(By.xpath(actions.getLocator("DepositSet.FirstData"))).getText();
			actions.setValue("MasterMenuItemList.Searchfield", ele2);
			actions.keyboardEnter("MasterMenuItemList.Searchbtn");
			actions.smartWait(20);

			// Select invalid Family Group in Search Within drop down & Click on
			// Search Button ,Verify Message
			actions.clear("MasterMenuItemList.Searchfield");
			actions.keyboardEnter("MasterMenuItemList.Searchbtn");
			actions.smartWait(20);
			actions.setValue("MasterMenuItemList.FamilyGroupDDL", "BREAKFAST_DRINK");
			actions.smartWait(20);
			String ele3 = driver.findElement(By.xpath(actions.getLocator("DepositSet.FirstData"))).getText();
			actions.setValue("MasterMenuItemList.Searchfield", ele3);
			actions.javaScriptClick("MasterMenuItemList.exactbtn");
			actions.setValue("ManageMenuItem.FamilyGroup", "REGULAR_DRINK");
			actions.keyboardEnter("MasterMenuItemList.Searchbtn");
			actions.smartWait(20);
			actions.verifyTextPresence(strmsg, true);

			// Select invalid Approval status in search section & Click on
			// Search Button ,Verify Message
			actions.clear("MasterMenuItemList.Searchfield");
			actions.keyboardEnter("MasterMenuItemList.Searchbtn");
			actions.smartWait(20);
			if (strMarket.equalsIgnoreCase("Australasia")) {
				actions.setValue("SmartReminderSets.StatusFilter", "Inactive");
				actions.smartWait(20);
			} else {
				actions.setValue("RestMIList.MIApprovalDrpdwn", "Not Approved");
				actions.smartWait(20);
			}
			String ele4 = driver.findElement(By.xpath(actions.getLocator("DepositSet.FirstData"))).getText();
			actions.setValue("MasterMenuItemList.Searchfield", ele4);
			actions.javaScriptClick("MasterMenuItemList.exactbtn");
			Thread.sleep(2000);
			if (strMarket.equalsIgnoreCase("Australasia")) {
				actions.setValue("MediaAssets.SearchStatus", "Active");
			} else {
				actions.setValue("ManageMenuItem.ApprovalSt", "Approved");
			}

			actions.keyboardEnter("MasterMenuItemList.Searchbtn");
			actions.smartWait(20);
			actions.verifyTextPresence(strmsg, true);

			// Select invalid "Saved as Partial" value & Click on Search Button
			// ,Verify Message
			actions.clear("MasterMenuItemList.Searchfield");
			actions.keyboardEnter("MasterMenuItemList.Searchbtn");
			actions.smartWait(20);
			actions.setValue("RFMMMIL.SaveAsPartialList1", "No");
			actions.smartWait(20);
			String ele5 = driver.findElement(By.xpath(actions.getLocator("DepositSet.FirstData"))).getText();
			actions.setValue("MasterMenuItemList.Searchfield", ele5);
			actions.javaScriptClick("MasterMenuItemList.exactbtn");
			actions.setValue("RFMMMIL.SaveAsPartialList2", "Yes");
			actions.keyboardEnter("MasterMenuItemList.Searchbtn");
			actions.smartWait(20);
			actions.verifyTextPresence(strmsg, true);
			rfm.Logout();

		} catch (Exception e) {
			// Reporter.log("Test Failed :: " + e.getCause() + " - " +
			// e.getMessage());
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());

		} finally {
			// actions.quitBrowser();
			actions.reportCreatePASS("Closing Browser", "Should close the browser.", "Closed the browser.", "Pass");
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}
