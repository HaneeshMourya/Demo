package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20511_VrfyDeleteExistingFS {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo1;
	private String strNavigateTo2;
	private String ResetDefaultMsg;
	private String strWM2;
	private String strWM3;
	private boolean flag;
	// TODO: Declare test-data variables for other data-parameters

	public MNU_20511_VrfyDeleteExistingFS(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo1 = mcd.GetTestData("DT_NAVIGATE_TO1");
		strNavigateTo2 = mcd.GetTestData("DT_NAVIGATE_TO2");
		ResetDefaultMsg = mcd.GetTestData("DT_ResetDefaultMessage");
		strWM2 = mcd.GetTestData("WarningMessage2");
		strWM3 = mcd.GetTestData("WarningMessage3");

		// TODO: GetTestData for other data-parameters
	}

	@Test
	public void test_MNU_20511_VrfyDeleteExistingFS() throws InterruptedException {
		String strPageTitle = ""; // TODO: Exact page-title
		String strPageSubHeading1 = "Flavor Set"; // TODO: Page Heading
		String strPageSubHeading2 = "Master Flavors";

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(
					"Verify that the user is not able to delete an existing Flavor if the Nozzle id is customized at the Flavor Set");
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo2);
			actions.select_menu("RFMHome.Navigation", strNavigateTo2);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Verify Page Header */
			System.out.println("> Verify Page Heading");
			mcd.VerifyPageHeading(strPageSubHeading2, "SubHeading");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------

			// Creating Master Flavor
			actions.WaitForElementPresent("MasterFlavors.NewFlavor", 100);
			actions.keyboardEnter("MasterFlavors.NewFlavor");

			int rw_cnt = mcd.GetTableRowCount("RFMHome.Table");
			System.out.println(rw_cnt);
			String strRandName = mcd.fn_GetRndName("Auto");
			System.out.println(strRandName);
			mcd.SetTableCellValue("RFMHome.Table", rw_cnt, "Flavor Name", strRandName, "input", "value");

			do {
				int randomNum = mcd.fn_GetRndNumInRange(0, 99);
				System.out.println(randomNum);
				String strI = "" + randomNum;
				System.out.println(strI);
				mcd.SetTableCellValue("RFMHome.Table", rw_cnt, "Nozzle Id", strI, "input", "value");
				actions.click("MasterFlavors.SaveButton");
				try {

					flag = actions.isAlertPresent(5);
					if(flag){
						mcd.VerifyAlertMessageDisplayed("Warning Message", strWM2, true, AlertPopupButton.OK_BUTTON);
					}

				} catch (Exception f) {
					flag = false;
					actions.smartWait(10);

				}

			} while (flag);
			

			// Verify the on-screen message
			flag = mcd.VerifyOnscreenMessage("MasterFlavor.InfoMessage", "Your changes have been saved.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}
			

			// Navigate Flavor Set
			System.out.println("> Navigate to :: " + strNavigateTo1);
			actions.select_menu("RFMHome.Navigation", strNavigateTo1);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Verify Page Header */
			System.out.println("> Verify Page Heading");
			mcd.VerifyPageHeading(strPageSubHeading1, "SubHeading");
			
			

			// Select any Exiting Flavor Set
			actions.WaitForElementPresent("FlavorSet.SearchButton", 100);
			actions.keyboardEnter("FlavorSet.SearchButton");
			actions.smartWait(100);
			WebElement flvr_sel = mcd.GetTableCellElement("FieldPermissions.Table", 1, 1, "a");
			actions.keyboardEnter(flvr_sel);
			actions.smartWait(100);
			

			// Click on Reset to Default Button if it is Present on the Page
			if (actions.isElementPresent("FlavorSet.ResetDefaultBtn")) {
				actions.click("FlavorSet.ResetDefaultBtn");
				if (mcd.VerifyAlertMessageDisplayed("Information", ResetDefaultMsg, true, AlertPopupButton.OK_BUTTON)) {
					actions.reportCreatePASS("Veriyfing the '" + ResetDefaultMsg + " 'is Present or not",
							ResetDefaultMsg + " should be present", ResetDefaultMsg + " is present", "Pass");
				} else {
					actions.reportCreateFAIL("Veriyfing the '" + ResetDefaultMsg + " 'is Present or not",
							ResetDefaultMsg + " should be present", ResetDefaultMsg + " is not present", "Fail");
				}
			}
			

			// Customized the NozzleId Value
			if (driver.findElement(By.xpath(actions.getLocator("FlavorSet.CustomizeButton"))).getText()
					.equalsIgnoreCase("Customize Settings"))
				;
			actions.javaScriptClick("FlavorSet.CustomizeButton");
			actions.smartWait(10);

			List<WebElement> FlavorsetList = driver.findElements(By.xpath(actions.getLocator("FlavorSet.FlavorList")));
			WebElement ele = null;

			String str = "";
			int a = 0;

			String Flavorset;
			for (int i = 0; i < FlavorsetList.size(); i++) {

				Flavorset = FlavorsetList.get(i).getText();
				if (Flavorset.trim().equals(strRandName)) {
					i = i + 1;
					ele = driver.findElement(By.xpath("//*[@id='Sess1']/tbody/tr[" + i + "]/td[2]/input[1]"));
					str = ele.getAttribute("value");
					a = Integer.parseInt(str) + 1;
					str = Integer.toString(a);
					ele.clear();
					ele.sendKeys(str);
					break;

				}
			}
			

			// Click on Save Button and verify on-Screen Message
			actions.click("FlavorSet.SavelButton");
			flag = mcd.VerifyOnscreenMessage("FlavorSet.InfoMessage", "Your changes have been saved.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}
			
			

			// Navigate to Master Flavors
			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo2);
			actions.select_menu("RFMHome.Navigation", strNavigateTo2);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Verify Page Header */
			System.out.println("> Verify Page Heading");
			mcd.VerifyPageHeading(strPageSubHeading2, "SubHeading");
			

			// Click on Delete button on newly created Mater Flavor
			List<WebElement> MasterFlavorsetList = driver.findElements(By.xpath(actions.getLocator("MasterFlavor.FlavorNameList")));
			String MasterFlavorSet;

			for (int i = 0; i < MasterFlavorsetList.size(); i++) 
			{
				MasterFlavorSet = MasterFlavorsetList.get(i).getAttribute("value");

				if (MasterFlavorSet.trim().equals(strRandName)) 
					
				{
					i = i + 1;
					
					WebElement DeleteFlavor = driver.findElement(By.xpath("//*[@id='Sess1']/tbody/tr[" + i + "]/td[3]/a"));
					
					actions.click(DeleteFlavor);
					if (mcd.VerifyAlertMessageDisplayed("Information", strWM3, true, AlertPopupButton.OK_BUTTON)) {
						actions.reportCreatePASS("Veriyfing the '" + strWM3 + " 'is Present or not",
								strWM3 + " should be present", strWM3 + " is present", "Pass");
					} else {
						actions.reportCreateFAIL("Veriyfing the '" + strWM3 + " 'is Present or not",
								strWM3 + " should be present", strWM3 + " is not present", "Fail");
					}
					
					
					// Verify the on-screen message
					flag = mcd.VerifyOnscreenMessage("MasterFlavor.DeleteInfoMessage",
							"Flavor cannot be deleted as it is customized at lower level.", true);

					if (flag) {
						actions.reportCreatePASS("Verify the on-screen message",
								"Message 'Flavor cannot be deleted as it is customized at lower level.'",
								"Expected Message is displayed", "PASS");
					} else {
						actions.reportCreateFAIL("Verify the on-screen message",
								"Message 'Flavor cannot be deleted as it is customized at lower level.'",
								"Expected Message is not displayed", "FAIL");
					}
					
					
					actions.smartWait(10);
					break;
				}
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
	
	public boolean VerifyAlertMessageDisplayed(String strMessageType, String strExptMessage, Boolean blnVerifyExactMsg,
			AlertPopupButton alertActionButton) {
		boolean blnReturn = false;
		String strReturn = "";
		String strActualMsg = "";

		try {
			// Verify that confirmation popup is displayed
			System.out.println("> Verify that " + strMessageType.toLowerCase() + " is displayed");
			//To check the popup before switching 6/9/2016
			new WebDriverWait(driver,
					30).until(ExpectedConditions.alertIsPresent());
			Alert popup = driver.switchTo().alert();
			if (popup != null) {
				// Verify the message displayed
				System.out.println("> Verify the message displayed");
				strActualMsg = popup.getText().trim();
				if (blnVerifyExactMsg) {
					System.out.println("*******************" + strActualMsg.length());
					System.out.println("*******************" + strExptMessage.trim().length());
					// actions.verifyTextContains(strActualMsg.trim(),
					// strExptMessage.trim(), false);
					if (strActualMsg.equalsIgnoreCase(strExptMessage.trim())) {
						blnReturn = true;
						strReturn = strMessageType + " message is displayed as expected";

						// actions.verifyTestStep(actual, expected,
						// continueExecution);
					} else {
						blnReturn = false;
						strReturn = strMessageType + " message displayed is NOT as expected. Actual message : '"
								+ strActualMsg + "' (Expected message : '" + strExptMessage + "')";
					}
				} else {
					System.out.println("*******************" + strActualMsg.length());
					System.out.println("*******************" + strExptMessage.trim().length());
					// actions.verifyTextContains(strActualMsg.trim().toUpperCase(),
					// strExptMessage.trim().toUpperCase(), false);
					if (strActualMsg.toUpperCase().contains(strExptMessage.trim().toUpperCase())) {
						blnReturn = true;
						strReturn = strMessageType + " message is displayed as expected";
					} else {
						blnReturn = false;
						strReturn = strMessageType + " message displayed is NOT as expected. Actual message : '"
								+ strActualMsg + "' (Expected message : '" + strExptMessage + "')";
					}
				}
			} else {
				blnReturn = false;
				strReturn = strMessageType + " is NOT displayed";
			}

			// Click 'strPopupAction' button on confirmation popup
			if (alertActionButton.equals(AlertPopupButton.OK_BUTTON)) {
				System.out.println("> Click 'OK' button on confirmation popup");
				popup.accept();

			} else if (alertActionButton.equals(AlertPopupButton.CANCEL_BUTTON)) {
				System.out.println("> Click 'Cancel' button on confirmation popup");
				popup.dismiss();
			}

			Thread.sleep(3000);
			;
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println(strReturn);
		return blnReturn;
	}
}
