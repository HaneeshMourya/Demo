package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20483_CreateUpdtDeltSRG {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strWM1;
	private String strWM3;
	private String strWM4;
	private String strWM5;
	private String strWM6, strTestDescription;
	private String strActivity, strActivity1, strActivity2, strMessage;
	private String strDBName, strUserID, strOperation, strLevel, strNodeName;
	boolean AuditEntry;
	String AuditDesc;
	boolean AuditDetail;

	public MNU_20483_CreateUpdtDeltSRG(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strWM1 = mcd.GetTestData("WarningMessage1");
		strWM3 = mcd.GetTestData("WarningMessage3");
		strWM4 = mcd.GetTestData("WarningMessage4");
		strWM5 = mcd.GetTestData("WarningMessage5");
		strWM6 = mcd.GetTestData("WarningMessage6");
		strDBName = mcd.GetTestData("DT_DB_NAME");
		strUserID = mcd.GetTestData("DT_USER_ID");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strActivity = mcd.GetTestData("DT_ACTIVITY");
		strActivity1 = mcd.GetTestData("DT_ACTIVITY1");
		strActivity2 = mcd.GetTestData("DT_ACTIVITY2");
		strLevel = mcd.GetTestData("DT_LEVEL");
		strNodeName = mcd.GetTestData("DT_NODE_NAME");
		strMessage = mcd.GetTestData("DT_MESSAGES");
	}

	@Test
	public void test_MNU_20485_CreateSRG() throws InterruptedException {
		// This script covers 5 test cases
		strTestDescription = "Verify Create, Update and delete operations of Smart Reminder Groups with Audit log Verification for each operation";
		try {
			System.out.println("***************************** Test execution starts");
			/** Get Test Case Description */
			actions.setTestcaseDescription(strTestDescription);

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Navigating to Smart Reminder Groups */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			String[] strMsg = strMessage.split("#");
			actions.WaitForElementPresent("SmartReminderGroup.NewSmartReminderGroupButton", 100);

			// Creating new Smart Reminder Group to Verify create operation and
			// Audit log generation
			actions.keyboardEnter("SmartReminderGroup.NewSmartReminderGroupButton");
			mcd.SwitchToWindow("Add New Smart Reminder Group");

			// GUI Verification of 'Add New Smart Reminder Group'
			// Check if Smart Reminder Group Name text box is Present
			boolean booDisplayed1 = driver
					.findElement(By.xpath(actions.getLocator("AddNewSmartReminderGroup.SearchTextBox"))).isDisplayed();
			System.out.println(booDisplayed1);
			if (booDisplayed1 == true) {
				System.out.println("Present");
				actions.reportCreatePASS("Smart Reminder Group Name is Present",
						"Smart Reminder Group Name should Present", "Smart Reminder Group Name Button is Present",
						"Pass");
			} else {
				actions.reportCreateFAIL("Smart Reminder Group Name is Present",
						"Smart Reminder Group Name should Present", "Smart Reminder Group Name Button is not Present",
						"Fail");
			}

			// Check if 'Yes' Radio Button is Present
			String strDisplayed2 = driver.findElement(By.xpath(actions.getLocator("AddNewSmartReminderGroup.RadioYes")))
					.getAttribute("type");
			System.out.println(strDisplayed2);
			if (strDisplayed2.equals("radio")) {
				System.out.println("Present");
				actions.reportCreatePASS(
						"Copy Settings from existing Smart Reminder Group : 'Yes' Radio Button is Present",
						"Copy Settings from existing Smart Reminder Group : 'Yes' Radio Button should Present",
						"Copy Settings from existing Smart Reminder Group : 'Yes' Radio Button is Present", "Pass");
			} else {
				actions.reportCreateFAIL(
						"Copy Settings from existing Smart Reminder Group : 'Yes' Radio Button is Present",
						"Copy Settings from existing Smart Reminder Group : 'Yes' Radio Button should Present",
						"Copy Settings from existing Smart Reminder Group : 'Yes' Radio Button is not Present", "Fail");
			}

			// Check if 'NO' Radio Button is Present
			String strDisplayed3 = driver.findElement(By.xpath(actions.getLocator("AddNewSmartReminderGroup.RadioNo")))
					.getAttribute("type");
			System.out.println(strDisplayed3);
			if (strDisplayed3.equals("radio")) {
				System.out.println("Present");
				actions.reportCreatePASS(
						"Copy Settings from existing Smart Reminder Group : 'No' Radio Button is Present",
						"Copy Settings from existing Smart Reminder Group : 'No' Radio Button should Present",
						"Copy Settings from existing Smart Reminder Group : 'No' Radio Button is Present", "Pass");
			} else {
				actions.reportCreateFAIL(
						"Copy Settings from existing Smart Reminder Group : 'No' Radio Button is Present",
						"Copy Settings from existing Smart Reminder Group : 'No' Radio Button should Present",
						"Copy Settings from existing Smart Reminder Group : 'No' Radio Button is not Present", "Fail");
			}

			// Check if Next Button is Present
			boolean booDisplayed4 = driver.findElement(By.xpath(actions.getLocator("AddNewSmartReminderGroup.Next")))
					.isDisplayed();
			System.out.println(booDisplayed4);
			if (booDisplayed4 == true) {
				System.out.println("Present");
				actions.reportCreatePASS("Next Button is Present", "Next Button should Present",
						"Next Button is Present", "Pass");
			} else {
				actions.reportCreateFAIL("SNextave Button is Present", "Next Button should Present",
						"Next Button is not Present", "Fail");
			}

			// Check if Cancel Button is Present
			boolean booDisplayed5 = driver.findElement(By.xpath(actions.getLocator("AddNewSmartReminderGroup.Cancel")))
					.isDisplayed();
			System.out.println(booDisplayed5);
			if (booDisplayed5 == true) {
				System.out.println("Present");
				actions.reportCreatePASS("Cancel Button is Present", "Cancel Button should Present",
						"Cancel Button is Present", "Pass");
			} else {
				actions.reportCreateFAIL("Cancel Button is Present", "Cancel Button should Present",
						"Cancel Button is not Present", "Fail");
			}
			actions.keyboardEnter("AddNewSmartReminderGroup.Next");

			// Verifying alert message for alerting to enter SRG Name
			mcd.VerifyAlertMessageDisplayed("Warning", strWM1, true, AlertPopupButton.OK_BUTTON);

			String strRandName = mcd.fn_GetRndName("Auto");
			actions.setValue("AddNewSmartReminderGroup.SearchTextBox", strRandName);
			driver.findElement(By.xpath(actions.getLocator("AddNewSmartReminderGroup.RadioNo"))).click();
			actions.keyboardEnter("AddNewSmartReminderGroup.Next");
			Thread.sleep(3000);
			mcd.SwitchToWindow("Smart Reminder Group");

			// Check if Group Name Text Field is Present
			boolean booDisplayed6 = driver
					.findElement(By.xpath(actions.getLocator("SmartReminderGroup.GroupNameTextField"))).isDisplayed();
			System.out.println(booDisplayed6);
			if (booDisplayed6 == true) {
				System.out.println("Present");
				actions.reportCreatePASS("Group Name Text Field is Present", "Group Name Text Field should Present",
						"Group Name Text Field is Present", "Pass");
			} else {
				actions.reportCreateFAIL("Group Name Text Field is Present", "Group Name Text Field should Present",
						"Group Name Text Field is not Present", "Fail");
			}

			// Check if Status Drop down is Present
			boolean booDisplayed7 = driver.findElement(By.xpath(actions.getLocator("SmartReminderGroup.StatusDDL")))
					.isDisplayed();
			System.out.println(booDisplayed7);
			if (booDisplayed7 == true) {
				System.out.println("Present");
				actions.reportCreatePASS("Status Dropdown is Present", "Status Dropdown should Present",
						"Status Dropdown is Present", "Pass");
			} else {
				actions.reportCreateFAIL("Status Dropdown is Present", "Status Dropdown should Present",
						"Status Dropdown is not Present", "Fail");
			}
			// Validating Error messages for each field on Smart Reminder Group
			// screen
			/** Click on Save Button */
			actions.keyboardEnter("SmartReminderGroup.SaveButton");
			mcd.VerifyAlertMessageDisplayed("Warning", strWM3, true, AlertPopupButton.OK_BUTTON);
			String strRandName1 = mcd.fn_GetRndName("Auto");
			actions.setValue("SmartReminderGroup.FirstName", strRandName1);
			actions.keyboardEnter("SmartReminderGroup.SaveButton");
			/** Click OK on Alert PopUp */
			mcd.VerifyAlertMessageDisplayed("Warning Message", strWM4, true, AlertPopupButton.OK_BUTTON);

			String strRandName2 = mcd.fn_GetRndName("Question");
			/** Set Value in First Question */
			actions.setValue("SmartReminderGroup.FirstQuestion", strRandName2);
			/** Click on Cancel Button */
			actions.keyboardEnter("SmartReminderGroup.CancelButton");
			Thread.sleep(5000);
			mcd.VerifyAlertMessageDisplayed("Warning Message", strWM5, true, AlertPopupButton.CANCEL_BUTTON);
			/** Click on Save Button */
			actions.keyboardEnter("SmartReminderGroup.SaveButton");
			Thread.sleep(5000);
			actions.waitForPageToLoad(120);

			// Verifying Create Success message and validating the same
			boolean booMsg = mcd.VerifyOnscreenMessage("ManageMenuItems.SaveMessage", strMsg[0], true);
			System.out.println(booMsg);
			if (booMsg == true) {
				actions.reportCreatePASS("Message: 'Your changes have been saved.' is Displayed",
						"Message: 'Your changes have been saved.' should Displayed",
						"Message: 'Your changes have been saved.' is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Message: 'Your changes have been saved.' is Displayed",
						"Message: 'Your changes have been saved.' should Displayed",
						"Message: 'Your changes have been saved.' is not Displayed", "Fail");
			}

			// Check Audit Log for Smart Reminder Group Create activity
			AuditEntry = rfm.VerifyAuditLog_Entry(strOperation, strActivity, strLevel);
			System.out.println(AuditEntry);
			if (AuditEntry) {
				actions.reportCreatePASS("Verify Audit Log Entry for create Smart Reminder Group",
						"Audit log should be generated for create Smart Reminder group",
						"Audit log generated for creating Smart Reminder group succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Entry for create Smart Reminder Group",
						"Audit log should be generated for create Smart Reminder group",
						"Audit log not generated for creating Smart Reminder group", "FAIL");
			}
			AuditDesc = "Smart Reminder Group " + strRandName + " has been created.";
			AuditDetail = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID, strOperation, strActivity, strLevel,
					strNodeName, AuditDesc);
			System.out.println(AuditDetail);
			if (AuditDetail) {
				actions.reportCreatePASS("Verify Audit Log Details for create Smart Reminder Group",
						"Audit log details should be generated for create Smart Reminder group",
						"Audit log details generated for creating Smart Reminder group succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Details for create Smart Reminder Group",
						"Audit log details should be generated for create Smart Reminder group",
						"Audit log details not generated for creating Smart Reminder group", "FAIL");
			}

			/**
			 * Navigating to Smart Reminder Group again to perform update
			 * operation
			 */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			actions.WaitForElementPresent("SmartReminderGroup.SearchTextBox", 100);

			// Searching for the created Smart Reminder Group and updating it's
			// status
			actions.setValue("SmartReminderGroup.SearchTextBox", strRandName);
			actions.forceClick("SmartReminderGroup.SearchButton");
			mcd.smartsync(100);
			actions.click("SmartReminderGroup.TableFirstValue");
			Thread.sleep(3000);
			actions.waitForPageToLoad(120);
			actions.setValue("SmartReminderGroup.StatusDDL", "Inactive");
			actions.keyboardEnter("SmartReminderGroup.SaveButton");
			mcd.smartsync(180);

			// Validating for Update operation of Smart Reminder Group is
			// successful
			boolean booMsg1 = mcd.VerifyOnscreenMessage("ManageMenuItems.SaveMessage", strMsg[0], true);
			System.out.println(booMsg1);
			if (booMsg1 == true) {
				actions.reportCreatePASS("Message: 'Your changes have been saved.' is Displayed",
						"Message: 'Your changes have been saved.' should Displayed",
						"Message: 'Your changes have been saved.' is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Message: 'Your changes have been saved.' is Displayed",
						"Message: 'Your changes have been saved.' should Displayed",
						"Message: 'Your changes have been saved.' is not Displayed", "Fail");
			}

			// Audit Log verification for Update activity of Smart Reminder
			// Group
			AuditEntry = rfm.VerifyAuditLog_Entry(strOperation, strActivity1, strLevel);
			System.out.println(AuditEntry);
			if (AuditEntry) {
				actions.reportCreatePASS("Verify Audit Log Entry for update Smart Reminder Group",
						"Audit log should be generated for update Smart Reminder group",
						"Audit log generated for updating Smart Reminder group succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Entry for update Smart Reminder Group",
						"Audit log should be generated for update Smart Reminder group",
						"Audit log not generated for updating Smart Reminder group", "FAIL");
			}
			AuditDesc = "Smart Reminder Group " + strRandName + " has been updated.";
			AuditDetail = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID, strOperation, strActivity1, strLevel,
					strNodeName, AuditDesc);
			System.out.println(AuditDetail);
			if (AuditDetail) {
				actions.reportCreatePASS("Verify Audit Log Details for update Smart Reminder Group",
						"Audit log details should be generated for update Smart Reminder group",
						"Audit log details generated for updating Smart Reminder group succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Details for update Smart Reminder Group",
						"Audit log details should be generated for update Smart Reminder group",
						"Audit log details not generated for updating Smart Reminder group", "FAIL");
			}

			/**
			 * Navigating to Smart Reminder Group again to perform Delete action
			 */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			// Deleting the earlier created Smart Reminder Group
			actions.WaitForElementPresent("SmartReminderGroup.SearchTextBox", 100);
			actions.setValue("SmartReminderGroup.SearchTextBox", strRandName);
			actions.keyboardEnter("SmartReminderGroup.SearchButton");
			mcd.smartsync(100);
			/** Deleting */
			actions.click("SmartReminderGroup.FirstDeleteIcon");

			/** Click OK on Alert Pop up */
			mcd.VerifyAlertMessageDisplayed("Warning", strWM6, true, AlertPopupButton.OK_BUTTON);
			mcd.smartsync(100);
			// Validating for delete successful message
			booMsg = mcd.VerifyOnscreenMessage("SmartReminderGroup.DeleteMessage", strMsg[1], true);
			System.out.println(booMsg);
			if (booMsg == true) {
				actions.reportCreatePASS("Message: 'Delete has been successfully completed.' is Displayed",
						"Message: 'Delete has been successfully completed.' should Displayed",
						"Message: 'Delete has been successfully completed.' is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Message: 'Delete has been successfully completed.' is Displayed",
						"Message: 'Delete has been successfully completed.' should Displayed",
						"Message: 'Delete has been successfully completed.' is not Displayed", "Fail");
			}

			// Audit Log verification for Delete operation of Smart Reminder
			// Group
			AuditEntry = rfm.VerifyAuditLog_Entry(strOperation, strActivity2, strLevel);
			System.out.println(AuditEntry);
			if (AuditEntry) {
				actions.reportCreatePASS("Verify Audit Log Entry for Delete Smart Reminder Group",
						"Audit log should be generated for Delete Smart Reminder group",
						"Audit log generated for Delete Smart Reminder group succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Entry for Delete Substitution Group",
						"Audit log should be generated for Delete Smart Reminder group",
						"Audit log not generated for Delete Smart Reminder group succesfully", "FAIL");
			}
			AuditDesc = "Smart Reminder Group " + strRandName + " has been deleted.";
			AuditDetail = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID, strOperation, strActivity2, strLevel,
					strNodeName, AuditDesc);
			System.out.println(AuditDetail);
			if (AuditDetail) {
				actions.reportCreatePASS("Verify Audit Log Details for delete Smart Reminder Group",
						"Audit log details should be generated for delete Smart Reminder group",
						"Audit log details generated for Smart Reminder group item succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Details for delete Smart Reminder Group",
						"Audit log details should be generated for delete Smart Reminder group",
						"Audit log details not generated for Smart Reminder group item succesfully", "FAIL");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			// reporting the Fail condition
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}
