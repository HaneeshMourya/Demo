package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20482_SRGFieldSpecifitn {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String StrWm, ExpectWm[];
	private String strOperation, StrActivity, StrLevel, StrLevedetails, strDBName, strUserID;
	private String strExpectlevel[], strExpectActivity[], strExpectLevelDetails[];
	private boolean flag;

	public MNU_20482_SRGFieldSpecifitn(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		StrWm = mcd.GetTestData("DT_WarningMessage");
		StrLevel = mcd.GetTestData("DT_LEVEL");
		StrLevedetails = mcd.GetTestData("DT_LevelDetails");
		StrActivity = mcd.GetTestData("DT_ACTIVITY");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strDBName = mcd.GetTestData("DT_DBNAME");
		strUserID = mcd.GetTestData("DT_USER_NAME");

		ExpectWm = StrWm.split("#");
		strExpectActivity = StrActivity.split("#");
		strExpectlevel = StrLevel.split("#");
		strExpectLevelDetails = StrLevedetails.split("#");

	}

	@Test
	public void test_MNU_20482_SRGFieldSpecifitn() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"Verify the field specifications and the functionality for Creating New Smart Reminder Group without copying existing settings.Also Verify the Audit log for same.");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			/** Get the Table First Value */
			actions.WaitForElementPresent("SmartReminderGroup.NewSmartReminderGroupButton", 50);
			String strValue = driver.findElement(By.xpath(actions.getLocator("SmartReminderGroup.TableFirstValue")))
					.getText();
			System.out.println(strValue);

			/** Verify if Search TextBox is Present */
			actions.WaitForElementPresent("SmartReminderGroup.SearchTextBox", 50);
			boolean booDisplayed = driver.findElement(By.xpath(actions.getLocator("SmartReminderGroup.SearchTextBox")))
					.isDisplayed();
			System.out.println(booDisplayed);
			if (booDisplayed == true) {
				System.out.println("Present");
				actions.reportCreatePASS("Smart Reminder Group Search TextBox is Present",
						"Smart Reminder Group Search TextBox should Present",
						"Smart Reminder Group Search TextBox is Present", "Pass");
			} else {
				actions.reportCreateFAIL("Smart Reminder Group Search TextBox is Present",
						"Smart Reminder Group Search TextBox should Present",
						"Smart Reminder Group Search TextBox is not Present", "Fail");
			}

			/**
			 * Verify if Message 'Search by Smart Reminder Group Name' is
			 * Displayed
			 */
			boolean booDisplayed1 = driver
					.findElement(By.xpath(actions.getLocator("SmartReminderGroup.SearchHintMessage"))).isDisplayed();
			System.out.println(booDisplayed1);
			if (booDisplayed1 == true) {
				System.out.println("Present");
				actions.reportCreatePASS("Text 'Search by Smart Reminder Group Name' is Present",
						"Text 'Search by Smart Reminder Group Name' should Present",
						"Text 'Search by Smart Reminder Group Name' is Present", "Pass");
			} else {
				actions.reportCreateFAIL("Text 'Search by Smart Reminder Group Name' is Present",
						"Text 'Search by Smart Reminder Group Name' should Present",
						"Text 'Search by Smart Reminder Group Name' is not Present", "Fail");
			}

			/** Verify if Search Button is Present */
			boolean booDisplayed2 = driver.findElement(By.xpath(actions.getLocator("SmartReminderGroup.SearchButton")))
					.isDisplayed();
			System.out.println(booDisplayed2);
			if (booDisplayed2 == true) {
				System.out.println("Present");
				actions.reportCreatePASS("Search Button is Present", "Search Button should Present",
						"Search Button is Present", "Pass");
			} else {
				actions.reportCreateFAIL("Search Button is Present", "Search Button should Present",
						"Search Button is not Present", "Fail");
			}

			/**
			 * Verify if Column Headers 'Group Name,Status,Delete' is Displayed
			 */
			boolean booDisplayed3 = mcd.RFM_VerifyTableColumns("RFMHome.Table", "Group Name,Status,Delete");
			System.out.println(booDisplayed3);
			if (booDisplayed3 == true) {
				System.out.println("Present");
				actions.reportCreatePASS("Column Headers 'Group Name,Status,Delete' is Displayed",
						"Column Headers 'Group Name,Status,Delete' should Displayed",
						"Column Headers 'Group Name,Status,Delete' is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Column Headers 'Group Name,Status,Delete' is Displayed",
						"Column Headers 'Group Name,Status,Delete' should Displayed",
						"Column Headers 'Group Name,Status,Delete' is not Displayed", "Fail");
			}

			/** Verify if New Smart Reminder Group Button is Present */
			boolean booDisplayed4 = driver
					.findElement(By.xpath(actions.getLocator("SmartReminderGroup.NewSmartReminderGroupButton")))
					.isDisplayed();
			System.out.println(booDisplayed4);
			if (booDisplayed4 == true) {
				System.out.println("Present");
				actions.reportCreatePASS("New Smart Reminder Group Button is Present",
						"New Smart Reminder Group Button should Present", "New Smart Reminder Group Button is Present",
						"Pass");
			} else {
				actions.reportCreateFAIL("New Smart Reminder Group Button is Present",
						"New Smart Reminder Group Button should Present",
						"New Smart Reminder Group Button is not Present", "Fail");
			}

			/** Click on Table First Value */
			actions.click("SmartReminderGroup.TableFirstValue");
			actions.smartWait(100);

			/** Verify the Status DropDown List */
			String strDDValues = driver.findElement(By.xpath(actions.getLocator("UpdateSmartReminderGroup.Status")))
					.getText();
			System.out.println(strDDValues);
			if (strDDValues.contains("Active") && strDDValues.contains("Inactive")) {
				System.out.println("Present");
				actions.reportCreatePASS("Required Values are present in 'Status Dropdown'",
						"Required Values should present in 'Status Dropdown'",
						"Required Values are present in 'Status Dropdown'", "Pass");
			} else {
				actions.reportCreateFAIL("Required Values are present in 'Status Dropdown'",
						"Required Values should present in 'Status Dropdown'",
						"Required Values are not present in 'Status Dropdown'", "Fail");
			}

			/** Click on Cancel */
			actions.keyboardEnter("RFMHome.Cancel");
			actions.smartWait(100);

			/** Verify Pagination */
			mcd.verifyPagination();

			/** MNU_20485 */

			// Verify the already group name in add new smart reminder group
			// page
			actions.keyboardEnter("SmartReminderGroup.NewSmartReminderGroupButton");
			mcd.waitAndSwitch("Add New Smart Reminder Group");
			actions.clear("AddNewSmartReminderGroup.SearchTextBox");
			actions.setValue("AddNewSmartReminderGroup.SearchTextBox", strValue);
			actions.click("NewScreenSet.NextBtn");

			// Verify the on-screen message
			flag = mcd.VerifyOnscreenMessage("DimensionNameSet.DuplicateName",
					"Smart Reminder Group Name already exists; please enter a different Smart Reminder Group Name.",
					true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message",
						"Message 'Smart Reminder Group Name already exists; please enter a different Smart Reminder Group Name.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message",
						"Message 'Smart Reminder Group Name already exists; please enter a different Smart Reminder Group Name.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Keep the Name field as blank and click on "Next" button
			actions.clear("AddNewSmartReminderGroup.SearchTextBox");
			actions.click("NewScreenSet.NextBtn");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWm[0], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWm[0] + " 'is Present or not",
						ExpectWm[0] + " should be present", ExpectWm[0] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWm[0] + " 'is Present or not",
						ExpectWm[0] + " should be present", ExpectWm[0] + " is not present", "Fail");
			}

			// Searching for the max string
			String strVal2;
			strVal2 = generateString('c', 61);
			System.out.println(strVal2.length());
			actions.clear("AddNewSmartReminderGroup.SearchTextBox");
			actions.setValue("AddNewSmartReminderGroup.SearchTextBox", strVal2);
			actions.smartWait(50);
			String strSentencePrinted = driver
					.findElement(By.xpath(actions.getLocator("AddNewSmartReminderGroup.SearchTextBox")))
					.getAttribute("value");
			System.out.println(strSentencePrinted.length());
			if (strSentencePrinted.length() <= 60) {
				actions.reportCreatePASS("verify the whether search box accepected more than 150 Characters",
						"search box should be accepected more than 150 Characters",
						"search box sshould not be more than 60 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether Search box accepected 150 characters",
						"search box should be accepected more than 150 Characters ",
						"search box should be accepected more than 60 Characters", "FAIL");
			}

			// Clear the smart reminder group text box
			actions.clear("AddNewSmartReminderGroup.SearchTextBox");
			actions.smartWait(20);

			/** Check if Smart Reminder Group Name is Present */
			boolean booDisplayedd = driver
					.findElement(By.xpath(actions.getLocator("AddNewSmartReminderGroup.SearchTextBox"))).isDisplayed();
			System.out.println(booDisplayedd);
			if (booDisplayedd == true) {
				System.out.println("Present");
				actions.reportCreatePASS("Smart Reminder Group Name is Present",
						"Smart Reminder Group Name should Present", "Smart Reminder Group Name Button is Present",
						"Pass");
			} else {
				actions.reportCreateFAIL("Smart Reminder Group Name is Present",
						"Smart Reminder Group Name should Present", "Smart Reminder Group Name Button is not Present",
						"Fail");
			}

			/** Check if 'Yes' Radio Button is Present */
			String strDisplayed2 = driver.findElement(By.xpath(actions.getLocator("AddNewSmartReminderGroup.RadioYes")))
					.getAttribute("type");
			System.out.println(strDisplayed2);
			if (strDisplayed2.equals("radio")) {
				System.out.println("Present");
				actions.reportCreatePASS(
						"Copy Settings from existing Smart Reminder Group : 'Yes' Radio Button is Present",
						"Copy Settings from existing Smart Reminder Group : 'Yes' Radio Button should Present",
						"Copy Settings from existing Smart Reminder Group : 'Yes' Radio Button is Present", "Pass");
			} else {
				actions.reportCreateFAIL(
						"Copy Settings from existing Smart Reminder Group : 'Yes' Radio Button is Present",
						"Copy Settings from existing Smart Reminder Group : 'Yes' Radio Button should Present",
						"Copy Settings from existing Smart Reminder Group : 'Yes' Radio Button is not Present", "Fail");
			}

			/** Check if 'NO' Radio Button is Present */
			String strDisplayed3 = driver.findElement(By.xpath(actions.getLocator("AddNewSmartReminderGroup.RadioNo")))
					.getAttribute("type");
			System.out.println(strDisplayed3);
			if (strDisplayed3.equals("radio")) {
				System.out.println("Present");
				actions.reportCreatePASS(
						"Copy Settings from existing Smart Reminder Group : 'No' Radio Button is Present",
						"Copy Settings from existing Smart Reminder Group : 'No' Radio Button should Present",
						"Copy Settings from existing Smart Reminder Group : 'No' Radio Button is Present", "Pass");
			} else {
				actions.reportCreateFAIL(
						"Copy Settings from existing Smart Reminder Group : 'No' Radio Button is Present",
						"Copy Settings from existing Smart Reminder Group : 'No' Radio Button should Present",
						"Copy Settings from existing Smart Reminder Group : 'No' Radio Button is not Present", "Fail");
			}

			/** Check if Next Button is Present */
			boolean booDisplayeded = driver.findElement(By.xpath(actions.getLocator("AddNewSmartReminderGroup.Next")))
					.isDisplayed();
			System.out.println(booDisplayeded);
			if (booDisplayeded == true) {
				System.out.println("Present");
				actions.reportCreatePASS("Next Button is Present", "Next Button should Present",
						"Next Button is Present", "Pass");
			} else {
				actions.reportCreateFAIL("SNextave Button is Present", "Next Button should Present",
						"Next Button is not Present", "Fail");
			}

			/** Check if Cancel Button is Present */
			boolean booDisplayed5 = driver.findElement(By.xpath(actions.getLocator("AddNewSmartReminderGroup.Cancel")))
					.isDisplayed();
			System.out.println(booDisplayed5);
			if (booDisplayed5 == true) {
				System.out.println("Present");
				actions.reportCreatePASS("Cancel Button is Present", "Cancel Button should Present",
						"Cancel Button is Present", "Pass");
			} else {
				actions.reportCreateFAIL("Cancel Button is Present", "Cancel Button should Present",
						"Cancel Button is not Present", "Fail");
			}

			// Enter valid Smart Reminder Group Name.
			String strRandName = mcd.fn_GetRndName("Auto");
			actions.clear("AddNewSmartReminderGroup.SearchTextBox");
			actions.setValue("AddNewSmartReminderGroup.SearchTextBox", strRandName);
			actions.javaScriptClick("AddNewSmartReminderGroup.RadioNo");
			actions.keyboardEnter("AddNewSmartReminderGroup.Next");
			mcd.SwitchToWindow("Smart Reminder Group");

			// Change the status as "Inactive"
			actions.setValue("SmartReminderGroup.StatusDDL", "Inactive");
			actions.smartWait(50);

			/** Check if Group Name Text Field is Present */
			boolean booDisplayed6 = driver
					.findElement(By.xpath(actions.getLocator("SmartReminderGroup.GroupNameTextField"))).isDisplayed();
			System.out.println(booDisplayed6);
			if (booDisplayed6 == true) {
				System.out.println("Present");
				actions.reportCreatePASS("Group Name Text Field is Present", "Group Name Text Field should Present",
						"Group Name Text Field is Present", "Pass");
			} else {
				actions.reportCreateFAIL("Group Name Text Field is Present", "Group Name Text Field should Present",
						"Group Name Text Field is not Present", "Fail");
			}

			/** Check if Status Dropdown is Present */
			boolean booDisplayed7 = driver.findElement(By.xpath(actions.getLocator("SmartReminderGroup.StatusDDL")))
					.isDisplayed();
			System.out.println(booDisplayed7);
			if (booDisplayed7 == true) {
				System.out.println("Present");
				actions.reportCreatePASS("Status Dropdown is Present", "Status Dropdown should Present",
						"Status Dropdown is Present", "Pass");
			} else {
				actions.reportCreateFAIL("Status Dropdown is Present", "Status Dropdown should Present",
						"Status Dropdown is not Present", "Fail");
			}

			// Click on Save button and verify the alert message
			actions.click("SmartReminderGroup.SaveButton");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWm[1], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWm[1] + " 'is Present or not",
						ExpectWm[1] + " should be present", ExpectWm[1] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWm[1] + " 'is Present or not",
						ExpectWm[1] + " should be present", ExpectWm[1] + " is not present", "Fail");
			}

			// Enter the valid name string.
			String strRandName1 = mcd.fn_GetRndName("Auto");
			actions.clear("SmartReminderGroup.FirstName");
			actions.setValue("SmartReminderGroup.FirstName", strRandName1);

			// again click on save button and verify the alert message
			actions.click("SmartReminderGroup.SaveButton");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWm[2], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWm[2] + " 'is Present or not",
						ExpectWm[2] + " should be present", ExpectWm[2] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWm[2] + " 'is Present or not",
						ExpectWm[2] + " should be present", ExpectWm[2] + " is not present", "Fail");
			}

			// Enter the string in the Question field, with more than 250
			// characters.
			String strVal3;
			strVal3 = generateString('c', 251);
			System.out.println(strVal3.length());
			actions.clear("SmartReminderGroup.FirstQuestion");
			actions.setValue("SmartReminderGroup.FirstQuestion", strVal3);
			actions.smartWait(50);
			String strQuestionfield = driver
					.findElement(By.xpath(actions.getLocator("SmartReminderGroup.FirstQuestion")))
					.getAttribute("value");
			System.out.println(strQuestionfield.length());
			if (strQuestionfield.length() >= 250) {
				actions.reportCreatePASS("verify the whether search box accepected more than 250 Characters",
						"search box should be accepected more than 250 Characters",
						"Question search box should not be accepected more than 250 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether Search box accepected 250 characters",
						"search box should be accepected more than 250 Characters ",
						"Question search box should be accepected more than 250 Characters", "FAIL");
			}

			// Enter valid string in the Question field.
			String strRandName2 = mcd.fn_GetRndName("Question");
			actions.clear("SmartReminderGroup.FirstQuestion");
			actions.setValue("SmartReminderGroup.FirstQuestion", strRandName2);

			// Click on cancel button and verify alert message
			actions.click("SmartReminderGroup.CancelButton");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWm[3], true, AlertPopupButton.CANCEL_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWm[3] + " 'is Present or not",
						ExpectWm[3] + " should be present", ExpectWm[3] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWm[3] + " 'is Present or not",
						ExpectWm[3] + " should be present", ExpectWm[3] + " is not present", "Fail");
			}

			// Click on Save Button and verify the on-screen Message
			actions.click("SmartReminderGroup.SaveButton");
			flag = mcd.VerifyOnscreenMessage("MassSetAssignment.OnScreenMessage", "Your changes have been saved.",
					true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Verify Audit log Details
			boolean AuditlogCorrectValuesDisplayed1 = rfm.VerifyAuditLog_Entry(strOperation, strExpectActivity[0],
					strExpectlevel[0]);

			if (AuditlogCorrectValuesDisplayed1) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "strExpectActivity[1],Level",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation," + "ActivityValue,Level",
						"Correct values are not displayed", "Fail");
			}

			String AuditDescc = "Smart Reminder Group " + strRandName + " has been created. ";

			boolean isAuditlogCorrectValuesDisplayed1 = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID,
					strOperation, strExpectActivity[0], strExpectlevel[0], strExpectLevelDetails[0], AuditDescc);

			if (isAuditlogCorrectValuesDisplayed1) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are not displayed", "Fail");
			}

			// Navigate Smart reminder group
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			// Delete the newly created smart reminder group
			actions.clear("SmartReminderGroup.SearchTextBox");
			actions.setValue("SmartReminderGroup.SearchTextBox", strRandName);
			actions.keyboardEnter("SmartReminderGroup.SearchButton");
			actions.smartWait(100);
			actions.click("SmartReminderGroup.FirstDeleteIcon");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWm[4], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWm[4] + " 'is Present or not",
						ExpectWm[4] + " should be present", ExpectWm[4] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWm[4] + " 'is Present or not",
						ExpectWm[4] + " should be present", ExpectWm[4] + " is not present", "Fail");
			}

			// Verify the on-screen message
			flag = mcd.VerifyOnscreenMessage("SmartReminderGroup.Deleteinfo", "Delete has been successfully completed.",
					true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message",
						"Message 'Delete has been successfully completed.'", "Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message",
						"Message 'Delete has been successfully completed.'", "Expected Message is not displayed",
						"FAIL");
			}

			// Verify Audit log Details
			boolean AuditlogCorrectValuesDisplayed = rfm.VerifyAuditLog_Entry(strOperation, strExpectActivity[1],
					strExpectlevel[0]);

			if (AuditlogCorrectValuesDisplayed) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "strExpectActivity[1],Level",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation," + "ActivityValue,Level",
						"Correct values are not displayed", "Fail");
			}

			String AuditDesc = "Smart Reminder Group " + strRandName + " has been deleted.";

			boolean isAuditlogCorrectValuesDisplayed = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID,
					strOperation, strExpectActivity[1], strExpectlevel[0], strExpectLevelDetails[0], AuditDesc);

			if (isAuditlogCorrectValuesDisplayed) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are not displayed", "Fail");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
	// To generate the string of specific size

	public static String generateString(char c, Integer n) {
		StringBuilder b = new StringBuilder();
		for (Integer x = 0; x < n; x++)
			b.append(c);
		return b.toString();
	}
}
