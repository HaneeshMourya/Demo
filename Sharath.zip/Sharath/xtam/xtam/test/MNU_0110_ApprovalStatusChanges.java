package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.MasterMenuItem;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class MNU_0110_ApprovalStatusChanges {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private MasterMenuItem mmi;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private Boolean verifypopup;
	private String strStatus1, MIrange, pro_type, strmsg, strmenutype, strWM;
	// TODO: Declare test-data variables for other data-parameters

	public MNU_0110_ApprovalStatusChanges(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		mmi = new MasterMenuItem(driver, actions, uiActions, inputData, mcd, rfm);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		MIrange = mcd.GetTestData("DT_MIRANGE");
		pro_type = mcd.GetTestData("DT_MENUITEMCLASS");
		strmsg = mcd.GetTestData("DT_ERR_MSG");
		strmenutype = mcd.GetTestData("DT_MIPARAM");
		strWM = mcd.GetTestData("DT_WarningMessage");
	}

	@Test
	public void test_MNU_0110_ApprovalStatusChanges() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription("Approval Status Changes [Applicable to Layering Logic Type 1 market ]");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.waitAndSwitch("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow

			// Create New Menu Item with Menu item Class as Product.
			String[] strparam = strmenutype.split("#");
			int MenuNumber = mmi.RFM_MI_CreateMenuItem_updated(MIrange, pro_type, strmsg, strmenutype);
			String strMenuNumber = Integer.toString(MenuNumber);
			System.out.println("> > > >" + strMenuNumber);

			// Click on Search button & Select any menu item with approved
			// status
			actions.setValue("ManageMenuItems.SearchText", strMenuNumber);
			actions.click("MenuItemSets.SearchButton");
			actions.smartWait(20);
			actions.waitForPageToLoad(10000);
			actions.keyboardEnter("MasterMenuItemList.NumberLink");
			actions.smartWait(20);
			actions.waitForPageToLoad(10000);
			actions.WaitForElementPresent("ManageMenuItems.ChangeAprrovalStatusButton", 100);
			String status1 = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.prodstatus")))
					.getAttribute("value");

			// Click on change approval status button
			actions.keyboardEnter("ManageMenuItems.ChangeAprrovalStatusButton");
			if (strMarket.equals("Australasia")) {
				mcd.SwitchToWindow("Status Changes");
			} else {
				mcd.SwitchToWindow("Approval Status Changes");
			}
			actions.WaitForElementPresent("ApprovalStatusChanges.AddButton", 100);

			// Click on Trash can icon
			actions.keyboardEnter("ApprovalStatusChanges.AddButton");
			if (actions.isElementPresent("ApprovalStatusChanges.Delete")) {
				actions.click("ApprovalStatusChanges.Delete");
				verifypopup = mcd.VerifyAlertMessageDisplayed("Warning",
						"Are you sure you want to delete the selected item?", true, AlertPopupButton.OK_BUTTON);
				if (verifypopup) {
					actions.reportCreatePASS("Delete Added Approval Status", "Delete Confirmation popup should appear",
							"Delete Confirmation popup is appearing", "PASS");
				} else {
					actions.reportCreateFAIL("Delete Added Approval Status", "Delete Confirmation popup should appear",
							"Delete Confirmation popup is not appearing", "FAIL");
				}
				actions.smartWait(15);
				actions.verifyTextPresence("Delete has been successfully completed.", true);
			}

			// Click on Add approval status button & Select Current Date
			actions.keyboardEnter("ApprovalStatusChanges.AddButton");
			actions.click("ApprovalStatusChanges.CalendarIconScnd");
			mcd.Get_future_date(0, "Close", strApplicationDate);

			// Click on Apply button
			if (strMarket.equals("Australasia")) {
				actions.keyboardEnter("RestaurantMenuItemList.ChangeStatus_Save");
				Thread.sleep(5000);
				boolean booAlert = mcd.VerifyAlertMessageDisplayed("Warning Message", strWM, true,
						AlertPopupButton.OK_BUTTON);
				if (booAlert) {
					actions.reportCreatePASS("Verify Alert is Present", "Alert should be Present", "Alert is Present",
							"PASS");
				} else {
					actions.reportCreateFAIL("Verify Alert is Present", "Alert should be Present",
							"Alert is not Present", "FAIL");
				}
			} else {
				actions.click("IngredientGroups.save");
				Thread.sleep(5000);
			}

			mcd.waitAndSwitch("Run Menu Item Usage Report");
			actions.keyboardEnter("RecipeReport.CancelButton");

			// Click on Cancel button
			if (mcd.GetGlobalData("Instance").equalsIgnoreCase("AP")) {
				mcd.waitAndSwitch("$Status Changes");
				actions.smartWait(180);
			} else {
				mcd.waitAndSwitch("$Approval Status Changes");
				actions.smartWait(180);
			}
			if (strMarket.equals("Australasia")) {
				Thread.sleep(2000);
				actions.click("RestaurantMenuItemList.ChangeStatus_Cancel");
			} else {
				Thread.sleep(2000);
				actions.click("GlobalSettingsLookups.cancel");
			}
			Thread.sleep(3000);
			mcd.SwitchToWindow("@Manage Menu Items");

			// Verify the approval status should change to Not approved or not
			String status = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.prodstatus")))
					.getAttribute("value");

			if (!status.equalsIgnoreCase(status1)) {

				actions.reportCreatePASS("Verify the approval status should change to Not approved",
						"The approval status should change to Not approved",
						"The approval status is change to Not approved", "PASS");
			} else {

				actions.reportCreateFAIL("Verify the approval status should change to Not approved",
						"The approval status should change to Not approved",
						"The approval status is not change to Not approved", "FAIL");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}
