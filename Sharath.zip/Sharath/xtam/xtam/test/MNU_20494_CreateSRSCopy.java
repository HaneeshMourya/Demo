package xtam.test;

import java.util.Map;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.CSVValidations;

public class MNU_20494_CreateSRSCopy {
       private Keywords actions;
       private WebDriver driver;
       private Map input;
       private UIValidations uiActions;
       private SoftAssert softAssert = new SoftAssert();
       
       private lib_MCD mcd;
       private lib_RFM2 rfm;
       private CSVValidations csv;
       
       private String strApplicationDate;
       
       // Test-Data Variables
       private Object strURL;
       private Object strUserName;
       private Object strPassword;
       private String strMarket;
       private String strNavigateTo;
       
       private String strNavigateToReport,strNavigateToView,strNavigateToAdmin,strNavigateToHOME,strNavigateToQM;
       private String strDBName,strUserID,strOperation,strActivity,strLevel,strNodeName,strDescription,strSuccessMsg,strActivity1,strActivity2;
       boolean AuditEntry;
       String AuditDesc;
       boolean AuditDetail;

       public MNU_20494_CreateSRSCopy (WebDriver nodeDriver, Map inputData, Object or){
              driver = nodeDriver;
              input = inputData;
              actions = new Keywords(driver, or);
              uiActions = new UIValidations();
              csv = new CSVValidations();
              
              mcd = new lib_MCD (driver, actions, uiActions, inputData);
              rfm = new lib_RFM2 (driver, actions, uiActions, inputData, mcd);

              // Read input Test-Data
              strURL                     = mcd.GetTestData("DT_URL");
              strUserName   = mcd.GetTestData("DT_USER_NAME");
              strPassword   = mcd.GetTestData("DT_PASSWORD");
              strMarket            = mcd.GetTestData("DT_MARKET");
              strNavigateTo        = mcd.GetTestData("DT_NAVIGATE_TO");
              
              strDBName                  = mcd.GetTestData("DT_DB_NAME");
              strUserID                  = mcd.GetTestData("DT_USER_ID");
              strOperation         		 = mcd.GetTestData("DT_OPERATION");
              strActivity                = mcd.GetTestData("DT_ACTIVITY");
              strLevel                   = mcd.GetTestData("DT_LEVEL");
              strNodeName                = mcd.GetTestData("DT_NODE_NAME");
              
       }
       
       @Test
       public void test_MNU_20494_CreateSRSCopy() throws InterruptedException {
              String strPageTitle = "Smart Reminder Sets";                
              String strPageSubHeading = "Smart Reminder Sets";        
              
              
              try {
                     System.out.println("********************************************************************** Test execution starts");

                     actions.setTestcaseDescription(" Create a New Smart Reminder Set by copying settings from existing Smart Reminder Set and Verify the Audit Log");
                     
                     /** Launch and Login RFM */
                     System.out.println("> Launch and Login RFM");
                     rfm.LaunchAndLogin(strURL, strUserName, strPassword);
                     
                     /** Select Market (Node) */
                     System.out.println("> Select Market (Node)");
                     rfm.SelectMarket(strMarket);
              
                     /** Select Menu Option */
                     System.out.println("> Navigate to :: " + strNavigateTo);
                     actions.select_menu("RFMHome.Navigation",strNavigateTo);
                     Thread.sleep(2000);
                     actions.waitForPageToLoad(120);

                     /** Verify Page Header */
                     System.out.println("> Verify Page Heading");
                     mcd.VerifyPageTitle(strPageTitle);

                     /** Update title of new Page  */
                     mcd.SwitchToWindow("#Title");
                     
                     /** Get application time */
                     WebElement apptime = mcd.getdate();
                     strApplicationDate = apptime.getText();


                     // ------------------------------------------------------------------------ Actions specific to test-flow
                     
                     actions.WaitForElementPresent("SmartReminderSets.NewSmartReminderSet", 100);
                     
                     /** Click on New Smart Reminder Set */
                     actions.keyboardEnter("SmartReminderSets.NewSmartReminderSet");
                     
                     /** Switch Window *///--/replaced switchtowindow with waitandwatch 8/8/2016
                     mcd.waitAndSwitch("Smart Reminder Set");
                                          
                     String strRandName=mcd.fn_GetRndName("Auto");
                     
                     /** Set Value in Smart Reminder Set Name */
                     actions.setValue("NewSmartReminderSets.SmartReminderSetName", strRandName);
                                          
                     /** Click on Select Button */
                     driver.findElement(By.xpath(actions.getLocator("NewSmartReminderSets.SelectButton"))).click();
                     //--// Replaced Switchtowindow with waitandwatch
                     /** Switch Window */
                     mcd.waitAndSwitch("Select Node");
                     
                     //actions.WaitForElementPresent("SmartReminderSetsSelectNode.SelectRest", 100);
                     
                     /** Click on Restaurant */
                     actions.click("SmartReminderSetsSelectNode.SelectRest");
                     
                     //--/ Replaced SwitchToWindow with waitandwatch 8/8/2016 
                     /** Switch Window */
                     mcd.waitAndSwitch("Smart Reminder Set");
                     
                     /** Click on Copy Yes Radio Button */
                     actions.click("NewSmartReminderSets.CopyYes");
                     
                     /** Click on Select Copy Button */
                     driver.findElement(By.xpath(actions.getLocator("NewSmartReminderSets.SelectCopyButton"))).click();
                     //Replaced SwitchToWindow with waitandswitch 8/8/2016
                     /** Switch Window */
                     mcd.waitAndSwitch("Smart Reminder Set To Copy");
                     
                     /** Click on View Full List button is not available in 2.14*/
                   //  actions.keyboardEnter("RFMHome.ViewFullList");
                   //  actions.smartWait(100);
                     
                     actions.keyboardEnter("RFMHome.SearchButton");
         			mcd.smartsync(100);
                     
                     /** Click on Table First Value */
                     actions.click("SmartReminderSets.TableFirstValue");
                     
                     /** Switch Window */
                     mcd.waitAndSwitch("Smart Reminder Set");
                     
                     /** Click on Next */
                     actions.keyboardEnter("RFMHome.Next");
                                    
                     /** Switch Window */
                     mcd.waitAndSwitch("Smart Reminder Sets");
                     
                     /** Click on Cancel */
                     actions.keyboardEnter("UpdateSmartReminderSets.CancelButton");
                     actions.smartWait(100);
                     
                     /** Audit Log */
                     AuditEntry = rfm.VerifyAuditLog_Entry(strOperation, strActivity, strLevel);
                     System.out.println(AuditEntry);
                     AuditDesc = "Queue Side ["+strRandName+"] has been created.";
                     AuditDetail = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID, strOperation, strActivity, strLevel, strNodeName, AuditDesc);
                     System.out.println(AuditDetail);
                     
                     // Verify Audit Log ID in CSV file for Update operation
            		 String AuditLogIdU = rfm.GetAuditLogID(strOperation);   		
         			 mcd.GetTableCellElement("RFMHomePage.AuditLog", "Operations", strOperation, "", "", "Id", "a").sendKeys(Keys.ENTER);
         			 Thread.sleep(1000);
         			 mcd.waitAndSwitch("Manage Audit Log");		
         			 VerifyAuditLogPrint();			
         			 VerifyAuditLogCSV(AuditLogIdU, "Create");

                     // ------------------------------------------------------------------------ 
                     
                     /** Logout the application */
                     rfm.Logout();
                     

              } catch(Exception e) {
                     
                     //reporting the Fail condition
                     actions.catchException(e);
                     
              } finally {
                     actions.quitBrowser();
                     actions.verifyTestCase(this.getClass());
                     
                           
              }
       }
       
// Functions to Verify Audit log functionality for Print and Save as CSV File
       
       public void VerifyAuditLogPrint(){
    	  
			// Click print button, Print popup should be displayed
			try {
				
				WebElement printBtn = driver.findElement(By.xpath("//a[contains(text(),'Print')]"));
				actions.javaScriptClick(printBtn);
				Thread.sleep(5000);
				Alert myAlert = driver.switchTo().alert();
				Thread.sleep(2000);
				actions.reportCreatePASS("Click Print button",
						"Print Window should be displayed.",
						"Print Window is displayed.", "PASS");
				myAlert.dismiss();
			
			}
			catch (Exception error1){
				System.out.println("Print Alert is not displayed");
			}	 
			
  			
       }
       
       public void VerifyAuditLogCSV(String AuditLogId, String strOperation){

			
			// Click Save as CSV file button and verify that Audit log Id is displayed in CSV
			try {
				WebElement SaveCSVBtn = driver.findElement(By.xpath("//a[contains(text(),'Save as CSV File')]"));
				actions.javaScriptClick(SaveCSVBtn);
				Thread.sleep(3000);
				
				actions.ieDownload();
				Thread.sleep(3000);
				
				WebElement OKBtn = driver.findElement(By.xpath("//a[contains(text(),'OK')]"));
				actions.javaScriptClick(OKBtn);	
		
				String targetData = "{\"Id\":\"" + AuditLogId+"\"}";
		
				boolean csvFlag = csv.validateColumnsData("AuditLogDetail.CSV", "Id", AuditLogId, targetData, false, true);
				
				System.out.println("CSV field validation = "+csvFlag);
				
	     		if(csvFlag)
	     			actions.reportCreatePASS("Verify AuditLogDetail.CSV file for "+strOperation+" operation.", "Auditlog Id should be displayed in CSV file.", "Auditlog Id is displayed in CSV file.", "PASS");
	        	else
	     			actions.reportCreateFAIL("Verify AuditLogDetail.CSV file for "+strOperation+" operation.", "Auditlog Id should be displayed in CSV file.", "Auditlog Id is not displayed in CSV file.", "FALSE");
	     		
	     		mcd.SwitchToWindow("@RFM - Home");
			}
			catch (Exception error2){
				System.out.println("Failed to verify CSV file...");
			}
    	   
       }
}
