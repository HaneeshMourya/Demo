package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20417_ErrMsg_AddMIinDG {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String tcDescription;
	private boolean flag;
	private String dgName;
	private String miName_1;
	private String navigateToReport;
	private String dtErr;
	private String strErrMsg[];
	private String strNavigateTo_1, strMsg1, strMsg2, strMsg3, strMsg4;

	// TODO: Declare test-data variables for other data-parameters

	public MNU_20417_ErrMsg_AddMIinDG(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		tcDescription = mcd.GetTestData("DT_Description");
		dtErr = mcd.GetTestData("DT_WarningMessage");
		strNavigateTo_1 = mcd.GetTestData("DT_NAVIGATE_TO_1");
		navigateToReport = mcd.GetTestData("DT_NAVIGATE_TO_REPORTS");
		dtErr = mcd.GetTestData("DT_WarningMessage");
		strMsg1 = mcd.GetTestData("DT_MSG1");
		strMsg2 = mcd.GetTestData("DT_MSG2");
		strMsg3 = mcd.GetTestData("DT_MSG3");
		strMsg4 = mcd.GetTestData("DT_MSG4");

		// TODO: GetTestData for other data-parameters
	}

	@Test
	public void test_MNU_20418_ErrMsg_AddMIinDG() throws InterruptedException {
		String strPageTitle = mcd.GetTestData("DT_PAGE_TITLE"); // TODO: Exact
																// page-title
		String strPageSubHeading = ""; // TODO: Page Heading

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription("Verify the error message while Creation of Dimension Groups");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			// ** Select Menu Option *//
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			actions.smartWait(15);

			// ** Update title of new Page
			mcd.SwitchToWindow("#Title");

			// ** Get application time *//
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			String value = "";
			System.out.println("Start");
			strErrMsg = dtErr.split("#");
			actions.smartWait(180);

			// Verifying Search within status drop down
			Boolean resultStatus;
			Select selObj = new Select(
					driver.findElement(By.xpath(actions.getLocator("ManageDimensionGroup.STSearchWithInStatus"))));
			resultStatus = selObj.getFirstSelectedOption().getText().trim().equalsIgnoreCase("Active/Inactive");
			reporting_Pass_Fail("Verify whether Status Active/Inactive is selected by default for Status DDL",
					"Status Active/Inactive should be selected by default",
					"Status Active/Inactive is selected by default",
					"Status Active/Inactive is not selected by default", resultStatus);

			// Verifying status drop down
			Boolean resultStatus1;
			Select selObj1 = new Select(driver.findElement(By.xpath(actions.getLocator("PricingSets.StatusFilter"))));
			resultStatus1 = selObj1.getFirstSelectedOption().getText().trim().equalsIgnoreCase("Active/Inactive");
			reporting_Pass_Fail("Verify whether Status Active/Inactive is selected by default for Status DDL",
					"Status Active/Inactive should be selected by default",
					"Status Active/Inactive is selected by default",
					"Status Active/Inactive is not selected by default", resultStatus1);

			// Verifying Manage dimension groups columns

			verifyTablecolumnsPresent("UpdateTaxType.TaxBreakTable", "Status");
			verifyTablecolumnsPresent("UpdateTaxType.TaxBreakTable", "Group Name");
			verifyTablecolumnsPresent("UpdateTaxType.TaxBreakTable", "Delete");

			// Verifying Save button
			if (actions.isElementPresent("RFMQueueRoutingPopupPage.SaveButton")) {
				actions.reportCreatePASS("Verifying Save button ", "Save button should display",
						"Save button is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Save button ", "Save button should display",
						"Save button is not displayed", "FAIL");
			}

			// Verifying Cancel button
			if (actions.isElementPresent("RFMQueueManagementPage.CancelButton")) {
				actions.reportCreatePASS("Verifying Cancel button ", "Cancel button should display",
						"Cancel button is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Cancel button ", "Cancel button should display",
						"Cancel button is not displayed", "FAIL");
			}

			// Click on search
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			actions.smartWait(180);
			String dim_Group_Name = driver.findElement(By.xpath(actions.getLocator("ProductionRouting.TableFIrstData")))
					.getText();

			// Click on New dimension group button
			actions.keyboardEnter("DimensionGroup.NewDimensionGroupButton");
			mcd.SwitchToWindow("#Title");

			// Verifying Status drop down
			Boolean resultStatus2;
			Select selObj2 = new Select(driver.findElement(By.xpath(actions.getLocator("DimensionGroups.StatusDDL"))));
			resultStatus2 = selObj2.getFirstSelectedOption().getText().trim().equalsIgnoreCase("Active");
			reporting_Pass_Fail("Verify whether Status Active is selected by default for Status DDL",
					"Status Active should be selected by default", "Status Active is selected by default",
					"Status Active is not selected by default", resultStatus2);

			// Verifying column name of dimension group
			verifyTablecolumnsPresent("FieldPermissions.Table", "Menu Item Code");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Menu Item Name");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Menu Item Status");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Dimension");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Delete");

			// Without entering dimension name click on save button
			actions.clear("DimensionGroup.DimensionGroupName");
			actions.click("DimensionGroup.SaveButton");
			boolean flag = mcd.VerifyAlertMessageDisplayed("Warning", strMsg1, true, AlertPopupButton.OK_BUTTON);
			if (flag) {
				actions.reportCreatePASS("Verifying Alert message", "Alert message should display",
						"Alert message is displayed as expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Alert message", "Alert message should display",
						"Alert message is not displayed as expected", "FAIL");
			}

			// Entering existing dimension name group name and click on Save
			// button
			actions.setValue("DimensionGroup.DimensionGroupName", dim_Group_Name);
			actions.click("DimensionGroup.SaveButton");
			actions.smartWait(180);
			actions.verifyTextPresence(strMsg2, true);

			// Click on Cancel
			actions.keyboardEnter("RFMQueueManagementPage.CancelButton");
			mcd.VerifyAlertMessageDisplayed("Warning", strMsg3, true, AlertPopupButton.OK_BUTTON);
			mcd.SwitchToWindow("#Title");

			// Click on new dimension group button
			actions.keyboardEnter("DimensionGroup.NewDimensionGroupButton");
			actions.smartWait(180);

			// Enter name in dimension name in dimension name text box
			actions.setValue("DimensionGroup.DimensionGroupName", "DIMENSION");

			// Click on Cancel button
			actions.keyboardEnter("RFMQueueManagementPage.CancelButton");
			boolean flag1 = mcd.VerifyAlertMessageDisplayed("Warning", strMsg3, true, AlertPopupButton.CANCEL_BUTTON);
			if (flag1) {
				actions.reportCreatePASS("Verifying Alert message", "Alert message should display",
						"Alert message is displayed as expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Alert message", "Alert message should display",
						"Alert message is not displayed as expected", "FAIL");
			}

			// Click on Cancel button again
			actions.keyboardEnter("RFMQueueManagementPage.CancelButton");
			boolean flag2 = mcd.VerifyAlertMessageDisplayed("Warning", strMsg3, true, AlertPopupButton.OK_BUTTON);
			if (flag2) {
				actions.reportCreatePASS("Verifying Alert message", "Alert message should display",
						"Alert message is displayed as expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Alert message", "Alert message should display",
						"Alert message is not displayed as expected", "FAIL");
			}

			mcd.SwitchToWindow("#Title");

			// Click on new dimension group button
			actions.keyboardEnter("DimensionGroup.NewDimensionGroupButton");
			actions.smartWait(180);
			mcd.SwitchToWindow("#Title");

			// Selecting status to inactive
			actions.setValue("DimensionGroups.StatusDDL", "Inactive");

			// Click on Cancel button
			actions.keyboardEnter("RFMQueueManagementPage.CancelButton");
			boolean flag3 = mcd.VerifyAlertMessageDisplayed("Warning", strMsg3, true, AlertPopupButton.CANCEL_BUTTON);
			if (flag3) {
				actions.reportCreatePASS("Verifying Alert message", "Alert message should display",
						"Alert message is displayed as expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Alert message", "Alert message should display",
						"Alert message is not displayed as expected", "FAIL");
			}

			// Click on Cancel button again
			actions.keyboardEnter("RFMQueueManagementPage.CancelButton");
			boolean flag4 = mcd.VerifyAlertMessageDisplayed("Warning", strMsg3, true, AlertPopupButton.OK_BUTTON);
			if (flag4) {
				actions.reportCreatePASS("Verifying Alert message", "Alert message should display",
						"Alert message is displayed as expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Alert message", "Alert message should display",
						"Alert message is not displayed as expected", "FAIL");
			}
			mcd.SwitchToWindow("#Title");

			// Click on new dimension group button
			actions.keyboardEnter("DimensionGroup.NewDimensionGroupButton");
			actions.smartWait(180);
			mcd.SwitchToWindow("#Title");
			actions.setValue("DimensionGroup.DimensionGroupName", "DIMENSION");

			// Navigate to HOME TAB
			actions.keyboardEnter("SubstitutionGroups.Home");

			// Verifying pop up message
			boolean flag5 = mcd.VerifyAlertMessageDisplayed("Warning", strMsg3, true, AlertPopupButton.CANCEL_BUTTON);
			if (flag5) {
				actions.reportCreatePASS("Verifying Alert message", "Alert message should display",
						"Alert message is displayed as expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Alert message", "Alert message should display",
						"Alert message is not displayed as expected", "FAIL");
			}

			// Navigate to HOME TAB
			actions.keyboardEnter("SubstitutionGroups.Home");
			boolean flag6 = mcd.VerifyAlertMessageDisplayed("Warning", strMsg3, true, AlertPopupButton.OK_BUTTON);
			if (flag6) {
				actions.reportCreatePASS("Verifying Alert message", "Alert message should display",
						"Alert message is displayed as expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Alert message", "Alert message should display",
						"Alert message is not displayed as expected", "FAIL");
			}

			mcd.VerifyPageTitle("RFM - Home");

			// Navigate to dimension group
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			actions.smartWait(15);

			// Creating new dimension group
			actions.click("DimensionGroup.NewDimensionGroupButton");
			actions.smartWait(15);

			do {

				dgName = mcd.fn_GetRndName("Auto_DG");
				actions.clear("DimensionGroup.DimensionGroupName");
				actions.setValue("DimensionGroup.DimensionGroupName", dgName);
				actions.click("DimensionGroup.SaveButton");

				flag = mcd.VerifyOnscreenMessage("DimensionGroup.InfoMessage", "Your changes have been saved.", true);

			} while (!(flag));

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}
			actions.smartWait(180);
			actions.keyboardEnter("DimensionGroup.CancelButton");
			actions.smartWait(180);
			mcd.SwitchToWindow("#Title");

			// Searching for existing dimension group and click on dimension
			// group
			actions.setValue("PermissionReportbyRole.SearchTextbox", dgName);
			actions.click("ManageDimensionGroup.SearchButton");
			actions.smartWait(180);
			WebElement Element = mcd.GetTableCellElement("ManageDimensionGroup.Table", 1, "Group Name", "a/pre");
			actions.click(Element);
			mcd.SwitchToWindow("#Title");

			// Click on Add menu item button and click on Cancel button
			actions.click("DimensionGroup.AddMenuItemButton");
			mcd.SwitchToWindow("Common Menu Item Selector");
			actions.smartWait(180);
			actions.keyboardEnter("DimensionGroup.CancelButton");
			mcd.SwitchToWindow("@Dimension Groups");

			// Click on Add menu item button and add menu items for dimension
			// group and click on continue button
			actions.click("DimensionGroup.AddMenuItemButton");
			mcd.SwitchToWindow("Common Menu Item Selector");
			actions.smartWait(180);
			actions.javaScriptClick("SetAssignmentReport.SearchButton");
			actions.smartWait(180);
			Element = mcd.GetTableCellElement("CommonMenuItemSelector.Table", 1, "Add", "input");
			Element.sendKeys(Keys.SPACE);
			miName_1 = mcd.GetTableCellValue("CommonMenuItemSelector.Table", 1, "Name", "", "");
			actions.click("CommonMenuItemSelector.ContinueButton");
			mcd.SwitchToWindow("Dimension Groups");

			// Click on Apply button without selecting dimension form drop down
			actions.click("DimensionGroups.ApplyButton");
			// strMsg4
			flag = mcd.VerifyAlertMessageDisplayed("Warning Message", strMsg4, true, AlertPopupButton.OK_BUTTON);
			if (flag) {
				actions.reportCreatePASS("Verifying Alert message", "Alert message should display",
						"Alert message is displayed as expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Alert message", "Alert message should display",
						"Alert message is not displayed as expected", "FAIL");
			}

			// Click on Cancel button and verify pop up message
			actions.keyboardEnter("RFMQueueManagementPage.CancelButton");
			boolean flag7 = mcd.VerifyAlertMessageDisplayed("Warning", strMsg3, true, AlertPopupButton.CANCEL_BUTTON);
			if (flag7) {
				actions.reportCreatePASS("Verifying Alert message", "Alert message should display",
						"Alert message is displayed as expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Alert message", "Alert message should display",
						"Alert message is not displayed as expected", "FAIL");
			}

			// Navigate to HOME TAB

			actions.keyboardEnter("SubstitutionGroups.Home");

			// Verifying pop up message
			boolean flag8 = mcd.VerifyAlertMessageDisplayed("Warning", strMsg3, true, AlertPopupButton.CANCEL_BUTTON);
			if (flag8) {
				actions.reportCreatePASS("Verifying Alert message", "Alert message should display",
						"Alert message is displayed as expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Alert message", "Alert message should display",
						"Alert message is not displayed as expected", "FAIL");
			}

			// Navigate to HOME TAB
			actions.keyboardEnter("SubstitutionGroups.Home");

			boolean flag9 = mcd.VerifyAlertMessageDisplayed("Warning", strMsg3, true, AlertPopupButton.OK_BUTTON);
			if (flag9) {
				actions.reportCreatePASS("Verifying Alert message", "Alert message should display",
						"Alert message is displayed as expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Alert message", "Alert message should display",
						"Alert message is not displayed as expected", "FAIL");
			}

			mcd.VerifyPageTitle("RFM - Home");

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	public void alertMessageCancel() {
		flag = mcd.VerifyAlertMessageDisplayed("Warning Message", strErrMsg[1], true, AlertPopupButton.CANCEL_BUTTON);

		if (flag) {
			actions.reportCreatePASS("Verify the onscreen Message",
					"Message '" + strErrMsg[1] + "' should be displayed", "Expected Message is displayed.", "PASS");
		} else {
			actions.reportCreateFAIL("Verify the onscreen Message",
					"Message '" + strErrMsg[1] + "' should be displayed", "Expected Message is not displayed.", "FAIL");
		}

	}

	public void alertMessageOK() {
		flag = mcd.VerifyAlertMessageDisplayed("Warning Message", strErrMsg[1], true, AlertPopupButton.OK_BUTTON);

		if (flag) {
			actions.reportCreatePASS("Verify the onscreen Message",
					"Message '" + strErrMsg[1] + "' should be displayed", "Expected Message is displayed.", "PASS");
		} else {
			actions.reportCreateFAIL("Verify the onscreen Message",
					"Message '" + strErrMsg[1] + "' should be displayed", "Expected Message is not displayed.", "FAIL");
		}
	}

	public String dimensionGroupName() {

		dgName = mcd.fn_GetRndName("Auto_DG");
		actions.clear("DimensionGroup.DimensionGroupName");
		actions.setValue("DimensionGroup.DimensionGroupName", dgName);
		return dgName;

	}

	/////// METHOD WE HAVE TO USE FOR THIS
	public void reporting_Pass_Fail(String Desc, String ExpRes, String ActRes_Pass, String ActRes_Fail,
			Boolean status) {
		if (status) {
			actions.reportCreatePASS(Desc, ExpRes, ActRes_Pass, "PASS");
		}

		if (!status) {
			actions.reportCreateFAIL(Desc, ExpRes, ActRes_Fail, "FAIL");
		}
	}

	// VERIFYING TABLE COLUMS CODE
	public void verifyTablecolumnsPresent(String tableLocator, String colName) {

		boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

		if (iscolPresent) {
			actions.reportCreatePASS("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is present in table", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is NOT present in table",
					"Fail");
		}
	}

}