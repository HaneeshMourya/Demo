package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20490_ViewFullList {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strstatus,Exstatus[],strregion,strcoop;
	private String strcountry;

	public MNU_20490_ViewFullList(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strstatus = mcd.GetTestData("DT_Status");
		strcountry = mcd.GetTestData("DT_Country");
		strregion  = mcd.GetTestData("DT_Region");
		strcoop  = mcd.GetTestData("DT_Coop");
		Exstatus = strstatus.split("#");
	}

	@Test
	public void test_MNU_20490_ViewFullList() throws InterruptedException {
		String strPageTitle = "Smart Reminder Sets";
		String strPageSubHeading = "Smart Reminder Sets";

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"Verify that the search functionality for flavor set with Filter Functionality");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Verify Page Header */
			System.out.println("> Verify Page Heading");
			mcd.VerifyPageTitle(strPageTitle);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Verifying 'Search Full List By Smart Reminder Set Name ' Text Box
			Boolean smartRSETTextbox;
			smartRSETTextbox = actions.isElementPresent("SmartReminderSet.SearchTextField");
			reporting_Pass_Fail("Verify whether Search Full List By Smart Reminder Set Name  Textbox is present",
					"Search Full List By Smart Reminder Set Name  Textbox should be present",
					"Search Full List By Smart Reminder Set Name  Textbox is present",
					"Search Full List By Smart Reminder Set Name  Textbox is not present", smartRSETTextbox);

			// Verifying presence of 'Search' Button
			Boolean Nextbutton;
			Nextbutton = actions.isElementPresent("SmartReminderSet.SearchButton");
			reporting_Pass_Fail("Verify whether 'Search' Button is present", "'Search' Button should be present",
					"'Search' Button is present", "'Search' Button is not present", Nextbutton);

			// Verifying presence of 'New Smart Reminder Set' Button
			Boolean newsmartRSETbutton;
			newsmartRSETbutton = actions.isElementPresent("SmartReminderSets.NewSmartReminderSet");
			reporting_Pass_Fail("Verify whether 'New Smart Reminder Set' Button is present", "'New Smart Reminder Set' Button should be present",
					"'New Smart Reminder Set' Button is present", "'New Smart Reminder Set' Button is not present", newsmartRSETbutton);

			// Verifying 'Search within Status' Filter
			Boolean resultStatus;
			Select selObj = new Select(
					driver.findElement(By.xpath(actions.getLocator("SmartReminderSets.SearchByStatus"))));
			resultStatus = selObj.getFirstSelectedOption().getText().trim().equalsIgnoreCase("Active/Inactive");
			reporting_Pass_Fail(
					"Verify whether Search Within Status Active/Inactive is selected by default for Status DDL",
					"Search Within Status Active/Inactive should be selected by default",
					"Search Within Status Active/Inactive is selected by default",
					"Search Within Status Active/Inactive is not selected by default", resultStatus);

			// Verify status is disabled
			if (!mcd.fn_VerifyWebelementEnableDisable("SmartReminderSets.StatusFilter")) {
				actions.reportCreatePASS("Verify  Status filter is dispalyed as Disabled ",
						" Status filter should be dispalyed", " Status filter is dispalyed as Disabled", "Pass");
			} else {
				actions.reportCreateFAIL("Verify  Status filter is dispalyed as Disabled ",
						" Status filter should be dispalyed", " Status filter is dispalyed as Enabled", "Fail");
			}

			// verifying the presence of column headers i.e. name, node, status,
			// delete
			boolean booDisplayed5 = mcd.RFM_VerifyTableColumns("RFMHome.Table", "Name,Node,Status,Delete");
			System.out.println(booDisplayed5);
			if (booDisplayed5 == true) {
				System.out.println("Present");
				actions.reportCreatePASS("Column Headers 'Name,Node,Status,Delete' is Displayed",
						"Column Headers 'Name,Node,Status,Delete' should Displayed",
						"Column Headers 'Name,Node,Status,Delete' is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Column Headers 'Name,Node,Status,Delete' is Displayed",
						"Column Headers 'Name,Node,Status,Delete' should Displayed",
						"Column Headers 'Name,Node,Status,Delete' is not Displayed", "Fail");
			}
			// verify the Search Functionality
			SearchFunctionality("SmartReminderSets.Table", "Smart Reminder Sets");

			// Filter the Search Result by Active Records
			actions.clear("SmartReminderSet.SearchTextField");
			actions.keyboardEnter("SmartReminderSets.SearchBtn");
			actions.smartWait(20);
			actions.setValue("SmartReminderSets.StatusFilter", Exstatus[0]);
			actions.smartWait(20);
			if (mcd.GetTableRowCount("MenuItemGroup.Datatable") > 0) {

				String record_name = mcd.GetTableCellValue("MenuItemGroup.Datatable", 1, "Status", "", "");
				verify_search_result("contains", record_name, Exstatus[0]);
			}

			// Filter the Search Result by Inactive Records
			actions.clear("SmartReminderSet.SearchTextField");
			actions.keyboardEnter("SmartReminderSets.SearchBtn");
			actions.smartWait(20);
			actions.setValue("SmartReminderSets.StatusFilter", Exstatus[1]);
			actions.smartWait(20);
			if (mcd.GetTableRowCount("MenuItemGroup.Datatable") > 0) {

				String record_name = mcd.GetTableCellValue("MenuItemGroup.Datatable", 1, "Status", "", "");
				verify_search_result("contains", record_name, Exstatus[1]);
			}


			// Select country dropdown value and verify the result grid
			if(input.get("_rowId").toString().toUpperCase().contains("US"))
			{
				actions.clear("SmartReminderSet.SearchTextField");
				actions.keyboardEnter("SmartReminderSets.SearchBtn");
				actions.smartWait(20);
				if (mcd.GetTableRowCount("MenuItemGroup.Datatable") > 0) {

					String record_name = mcd.GetTableCellValue("MenuItemGroup.Datatable", 1, "Node", "", "");
					verify_search_result("contains", record_name, strcountry);
				}
				actions.clear("SmartReminderSet.SearchTextField");
				actions.keyboardEnter("SmartReminderSets.SearchBtn");
				actions.smartWait(20);
				actions.setValue("RestaurantProfile.CountryFilter", strregion);
				actions.smartWait(10);
				actions.keyboardEnter("SmartReminderSets.FilterButton");
				actions.smartWait(10);
				
			}
			else if(input.get("_rowId").toString().toUpperCase().contains("AP"))
			{
			actions.clear("SmartReminderSet.SearchTextField");
			actions.keyboardEnter("SmartReminderSets.SearchBtn");
			actions.smartWait(20);
			actions.setValue("SmartReminderSets.Filter", strcountry);
			actions.smartWait(20);
			actions.keyboardEnter("SmartReminderSets.FilterButton");
			actions.smartWait(10);
			if (mcd.GetTableRowCount("MenuItemGroup.Datatable") > 0) {

				String record_name = mcd.GetTableCellValue("MenuItemGroup.Datatable", 1, "Node", "", "");
				verify_search_result("contains", record_name, strcountry);
			}
			}
			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	public void SearchFunctionality(String eElemtTableRowCount, String functionalityName) throws InterruptedException {

		/*
		 * WebElement viewFullListBtn = driver.findElement(By.xpath(
		 * "//*[(normalize-space(text())='View Full List')]"));
		 * actions.keyboardEnter(viewFullListBtn);
		 */

		actions.keyboardEnter("SmartReminderSets.SearchBtn");
		actions.smartWait(20);

		// Verify that Search button functionality
		int count_NumberofRows = driver.findElements(By.xpath(actions.getLocator(eElemtTableRowCount))).size();
		if (count_NumberofRows > 0) {
			actions.reportCreatePASS("Verify the Search " + functionalityName + " by View Full List",
					"All Active & Inactive " + functionalityName
							+ "  available in the Market are displayed in the grid ",
					"Total " + count_NumberofRows + functionalityName
							+ "  available in the Market are displayed in the grid ",
					"Pass");
		} else {
			actions.reportCreatePASS("Verify the Search " + functionalityName + " by View Full List",
					"All Active & Inactive " + functionalityName
							+ "  available in the Market are displayed in the grid ",
					"Total  '0 ' " + functionalityName + "  available in the Market are displayed in the grid ",
					"Fail");
		}

	}

	// Function for Reporting Pass/Fail
	public void reporting_Pass_Fail(String Desc, String ExpRes, String ActRes_Pass, String ActRes_Fail,
			Boolean status) {
		if (status) {
			actions.reportCreatePASS(Desc, ExpRes, ActRes_Pass, "PASS");
		}

		if (!status) {
			actions.reportCreateFAIL(Desc, ExpRes, ActRes_Fail, "FAIL");
		}
	}

	public void verify_search_result(String search_type, String record_name, String srchtxt) {
		switch (search_type) {

		case "max":
		case "invalid":

			break;
		case "null":

			break;
		case "contains":
			if (record_name.contains(srchtxt)) {
				actions.reportCreatePASS("Valdating the Search result with Special Character",
						"Should display Correct result", "Correct result is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Valdating the Search result", "Should display Correct result",
						"Correct results are not displayed", "Fail");
			}
			break;
		case "equal":
			if (record_name.equals(srchtxt)) {
				actions.reportCreatePASS("Valdating the Search result", "Should display Correct result" + srchtxt,
						"Correct result is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Valdating the Search result for" + srchtxt,
						"Should display Correct result for " + srchtxt, "Correct results are not displayed", "Fail");
			}
			break;
		case "filter":
			if (record_name.contains(srchtxt)) {

				actions.reportCreatePASS("Valdating the Search result with status filter",
						"Should display Correct result", "Correct results are displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Valdating the Search result with status filter",
						"Should display Correct result", "Correct results are not displayed", "Fail");
			}
			break;
		}

	}

}
