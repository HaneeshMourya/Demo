package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.MasterMenuItem;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0223_PRO_MI_Validation {
	private Keywords		actions;
	private WebDriver		driver;
	private Map				input;
	private UIValidations	uiActions;
	private SoftAssert		softAssert	= new SoftAssert();

	private lib_MCD		mcd;
	private lib_RFM2	rfm;
	private MasterMenuItem mmi;

	// Test-Data Variables
	private Object	strURL;
	private Object	strUserName;
	private Object	strPassword;
	private String	strMarket;
	private String	strNavigateTo, strpagetitle, mainwindow, strexp;
	private int		Col_cnt;
	private String strerrmsg,strParam,strrange;
	// TODO: Declare test-data variables for other data-parameters

	public MNU_0223_PRO_MI_Validation(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		mmi = new MasterMenuItem(driver, actions, uiActions, inputData, mcd, rfm);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strpagetitle = mcd.GetTestData("DT_PageTitle");
		strexp = mcd.GetTestData("DT_Expmsg");
		// TODO: GetTestData for other data-parameters
		strerrmsg = mcd.GetTestData("DT_ERMSG");
		strParam = mcd.GetTestData("DT_PARAM");
		strrange = mcd.GetTestData("DT_RANGE");
		
	}

	@Test
	public void test_MNU_0223_PRO_MI_Validation() throws InterruptedException {

		
		try {
			System.out.println("************************** Test execution starts");

			/** setting the test case description */
			actions.setTestcaseDescription("Verify Promotion Range tab is enabled at Master Menu Item List if Promotional Menu Item flag or Promotional Choice flag is 'YES' for a Menu Item");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
			actions.waitForPageToLoad(120);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(4000);
			actions.waitForPageToLoad(120);
			actions.smartWait(60);

			//Verifying menu items in master menu item list
			actions.click("MasterMenuItemList.Searchbtn");
			actions.smartWait(180);
			int master_table_rc=mcd.GetTableRowCount("FieldPermissions.Table");
			if(master_table_rc>0)
			{
				actions.reportCreatePASS("Verifying All menu items", "All menu items should display", "All menu items are displayed", "PASS");
			}else{
				actions.reportCreateFAIL("Verifying All menu items", "All menu items should display", "All menu items are  NOT displayed", "FAIL");
			}
				
			/** creating the menu item with Product class & choice class */
		   int MI_Choice= mmi.RFM_MI_CreateMenuItem_updated(strrange, "CHOICE", strerrmsg, strParam);
			int MI_Pro = mmi.RFM_MI_CreateMenuItem_updated(strrange, "PRODUCT", strerrmsg, strParam);
			
			
					
			//Searching Product menu item
			actions.setValue("MasterMenuItemList.srch_text", MI_Pro);
			actions.click("MasterMenuItemList.Searchbtn");
			actions.smartWait(180);

			//Selecting Product menu item
			WebElement rec_sel = mcd.GetTableCellElement("MasterMenuItemList.datatable", 1, "Number", "a");
			actions.click(rec_sel);
			actions.smartWait(180);

			//Checking for the Promotion choice settings components
			if (ISAttribtuePresent("ManageMenuItem.ProCh_Yes", "disabled") && ISAttribtuePresent("ManageMenuItem.ProCh_No", "disabled")) {

				actions.reportCreatePASS("Promotional Choice Settings are disabled as Expected", "Promotional Choice Settings are disabled as Expected", "Promotional Choice Settings are disabled as Expected", "PASS");
			} else {

				actions.reportCreateFAIL("Promotional Choice Settings are not disabled as Expected", "Promotional Choice Settings are not disabled as Expected", "Promotional Choice Settings are not disabled as Expected", "FAIL");
			}

			/// Verify promotion choice is set to No by default
			if (ISAttribtuePresent("ManageMenuItem.ProCh_No", "checked"))    
			{
				WebElement elem = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.ProCh_No")));
				String value = elem.getAttribute("checked");
				if (value.equals("true")) {
					actions.reportCreatePASS("By Default the Promotional Choice setting is set to NO ", "By Default the Promotional Choice setting is set to NO ", "By Default the Promotional Choice setting is set to NO ", "PASS");
				}

			} else {
				actions.reportCreateFAIL("Fail:Promotional Choice Setting is not displayed as expected.", "Promotional Choice Setting is not displayed as expected.", "Fail:Promotional Choice Setting is not displayed as expected.", "FAIL");
			}

			// verifying Promotional Menu item flags
			if (!ISAttribtuePresent("ManageMenuItem.ProMI_Yes", "disabled") && !ISAttribtuePresent("ManageMenuItem.ProMI_No", "disabled")) {
				actions.reportCreatePASS("Promotional Menu Item Settings are Enabled as Expected", "Promotional Menu Item Settings are Enabled as Expected", "Promotional Menu Item Settings are Enabled as Expected", "PASS");
			} else {
				actions.reportCreateFAIL("Fail:Promotional Menu Item Settings are disabled", "Fail:Promotional Menu Item Settings are disabled", "Fail:Promotional Menu Item Settings are disabled", "FAIL");
			}

			
			//Changing Promotional menu item flag to yes and click on save button
			actions.click("ManageMenuItem.ProMI_Yes");
			actions.click("ManageMenuItem.ApplySavebtn");
			mcd.SwitchToWindow("Apply Changes Details");
			actions.click("ApplyChangesDetails.save");
			mcd.SwitchToWindow("@Manage Menu Items");
			actions.smartWait(180);

			// checking for the attribute present or not for promotion range tab
			if (!ISAttribtuePresent("ManageMenuItem.PromRngtab", "disabled")) {
				actions.reportCreatePASS("Promotion range status", "Promotion range is enabled as Expected", "Promotion range is enabled as Expected", "PASS");
			} else {
				actions.reportCreateFAIL("Promotion range status", "Promotion range is enabled as Expected", "Promotion range is not enabled as Expected", "Fail");
			}

				
			// reverting back the changes made
			actions.keyboardEnter(driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.ProMI_No"))));
			
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("window.scrollBy(0,250)", "");
			Thread.sleep(1000);
			actions.click("ManageMenuItem.ProMI_No");


			//verifying the laert present or not
			if (mcd.VerifyAlertMessageDisplayed("Confirming", strexp, true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Verify the alert message", strexp + " should be displayed", strexp + " is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify the alert message", strexp + " should be displayed", strexp + " is not displayed", "Fail");
			}
			
			actions.click("ManageMenuItem.ApplySavebtn");
			actions.smartWait(180);

			// navigating to the master menu item list page
			actions.click("ManageMenuItem.Cancelbtn1");
			actions.smartWait(180);

			//Searching for Choice menu item
			actions.clear("MasterMenuItemList.srch_text");
			actions.setValue("MasterMenuItemList.srch_text",MI_Choice);
			actions.click("MasterMenuItemList.Searchbtn");
			actions.smartWait(180);

			//Click on menu item
			rec_sel = mcd.GetTableCellElement("MasterMenuItemList.datatable", 1,"Number", "a");
			actions.click(rec_sel);
			actions.smartWait(180);

			//Checking for Promotional menu item flags
			if (ISAttribtuePresent("ManageMenuItem.ProMI_Yes", "disabled") && ISAttribtuePresent("ManageMenuItem.ProMI_No", "disabled")) {
				actions.reportCreatePASS("Verify Promotional Menu Item Settings are disabled or not", "Promotional Menu Item Settings should be disabled", "Promotional Menu Item Settings are disabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Promotional Menu Item Settings are disabled or not", "Promotional Menu Item Settings should be disabled", "Promotional Menu Item Settings are not disabled", "Fail");
			}

			//Verify the by default selection of the promotion choice is set to NO
			if (ISAttribtuePresent("ManageMenuItem.ProMI_No", "checked"))   
			{
				WebElement elem = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.ProMI_No")));
				String value = elem.getAttribute("checked");
				if (value.equals("true")) {
					Reporter.log("By Default the Promotional Menu Item setting is set to NO ");
					actions.reportCreatePASS("Validating Promotional Menu Item setting is set to NO by default", "Promotional Menu Item setting should set to NO by default", "Promotional Menu Item setting is set to NO", "PASS");
				}

			} else {
				actions.reportCreateFAIL("Validating Promotional Menu Item setting is set to NO by default", "Promotional Menu Item setting should set to NO by default", "Promotional Menu Item setting is not set to NO", "Fail");
			}

			
			
			//Verifying the Promotional Choice Yes radio button status
			if (!ISAttribtuePresent("ManageMenuItem.ProCh_Yes", "disabled") && !ISAttribtuePresent("ManageMenuItem.ProCh_No", "disabled")) {
				actions.reportCreatePASS("Validating Promotional Choice Settings status", "Promotional Choice Settings should not disabled", "Promotional Choice Settings are not disabled", "Pass");
			} else {

				actions.reportCreateFAIL("Validating Promotional Choice Settings status", "Promotional Choice Settings should not disabled", "Promotional Choice Settings are disabled", "Fail");
			}

			//** Verify the by default selection of the promotion choice is set to NO 
			if (ISAttribtuePresent("ManageMenuItem.ProCh_No", "checked"))   
			{
				WebElement elem = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.ProCh_No")));
				String value = elem.getAttribute("checked");
				if (value.equals("true")) {

					actions.reportCreatePASS("Validating Promotional Choice No radio button status", "Promotional Choice No radio button should not disabled", "Promotional Choice No radio button are not disabled", "Pass");
				} else {

					actions.reportCreateFAIL("Validating Promotional Choice No radio button status", "Promotional Choice No radio button should not disabled", "Promotional Choice No radio button are disabled", "Fail");
				}
			}


			//Click on promotional choice flag to yes radio button and click on save button
			actions.click("ManageMenuItem.ProCh_Yes");
			actions.click("ManageMenuItem.ApplySavebtn");
			mcd.SwitchToWindow("Apply Changes Details");
			actions.click("ApplyChangesDetails.save");
			mcd.SwitchToWindow("@Manage Menu Item");
			actions.smartWait(180);
			
			//Verifying  Promotion Range tab should be enabled
			if (!ISAttribtuePresent("ManageMenuItem.PromRngtab", "disabled")) {
				actions.reportCreatePASS("Promotion range is enabled as Expected",
						"Promotion range is enabled as Expected",
						"Promotion range is enabled as Expected", "PASS");
			} else {
				actions.reportCreateFAIL("Promotion range is not displayed as Expected",
						"Promotion range is not displayed as Expected", 
						"Promotion range is not displayed as Expected", "FAIL");
			}
			
			
			//Reverting back the changes made
			jse = (JavascriptExecutor)driver;
			jse.executeScript("window.scrollBy(0,250)", "");
			Thread.sleep(1000);
			actions.click("ManageMenuItem.ProCh_No");
			
			
			
			
			if(mcd.VerifyAlertMessageDisplayed("Confirming", strexp, true, AlertPopupButton.OK_BUTTON)){
				actions.reportCreatePASS("Verify the alert message",
						                   strexp+" should be displayed",
						                   strexp+" is displayed", "Pass");
			}else{
				actions.reportCreateFAIL("Verify the alert message",
		                   strexp+" should be displayed",
		                   strexp+" is not displayed", "Fail");
			}
			
			actions.click("ManageMenuItem.ApplySavebtn");
			actions.smartWait(30);
			
			//**clicking on the cancel button*//*
			actions.click("ManageMenuItem.Cancelbtn");
			actions.waitForPageToLoad(120);
			actions.smartWait(120);
			

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	public boolean ISAttribtuePresent(String sElement, String attribute) {
		Boolean result = false;
		try {
			WebElement element = driver.findElement(By.xpath(actions.getLocator(sElement)));
			String value = element.getAttribute(attribute);
			if (value != null) {
				result = true;
			}
		} catch (Exception e) {

			// Reporter.log(e.getMessage());
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());

		}

		return result;
	}

}
