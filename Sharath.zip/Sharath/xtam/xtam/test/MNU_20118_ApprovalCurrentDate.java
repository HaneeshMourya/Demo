package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20118_ApprovalCurrentDate {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private boolean flag;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strWM1;
	private String strDate, status, status1, strWM;
	// TODO: Declare test-data variables for other data-parameters

	public MNU_20118_ApprovalCurrentDate(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strWM1 = mcd.GetTestData("WarningMessage1");
		strWM = mcd.GetTestData("DT_WarningMessage");
		strDate = mcd.GetTestData("DT_DATE_FORMAT");
		status = mcd.GetTestData("DT_STATUS");
		status1 = mcd.GetTestData("DT_Status");

		// TODO: GetTestData for other data-parameters
	}

	@Test
	public void test_MNU_20118_ApprovalCurrentDate() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(
					"Approval Status Changes � Form Actions and Approval Status Changes for Current date");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow

			// Click on search button & Select Any Menu Item which is Not
			// Approved
			actions.keyboardEnter("MasterMenuItemList.SearchButton");
			actions.smartWait(100);
			if (strMarket.equals("Australasia")) {
				actions.WaitForElementPresent("SmartReminderSets.StatusFilter", 180);
				actions.setValue("SmartReminderSets.StatusFilter", status);
			} else {
				actions.WaitForElementPresent("RestMIList.MIApprovalDrpdwn", 180);
				actions.setValue("RestMIList.MIApprovalDrpdwn", status);
			}
			actions.smartWait(100);
			actions.waitForPageToLoad(20);
			actions.keyboardEnter("MasterMenuItemList.TableFirstValue");
			actions.smartWait(100);
			actions.WaitForElementPresent("ManageMenuItems.ChangeAprrovalStatusButton", 100);

			// Click on Change approval status button
			actions.keyboardEnter("ManageMenuItems.ChangeAprrovalStatusButton");
			if (strMarket.equals("Australasia")) {
				mcd.SwitchToWindow("Status Changes");
			} else {
				mcd.SwitchToWindow("Approval Status Changes");
			}
			actions.WaitForElementPresent("ApprovalStatusChanges.AddButton", 100);

			if (actions.isElementPresent("ApprovalStatusChanges.DeleteIconScnd")) {
				actions.click("ApprovalStatusChanges.DeleteIconScnd");
				actions.acceptAlert();
				mcd.SwitchToWindow("Run Menu Item Usage Report");
				actions.click("TenderTypeSet.CustomizeCancelButton");
				if (strMarket.equals("Australasia")) {
					mcd.SwitchToWindow("$Status Changes");
				} else {
					mcd.SwitchToWindow("$Approval Status Changes");
				}
			}

			// Click on Add approval status button & Select future date
			actions.keyboardEnter("ApprovalStatusChanges.AddButton");
			actions.click("ApprovalStatusChanges.CalendarIconScnd");
			mcd.Get_future_date(1, "Close", strApplicationDate);

			// Click on Save Button & Verify Message
			if (strMarket.equals("Australasia")) {
				actions.click("RestaurantMenuItemList.ChangeStatus_Save");
				actions.smartWait(20);
			} else {
				actions.click("IngredientGroups.save");
				actions.smartWait(20);
			}
			actions.verifyTextPresence("Your changes have been saved.", true);
			if (strMarket.equals("Australasia")) {
				Thread.sleep(2000);
				actions.click("RestaurantMenuItemList.ChangeStatus_Cancel");
			} else {
				Thread.sleep(2000);
				actions.click("GlobalSettingsLookups.cancel");
			}

			mcd.SwitchToWindow("@Manage Menu Items");
			actions.WaitForElementPresent("ManageMenuItems.ChangeAprrovalStatusButton", 100);

			// Click on change approval status button
			actions.keyboardEnter("ManageMenuItems.ChangeAprrovalStatusButton");
			if (strMarket.equals("Australasia")) {
				mcd.SwitchToWindow("Status Changes");
			} else {
				mcd.SwitchToWindow("Approval Status Changes");
			}

			actions.WaitForElementPresent("ApprovalStatusChanges.AddButton", 100);

			// Verify Fields Should be Disabled are not.
			String ele = driver.findElement(By.xpath(actions.getLocator("ApprovalStatusChanges.AddButton")))
					.getAttribute("disabled");
			if (ele.equalsIgnoreCase("true")) {
				actions.reportCreatePASS("Verify Add Status Button", "Add Status Button Should be Disabled",
						"Add Status Button is Disabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Add Status Button", "Add Status Button Should be Disabled",
						"Add Status Button is not Disabled", "FAIL");
			}
			if (!actions.isElementEnabled("ManageMenuItem.Date")) {
				actions.reportCreatePASS("Verify Change Approval Status To Date ",
						"Change Approval Status To Date Should be Disabled",
						"Change Approval Status To Date is Disabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Change Approval Status To Date",
						"Change Approval Status To Date Should be Disabled",
						"Change Approval Status To Date is not Disabled", "FAIL");
			}
			if (!actions.isElementEnabled("ApprovalStatusChanges.ChangeStatus")) {
				actions.reportCreatePASS("Verify Change Approval Status", "Change Approval Status Should be Disabled",
						"Change Approval Status is Disabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Change Approval Status", "Change Approval Status Should be Disabled",
						"Change Approval Status is not Disabled", "FAIL");
			}

			// Click on Add approval status button & Select Current date
			actions.keyboardEnter("ApprovalStatusChanges.AddButton");
			actions.click("ApprovalStatusChanges.CalendarIconScnd");
			mcd.Get_future_date(0, "Close", strApplicationDate);

			// Click on Save Button & Verify Alert is Present or not.
			if (strMarket.equals("Australasia")) {
				actions.click("RestaurantMenuItemList.ChangeStatus_Save");
				boolean booAlert3 = mcd.VerifyAlertMessageDisplayed("Warning Message", strWM, true,
						AlertPopupButton.CANCEL_BUTTON);
				if (booAlert3) {
					actions.reportCreatePASS("Verify Alert is Present", "Alert should be Present", "Alert is Present",
							"PASS");
				} else {
					actions.reportCreateFAIL("Verify Alert is Present", "Alert should be Present",
							"Alert is not Present", "FAIL");
				}
				actions.click("RestaurantMenuItemList.ChangeStatus_Save");
				boolean booAlert = mcd.VerifyAlertMessageDisplayed("Warning Message", strWM, true,
						AlertPopupButton.OK_BUTTON);
				if (booAlert) {
					actions.reportCreatePASS("Verify Alert is Present", "Alert should be Present", "Alert is Present",
							"PASS");
				} else {
					actions.reportCreateFAIL("Verify Alert is Present", "Alert should be Present",
							"Alert is not Present", "FAIL");
				}
				actions.smartWait(20);
			} else {
				actions.click("IngredientGroups.save");
				actions.smartWait(20);
			}
			actions.verifyTextPresence("Your changes have been saved.", true);
			if (strMarket.equals("Australasia")) {
				Thread.sleep(2000);
				actions.click("RestaurantMenuItemList.ChangeStatus_Cancel");
			} else {
				Thread.sleep(2000);
				actions.click("GlobalSettingsLookups.cancel");
			}
			mcd.SwitchToWindow("@Manage Menu Items");

			// Verify the approval status
			String ele1 = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.prodstatus")))
					.getAttribute("value");
			if (ele1.equalsIgnoreCase(status1)) {
				actions.reportCreatePASS("Verify the approval status", "The approval status should be Present",
						"The approval status is Present", "PASS");
			}

			else {
				actions.reportCreateFAIL("Verify the approval status", "The approval status should be Present",
						"The approval status is Present", "FAIL");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);
			// System.out.println("Test Failed :: " + e.getCause() + " - " +
			// e.getMessage());

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}
