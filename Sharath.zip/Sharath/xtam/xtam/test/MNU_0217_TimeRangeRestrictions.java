package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0217_TimeRangeRestrictions {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strlevel;
	// TODO: Declare test-data variables for other data-parameters
	private String strPageTitle, strTableElement, strmsg, strerrmsg[], strfrm1, strto1, strfrm2, strto2, strfrm3,
			strto3;

	public MNU_0217_TimeRangeRestrictions(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strlevel = mcd.GetTestData("DT_LEVEL");
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		strPageTitle = mcd.GetTestData("DT_TITLE");
		strTableElement = "MasterMenuItemList.datatable";
		strmsg = mcd.GetTestData("DT_ERR_MSG");
		strfrm1 = mcd.GetTestData("DT_FROM_TIME1");
		strto1 = mcd.GetTestData("DT_TO_TIME1");
		strfrm2 = mcd.GetTestData("DT_FROM_TIME2");
		strto2 = mcd.GetTestData("DT_TO_TIME2");
		strfrm3 = mcd.GetTestData("DT_FROM_TIME3");
		strto3 = mcd.GetTestData("DT_TO_TIME3");
		strerrmsg = strmsg.split("#");

	}

	@Test
	public void test_MNU_0217_TimeRangeRestrictions() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);
			Thread.sleep(3000);
			actions.waitForPageToLoad(15000);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
			Thread.sleep(3000);
			actions.waitForPageToLoad(120);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(3000);
			actions.waitForPageToLoad(120);
			actions.smartWait(30);

			/** Verify Page Header */
			System.out.println("> Verify Page Title");
			mcd.VerifyPageTitle(strPageTitle);
			mcd.SwitchToWindow("#Title");

			// ------------------------------------------------------------------------
			// Actions specific to test-flow

			/** TODO: Select menu item */
			actions.setValue("MasterMenuItemList.Searchfield", 1);
			Thread.sleep(2000);
			actions.click("MasterMenuItemList.Searchbtn");
			actions.smartWait(60);
			WebElement ws = mcd.GetTableCellElement(strTableElement, "Future Settings", "", "", "", "Number", "a");
			actions.click(ws);

			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** TODO: Verify if any time restriction fields are displayed */
			if (mcd.fn_VerifyWebObjectsDisplayed("MasterMenuItemList.TimeRange1")) {
				this.TimeRangeFieldValidation();
			} else {
				actions.click("MasterMenuItemList.AddTimeFrame");
				Thread.sleep(2000);
				this.TimeRangeFieldValidation();
			}

			if (mcd.fn_VerifyWebObjectsDisplayed("MasterMenuItemList.TimeRange3")) {
				actions.clear("MasterMenuItemList.TimeRange3");
				actions.setValue("MasterMenuItemList.TimeRange3", strfrm2);
				actions.clear("MasterMenuItemList.TimeRange4");
				actions.setValue("MasterMenuItemList.TimeRange4", strto2);

			} else {
				actions.click("MasterMenuItemList.AddTimeFrame");
				Thread.sleep(2000);
				actions.clear("MasterMenuItemList.TimeRange3");
				actions.setValue("MasterMenuItemList.TimeRange3", strfrm2);
				actions.clear("MasterMenuItemList.TimeRange4");
				actions.setValue("MasterMenuItemList.TimeRange4", strto2);

			}

			/** TODO: Update Time Frame fields for Menu Items */
			driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.ApplySavebtn"))).click();
			if (mcd.VerifyAlertMessageDisplayed("Warning Message", strerrmsg[4], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Verify message-" + strerrmsg[4] + "is displayed",
						"Message-" + strerrmsg[4] + " should be  displayed",
						"Message-" + strerrmsg[4] + " is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify message-" + strerrmsg[4] + "is displayed",
						"Message-" + strerrmsg[4] + " should be  displayed",
						"Message-" + strerrmsg[4] + " is not displayed", "Fail");
			}
			actions.clear("MasterMenuItemList.TimeRange3");
			actions.clear("MasterMenuItemList.TimeRange4");
			actions.setValue("MasterMenuItemList.TimeRange3", strfrm3);
			actions.setValue("MasterMenuItemList.TimeRange4", strto3);
			actions.click("ManageMenuItem.ApplySavebtn");
			Thread.sleep(2000);
			mcd.SwitchToWindow("Apply Changes Details");
			Thread.sleep(2000);
			actions.click("MasterMenuItemList.ApplyChangeSave");
			Thread.sleep(5000);
			mcd.SwitchToWindow("Manage Menu Items");
			actions.smartWait(10);
			actions.verifyTextPresence(strerrmsg[3], true);
			Thread.sleep(3000);

			/** TODO: Delete Time Frame */
			actions.click("MasterMenuItemList.TimesDelete");
			if (mcd.VerifyAlertMessageDisplayed("Warning Message", strerrmsg[5], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Verify Delete Button is Clicked",
						"Delete button should be clicked and warning message should be displayed",
						"Warning message as-" + strerrmsg[5] + "is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify Delete Button is Clicked",
						"Delete button should be clicked and warning message should be displayed",
						"Warning message as-" + strerrmsg[5] + "is not displayed", "Fail");
			}
			actions.click("ManageMenuItem.ApplySavebtn");
			actions.smartWait(10);
			actions.verifyTextPresence(strerrmsg[3], true);
			actions.click("RFM.CancelBtn");
			actions.smartWait(50);

			/** Verify for choice and other Menu items **/
			actions.clear("ProductionRouting.SearchTextField");
			actions.setValue("ProductionRouting.SearchTextField", "1000000");
			actions.keyboardEnter("MenuItemPriceandTaxByRestaurant.NBSearchButton");
			actions.smartWait(20);
			WebElement firstmenuitem = mcd.GetTableCellElement("ViewGeneratedReport.ReportTable", 1, "Number", "a");
			actions.keyboardEnter(firstmenuitem);
			actions.smartWait(20);

			/** Verify the timeframe fields are disabled or not **/

			if (mcd.fn_VerifyWebelementEnableDisable("ManageMenuItemCurrentMenuItemDetails.addTimeFrame")) {
				actions.reportCreatePASS("-Times available for sale section should be disabled",
						"-Times available for sale section should be disabled",
						"-Times available for sale section should be disabled", "Pass");

			} else {
				actions.reportCreateFAIL("-Times available for sale section should be disabled",
						"-Times available for sale section should be disabled",
						"-Times available for sale section is not disabled", "Fail");
			}

			/** Verify Audit Log */
			if (rfm.VerifyAuditLog_Entry(strPageTitle, "Update", strlevel)) {
				actions.reportCreatePASS("Verify Audit Log is created for update operation",
						"Audit log should be displayed for updated operation",
						"Audit log is displayed succesfully for updated operation.", "Pass");
			} else {
				actions.reportCreateFAIL("Verify Audit Log is created for update operation",
						"Audit log should be displayed for updated operation",
						"Audit log is not displayed for updated operation.", "Fail");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	public void TimeRangeFieldValidation() {
		actions.clear("MasterMenuItemList.TimeRange1");
		String frmval = mcd.fn_GetRndNumericString(2);
		actions.setValue("MasterMenuItemList.TimeRange1", frmval + 1);
		actions.clear("MasterMenuItemList.TimeRange2");
		actions.setValue("MasterMenuItemList.TimeRange2", frmval);
		driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.ApplySavebtn"))).click();

		if (mcd.VerifyAlertMessageDisplayed("Warning Message", strerrmsg[0], true, AlertPopupButton.OK_BUTTON)) {
			actions.reportCreatePASS("Verify message-" + strerrmsg[0] + "is displayed",
					"Message-" + strerrmsg[0] + " should be  displayed", "Message-" + strerrmsg[4] + " is displayed",
					"Pass");
		} else {
			actions.reportCreateFAIL("Verify message-" + strerrmsg[0] + "is displayed",
					"Message-" + strerrmsg[0] + " should be  displayed",
					"Message-" + strerrmsg[4] + " is not displayed", "Fail");
		}
		actions.clear("MasterMenuItemList.TimeRange1");
		actions.clear("MasterMenuItemList.TimeRange2");
		driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.ApplySavebtn"))).click();
		if (mcd.VerifyAlertMessageDisplayed("Warning Message", strerrmsg[2], true, AlertPopupButton.OK_BUTTON)) {
			actions.reportCreatePASS("Verify message-" + strerrmsg[2] + "is displayed",
					"Message-" + strerrmsg[2] + " should be  displayed", "Message-" + strerrmsg[4] + " is displayed",
					"Pass");
		} else {
			actions.reportCreateFAIL("Verify message-" + strerrmsg[2] + "is displayed",
					"Message-" + strerrmsg[2] + " should be  displayed",
					"Message-" + strerrmsg[4] + " is not displayed", "Fail");
		}
		actions.clear("MasterMenuItemList.TimeRange1");
		actions.clear("MasterMenuItemList.TimeRange2");
		actions.setValue("MasterMenuItemList.TimeRange1", strfrm1);
		actions.setValue("MasterMenuItemList.TimeRange2", strto1);

		driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.ApplySavebtn"))).click();
		if (mcd.VerifyAlertMessageDisplayed("Warning Message", strerrmsg[1], true, AlertPopupButton.OK_BUTTON)) {
			actions.reportCreatePASS("Verify message-" + strerrmsg[1] + "is displayed",
					"Message-" + strerrmsg[1] + " should be  displayed", "Message-" + strerrmsg[4] + " is displayed",
					"Pass");
		} else {
			actions.reportCreateFAIL("Verify message-" + strerrmsg[1] + "is displayed",
					"Message-" + strerrmsg[1] + " should be  displayed",
					"Message-" + strerrmsg[4] + " is not displayed", "Fail");
		}
		actions.clear("MasterMenuItemList.TimeRange1");
		actions.clear("MasterMenuItemList.TimeRange2");
		actions.setValue("MasterMenuItemList.TimeRange2", strto1);
		driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.ApplySavebtn"))).click();

		if (mcd.VerifyAlertMessageDisplayed("Warning Message", strerrmsg[2], true, AlertPopupButton.OK_BUTTON)) {
			actions.reportCreatePASS("Verify message-" + strerrmsg[2] + "is displayed",
					"Message-" + strerrmsg[2] + " should be  displayed", "Message-" + strerrmsg[4] + " is displayed",
					"Pass");
		} else {
			actions.reportCreateFAIL("Verify message-" + strerrmsg[2] + "is displayed",
					"Message-" + strerrmsg[2] + " should be  displayed",
					"Message-" + strerrmsg[4] + " is not displayed", "Fail");
		}
		actions.clear("MasterMenuItemList.TimeRange1");
		actions.clear("MasterMenuItemList.TimeRange2");
		actions.setValue("MasterMenuItemList.TimeRange1", strto1);
		actions.setValue("MasterMenuItemList.TimeRange2", strfrm1);

	}
}
