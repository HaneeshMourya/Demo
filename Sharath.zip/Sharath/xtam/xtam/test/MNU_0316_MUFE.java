/**
   [Class description.  This Test Script covers the below Test Cases:
		MNU_0316_MUFE
	]  
	
	JIRA ID: RFM-4030
   @author Anubhuti
   @version 1.0
**/

package xtam.test;


import java.util.Map;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.CSVValidations;


public class MNU_0316_MUFE {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();
	
	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private String strApplicationDate;
	private CSVValidations csv;
	
	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String MSG;
	// TODO: Declare test-data variables for other data-parameters
	
	private String strDBName, strUserID, strOperation, strActivity, strLevel, strNodeName, strDescription,
	strSuccessMsg;
	boolean AuditEntry;
	String AuditDesc;
	boolean AuditDetail;
	
	public MNU_0316_MUFE (WebDriver nodeDriver, Map inputData, Object or){
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();
		csv = new CSVValidations();
		
		mcd = new lib_MCD (driver, actions, uiActions, inputData);
		rfm = new lib_RFM2 (driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL 			= mcd.GetTestData("DT_URL");
		strUserName 	= mcd.GetTestData("DT_USER_NAME");
		strPassword 	= mcd.GetTestData("DT_PASSWORD");
		strMarket 		= mcd.GetTestData("DT_MARKET");
		strNavigateTo 	= mcd.GetTestData("DT_NAVIGATE_TO");
		MSG=mcd.GetTestData("DT_MSG");
		// TODO: GetTestData for other data-parameters
		
		strDBName = mcd.GetTestData("DT_DB_NAME");
		strUserID = mcd.GetTestData("DT_USER_ID");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strActivity = mcd.GetTestData("DT_ACTIVITY");
		strLevel = mcd.GetTestData("DT_LEVEL");
		strNodeName = mcd.GetTestData("DT_NODE_NAME");
	}
	
	@Test
	public void test_SMK_0029_MUFE() throws InterruptedException {
		String strPageTitle = "Update Multiple Menu Items by Fee Exempt";			// TODO: Exact page-title
		String strPageSubHeading = "Update Multiple Menu Items by Fee Exempt";		// TODO: Page Heading
		
		try {
			System.out.println("********************************************************************** Test execution starts");
			actions.setTestcaseDescription("Verify the functionality for Update Multiple Menu Items by Fee Exempt screen, audit log generated for that and menu item updated in master menu item list..");
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);
			
			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
		
			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.MenuItem", strNavigateTo);
			Thread.sleep(2000);
            actions.waitForPageToLoad(120);
            
			/** Verify Page Header */
			System.out.println("> Verify Page Heading");
			mcd.VerifyPageHeading(strPageSubHeading, "SubHeading");
			
			  /** Update title of new Page  */
            mcd.SwitchToWindow("#Title");
            
            /** Get application time */
            WebElement apptime = mcd.getdate();
            strApplicationDate = apptime.getText();
			
			// ------------------------------------------------------------------------ Actions specific to test-flow
			

		
			/** Click on View Full List */
			//actions.WaitForElementPresent("MenuItemPriceandTaxByRestaurant.NBViewFullListButton", 120);
			//actions.smartWait(100);
			//actions.keyboardEnter("MenuItemPriceandTaxByRestaurant.NBViewFullListButton");
            actions.keyboardEnter("RFM.SearchButton");
			actions.smartWait(120);
			/** Select Row from Table */
			/*mcd.select_row("UMMIFeeExempt.LeftTable", 1);
			System.out.println("1");*/
			
			actions.click("UMMIFeeExempt.LeftTableFirstValue");
			Thread.sleep(2000);
			/** Click on > Button */
			actions.javaScriptClick("UMMIFeeExempt.Button>");
			Thread.sleep(2000);
			
			/** Click on CheckBox */
			actions.click("UMMIFeeExempt.EatIn");
			
			/** Click on CheckBox */
			actions.click("UMMIFeeExempt.TakeOut");
			
			/** Click on Apply */
			actions.click("UMMIFeeExempt.Apply");
			actions.smartWait(100);
			
			//verifying your changes have been saved
			actions.verifyTextPresence(MSG, true);
			
			// Navigate to Manage Menu Item screen and select  any menu item which was used for mass update fee exempt in above steps
			/** Select Menu Option */
			System.out.println("> Navigate to :: " + "MENU ITEM > Menu Item > Master Menu Item List");
			actions.select_menu("RFMHome.MenuItem", "MENU ITEM > Menu Item > Master Menu Item List");
			Thread.sleep(2000);
            actions.waitForPageToLoad(120);
            /** Update title of new Page  */
            mcd.SwitchToWindow("#Title");    
			
            actions.keyboardEnter("RFM.SearchButton");
 			actions.smartWait(25);

 			WebElement Element = mcd.GetTableCellElement("RFM.Table", 1, "Number", "a");
 			Element.click();
 			actions.smartWait(25);
 			mcd.SwitchToWindow("#Title");
            Thread.sleep(5000);
            
            // Click on "POS/KVS Settings" tab.
         	// Verify the screen contains a section "Fee Exempt"
         	// Verify the checkboxes for "Eat-in", Other and "Take-out" under Fee Exempt section.
			actions.keyboardEnter("ManageMenuItem.POSKVS_tab");
			
			//wait for page to load
			actions.smartWait(15);
			actions.verifyTextPresence("Fee Exempt", true);
			actions.verifyTextPresence("Eatin", true);
			actions.verifyTextPresence("Takeout", true);
			
			boolean bEatin = driver.findElement(By.id("feeEatin")).isDisplayed();
			boolean bTakeout = driver.findElement(By.id("feeTakeout")).isDisplayed();
			boolean bOther = driver.findElement(By.id("feeOther")).isDisplayed();
			
			if ((bEatin)&&(bTakeout)&&(bOther))
				 actions.reportCreatePASS("Verify the checkboxes for 'Eat-in', Other and 'Take-out' under Fee Exempt section.",
						 "Checkboxes should be displayed",
						 "Checkboxes are displayed", "Pass");
			else
				 actions.reportCreateFAIL("Verify the checkboxes for 'Eat-in', Other and 'Take-out' under Fee Exempt section.",
						 "Checkboxes should be displayed",
						 "Checkboxes are not displayed", "Fail");
			
			

			// Navigate to Home page and verify the Audit log details			
			AuditEntry = rfm.VerifyAuditLog_Entry(strOperation, "Update", strLevel);
			System.out.println(AuditEntry);
			
			// AuditDesc = "Master Flavors " + strTableValues + " has been created.";
			// AuditDetail = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID, strOperation, "Create", strLevel,
			//		strNodeName, AuditDesc);
			//System.out.println(AuditDetail);

			// Verify Audit Log ID in CSV file for Create operation
			String AuditLogId = rfm.GetAuditLogID(strOperation);
			mcd.GetTableCellElement("RFMHomePage.AuditLog", "Operations", strOperation, "", "", "Id", "a").sendKeys(
					Keys.ENTER);
			Thread.sleep(1000);
			mcd.waitAndSwitch("Manage Audit Log");
			VerifyAuditLogPrint();
			VerifyAuditLogCSV(AuditLogId, "Update");
		
			
			// ------------------------------------------------------------------------ 
			
			/** Logout the application */
			driver.switchTo().window("");
			rfm.Logout();
			

		}  catch(Exception e) {

			System.out.println("Test Failed :: " + e.getCause() + " - " +  e.getMessage());
			actions.catchException(e);
			
		        } finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());	
		}
	}
	
	// Functions to Verify Audit log functionality for Print and Save as CSV File

		public void VerifyAuditLogPrint() {

			// Click print button, Print popup should be displayed
			try {

				WebElement printBtn = driver.findElement(By.xpath("//a[contains(text(),'Print')]"));
				actions.keyboardEnter(printBtn);
				Thread.sleep(5000);
				Alert myAlert = driver.switchTo().alert();
				Thread.sleep(2000);
				actions.reportCreatePASS("Click Print button", "Print Window should be displayed.",
						"Print Window is displayed.", "PASS");
				myAlert.dismiss();

			} catch (Exception error1) {
				System.out.println("Print Alert is not displayed");
			}

		}

		
		public void VerifyAuditLogCSV(String AuditLogId, String strOperation) {

			// Click Save as CSV file button and verify that Audit log Id is
			// displayed in CSV
			try {
				WebElement SaveCSVBtn = driver.findElement(By.xpath("//a[contains(text(),'Save as CSV File')]"));
				actions.javaScriptClick(SaveCSVBtn);
				Thread.sleep(3000);

				actions.ieDownload();
				Thread.sleep(3000);

				WebElement OKBtn = driver.findElement(By.xpath("//a[contains(text(),'OK')]"));
				actions.javaScriptClick(OKBtn);

				String targetData = "{\"Id\":\"" + AuditLogId + "\"}";

				boolean csvFlag = csv.validateColumnsData("AuditLogDetail.CSV", "Id", AuditLogId, targetData, false, true);

				System.out.println("CSV field validation = " + csvFlag);

				if (csvFlag)
					actions.reportCreatePASS("Verify AuditLogDetail.CSV file for " + strOperation + " operation.",
							"Auditlog Id should be displayed in CSV file.", "Auditlog Id is displayed in CSV file.", "PASS");
				else
					actions.reportCreateFAIL("Verify AuditLogDetail.CSV file for " + strOperation + " operation.",
							"Auditlog Id should be displayed in CSV file.", "Auditlog Id is not displayed in CSV file.",
							"FAIL");

				mcd.waitAndSwitch("@RFM - Home");
			} catch (Exception error2) {
				System.out.println("Failed to verify CSV file...");
			}

		}
}

