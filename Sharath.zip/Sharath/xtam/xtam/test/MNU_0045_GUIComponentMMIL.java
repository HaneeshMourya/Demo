package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.CSVValidations;
import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;

public class MNU_0045_GUIComponentMMIL {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String category, strFamGroup;

	public MNU_0045_GUIComponentMMIL(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// Test data variables
		category = mcd.GetTestData("DT_CATEGORY");
		strFamGroup = mcd.GetTestData("DT_FAMILYGROUP");
	}

	@Test
	public void test_MNU_0045_GUIComponentMMIL() throws InterruptedException {

		try {
			System.out.println("********** Test execution starts *************");

			actions.setTestcaseDescription(
					"Verify the GUI of Components Tab on Menu Item Details screen at Master Level");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			String[] strCat = category.split("#");
			String[] strFamily = strFamGroup.split("#");

			// Selecting any Menu Item to check the 'Components' tab GUI
			actions.WaitForElementPresent("RestaurantSet.Searchbtn", 120);
			actions.keyboardEnter("RestaurantSet.Searchbtn");
			mcd.smartsync(180);
			actions.WaitForElementPresent("MenuItemSets.FamilyFltr", 120);
			actions.setValue("MenuItemSets.FamilyFltr", strFamily[0]);
			mcd.smartsync(180);
			mcd.GetTableCellElement("Lookups.UpdateTable", 1, 1, "a").click();
			mcd.smartsync(180);
			mcd.SwitchToWindow("#Title");
			actions.click("ManageMenuItem.ComponentsTab");
			mcd.smartsync(180);
			String strApprStaus = "MenuItemSets.ApprStatus";
			String strRemoveBtn = "MenuItemSets.RemoveBtn";
			String strCopyBtn = "MenuItemSets.CopyBtn";
			String strOrderComp = "MenuItemSets.OrderCompBtn";
			String strAddRemove = "ManageMenuItems.AddRemove";
			String strViewType = "MenuItemSets.ViewTypeDDL";
			String strCancel = "MenuItemSets.CompCancelbtn";
			String Savebtn = "MenuItemSets.Savebtn";
			String GUIEle[] = { strApprStaus, strRemoveBtn, strCopyBtn, strOrderComp, strAddRemove, strViewType,
					Savebtn, strCancel };
			for (int i = 0; i < GUIEle.length; i++) {
				String str = driver.findElement(By.xpath(actions.getLocator(GUIEle[i]))).getText();
				if (mcd.fn_VerifyWebObjectsDisplayed(GUIEle[i])) {
					actions.reportCreatePASS("Verify the element" + str,
							"Element named-" + str + " should be displayed on component GUI screen",
							"Element named-" + str + " is displayed on component GUI screen", "PASS");
				} else {
					actions.reportCreateFAIL("Verify the element" + str,
							"Element named-" + str + " should be displayed on component GUI screen",
							"Element named-" + str + " is not displayed on component GUI screen", "FAIL");
				}
			}
			// Navigating back to main page and selecting NON_PRODUCT item
			actions.WaitForElementPresent("RFM.Cancelbtn", 120);
			actions.keyboardEnter("RFM.Cancelbtn");
			mcd.smartsync(180);
			mcd.SwitchToWindow("#Title");
			actions.WaitForElementPresent("MenuItemSets.FamilyFltr", 120);
			actions.setValue("MenuItemSets.FamilyFltr", strFamily[1]);
			mcd.smartsync(180);

			// Validating Components tab is enabled for 'PAPER' category
			CheckingandSettingRequired_Cateogry(strCat[0], 1);
			// Validating Components tab is enabled for 'MATERIAL' category
			CheckingandSettingRequired_Cateogry(strCat[1], 2);
			// Validating Components tab is enabled for 'SERVICE' category
			CheckingandSettingRequired_Cateogry(strCat[2], 3);

			/** Logout the application */
			driver.switchTo().window("");
			rfm.Logout();

		} catch (Exception e) {
			// reporting the Fail condition
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}

	// Checking the 'Components' tab is enabled by selecting and saving the
	// required Menu Item Category from the drop down and validating
	public void CheckingandSettingRequired_Cateogry(String strCategory, int i) throws Exception {
		mcd.GetTableCellElement("Lookups.UpdateTable", i, 1, "a").click();
		mcd.smartsync(180);
		mcd.SwitchToWindow("#Title");
		actions.setValue("RFMMMIL.MICategory", strCategory);
		actions.keyboardEnter("TenderTypeSet.ApplyButton");
		try {
			mcd.smartsync(180);
			String TextAlrt = driver.switchTo().alert().getText();
			if (TextAlrt.contains("No changes")) {
				driver.switchTo().alert().accept();
			} else {
				mcd.smartsync(180);
				mcd.SwitchToWindow("Apply Changes Details");
				mcd.smartsync(180);
				actions.WaitForElementPresent("UpdateGlobalSettings.save", 120);
				actions.keyboardEnter("UpdateGlobalSettings.save");
				mcd.SwitchToWindow("Manage Men Items");
				mcd.smartsync(180);
				try {
					driver.switchTo().alert().accept();
					mcd.smartsync(180);
				} catch (Exception e1) {
					mcd.SwitchToWindow("Menu Item Association Report");
					actions.keyboardEnter("RFM.ContinueButton");
					mcd.SwitchToWindow("Mamage Menu Items");
					mcd.smartsync(180);
				}
				mcd.smartsync(180);
			}
		} catch (Exception e) {
		}

		if (actions.isElementEnabled("ManageMenuItem.ComponentsTab")) {
			actions.reportCreatePASS("Verify Components tab enabled for " + strCategory + " Category Menu Item",
					"Components tab should be enabled",
					"Components tab is enabled for " + strCategory + " Category Menu Item", "Pass");
		} else {
			actions.reportCreateFAIL("Verify Components tab enabled for " + strCategory + " Category Menu Item",
					"Components tab should be enabled",
					"Components tab is not enabled for " + strCategory + " Category Menu Item", "Fail");
		}
		actions.WaitForElementPresent("RFM.Cancelbtn", 120);
		actions.keyboardEnter("RFM.Cancelbtn");
		mcd.smartsync(180);
		mcd.SwitchToWindow("#Title");
	}
}