/***********
 * JIRA id covered: RFM-4516,RFM-4518,RFM-4512
 ***********/

package xtam.test;

import java.util.Map;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.CSVValidations;


public class MNU_20454_Vrf_CrtUpdtDel_AuditL {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();
	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private CSVValidations csv;
	
	private String strApplicationDate;
	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String strRest;
	private boolean flag;
	private String setName;
	private String strErrmsg[];
	private String dtErr;
	private String strUserID;
	private String auditMarket;


       
       public MNU_20454_Vrf_CrtUpdtDel_AuditL (WebDriver nodeDriver, Map inputData, Object or){
              driver = nodeDriver;
              input = inputData;
              actions = new Keywords(driver, or);
              uiActions = new UIValidations();
              
              mcd = new lib_MCD (driver, actions, uiActions, inputData);
              rfm = new lib_RFM2 (driver, actions, uiActions, inputData, mcd);
              csv = new CSVValidations();

           // Read input Test-Data
      		strURL = mcd.GetTestData("DT_URL");
      		strUserName = mcd.GetTestData("DT_USER_NAME");
      		strPassword = mcd.GetTestData("DT_PASSWORD");
      		strMarket = mcd.GetTestData("DT_MARKET");
      		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
      		// TODO: GetTestData for other data-parameters
      		strRest = mcd.GetTestData("DT_Node");
      		dtErr = mcd.GetTestData("DT_ERR_MSG");
      		strUserID = mcd.GetTestData("DT_USER_NAME");
    		auditMarket = mcd.GetTestData("DT_AUDITLOG_MARKET");

       }
       
       @Test
       public void test_MNU_20454_Vrf_CrtUpdtDel_AuditL() throws InterruptedException {
    	   String strPageTitle = "Dimension Name Set"; // TODO: Exact page-title
   		String strPageSubHeading = ""; // TODO: Page Heading

   		try {
   			System.out.println(
   					"********************************************************************** Test execution starts");
   			actions.setTestcaseDescription("Create a New Dimension Name Set without copying settings from existing Dimension Name Set and Verify the Audit Log");

   			/** Launch and Login RFM */
   			System.out.println("> Launch and Login RFM");
   			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

   			/** Select Market (Node) */
   			System.out.println("> Select Market (Node)");
   			rfm.SelectMarket(strMarket);

   			/** Select Menu Option */
   			System.out.println("> Navigate to :: " + strNavigateTo);
   			// actions.select_menu("RFMHome.Navigation",strNavigateTo);
   			actions.select_menu("RFMHome.Navigate", strNavigateTo);
   			Thread.sleep(2000);
            actions.waitForPageToLoad(120);

   			/** Update title of new Page */
   			mcd.SwitchToWindow("#Title");

   			/** Get application time */
   			WebElement apptime = mcd.getdate();
   			strApplicationDate = apptime.getText();

   			// ------------------------------------------------------------------------
   			// Actions specific to test-flow

   			/** TODO: Step 1 */
   			System.out.println("Start");
   			strErrmsg = dtErr.split("#");
   			actions.click("DimensionNameSet.NewDimensionSetButton");
   			Thread.sleep(2000);
   			mcd.SwitchToWindow("Dimension Name Sets");
   			actions.click("DimensionNameSet.SelectButton");
   			Thread.sleep(2000);
   			mcd.SwitchToWindow("Select Node");
   			mcd.Selectrestnode("SelectNode.Table", strRest);
   			mcd.SwitchToWindow("Dimension Name Sets");

   			do {

   				boolean blnWindow = false;
   				setName = mcd.fn_GetRndName("Auto_DNS");
   				actions.clear("DimensionNameSet.SetNameTextBox");
   				actions.setValue("DimensionNameSet.SetNameTextBox", setName);
   				actions.click("DimensionNameSet.NextButton");
   				Thread.sleep(1000);

   				try {
   					blnWindow = mcd.SwitchToWindow("@Dimension Name Set");
   					if (blnWindow) {
   						System.out.println("Menu Name and Number is accepted successfully");
   						flag = false;
   					} else {
   						mcd.SwitchToWindow("Dimension Name Sets");
   						if (actions.isTextPresence(strErrmsg[0], true)) {
   							flag = true;
   							mcd.VerifyOnscreenMessage("DimensionNameSet.DuplicateName", strErrmsg[0], true);
   							System.out.println("Entered  number " + setName + " is already exist.");
   							System.out.println(flag);
   						}
   					}

   				} catch (Exception e) {
   					if (actions.isTextPresence(strErrmsg[0], true)) {
   						flag = true;
   						System.out.println("Entered  number " + setName + " is already exist.");
   						System.out.println(flag);
   					}

   				}

   			} while (flag);

   			// Verifying audit log for create operation

   			boolean blnAudit = false;
   			blnAudit = rfm.VerifyAuditLog_Entry(strPageTitle, "Create", auditMarket);

   			if (blnAudit) {
   				actions.reportCreatePASS("Verify Audit Log Entry for Create Dimension Names Set",
   						"Audit log should be generated for Create Dimension Names Set",
   						"Audit log generated for Create Dimension Names Set succesfully", "PASS");
   			} else {
   				actions.reportCreateFAIL("Verify Audit Log Entry for Create Dimension Names Set",
   						"Audit log should be generated for Create Dimension Names Set",
   						"Audit log not generated for Create Dimension Names Set succesfully", "FAIL");
   			}

   			actions.smartWait(20);
   			
   			blnAudit = rfm.RFM_VerifyAuditLog_Details("RFM2", strUserID, strPageTitle, "Create", auditMarket, strMarket,
   					"Dimension Name set " + setName + " has been created at Node " + strMarket + ".");
   			if (blnAudit) {
   				actions.reportCreatePASS("Verify Audit Log Details for Create Dimension Names Set",
   						"Audit log details should be generated for Create Dimension Names Set",
   						"Audit log details generated for Dimension Names Set succesfully", "PASS");
   			} else {
   				actions.reportCreateFAIL("Verify Audit Log Details for Create Dimension Names Set",
   						"Audit log details should be generated for Create Dimension Names Set",
   						"Audit log details not generated for Dimension Names Set item succesfully", "FAIL");
   			}
   			
   			
   			// Verify Audit Log ID in CSV file
   			String AuditLogId = rfm.GetAuditLogID(strPageTitle);   		
			mcd.GetTableCellElement("RFMHomePage.AuditLog", "Operations", strPageTitle, "", "", "Id", "a").sendKeys(Keys.ENTER);
			Thread.sleep(1000);
			mcd.waitAndSwitch("Manage Audit Log");
			VerifyAuditLogPrint();			
			VerifyAuditLogCSV(AuditLogId, "Create");
			
   			/** TODO: Step 2 */

   			/** Select Menu Option */
   			System.out.println("> Navigate to :: " + strNavigateTo);
   			actions.select_menu("RFMHome.Navigate", strNavigateTo);
   			actions.smartWait(15);
   			mcd.SwitchToWindow("#Title");
   			actions.setValue("DimensionNameSet.SearchSetTextbox", setName);
   			actions.click("SubstitutionGroups.SearchButton");
   			actions.smartWait(15);
   			WebElement Element = mcd.GetTableCellElement("DimensionName.Table", 1, "Name", "a");
   			Element.click();
   			actions.smartWait(15);
   			actions.setValue("DimensionNameSet.StatusDropDown", "Inactive");
   			actions.click("DimensionNameSet.SaveButton");
   			actions.smartWait(15);

   			// Verifying Audit log for updating

   			blnAudit = false;
   			blnAudit = rfm.VerifyAuditLog_Entry(strPageTitle, "Update", auditMarket);

   			if (blnAudit) {
   				actions.reportCreatePASS("Verify Audit Log Entry for Update Dimension Names Set",
   						"Audit log should be generated for Update Dimension Names Set",
   						"Audit log generated for Update Dimension Names Set succesfully", "PASS");
   			} else {
   				actions.reportCreateFAIL("Verify Audit Log Entry for Update Dimension Names Set",
   						"Audit log should be generated for Update Dimension Names Set",
   						"Audit log not generated for Update Dimension Names Setsuccesfully", "FAIL");
   			}

   			blnAudit = rfm.RFM_VerifyAuditLog_Details("RFM2", strUserID, strPageTitle, "Update", auditMarket, strMarket, "Dimension Name set " + setName + " has been updated.");
   			if (blnAudit) {
   				actions.reportCreatePASS("Verify Audit Log Details for Update Dimension Names Set",
   						"Audit log details should be generated for Update Dimension Names Set",
   						"Audit log details generated for Update Dimension Names Set succesfully", "PASS");
   			} else {
   				actions.reportCreateFAIL("Verify Audit Log Details for Update Dimension Names Set",
   						"Audit log details should be generated for Update Dimension Names Set",
   						"Audit log details not generated for Update Dimension Names Set succesfully", "FAIL");
   			}
   			
   			// Verify Audit Log ID in CSV file for Update operation
   			String AuditLogIdU = rfm.GetAuditLogID(strPageTitle);   		
			mcd.GetTableCellElement("RFMHomePage.AuditLog", "Operations", strPageTitle, "", "", "Id", "a").sendKeys(Keys.ENTER);
			Thread.sleep(1000);
			mcd.waitAndSwitch("Manage Audit Log");		
			VerifyAuditLogPrint();			
			VerifyAuditLogCSV(AuditLogIdU, "Update");
			

   			/** TODO: Step 3 */

   			// Deleting the a Dimension Set Name

   			/** Select Menu Option */
   			System.out.println("> Navigate to :: " + strNavigateTo);
   			actions.select_menu("RFMHome.Navigate", strNavigateTo);
   			actions.smartWait(15);
   			mcd.SwitchToWindow("#Title");
   			actions.setValue("DimensionNameSet.SearchSetTextbox", setName);
   			Thread.sleep(1000);
   			actions.javaScriptClick("SubstitutionGroups.SearchButton");
   			actions.smartWait(15);
   			Thread.sleep(1000);
  			Element = mcd.GetTableCellElement("DimensionName.Table",1, "Delete","a");
  			
   			actions.click(Element);		// clicking on trash icon  	
   			//--Included wait 09/August/2016
   			Thread.sleep(1000);
   			flag = mcd.VerifyAlertMessageDisplayed("Warning Message",strErrmsg[1],true,AlertPopupButton.OK_BUTTON);
   			//---//
   			if(flag){
   				actions.reportCreatePASS("Verify text on alert box",
						"Message '" + strErrmsg[1] + "' should be displayed", "Expected message is displayed", "PASS");
   			}
   			else{
   				actions.reportCreateFAIL("Verify text on alert box",
						"Message '" + strErrmsg[1] + "' should be displayed", "Expected message is not displayed", "FAIL");
   			}
   				
   			//actions.smartWait(15);

   			// Verifying audit log for deletion

   			blnAudit = false;
   			blnAudit = rfm.VerifyAuditLog_Entry(strPageTitle, "Delete", auditMarket);

   			if (blnAudit) {
   				actions.reportCreatePASS("Verify Audit Log Entry for Delete Dimension Names Set",
   						"Audit log should be generated for Delete Dimension Names Set",
   						"Audit log generated for Delete Dimension Names Setsuccesfully", "PASS");
   			} else {
   				actions.reportCreateFAIL("Verify Audit Log Entry for Delete Dimension Names Set",
   						"Audit log should be generated for Delete Dimension Names Set",
   						"Audit log not generated for Delete Dimension Names Set succesfully", "FAIL");
   			}

   			blnAudit = rfm.RFM_VerifyAuditLog_Details("RFM2", strUserID, strPageTitle, "Delete", auditMarket, strMarket,
   					"Dimension Name set " + setName + " has been deleted.");
   			if (blnAudit) {
   				actions.reportCreatePASS("Verify Audit Log Details for Delete Dimension Names Set",
   						"Audit log details should be generated for Delete Dimension Names Set",
   						"Audit log details generated for Delete Dimension Names Setsuccesfully", "PASS");
   			} else {
   				actions.reportCreateFAIL("Verify Audit Log Details for Delete Dimension Names Set",
   						"Audit log details should be generated for Delete Dimension Names Set",
   						"Audit log details not generated for Delete Dimension Names Set succesfully", "FAIL");
   			}

   			// Verify Audit log Id in CSV file
   			String AuditLogIdD = rfm.GetAuditLogID(strPageTitle);   		
			mcd.GetTableCellElement("RFMHomePage.AuditLog", "Operations", strPageTitle, "", "", "Id", "a").sendKeys(Keys.ENTER);
			Thread.sleep(1000);
			mcd.waitAndSwitch("Manage Audit Log");		
			VerifyAuditLogPrint();			
			VerifyAuditLogCSV(AuditLogIdD, "Delete");
   	

   			// ------------------------------------------------------------------------

   			/** Logout the application */
   			rfm.Logout();

   		} catch (Exception e) {

   			// reporting the Fail condition
   			actions.catchException(e);

   		} finally {
   			actions.quitBrowser();
   			actions.verifyTestCase(this.getClass());

   		}
   	}
       
       // Functions to Verify Audit log functionality for Print and Save as CSV File
       
       public void VerifyAuditLogPrint(){
    	  
			// Click print button, Print popup should be displayed
			try {
				
				WebElement printBtn = driver.findElement(By.xpath("//a[contains(text(),'Print')]"));
				actions.javaScriptClick(printBtn);
				Thread.sleep(5000);
				Alert myAlert = driver.switchTo().alert();
				Thread.sleep(2000);
				actions.reportCreatePASS("Click Print button",
						"Print Window should be displayed.",
						"Print Window is displayed.", "PASS");
				myAlert.dismiss();
			
			}
			catch (Exception error1){
				System.out.println("Print Alert is not displayed");
			}	 
			
  			
       }
       
       public void VerifyAuditLogCSV(String AuditLogId, String strOperation){

			
			// Click Save as CSV file button and verify that Audit log Id is displayed in CSV
			try {
				WebElement SaveCSVBtn = driver.findElement(By.xpath("//a[contains(text(),'Save as CSV File')]"));
				actions.javaScriptClick(SaveCSVBtn);
				Thread.sleep(3000);
				
				actions.ieDownload();
				Thread.sleep(3000);
				
				WebElement OKBtn = driver.findElement(By.xpath("//a[contains(text(),'OK')]"));
				actions.javaScriptClick(OKBtn);	
		
				// Add DwnldFldr key in Crossbrowser properties file . For example : DwnldFldr =D:\\Users\\<user>\\Downloads
				String targetData = "{\"Id\":\"" + AuditLogId+"\"}";		
				boolean csvFlag = csv.validateColumnsData("AuditLogDetail.CSV", "Id", AuditLogId, targetData, false, true);
				
				System.out.println("CSV field validation = "+csvFlag);
				
	     		if(csvFlag)
	     			actions.reportCreatePASS("Verify AuditLogDetail.CSV file for "+strOperation+" operation.", "Auditlog Id should be displayed in CSV file.", "Auditlog Id is displayed in CSV file.", "PASS");
	        	else
	     			actions.reportCreateFAIL("Verify AuditLogDetail.CSV file for "+strOperation+" operation.", "Auditlog Id should be displayed in CSV file.", "Auditlog Id is not displayed in CSV file.", "FALSE");
	     		
	     		mcd.SwitchToWindow("@RFM - Home");
			}
			catch (Exception error2){
				System.out.println("Failed to verify CSV file...");
			}
    	   
       }
       
   }
