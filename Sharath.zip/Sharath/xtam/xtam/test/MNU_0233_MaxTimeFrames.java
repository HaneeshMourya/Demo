package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Keywords.DialogType;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0233_MaxTimeFrames {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String strPageTitle, currval, strTableElement, strmsg, strerrmsg[];
	private Integer newval = 0;
	boolean flag = false, blnflag = false;

	public MNU_0233_MaxTimeFrames(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strTableElement = "MasterMenuItemList.datatable";
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		strPageTitle = mcd.GetTestData("DT_TITLE");
		strmsg = mcd.GetTestData("DT_MSG");
		strerrmsg = strmsg.split("#");
	}

	@Test
	public void test_MNU_0233_MaxTimeFrames() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(
					"Verify the maximum number of Promotional Time Frames which can be added to a Menu Item at Promotion Range tab can be configured from Cache Refresh");
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
			actions.waitForPageToLoad(120);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			actions.waitForPageToLoad(120);
			actions.smartWait(30);

			actions.WaitForElementPresent("UpdateSettings.MenuItemTag", 25);
			actions.click("UpdateSettings.MenuItemTag");
			currval = driver.findElement(By.xpath(actions.getLocator("UpdateSettings.CurrentValue")))
					.getAttribute("value");
			if (Integer.parseInt(currval) == 1 || Integer.parseInt(currval) == 0 || Integer.parseInt(currval) == 2) {
				newval = Integer.parseInt(currval) + 1;
			}

			if (Integer.parseInt(currval) > 2) {
				newval = Integer.parseInt(currval) - 1;
			}

			// Updating maximum time frame with new value and click on save
			// button
			actions.setValue("UpdateSettings.NewValue", newval);
			actions.smartWait(60);
			actions.click("MasterMenuItemList.ApplyChangeSave");
			actions.smartWait(60);
			actions.waitForPageToLoad(120);
			actions.verifyTextPresence("Your changes have been saved and cache is refreshed.", true);

			// Navigate master menu item list and click on search button
			actions.select_menu("RFMHome.Navigation", "MENU ITEM>Menu Item>Master Menu Item List");
			actions.waitForPageToLoad(120);
			actions.click("MasterMenuItemList.Searchbtn");
			actions.smartWait(10);

			// Clicking the first element
			WebElement ws = mcd.GetTableCellElement(strTableElement, "Future Settings", "", "", "", "Number", "a");
			actions.click(ws);
			actions.smartWait(60);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			// Setting promotional menu item radio button to yes
			if (driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.ProMI_Yes"))).isSelected()) {
				flag = true;
			} else {
				actions.click("ManageMenuItem.ProMI_Yes");
				actions.WaitForElementPresent("CurrentMenuItemDetails.Apply", 120);
				actions.click("CurrentMenuItemDetails.Apply");
				actions.smartWait(60);
				mcd.SwitchToWindow("Apply Changes Details");
				actions.WaitForElementPresent("MasterMenuItemList.ApplyChangeSave", 120);
				actions.click("MasterMenuItemList.ApplyChangeSave");
				actions.smartWait(60);
				mcd.SwitchToWindow("Manage Menu Items");
				actions.smartWait(30);
				actions.verifyTextPresence(strerrmsg[0], true);
				actions.smartWait(60);
				flag = true;
			}

			// Click on Promotional rang tab
			if (flag) {
				actions.click("ManageMenuItem.PromRngtab");
				actions.smartWait(60);
				actions.waitForPageToLoad(15000);
				mcd.SwitchToWindow("#Title");

				// deleting the already existing time frames
				List<WebElement> Set_Del = driver
						.findElements(By.xpath(actions.getLocator("MasterMenuItemList.TimeFrameTable")));
				for (int i = 1; i < Set_Del.size() - 1; i++) {
					actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
					driver.findElements(By.xpath(".//*[@id='deleteButton_" + i + "']/img")).get(i - 1).click();
					actions.smartWait(60);
					actions.reportCreatePASS("Click on delete button", "Should click on Delete button",
							"Clicked on Delete button", "Pass");
					mcd.VerifyAlertMessageDisplayed("Alert Message", strerrmsg[1], true, AlertPopupButton.OK_BUTTON);

					actions.smartWait(60);

				}

				// Adding time frames till the range of new time frame added
				for (int j = 1; j < newval; j++) {
					actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
					actions.click("MasterMenuItemList.AddTimeFrame");
				}
				actions.click("MasterMenuItemList.AddTimeFrame");
				new WebDriverWait(driver, 10).until(ExpectedConditions.alertIsPresent());
				boolean popup = mcd.VerifyAlertMessageDisplayed("Alert Message", strerrmsg[2].concat(" " + newval),
						true, AlertPopupButton.OK_BUTTON);

				// Verifying pop up message
				if (popup) {
					actions.reportCreatePASS("Verifying pop up message", "Pop up message should display",
							"pop up message is displayed as expected", "PASS");
				} else {
					actions.reportCreateFAIL("Verifying pop up message", "Pop up message should display",
							"pop up message is NOT displayed as expected", "FAIL");
				}

				// Click on cancel button
				actions.WaitForElementPresent("ManageMenuItem.Cancelbtn1", 120);
				actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
				actions.click("ManageMenuItem.Cancelbtn1");
				new WebDriverWait(driver, 10).until(ExpectedConditions.alertIsPresent());
				mcd.VerifyAlertMessageDisplayed("Alert Message", strerrmsg[3], true, AlertPopupButton.OK_BUTTON);
				actions.smartWait(60);
				actions.waitForPageToLoad(120);
				mcd.SwitchToWindow("#Title");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}
