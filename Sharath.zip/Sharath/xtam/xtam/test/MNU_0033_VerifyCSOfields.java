package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Keywords.DialogType;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0033_VerifyCSOfields {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private boolean flag;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo, strmsg;
	private String status;
	private String strWM1, strAuditlog, strOperation, strActivity_1, strLevelCreate,strleveldetails;
	// TODO: Declare test-data variables for other data-parameters

	public MNU_0033_VerifyCSOfields(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strmsg = mcd.GetTestData("DT_MSG");
		status = mcd.GetTestData("DT_STATUS");
		strWM1 = mcd.GetTestData("DT_MSG1");
		strAuditlog = mcd.GetTestData("DT_USER_NAME");
		strOperation = mcd.GetTestData("DT_Operation");
		strActivity_1 = mcd.GetTestData("DT_Activity");
		strLevelCreate = mcd.GetTestData("DT_Level");
		strleveldetails=mcd.GetTestData("DT_leveldetails");

	}

	@Test
	public void MNU_0033_VerifyCSOfields() throws InterruptedException {
		String[] str = strmsg.split("#");

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"Verify the functionality of two new fields- CSO Size Name & CSO Generic Name added in General Settings tab of Menu Item."
							+ "Verify the special characters that can be entered in CSO Size Name and CSO Generic Name field.");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			actions.waitForPageToLoad(180);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------

			// Click on any Menu Item Set
			actions.WaitForElementPresent("ManageMenuItemSet.TableFirstValue");
			String ele1 = driver.findElement(By.xpath(actions.getLocator("ManageMenuItemSet.TableFirstValue")))
					.getText();
			actions.keyboardEnter("ManageMenuItemSet.TableFirstValue");
			actions.smartWait(80);
			actions.waitForPageToLoad(20);

			// Click on any Number HyperLink of a menu item.
			String ele = driver.findElement(By.xpath(actions.getLocator("ManageMenuItemSet.Tablefirstvalue1")))
					.getText();
			actions.keyboardEnter("ManageMenuItemSet.Tablefirstvalue1");
			actions.smartWait(100);
			if (mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.Custbtn")) {
				actions.keyboardEnter("MenuItemSets.Custbtn");
				actions.smartWait(80);
			}

			// Left the CSO Size Name & CSO Generic Name field blank and click
			// on Apply button.
			String ele6 = driver.findElement(By.xpath(actions.getLocator("MenuItemSets.CSOSizeName")))
					.getAttribute("value");
			if (ele6.isEmpty()) {
				actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
				actions.keyboardEnter("MenuItemSets.Savebtn");
				actions.smartWait(180);
				flag = mcd.VerifyAlertMessageDisplayed("Warning Message", "No changes have been made.", true,
						AlertPopupButton.OK_BUTTON);
				if (flag) {
					actions.reportCreatePASS("Verify the alert message", "Message 'No changes have been made.' ",
							"Expected Message is displayed", "PASS");
				} else {
					actions.reportCreateFAIL("Verify the alert message", "Message 'No changes have been made.'",
							"Expected Message is not displayed", "FAIL");
				}
			} else {
				actions.clear("MenuItemSets.CSOSizeName");
				actions.smartWait(200);
				actions.clear("MenuItemSets.CSOGenericName");
				if (actions.isElementPresent("RFMMMIL.FutureSettingbtn")) {
					actions.smartWait(180);
					actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
					actions.keyboardEnter("MenuItemSets.Savebtn");
					actions.smartWait(180);
					flag = mcd.VerifyAlertMessageDisplayed("Warning Message",
							"Are you sure you want to save changes to the current settings?", true,
							AlertPopupButton.OK_BUTTON);

					if (flag) {
						actions.reportCreatePASS("Verify the alert message",
								"Message 'Are you sure you want to save changes to the current settings?' ",
								"Expected Message is displayed", "PASS");
					} else {
						actions.reportCreateFAIL("Verify the alert message",
								"Message 'Are you sure you want to save changes to the current settings?' ",
								"Expected Message is not displayed", "FAIL");
					}
				} else {
					
					actions.keyboardEnter("MenuItemSets.Savebtn");
					actions.smartWait(200);

					mcd.SwitchToWindow("Apply Changes Details");
					actions.keyboardEnter("MenuItemSets.ApplyChangeSave");
					actions.smartWait(200);
					actions.waitForPageToLoad(20);
					for (String winHandle : driver.getWindowHandles()) {
						driver.switchTo().window(winHandle);
						System.out.println(driver.switchTo().window(winHandle).getTitle());
					}
					actions.smartWait(20);
				}
			}
			// Enter string more than 30 characters in CSO Size Name
			actions.clear("MenuItemSets.CSOSizeName");
			actions.smartWait(200);
			actions.clear("MenuItemSets.CSOGenericName");
			String strVal2;
			strVal2 = mcd.generateString('c', 31);
			System.out.println(strVal2.length());
			actions.setValue("MenuItemSets.CSOSizeName", strVal2);
			actions.smartWait(20);
			String charc = driver.findElement(By.xpath(actions.getLocator("MenuItemSets.CSOSizeName")))
					.getAttribute("value");
			System.out.println(charc.length());
			if (charc.length() >= 30) {
				actions.reportCreatePASS("verify the whether group name text box accepected 30 Characters",
						"group name text box should be accepected 30 Characters",
						"group name text box should not  be accepected more than 30 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether group name text box accepected 30 characters",
						"group name text box should be accepected 30 Characters ",
						"group name text box should be accepected more than 30 Characters", "FAIL");
			}

			// Enter string more than 100 characters in CSO Name & Click on
			// Apply Button
			actions.clear("MasterMenuItemList.CSOname");
			String strVal3;
			strVal3 = mcd.generateString('c', 101);
			System.out.println(strVal2.length());
			actions.setValue("MasterMenuItemList.CSOname", strVal3);
			actions.smartWait(20);
			String charc1 = driver.findElement(By.xpath(actions.getLocator("MasterMenuItemList.CSOname")))
					.getAttribute("value");
			System.out.println(charc.length());
			if (charc1.length() >= 100) {
				actions.reportCreatePASS("verify the whether group name text box accepected 100 Characters",
						"group name text box should be accepected 100 Characters",
						"group name text box should not  be accepected more than 100 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether group name text box accepected 100 characters",
						"group name text box should be accepected 100 Characters ",
						"group name text box should be accepected more than 100 Characters", "FAIL");
			}

			actions.keyboardEnter("MenuItemSets.Savebtn");
			try {
				mcd.SwitchToWindow("Apply Changes Details");
				actions.keyboardEnter("MenuItemSets.ApplyChangeSave");
				mcd.SwitchToWindow("@Manage Menu Items");
			} catch (Exception e) {

			}
			actions.smartWait(100);
			actions.isTextPresence(str[1], true);

			// Enter Numbers in CSO Size Name,CSO Generic Name and click on
			// Save/Apply button.
			actions.WaitForElementPresent("MenuItemSets.CSOSizeName");
			actions.clear("MenuItemSets.CSOSizeName");
			actions.smartWait(200);
			actions.clear("MenuItemSets.CSOGenericName");
			actions.setValue("MenuItemSets.CSOSizeName", "123@");
			actions.setValue("MasterMenuItemList.CSOGenname", "123@");
			actions.smartWait(200);
			actions.keyboardEnter("MenuItemSets.Savebtn");
			actions.smartWait(100);
			actions.isTextPresence(str[1], true);

			// Enter Chracters in CSO Size Name,CSO Generic Name and click on
			// Save/Apply button.
			actions.WaitForElementPresent("MenuItemSets.CSOGenericName");
			actions.clear("MenuItemSets.CSOSizeName");
			actions.smartWait(200);
			actions.clear("MenuItemSets.CSOGenericName");
			actions.setValue("MenuItemSets.CSOSizeName", "a123^");
			actions.setValue("MasterMenuItemList.CSOGenname", "a123^");
			actions.keyboardEnter("MenuItemSets.Savebtn");
			actions.smartWait(100);
			actions.isTextPresence(str[1], true);

			// Enter Symbols in CSO Size Name and CSO Generic Name field and
			// click on Save/Apply button.
			actions.WaitForElementPresent("MenuItemSets.CSOGenericName");
			actions.clear("MenuItemSets.CSOSizeName");
			actions.smartWait(200);
			actions.clear("MenuItemSets.CSOGenericName");
			actions.setValue("MenuItemSets.CSOSizeName", "/r");
			actions.setValue("MasterMenuItemList.CSOGenname", "/r");
			actions.keyboardEnter("MenuItemSets.Savebtn");
			actions.smartWait(100);
			actions.isTextPresence(str[1], true);

			// Enter Symbols in CSO Size Name and CSO Generic Name field and
			// click on Save/Apply button.
			/*actions.WaitForElementPresent("MenuItemSets.CSOGenericName");
			actions.clear("MenuItemSets.CSOSizeName");
			actions.smartWait(200);
			actions.clear("MenuItemSets.CSOGenericName");
			actions.setValue("MenuItemSets.CSOSizeName", "/t");
			actions.setValue("MasterMenuItemList.CSOGenname", "/t");
			actions.keyboardEnter("MenuItemSets.Savebtn");
			actions.smartWait(100);
			actions.isTextPresence(str[1], true);
*/
			// Enter Symbols in CSO Size Name and CSO Generic Name field and
			// click on Save/Apply button.
			/*actions.WaitForElementPresent("MenuItemSets.CSOGenericName");
			actions.clear("MenuItemSets.CSOSizeName");
			actions.smartWait(200);
			actions.clear("MenuItemSets.CSOGenericName");
			actions.smartWait(20);
			actions.setValue("MenuItemSets.CSOSizeName", "/n");
			actions.setValue("MasterMenuItemList.CSOGenname", "/n");
			actions.keyboardEnter("MenuItemSets.Savebtn");
			actions.smartWait(100);
			actions.isTextPresence(str[1], true);
*/
			// Enter Symbols in CSO Size Name and CSO Generic Name field and
			// click on Save/Apply button.
			/*actions.WaitForElementPresent("MenuItemSets.CSOGenericName");
			actions.clear("MenuItemSets.CSOSizeName");
			actions.smartWait(200);
			actions.clear("MenuItemSets.CSOGenericName");
			actions.setValue("MenuItemSets.CSOSizeName", "/s");
			actions.setValue("MasterMenuItemList.CSOGenname", "/s");
			actions.keyboardEnter("MenuItemSets.Savebtn");
			actions.smartWait(100);
			actions.isTextPresence(str[1], true);
*/
			// Enter Symbols in CSO Size Name and CSO Generic Name field and
			// click on Save/Apply button.
			/*actions.WaitForElementPresent("MenuItemSets.CSOGenericName");
			actions.clear("MenuItemSets.CSOSizeName");
			actions.smartWait(200);
			actions.clear("MenuItemSets.CSOGenericName");
			actions.setValue("MenuItemSets.CSOSizeName", "/c");
			actions.setValue("MasterMenuItemList.CSOGenname", "/c");
			actions.keyboardEnter("MenuItemSets.Savebtn");
			actions.smartWait(100);
			actions.isTextPresence(str[1], true);
*/
			// Verify audit log for Entry
			Boolean blnAudit = false;
			blnAudit = rfm.VerifyAuditLog_Entry(strOperation, strActivity_1, strLevelCreate);
			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Entry for Update Master Menu Item List .",
						"Audit log should be generated for Update Master Menu Item List .",
						"Audit log generated for Update Master Menu Item List succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Entry for Update Master Menu Item List.",
						"Audit log should be generated for Update Master Menu Item List.",
						"Audit log not generated for Update Master Menu Item List succesfully", "FAIL");
			}

			// Verify audit login Details for Updated Manage Menu Item Set
			blnAudit = rfm.RFM_VerifyAuditLog_Details("RFM2", strAuditlog, strOperation, strActivity_1, strLevelCreate,
					strleveldetails, "Menu Item " + ele + " of Menu Item Set " + ele1 + " has been updated.");
			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Details for Update Master Menu Item List.",
						"Audit log details should be generated for Update Master Menu Item List.",
						"Audit log details generated for UpdateMaster Menu Item List succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Details for  Update Master Menu Item List .",
						"Audit log details should be generated for  Update Master Menu Item List..",
						"Audit log details not generated for  Update Master Menu Item List itemsuccesfully", "FAIL");
			}
			// Click on audit login report
			mcd.GetTableCellElement("RFMHomePage.AuditLog", "Operations", strOperation, "", "", "Id", "a")
					.sendKeys(Keys.ENTER);
			mcd.waitAndSwitch("Manage Audit Log");

			// Verify Print &Save As CSV File Button is Present
			if (actions.isElementPresent("RFM.PrintBtn")) {
				actions.reportCreatePASS("Verify Print Button is Present", "Print Button should be Present",
						"Print Button is Present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Print Button is Present", "Print Button should not be Present",
						"Print Button is not Present", "FAIL");
			}
			if (actions.isElementPresent("RFM.SaveAsCSVBtn")) {
				actions.reportCreatePASS("Verify Save AS CSV File Button is Present",
						"Save AS CSV File Button should be Present", "Save AS CSV File Button is Present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Save AS CSV File Button is Present",
						"Save AS CSV File Button should not be Present", "Save AS CSV File Button is not Present",
						"FAIL");
			}

			// Verify CSO Size Name is present & Click on OK Button
			String ele3 = driver.findElement(By.xpath(actions.getLocator("PromotionManagement.TableFirstRow")))
					.getText();
			if (ele3.contains("/c")) {
				actions.reportCreatePASS("Verify NGABSCode Value is Present", "NGABSCode Value should be Present",
						"NGABSCode Value is Present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify NGABSCode Value is Present", "NGABSCode Value should not be Present",
						"NGABSCode Value is not Present", "FAIL");
			}
			actions.keyboardEnter("RFMHomePage.AuditLogDetailsOKButton");
			Thread.sleep(1000);
			mcd.SwitchToWindow("RFM - Home");

			// ------------------------------------------------------------------------

			/** Logout the application */
			/*rfm.Logout();*/

		} catch (Exception e) {
			// Reporter.log("Test Failed :: " + e.getCause() + " - " +
			// e.getMessage());
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			// actions.quitBrowser(); //added by Sunny actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}
