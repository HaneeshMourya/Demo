package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;


public class MNU_20443_ViewFullList {
       private Keywords actions;
       private WebDriver driver;
       private Map input;
       private UIValidations uiActions;
       private SoftAssert softAssert = new SoftAssert();
       
       private lib_MCD mcd;
       private lib_RFM2 rfm;
       
       private String strApplicationDate;
       
       // Test-Data Variables
       private Object strURL;
       private Object strUserName;
       private Object strPassword;
       private String strMarket;
       private String strNavigateTo;
       // TODO: Declare test-data variables for other data-parameters

       
       public MNU_20443_ViewFullList (WebDriver nodeDriver, Map inputData, Object or){
              driver = nodeDriver;
              input = inputData;
              actions = new Keywords(driver, or);
              uiActions = new UIValidations();
              
              mcd = new lib_MCD (driver, actions, uiActions, inputData);
              rfm = new lib_RFM2 (driver, actions, uiActions, inputData, mcd);

              // Read input Test-Data
              strURL                     = mcd.GetTestData("DT_URL");
              strUserName   = mcd.GetTestData("DT_USER_NAME");
              strPassword   = mcd.GetTestData("DT_PASSWORD");
              strMarket            = mcd.GetTestData("DT_MARKET");
              strNavigateTo        = mcd.GetTestData("DT_NAVIGATE_TO");
              // TODO: GetTestData for other data-parameters
       }
       
       @Test
       public void test_MNU_20443_ViewFullList() throws InterruptedException {
              String strPageTitle = "";                // TODO: Exact page-title
              String strPageSubHeading = "Dimension Name Sets";           // TODO: Page Heading
              
              
              try {
                     System.out.println("********************************************************************** Test execution starts");
                     actions.setTestcaseDescription("Verify the Search functionality of Dimension Name Set using �Search Full List by Dimension Name Set� field and also verify the same using View Full List button.");
                     /** Launch and Login RFM */
                     System.out.println("> Launch and Login RFM");
                     rfm.LaunchAndLogin(strURL, strUserName, strPassword);
                     
                     /** Select Market (Node) */
                     System.out.println("> Select Market (Node)");
                     rfm.SelectMarket(strMarket);
              
                     /** Select Menu Option */
                     System.out.println("> Navigate to :: " + strNavigateTo);
                     actions.select_menu("RFMHome.Navigation",strNavigateTo);
                     Thread.sleep(2000);
                     actions.smartWait(10);
                     actions.waitForPageToLoad(120);
                    

                     /** Verify Page Header */
                     System.out.println("> Verify Page Heading");
                     mcd.VerifyPageHeading(strPageSubHeading, "SubHeading");

                     /** Update title of new Page  */
                     mcd.SwitchToWindow("#Title");
                     
                     /** Get application time */
                     WebElement apptime = mcd.getdate();
                     strApplicationDate = apptime.getText();

                 //GUI verification for dimension name set
                     
                 if(!actions.isElementEnabled("RestMIList.MIStatusDrpdwn"))
                 {
                	 actions.reportCreatePASS("Verify Status drop down", "Status drop down should be disable", "Status drop down is disable", "PASS");
                 }else{
                	 actions.reportCreateFAIL("Verify Status drop down", "Status drop down should be disable", "Status drop down is NOT  disable", "FAIL");
                 }
                     
                 //Verify market drop down is disable
                if(!actions.isElementEnabled("MenuItemSets.Marketdrp"))
                {
               	 actions.reportCreatePASS("Verify Market  drop down", "Market  drop down should be disable", "Market  drop down is disable", "PASS");
                }else{
               	 actions.reportCreateFAIL("Verify Market  drop down", "Market  drop down should be disable", "Market  drop down is NOT  disable", "FAIL");
                }	
                     
              //Verifying Country drop down is disable       
                if(!actions.isElementEnabled("ScreenSet.FilterListRegionDD"))
                {
               	 actions.reportCreatePASS("Verify Country  drop down", "Country  drop down should be disable", "Country  drop down is disable", "PASS");
                }else{
               	 actions.reportCreateFAIL("Verify Country  drop down", "Country  drop down should be disable", "Country  drop down is NOT  disable", "FAIL");
                }   
                
                //Verify New Dimension Name Set button

                if(actions.isElementPresent("DimensionNameSet.NewDimensionSetButton"))
                {
                  	 actions.reportCreatePASS("Verify New Dimension Name Set button", "New Dimension Name Set button should be display", "New Dimension Name Set button is displayed", "PASS");
                   }else{
                  	 actions.reportCreateFAIL("Verify New Dimension Name Set button", "New Dimension Name Set button should be display", "New Dimension Name Set button is NOT  displayed", "FAIL");
                   } 	
                     
                 //Verifying  New Dimension Name Set columns   
                verifyTablecolumnsPresent("FieldPermissions.Table", "Name"); 
                verifyTablecolumnsPresent("FieldPermissions.Table", "Node"); 
                verifyTablecolumnsPresent("FieldPermissions.Table", "Status"); 
                verifyTablecolumnsPresent("FieldPermissions.Table", "Delete"); 
                
                //Don't enter Search criteria and click on search button
                actions.clear("CopyScreenSet.CopySearchTextBox");
                actions.keyboardEnter("SetAssignmentReport.SearchButton");
                actions.smartWait(180);
                 String dim_name_set=driver.findElement(By.xpath(actions.getLocator("DimesionNameSets.Firstlink"))).getText();    
                //Verifying records of New Dimension Name Set table
                int rc=mcd.GetTableRowCount("FieldPermissions.Table");
                if(rc>0)
                {
                	 actions.reportCreatePASS("Verify New Dimension Name Set records", "New Dimension Name Set records should be display", "New Dimension Name Set records are displayed", "PASS");
                }else{
                	 actions.reportCreateFAIL("Verify New Dimension Name Set records", "New Dimension Name Set records should be display", "New Dimension Name Set records are not displayed", "FAIL");
                }
                     
                     
                 //Enter invalid New Dimension Name Set and click search button and verify error message on screen
                actions.clear("CopyScreenSet.CopySearchTextBox");
                actions.setValue("CopyScreenSet.CopySearchTextBox", "aaaa");
                actions.keyboardEnter("SetAssignmentReport.SearchButton");
                actions.smartWait(180); 
                actions.verifyTextPresence("Search returned no matching results.", true);
                     
               //Enter valid  New Dimension Name Set and click on search button 
                actions.clear("CopyScreenSet.CopySearchTextBox");
                actions.setValue("CopyScreenSet.CopySearchTextBox", dim_name_set);
                actions.keyboardEnter("SetAssignmentReport.SearchButton");
                actions.smartWait(180);     
                     
              //Enter Active dimension name set name and select inactive form status drop down
                actions.clear("CopyScreenSet.CopySearchTextBox");
                actions.keyboardEnter("SetAssignmentReport.SearchButton");
                actions.smartWait(180);  
                actions.setValue("RestMIList.MIStatusDrpdwn", "Active");
                actions.smartWait(180);
                String active_set_name=driver.findElement(By.xpath(actions.getLocator("DimesionNameSets.Firstlink"))).getText();
                
                actions.setValue("RestMIList.MIStatusDrpdwn", "Inactive");
                actions.smartWait(180);
                String inactive_set_name=driver.findElement(By.xpath(actions.getLocator("DimesionNameSets.Firstlink"))).getText();
                     
                
                
                
                /*actions.clear("CopyScreenSet.CopySearchTextBox");
                actions.keyboardEnter("SetAssignmentReport.SearchButton");
                actions.smartWait(180); */
                actions.clear("CopyScreenSet.CopySearchTextBox");    
                actions.setValue("CopyScreenSet.CopySearchTextBox", active_set_name);     
                actions.setValue("ManageDimensionGroups.SearchWithinStatus", "Inactive");
                actions.keyboardEnter("SetAssignmentReport.SearchButton");
                actions.smartWait(180);     
                actions.verifyTextPresence("Search returned no matching results.", true);     
                
                //Enter Inactive Dimension Name Set in Search field and select active from within status drop down
                actions.clear("CopyScreenSet.CopySearchTextBox");    
                actions.setValue("CopyScreenSet.CopySearchTextBox", inactive_set_name);     
                actions.setValue("ManageDimensionGroups.SearchWithinStatus", "Active");
                actions.keyboardEnter("SetAssignmentReport.SearchButton");
                actions.smartWait(180);     
                actions.verifyTextPresence("Search returned no matching results.", true); 
                     
               //Entering invalid dimension name set and select active/inactive form within status drop down
                actions.clear("CopyScreenSet.CopySearchTextBox");    
                actions.setValue("CopyScreenSet.CopySearchTextBox", "hhhh");     
                actions.setValue("ManageDimensionGroups.SearchWithinStatus", "Active/Inactive");
                actions.keyboardEnter("SetAssignmentReport.SearchButton");
                actions.smartWait(180);     
                actions.verifyTextPresence("Search returned no matching results.", true); 
                     
               //Enter Active Dimension Name Set in Search field and select active from  status drop down  
                actions.clear("CopyScreenSet.CopySearchTextBox"); 
                actions.keyboardEnter("SetAssignmentReport.SearchButton");
                actions.smartWait(180);
                actions.setValue("RestMIList.MIStatusDrpdwn", "Active");
                actions.smartWait(180);
                actions.clear("CopyScreenSet.CopySearchTextBox"); 
                actions.setValue("CopyScreenSet.CopySearchTextBox", active_set_name); 
                actions.keyboardEnter("SetAssignmentReport.SearchButton");
                actions.smartWait(180);
                
                
              //Verifying active records of New Dimension Name Set table
                int rc_active=mcd.GetTableRowCount("FieldPermissions.Table");
                if(rc_active>0)
                {
                	 actions.reportCreatePASS("Verify New Dimension Name Set records", "New Dimension Name Set record with active should be display", "New Dimension Name Set record with active is displayed", "PASS");
                }else{
                	 actions.reportCreateFAIL("Verify New Dimension Name Set records", "New Dimension Name Set record with active should be display", "New Dimension Name Set record with active is not displayed", "FAIL");
                } 
                
                
                //Enter Inactive Dimension Name Set in Search field and select inactive from  status drop down 
                actions.clear("CopyScreenSet.CopySearchTextBox"); 
                actions.keyboardEnter("SetAssignmentReport.SearchButton");
                actions.smartWait(180);
                actions.setValue("RestMIList.MIStatusDrpdwn", "Inactive");
                actions.smartWait(180);
                actions.clear("CopyScreenSet.CopySearchTextBox"); 
                actions.setValue("CopyScreenSet.CopySearchTextBox", inactive_set_name); 
                actions.keyboardEnter("SetAssignmentReport.SearchButton");
                actions.smartWait(180);
                
                
                //Verifying Inactive records of New Dimension Name Set table
                  int rc_Inactive=mcd.GetTableRowCount("FieldPermissions.Table");
                  if(rc_Inactive>0)
                  {
                  	 actions.reportCreatePASS("Verify New Dimension Name Set records", "New Dimension Name Set record with Inactive should be display", "New Dimension Name Set record with Inactive is displayed", "PASS");
                  }else{
                  	 actions.reportCreateFAIL("Verify New Dimension Name Set records", "New Dimension Name Set record with Inactive should be display", "New Dimension Name Set record with Inactive is not displayed", "FAIL");
                  } 
                
                
                //Enter valid Dimension Name Set in Search text field and select active/inactive from status drop down
                  actions.clear("CopyScreenSet.CopySearchTextBox"); 
                  actions.keyboardEnter("SetAssignmentReport.SearchButton");
                  actions.smartWait(180);
                  actions.setValue("RestMIList.MIStatusDrpdwn", "Inactive");
                  actions.smartWait(180);
                  actions.clear("CopyScreenSet.CopySearchTextBox"); 
                  actions.setValue("CopyScreenSet.CopySearchTextBox", inactive_set_name); 
                  actions.keyboardEnter("SetAssignmentReport.SearchButton");
                  actions.smartWait(180); 
                
                  //Verifying Inactive records of New Dimension Name Set table
                  int rc_Inactive_active=mcd.GetTableRowCount("FieldPermissions.Table");
                  if(rc_Inactive_active>0)
                  {
                  	 actions.reportCreatePASS("Verify New Dimension Name Set records", "New Dimension Name Set records with Inactive/active should be display", "New Dimension Name Set records with Inactive/active are displayed", "PASS");
                  }else{
                  	 actions.reportCreateFAIL("Verify New Dimension Name Set records", "New Dimension Name Set records with Inactive/active should be display", "New Dimension Name Set records with Inactive are not displayed", "FAIL");
                  } 
                     
                  
                  //Sort Search result in descending order by �Dimension Name� hyperlink
                  actions.clear("CopyScreenSet.CopySearchTextBox"); 
                  actions.keyboardEnter("SetAssignmentReport.SearchButton");
                  actions.smartWait(180);
                  actions.keyboardEnter("DimesionNameSets.NameLink");
                  actions.smartWait(180);
                  String value1=driver.findElement(By.xpath(actions.getLocator("DimesionNameSets.Firstlink"))).getText();
                  String value2=driver.findElement(By.xpath(actions.getLocator("DimesionNameSets.Secondlink"))).getText();
                  Verify_Sort_Descending(value1, value2, "Name", "string");
                  
                  
                  //Sort Search result in ascending order by �Dimension Name� hyperlink
                 /* actions.clear("CopyScreenSet.CopySearchTextBox"); 
                  actions.keyboardEnter("SetAssignmentReport.SearchButton");
                  actions.smartWait(180);*/
                  actions.keyboardEnter("DimesionNameSets.NameLink");
                  actions.smartWait(180);
                  String value3=driver.findElement(By.xpath(actions.getLocator("DimesionNameSets.Firstlink"))).getText();
                  String value4=driver.findElement(By.xpath(actions.getLocator("DimesionNameSets.Secondlink"))).getText();
                  Verify_Sort_Ascending(value3, value4, "Name", "string");
                  
                  
                  //Sort Search result in ascending order by �Status� hyperlink
                  actions.click("PermissionReportbyRole.SortArrow");
                  String up=driver.findElement(By.xpath("//*[@id='sortStatus']/img")).getAttribute("src");
                  if(up.contains("up"))
                  {
                	  actions.reportCreatePASS("Verify Records for Status", "Status records should display with active and up arrow", "Status records are displayed with active and up arrow", "PASS");
                  }
                  else
                  {
                	  actions.reportCreateFAIL("Verify Records for Status", "Status records should display with active and up arrow", "Status records are NOT displayed with active and up arrow", "FAIL");
                  }
                  
                  
                  //Sort Search result in descending order by �Status� hyperlink
                  actions.click("PermissionReportbyRole.SortArrow");
                  String down=driver.findElement(By.xpath("//*[@id='sortStatus']/img")).getAttribute("src");
                  if(down.contains("down"))
                  {
                	  actions.reportCreatePASS("Verify Records for Status", "Status records should display with inactive and down arrow", "Status records are displayed with inactive and down arrow", "PASS");
                  }
                  else
                  {
                	  actions.reportCreateFAIL("Verify Records for Status", "Status records should display with inactive and down arrow", "Status records are NOT displayed with inactive and down arrow", "FAIL");
                  }



                  
                  
                  
                  
                  
                  
                  
                  
                     

                    /* // ------------------------------------------------------------------------ Actions specific to test-flow
                     //Function to verify search functionality using view full list 
                     ViewFullListFunctionality("DimensionNameSets.Table", "Dimension Name Sets");*/
                     
                     
                     // ------------------------------------------------------------------------ 
                     
                     /** Logout the application */
                     rfm.Logout();
                     

              } catch(Exception e) {
                     
                     //reporting the Fail condition
                     actions.catchException(e);
                     
              } finally {
                     actions.quitBrowser();
                     actions.verifyTestCase(this.getClass());
                     
                           
              }
       }
       public void ViewFullListFunctionality(String eElemtTableRowCount, String functionalityName) throws InterruptedException {
        	 //clicking on view full list
        	 WebElement viewFullListBtn = driver.findElement(By.xpath("//*[@class='button'][contains(text(),'Search')]"));
             actions.keyboardEnter(viewFullListBtn);
        	 //wait
             Thread.sleep(1000);
             //actions.smartWait(12);
             
             // Verify that View Full List button functionality 
             int count_NumberofRows = driver.findElements(By.xpath(actions.getLocator(eElemtTableRowCount))).size();
             if(count_NumberofRows>0){
            	 actions.reportCreatePASS("Verify the Search "+functionalityName +" by View Full List","All Active & Inactive "+functionalityName +"  available in the Market are displayed in the grid " ,"Total " +count_NumberofRows+ functionalityName +"  available in the Market are displayed in the grid ", "Pass");
             }else{
            	 actions.reportCreatePASS("Verify the Search "+functionalityName +" by View Full List","All Active & Inactive "+functionalityName +"  available in the Market are displayed in the grid " ,"Total  '0 ' "+functionalityName +"  available in the Market are displayed in the grid ", "Fail");
             }
    		
 
       
  }
       
       
     //VERIFYING TABLE COLUMS CODE 
       public void verifyTablecolumnsPresent(String tableLocator, String colName) {

              boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

              if (iscolPresent) {
                     actions.reportCreatePASS("Verify " + colName + " Column is present in table",
                                  colName + " Column should be present in table", colName + " Column is present in table", "Pass");
              } else {
                     actions.reportCreateFAIL("Verify " + colName + " Column is present in table",
                                  colName + " Column should be present in table", colName + " Column is NOT present in table",
                                  "Fail");
              }
       }
       
       
       
       
       /**
        * SORT DESCENDING FUNTION
        */

        public void Verify_Sort_Descending(String strValue1, String strValue2, String strColumnName, String strDataType) {

               switch (strDataType.toLowerCase()) {
               case "integer":
                      if (Integer.parseInt(strValue1) >= Integer.parseInt(strValue2)) {
                            actions.reportCreatePASS("Verify Descending Sorting according to " + strColumnName,
                                          "List should be sorted(Descending) correctly", "List is sorted correctly(Descending)", "PASS");
                            // System.out.println("sorted descending correct");
                      } else {
                            actions.reportCreateFAIL("Verify Descending Sorting according to " + strColumnName,
                                          "List should be sorted(Descending) correctly", "List is not sorted(Descending) correctly",
                                          "FAIL");
                            // System.out.println("sorted descending incorrect");
                      }
                      break;
               case "string":
                      int ReturnNumber = strValue1.toUpperCase().compareTo(strValue2.toUpperCase());
                      if (ReturnNumber >= 0) {
                            actions.reportCreatePASS("Verify Descending Sorting according to " + strColumnName,
                                          "List should be sorted(Descending) correctly", "List is sorted correctly(Descending)", "PASS");
                            // System.out.println("sorted descending correct");
                      } else {
                            actions.reportCreateFAIL("Verify Descending Sorting according to " + strColumnName,
                                          "List should be sorted(Descending) correctly", "List is not sorted(Descending) correctly",
                                          "FAIL");
                            // System.out.println("sorted descending incorrect");
                      }
                      break;
               default:
                      break;
               }
        }
        
        
        /**
         * SORTING ASCENDING
         */

         public void Verify_Sort_Ascending(String strValue1, String strValue2, String strColumnName, String strDataType) {

                switch (strDataType.toLowerCase()) {
                case "integer":
                       if (Integer.parseInt(strValue1) <= Integer.parseInt(strValue2)) {
                             actions.reportCreatePASS("Verify Ascending Sorting according to " + strColumnName,
                                           "List should be sorted(Ascending)correctly", "List is sorted(Ascending) correctly", "PASS");
                             // System.out.println("sorted ascending correct");
                       } else {
                             actions.reportCreateFAIL("Verify Ascending Sorting according to " + strColumnName,
                                           "List should be sorted(Ascending) correctly", "List is not sorted(Ascending) correctly",
                                           "FAIL");
                             // System.out.println("sorted ascending incorrect");
                       }
                       break;
                case "string":
                       int ReturnNumber = strValue1.toUpperCase().compareTo(strValue2.toUpperCase());
                       if (ReturnNumber <= 0) {
                             actions.reportCreatePASS("Verify Ascending Sorting according to " + strColumnName,
                                           "List should be sorted(Ascending)correctly", "List is sorted(Ascending) correctly", "PASS");
                             // System.out.println("sorted ascending correct");
                       } else {
                             actions.reportCreateFAIL("Verify Ascending Sorting according to " + strColumnName,
                                           "List should be sorted(Ascending) correctly", "List is not sorted(Ascending) correctly",
                                           "FAIL");
                             // System.out.println("sorted ascending incorrect");
                       }
                       break;
                default:
                       break;
                }

         }

}
