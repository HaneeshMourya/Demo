package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0066_GUIComponent {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String strFamily;

	public MNU_0066_GUIComponent(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strFamily = mcd.GetTestData("DT_FamilyGroup");

	}

	@Test
	public void test_MNU_0066_GUIComponent() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription("Verify the GUI of Components Tab on Menu Item Details screen at Set Level");
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			actions.smartWait(15);
			mcd.SwitchToWindow("#Title");

			// ------------------------------------------------------------------------

			// Select any menu item contains Non-Product and click on components
			// tab
			WebElement Element1 = mcd.GetTableCellElement("MenuItemSets.Table", 1, "Name", "a");
			actions.keyboardEnter(Element1);
			actions.smartWait(40);
			actions.setValue("MenuItemSets.FamilyFltr", strFamily);
			actions.smartWait(20);
			actions.click("RestaurantProfile.FirstValue");
			actions.smartWait(15);
			actions.keyboardEnter("ManageMenuItem.Components");
			actions.smartWait(20);

			// Verify Remove,Copy&Order Components Buttons is Present
			Boolean result1;
			result1 = actions.isElementPresent("ManageMenuItemCurrentMenuItemDetails.Remove");
			reporting_Pass_Fail("Verify Remove Button is Present", "Remove Button Should be Present",
					"Remove Button is Present", "Remove Button is not Present", result1);
			Boolean result2;
			result2 = actions.isElementPresent("RFMMMIL.CopyBtn");
			reporting_Pass_Fail("Verify Copy Button is Present", "Copy Button Should be Present",
					"Copy Button is Present", "Copy Button is not Present", result2);

			Boolean result3;
			result3 = actions.isElementPresent("ManageMenuItem.OrderComp");
			reporting_Pass_Fail("Verify Order Component Button is Present", "Order Component Button Should be Present",
					"Order Component Button is Present", "Order Component Button is not Present", result3);

			// Verify Add/Remove,Apply&Cancel Button is Present
			Boolean result4;
			result4 = actions.isElementPresent("ManageMenuItems.AddRemoveButton");
			reporting_Pass_Fail("Verify Add/Remove Button is Present", "Add/Remove Button Should be Present",
					"Add/Remove Button is Present", "Add/Remove Button is not Present", result4);

			Boolean result5;
			result5 = actions.isElementPresent("ManageMenuItemCurrentMenuItemDetails.apply");
			reporting_Pass_Fail("Verify Apply Button is Present", "Apply Button Should be Present",
					"Apply Button is Present", "Apply Button is not Present", result5);
			Boolean result6;
			result6 = actions.isElementPresent("UsersUpdateUser.cancel");
			reporting_Pass_Fail("Verify Cancel Button is Present", "Cancel Button Should be Present",
					"Cancel Button is Present", "Cancel Button is not Present", result6);

			// Verify DropDown Values is Present
			String ele = mcd.getdropdownvalues("ManageMenuItem.ViewType");
			String ele2 = mcd.GetTestData("DT_DropDown");
			String[] ele3 = ele2.split("#");
			Boolean flag2 = false;
			for (int i = 0; i < ele3.length; i++) {
				if (ele2.contains(ele3[i])) {
					flag2 = true;
				}

				else {
					flag2 = false;
					break;
				}

			}
			if (flag2 == true) {
				actions.reportCreatePASS("Verify View Type Drop Down Values",
						"View Type Drop Down Values should be Present", "View Type Drop Down Values is Present",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify View Type Drop Down Values",
						"View Type Drop Down Values should be Present", "View Type Drop Down Values is not Present",
						"FAIL");
			}

			// Verify Table Heading in the Component tab
			verifyTablecolumnsPresent("ManageMenuItem.Table2", "--------- Quantity ----------");
			verifyTablecolumnsPresent("ManageMenuItem.Table2", "---Threshold---");
			verifyTablecolumnsPresent("ManageMenuItem.Table2", "Cost");
			verifyTablecolumnsPresent("ManageMenuItem.Table2", "Display on");
			verifyTablecolumnsPresent("ManageMenuItem.Table2", "Force");
			verifyTablecolumnsPresent("ManageMenuItem.Table2", "Reference");
			verifyTablecolumnsPresent("ManageMenuItem.Table2", "Default");
			//verifyTablecolumnsPresent("ManageMenuItem.Table2", "Min");//
			verifyTablecolumnsPresent("ManageMenuItem.Table2", "Max");
			verifyTablecolumnsPresent("ManageMenuItem.Table2", "Refund");
			verifyTablecolumnsPresent("ManageMenuItem.Table2", "Charge");
			verifyTablecolumnsPresent("ManageMenuItem.Table2", "Inclusive");
			verifyTablecolumnsPresent("ManageMenuItem.Table2", "CSO");
			verifyTablecolumnsPresent("ManageMenuItem.Table2", "Composition Display");
			verifyTablecolumnsPresent("ManageMenuItem.Table2", "Smart Grill");
			verifyTablecolumnsPresent("ManageMenuItem.Table2", "Plain Grill");
			verifyTablecolumnsPresent("ManageMenuItem.ComponentsTable", "Number");
			verifyTablecolumnsPresent("ManageMenuItem.ComponentsTable", "Name");
			verifyTablecolumnsPresent("ManageMenuItem.ComponentsTable", "Component");

			// Click on Cancel Button,Select Non-Product Menu Item&Click On
			// Components
			actions.keyboardEnter("ManageMenuItem.Cancel");
			actions.smartWait(20);
			actions.click("AuditLogReport.Idlink");
			actions.smartWait(20);
			actions.keyboardEnter("ManageMenuItem.Components");
			actions.smartWait(40);

			// ------------------------------------------------------------------------

			/** Logout the application */
			/*rfm.Logout();*/

		} catch (Exception e) {
			// Reporter.log("Test Failed :: " + e.getCause() + " - " +
			// e.getMessage());
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}

	// Function for Reporting Pass/Fail
	public void reporting_Pass_Fail(String Desc, String ExpRes, String ActRes_Pass, String ActRes_Fail,
			Boolean status) {
		if (status) {
			actions.reportCreatePASS(Desc, ExpRes, ActRes_Pass, "PASS");
		}

		if (!status) {
			actions.reportCreateFAIL(Desc, ExpRes, ActRes_Fail, "FAIL");
		}
	}

	// Verify Table Header Fields
	public void verifyTablecolumnsPresent(String tableLocator, String colName) {

		boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

		if (iscolPresent) {
			actions.reportCreatePASS("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is present in table", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is NOT present in table",
					"Fail");
		}
	}
}
