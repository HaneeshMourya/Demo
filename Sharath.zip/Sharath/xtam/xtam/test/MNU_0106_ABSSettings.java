package xtam.test;

import java.util.Date;
import java.util.Map;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Keywords.DialogType;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0106_ABSSettings {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();
	private lib_MCD mcd;
	private lib_RFM2 rfm;

	// Test Data variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket, MIparam, iceProductValue, flavour, menutype, range, errmsg, pro_type;
	private String strNavigateTo;
	private boolean flag = false;
	private boolean flagfuture = false;
	private String strApplicationDate;

	public MNU_0106_ABSSettings(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();
		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		MIparam = mcd.GetTestData("DT_MenuItemParam");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		pro_type = mcd.GetTestData("DT_MENUITEMCLASS");
		range = mcd.GetTestData("DT_MIRANGE");
		errmsg = mcd.GetTestData("DT_ERR_MSG");
		menutype = mcd.GetTestData("DT_MIPARAM");
		flavour = mcd.GetTestData("DT_Flavour");
	}

	@Test

	public void MNU_0106_ABSSettings() throws InterruptedException {
		String[] strmenutype = MIparam.split("#");
		try {
			System.out.println(
					"********************************************************************** Start Test-Steps executions");

			actions.setTestcaseDescription("Menu Item Details (ABS Settings) � Form Rules");

			/** Launch and Login RFM */
			Reporter.log("Lanuch application-" + strURL);
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);
			actions.waitForPageToLoad(10000);
			actions.smartWait(1000);

			/** Select Market (Node) */
			Reporter.log("Select market-" + strMarket);
			rfm.SelectMarket(strMarket);
			actions.waitForPageToLoad(120);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// --------------------------------------------------------------------------------------------

			// create a menu item
			boolean blnflag = false;
			actions.keyboardEnter("MasterMenuItemList.AddNewButton");
			mcd.SwitchToWindow("Add New Menu Item");

			String[] strparam = menutype.split("#");
			String[] strrange = range.split("#");
			String strerrmsg[] = errmsg.split("#");
			String s = "";

			int mi_num = 0, mi_start = 0, mi_end = 0;
			try {
				boolean flag = false;

				switch (pro_type) {
				case "CONTAINER_VALUE_MEAL":
					s = "Auto_CVM_" + RandomStringUtils.randomAlphabetic(6);
					mi_start = Integer.parseInt(strrange[4]);
					mi_end = Integer.parseInt(strrange[5]);
					break;
				case "PRODUCT":
					s = "Auto_Pro_" + RandomStringUtils.randomAlphabetic(6);
					mi_start = Integer.parseInt(strrange[4]);
					mi_end = Integer.parseInt(strrange[5]);
					break;
				case "VALUE_MEAL":
					s = "Auto_VM_" + RandomStringUtils.randomAlphabetic(6);
					mi_start = Integer.parseInt(strrange[4]);
					mi_end = Integer.parseInt(strrange[5]);
					break;
				case "CHOICE":
					s = "Auto_Choice_" + RandomStringUtils.randomAlphabetic(6);
					mi_start = Integer.parseInt(strrange[0]);
					mi_end = Integer.parseInt(strrange[1]);
					break;
				case "CHOICE_EVM":
					s = mcd.fn_GetRndName("Auto_ChoiceEVM");
					mi_start = Integer.parseInt(strrange[0]);
					mi_end = Integer.parseInt(strrange[1]);
					break;
				case "CHECK CATEGORY":
					s = "Auto_Check_" + RandomStringUtils.randomAlphabetic(6);
					mi_start = Integer.parseInt(strrange[2]);
					mi_end = Integer.parseInt(strrange[3]);
					break;
				case "NON_FOOD_PRODUCT":
					s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
					mi_start = Integer.parseInt(strrange[4]);
					mi_end = Integer.parseInt(strrange[5]);
					break;
				case "RAW_ITEM":
					s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
					mi_start = Integer.parseInt(strrange[4]);
					mi_end = Integer.parseInt(strrange[5]);
					break;
				case "EVM":
					s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
					mi_start = Integer.parseInt(strrange[4]);
					mi_end = Integer.parseInt(strrange[5]);
					break;
				case "COMMENT":
					s = "Auto_CMNT_" + RandomStringUtils.randomAlphabetic(6);
					mi_start = Integer.parseInt(strrange[6]);
					mi_end = Integer.parseInt(strrange[7]);
					break;
				default:
					break;
				}

				System.out.println("product name:" + s);
				actions.setValue("AddNewMI.MenuItemName", s);

				do {
					mi_num = mcd.fn_GetRndNumInRange(mi_start, mi_end);
					actions.clear("AddNewMI.MenuItemNumber");
					actions.setValue("AddNewMI.MenuItemNumber", mi_num);
					actions.keyboardEnter("AddNewMI.Next");
					Thread.sleep(3000);
					actions.waitForPageToLoad(180);
					boolean blnWindow = false;

					try {
						blnWindow = mcd.SwitchToWindow("@Manage Menu Items");
						if (blnWindow) {
							System.out.println("Menu Name and Number is accepted successfully");
							blnflag = false;
						} else {
							mcd.SwitchToWindow("Add New Menu Item");
							if (actions.isTextPresence(strerrmsg[0], true)) {
								blnflag = true;
								System.out.println("Entered  number " + mi_num + " is already exist.");
								System.out.println(blnflag);
							}
						}

					} catch (Exception err) {
						if (actions.isTextPresence(strerrmsg[0], true)) {
							blnflag = true;
							System.out.println("Entered  number " + mi_num + " is already exist.");
							System.out.println(blnflag);
						}
					}

				} while (blnflag == true);
				// SETTING THE VALUE OF THE MANDATORY FIELDS
				String instance = mcd.GetGlobalData("Instance");
				if (instance.equalsIgnoreCase("AP") || instance.equalsIgnoreCase("QMAP")
						|| instance.equalsIgnoreCase("EU")) {
					actions.setValue("ManageMenuItemCurrentMenuItemDetails.MenuItemType", "SMI");
				}
				actions.setValue("ManageMenuItem.ProductClass", pro_type);
				actions.setValue("ManageMenuItem.ProductCategory", strparam[0]);
				actions.setValue("ManageMenuItem.FamilyGroup", strparam[1]);
				actions.setValue("ManageMenuItem.DayPartCode","BREAKFAST_MENU");
				/*Select select = new Select(
						driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.DayPartCode"))));*/
				/*select.selectByVisibleText("BREAKFAST_MENU");*/
				actions.setValue("ManageMenuItem.ProductLName", s + "LN");
				actions.setValue("ManageMenuItem.ProductSName", s + "SN");
				actions.setValue("ManageMenuItem.ProductDTName", s + "DN");

				actions.keyboardEnter("ManageMenuItem.ApplySavebtn");
				actions.smartWait(20);
				flag = mcd.VerifyOnscreenMessage("ManageMenuItem.InfoMes", "Menu Item created successfully.", true);

				if (flag) {
					actions.reportCreatePASS("Verify the on-screen message",
							"Message 'Menu Item created successfully.'", "Expected Message is displayed", "PASS");
				} else {
					actions.reportCreateFAIL("Verify the on-screen message",
							"Message 'Menu Item created successfully.'", "Expected Message is not displayed", "FAIL");
				}

			} catch (Exception e) {

			}
			// Click on ABS Setting Tab
			actions.smartWait(10);
			actions.keyboardEnter("MasterMenuItemList.NavABStab");
			mcd.SwitchToWindow("#Title");
			actions.smartWait(10);
			actions.WaitForElementPresent("MasterMenuItemList.ABSCupsize");

			if (!mcd.fn_VerifyWebelementEnableDisable("MasterMenuItemList.ABSCupsize")) {
				actions.reportCreatePASS("-Cup size should be disabled in family group 'BREAKFAST_ENTREE'",
						"-Cup size should be disabled in family group 'BREAKFAST_ENTREE'",
						"-Cup size is disabled as expected for family group 'BREAKFAST_ENTREE'", "Pass");

			} else {
				actions.reportCreateFAIL("-Cup size is should be disabled in family group 'BREAKFAST_ENTREE'",
						"-Cup size is should be disabled in family group 'BREAKFAST_ENTREE'",
						"-Cup size is not enabled as expected for family group 'BREAKFAST_ENTREE'", "Fail");
			}

			if (!mcd.fn_VerifyWebelementEnableDisable("MasterMenuItemList.ABSFlavor")) {
				actions.reportCreatePASS("-flavor should be  disabled for family group 'BREAKFAST_ENTREE'",
						"-flavor should be  disabled for family group 'BREAKFAST_ENTREE'",
						"-flavor is disabled as expected for family group 'BREAKFAST_ENTREE'", "Pass");

			} else {
				actions.reportCreateFAIL("-flavor should be  disabled for family group 'BREAKFAST_ENTREE'",
						"-flavor should be  disabled for family group 'BREAKFAST_ENTREE'",
						"-flavor is enabled for family group 'BREAKFAST_ENTREE'", "Fail");

			}
			if (!mcd.fn_VerifyWebelementEnableDisable("MasterMenuItemList.ABSIceSelection")) {
				actions.reportCreatePASS("-IceSelection should be  disabled for family group 'BREAKFAST_ENTREE'",
						"-IceSelection should be  disabled for family group 'BREAKFAST_ENTREE'",
						"-IceSelection is disabled as expected for family group 'BREAKFAST_ENTREE'", "Pass");

			} else {
				actions.reportCreateFAIL("-IceSelection should be  disabled for family group 'BREAKFAST_ENTREE'",
						"-IceSelection should be  disabled for family group 'BREAKFAST_ENTREE'",
						"-IceSelection is enabled family group 'BREAKFAST_ENTREE'", "Fail");

			}

			if (!mcd.fn_VerifyWebelementEnableDisable("MasterMenuItemList.ABSLidoption")) {

				actions.reportCreatePASS(
						"-Lid option should be disabled as expected for family group 'BREAKFAST_ENTREE'",
						"-Lid option should be disabled as expected for family group 'BREAKFAST_ENTREE'",
						"-Lid option is disabled as expected for family group 'BREAKFAST_ENTREE'", "Pass");

			} else {

				actions.reportCreateFAIL(
						"-Lid option should be disabled as expected for family group 'BREAKFAST_ENTREE'",
						"-Lid option should be disabled as expected for family group 'BREAKFAST_ENTREE'",
						"-Lid option is enabled family group 'BREAKFAST_ENTREE'", "Fail");

			}

			if (!mcd.fn_VerifyWebelementEnableDisable("MasterMenuItemList.NGABSVolume")) {

				actions.reportCreatePASS("-NGABSVolume should be disabled for family group 'BREAKFAST_ENTREE'",
						"-NGABSVolume should be disabled for family group 'BREAKFAST_ENTREE'",
						"-NGABSVolume is disabled as expected for family group 'BREAKFAST_ENTREE'", "Pass");

			} else {

				actions.reportCreateFAIL("-NGABSVolume should be disabled for family group 'BREAKFAST_ENTREE'",
						"-NGABSVolume should be disabled for family group 'BREAKFAST_ENTREE'",
						"-NGABSVolume is enabled for family group 'BREAKFAST_ENTREE'", "Fail");
			}

			if (mcd.fn_VerifyWebelementEnableDisable("MasterMenuItemList.ABSIceProduct")) {

				actions.reportCreatePASS(
						"-Ice Product Definition should be enabled for family group 'BREAKFAST_ENTREE'",
						"-Ice Product Definition should be enabled for family group 'BREAKFAST_ENTREE'",
						"-Ice Product Definition is enabled as expected for family group 'BREAKFAST_ENTREE'", "Pass");

			} else {

				actions.reportCreateFAIL(
						"-Ice Product Definition should be enabled for family group 'BREAKFAST_ENTREE'",
						"-Ice Product Definition should be enabled for family group 'BREAKFAST_ENTREE'",
						"-Ice Product Definition is disabled for family group 'BREAKFAST_ENTREE'", "Fail");

			}

			/*
			 * // if the product is already selected, change the settings, save
			 * and // rechange //iceProductValue =
			 * actions.getValue("MasterMenuItemList.ABSIceProduct"); flag =
			 * true; actions.setValue("MasterMenuItemList.ABSIceProduct",
			 * strmenutype[2]);
			 * actions.WaitForElementPresent("ManageMenuItem.ApplySavebtn");
			 * actions.keyboardEnter("ManageMenuItem.ApplySavebtn");
			 * actions.smartWait(60); if (!flagfuture == true) {
			 * 
			 * mcd.SwitchToWindow("Apply Changes Details");
			 * actions.smartWait(60); actions.WaitForElementPresent(
			 * "MasterMenuItemList.ApplyChangeSave");
			 * actions.keyboardEnter("MasterMenuItemList.ApplyChangeSave");
			 * mcd.SwitchToWindow("Manage Menu Items");
			 * 
			 * flag = mcd.VerifyOnscreenMessage("MasterMenuItemList.errmsg",
			 * "Your changes have been saved.", true); if (flag == true) {
			 * actions.reportCreatePASS(
			 * "Message: 'Your changes have been saved.",
			 * "Message: 'Your changes have been saved.' should Displayed",
			 * "Message: 'Your changes have been saved.' is Displayed", "Pass");
			 * } else { actions.reportCreateFAIL(
			 * "Message: 'Your changes have been saved.",
			 * "Message: 'Your changes have been saved.' should Displayed",
			 * "Message: 'Your changes have been saved.' is not Displayed",
			 * "Fail"); }
			 * 
			 * } else { boolean booMsg = mcd.VerifyAlertMessageDisplayed(
			 * "ManageMenuItems.applyChangeMessage",
			 * "Update of Ice Product Definition will affect both current and future settings (if present)."
			 * , true, AlertPopupButton.OK_BUTTON);
			 * 
			 * boolean booMsg1 = mcd.VerifyAlertMessageDisplayed(
			 * "ManageMenuItems.applyChangeMessage",
			 * "Are you sure you want to save changes to the current settings?",
			 * true, AlertPopupButton.OK_BUTTON); //
			 * actions.waitForPageToLoad(100); if ((booMsg1 == true) && (booMsg
			 * == true)) { actions.reportCreatePASS(
			 * "Message: 'Update of Ice Product Definition will affect both current and future settings (if present).' is displayed"
			 * ,
			 * "Message: 'Update of Ice Product Definition will affect both current and future settings (if present).' should be displayed"
			 * ,
			 * "Message: 'Update of Ice Product Definition will affect both current and future settings (if present).' is displayed"
			 * , "Pass"); } else { actions.reportCreateFAIL(
			 * "Message: 'Update of Ice Product Definition will affect both current and future settings (if present).' is displayed"
			 * ,
			 * "Message: 'Update of Ice Product Definition will affect both current and future settings (if present).' should be displayed"
			 * ,
			 * "Message: 'Update of Ice Product Definition will affect both current and future settings (if present).' is not displayed"
			 * , "Fail"); } }
			 */

			actions.WaitForElementPresent("MasterMenuItemList.ABSIceProduct");
			actions.setValue("MasterMenuItemList.ABSIceProduct", strmenutype[2]);
			/*actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);*/
			actions.keyboardEnter("ManageMenuItem.ApplySavebtn");

			if (!flagfuture == true) {
				//
				mcd.SwitchToWindow("Apply Changes Details");
				actions.smartWait(60);
				actions.WaitForElementPresent("MasterMenuItemList.ApplyChangeSave");
				actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
				actions.keyboardEnter("MasterMenuItemList.ApplyChangeSave");
				// actions.smartWait(60);

				mcd.SwitchToWindow("Manage Menu Items");
				// mcd.waitAndSwitch("#Title");

				actions.WaitForElementPresent("ManageMenuItems.ErrorMessage");
				flag = mcd.VerifyOnscreenMessage("ManageMenuItems.ErrorMessage",
						"Ice Product Definition is already associated to another Menu Item. Please select a different value.",
						true);
				if (flag == true) {
					actions.reportCreatePASS(
							"Message: 'Ice Product Definition is already associated to another Menu Item. Please select a different value.",
							"Message: 'Ice Product Definition is already associated to another Menu Item. Please select a different value.' should Displayed",
							"Message: 'Ice Product Definition is already associated to another Menu Item. Please select a different value.' is Displayed",
							"Pass");
				} else {
					actions.reportCreateFAIL(
							"Message: 'Ice Product Definition is already associated to another Menu Item. Please select a different value.",
							"Message: 'Ice Product Definition is already associated to another Menu Item. Please select a different value.' should Displayed",
							"Message: 'Ice Product Definition is already associated to another Menu Item. Please select a different value.' is not Displayed",
							"Fail");
				}

			} else {
				
				boolean booMsg = mcd.VerifyAlertMessageDisplayed("ManageMenuItems.applyChangeMessage",
						"Update of Ice Product Definition will affect both current and future settings (if present).",
						true, AlertPopupButton.OK_BUTTON);

				boolean booMsg1 = mcd.VerifyAlertMessageDisplayed("ManageMenuItems.applyChangeMessage",
						"Are you sure you want to save changes to the current settings?", true,
						AlertPopupButton.CANCEL_BUTTON);

				if ((booMsg1 == true) && (booMsg == true)) {
					actions.reportCreatePASS(
							"Message: 'Update of Ice Product Definition will affect both current and future settings (if present).' is displayed",
							"Message: 'Update of Ice Product Definition will affect both current and future settings (if present).' should be displayed",
							"Message: 'Update of Ice Product Definition will affect both current and future settings (if present).' is displayed",
							"Pass");
				} else {
					actions.reportCreateFAIL(
							"Message: 'Update of Ice Product Definition will affect both current and future settings (if present).' is displayed",
							"Message: 'Update of Ice Product Definition will affect both current and future settings (if present).' should be displayed",
							"Message: 'Update of Ice Product Definition will affect both current and future settings (if present).' is not displayed",
							"Fail");
				}

			}
			// Click on General Setting
			actions.WaitForElementPresent("ManageMenuItem.GeneralSettings");
			actions.keyboardEnter("ManageMenuItem.GeneralSettings");
			actions.smartWait(10);
			mcd.SwitchToWindow("#Title");
			actions.WaitForElementPresent("ManageMenuItems.FamilyGroup");
			actions.setValue("ManageMenuItems.FamilyGroup", "BREAKFAST_DRINK");
			actions.keyboardEnter("ManageMenuItems.ARApplyButton");
			actions.smartWait(20);
			if (!actions.isElementPresent("ManageMenuItem.InfoMes")) {
				mcd.waitAndSwitch("Menu Item Association Report");
				actions.WaitForElementPresent("ManageMenuItems.Continue");
				actions.keyboardEnter("ManageMenuItems.Continue");
				mcd.SwitchToWindow("Manage Menu Items");
			} else {

			}
			flag = mcd.VerifyOnscreenMessage("ManageMenuItem.InfoMes", "Your changes have been saved.", true);
			if (flag) {
				actions.reportCreatePASS("Verify the alert message", "Message 'Your changes have been saved.' ",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the alert message", "Message 'Your changes have been saved.' ",
						"Expected Message is not displayed", "FAIL");
			}

			// Navigate to ABS Setting
			actions.keyboardEnter("MasterMenuItemList.NavABStab");
			Thread.sleep(1000);
			actions.smartWait(20);

			if (mcd.fn_VerifyWebelementEnableDisable("MasterMenuItemList.ABSCupsizeEnable")) {
				actions.reportCreatePASS("-Cup size should be enabled in family group 'BREAKFAST_ENTREE'",
						"-Cup size should be enabled in family group 'BREAKFAST_ENTREE''",
						"-Cup size is enabled as expected for family group 'BREAKFAST_ENTREE'", "Pass");

			} else {
				actions.reportCreateFAIL("-Cup size should be enabled in family group 'BREAKFAST_ENTREE'",
						"-Cup size should be enabled in family group 'BREAKFAST_ENTREE'",
						"-Cup size is disabled as expected for family group 'BREAKFAST_ENTREE'", "Fail");
			}

			if (mcd.fn_VerifyWebelementEnableDisable("MasterMenuItemList.ABSFlavorEnable")) {
				actions.reportCreatePASS("-flavor should be  enabled for family group 'BREAKFAST_ENTREE'",
						"-flavor should be  enabled for family group 'BREAKFAST_ENTREE'",
						"-flavor is enabled as expected for family group 'BREAKFAST_ENTREE'", "Pass");
			} else {
				actions.reportCreateFAIL("-flavor should be  enabled for family group 'BREAKFAST_ENTREE'",
						"-flavor should be  enabled for family group 'BREAKFAST_ENTREE'",
						"-flavor is disabled for family group 'BREAKFAST_ENTREE'", "Fail");
			}

			if (mcd.fn_VerifyWebelementEnableDisable("MasterMenuItemList.ABSIceSelectionEnable")) {
				actions.reportCreatePASS("-IceSelection should be  enabled for family group 'BREAKFAST_ENTREE'",
						"-IceSelection should be  enabled for family group 'BREAKFAST_ENTREE'",
						"-IceSelection is enabled as expected for family group 'BREAKFAST_ENTREE'", "Pass");

			} else {
				actions.reportCreateFAIL("-IceSelection should be  enabled for family group 'BREAKFAST_ENTREE'",
						"-IceSelection should be  enabled for family group 'BREAKFAST_ENTREE'",
						"-IceSelection is disabled family group 'BREAKFAST_ENTREE'", "Fail");

			}

			if (mcd.fn_VerifyWebelementEnableDisable("MasterMenuItemList.ABSLidoptionEnable")) {

				actions.reportCreatePASS(
						"-Lid option should be enabled as expected for family group 'BREAKFAST_ENTREE'",
						"-Lid option should be enabled as expected for family group 'BREAKFAST_ENTREE'",
						"-Lid option is enabled as expected for family group 'BREAKFAST_ENTREE'", "Pass");

			} else {

				actions.reportCreateFAIL(
						"-Lid option should be enabled as expected for family group 'BREAKFAST_ENTREE'",
						"-Lid option should be enabled as expected for family group 'BREAKFAST_ENTREE'",
						"-Lid option is disabled family group 'BREAKFAST_ENTREE'", "Fail");

			}

			if (mcd.fn_VerifyWebelementEnableDisable("MasterMenuItemList.NGABSVolume_ACT")) {

				actions.reportCreatePASS("-NGABSVolume should be enabled for family group 'BREAKFAST_ENTREE'",
						"-NGABSVolume should be enabled for family group 'BREAKFAST_ENTREE'",
						"-NGABSVolume is enabled as expected for family group 'BREAKFAST_ENTREE'", "Pass");

			} else {

				actions.reportCreateFAIL("-NGABSVolume should be enabled for family group 'BREAKFAST_ENTREE'",
						"-NGABSVolume should be enabled for family group 'BREAKFAST_ENTREE'",
						"-NGABSVolume is disabled for family group 'BREAKFAST_ENTREE'", "Fail");

			}

			// check for alert of flavour present
			/*actions.setValue("MasterMenuItemList.ABSCupsizeEnable", "Child");*/
			driver.findElement(By.xpath(actions.getLocator("MasterMenuItemList.ABSCupsizeEnable"))).sendKeys("Child");
			actions.smartWait(10);
			/*actions.setValue("MasterMenuItemList.ABSLidoptionEnable", "No Lid");*/
			driver.findElement(By.xpath(actions.getLocator("MasterMenuItemList.ABSLidoptionEnable"))).sendKeys("No Lid");
			actions.smartWait(10);
			driver.findElement(By.xpath(actions.getLocator("MasterMenuItemList.ABSIceSelectionEnable"))).sendKeys("Full Ice Drink");
			/*actions.setValue("MasterMenuItemList.ABSIceSelectionEnable", "Full Ice Drink");*/
			actions.smartWait(10);

			actions.keyboardEnter("ManageMenuItems.ARApplyButton");
			boolean booMsg1 = mcd.VerifyAlertMessageDisplayed("ManageMenuItems.applyChangeMessage",
					"Please select Flavor.", true, AlertPopupButton.OK_BUTTON);
			if ((booMsg1 == true)) {
				actions.reportCreatePASS("Message: 'Please select Flavor.' is displayed",
						"Message: 'Please select Flavor.' should be displayed",
						"Message: 'Please select Flavor.' is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Message: 'Please select Flavor.' is displayed",
						"Message: 'Please select Flavor.' should be displayed",
						"Message: 'Please select Flavor.' is not displayed", "Fail");
			}

			// reset all the fields
			actions.setValue("MasterMenuItemList.ABSCupsizeEnable", "Select");
			actions.smartWait(10);
			actions.setValue("MasterMenuItemList.ABSFlavorEnable", "Select");
			actions.setValue("MasterMenuItemList.ABSLidoptionEnable", "Select");
			actions.setValue("MasterMenuItemList.ABSIceSelectionEnable", "Select");

			// check for alert for cup size present
			Thread.sleep(2000);
			actions.setValue("MasterMenuItemList.ABSFlavorEnable", flavour);
			actions.setValue("MasterMenuItemList.ABSLidoptionEnable", "No Lid");
			actions.setValue("MasterMenuItemList.ABSIceSelectionEnable", "Full Ice Drink");

			actions.keyboardEnter("ManageMenuItems.ARApplyButton");
			booMsg1 = mcd.VerifyAlertMessageDisplayed("ManageMenuItems.applyChangeMessage", "Please select Cup Size.",
					true, AlertPopupButton.OK_BUTTON);
			if ((booMsg1 == true)) {
				actions.reportCreatePASS("Message: 'Please select Cup Size.' is displayed",
						"Message: 'Please select Cup Size.' should be displayed",
						"Message: 'Please select Cup Size.' is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Message: 'Please select Cup Size.' is displayed",
						"Message: 'Please select Cup Size.' should be displayed",
						"Message: 'Please select Cup Size.' is not displayed", "Fail");
			}

			// reset all the fields
			actions.setValue("MasterMenuItemList.ABSCupsizeEnable", "Select");
			actions.setValue("MasterMenuItemList.ABSFlavorEnable", "Select");
			actions.setValue("MasterMenuItemList.ABSLidoptionEnable", "Select");
			actions.setValue("MasterMenuItemList.ABSIceSelectionEnable", "Select");

			// check for alert for ice selection present
			actions.setValue("MasterMenuItemList.ABSCupsizeEnable", "Child");
			actions.setValue("MasterMenuItemList.ABSFlavorEnable", flavour);
			actions.setValue("MasterMenuItemList.ABSLidoptionEnable", "No Lid");

			actions.keyboardEnter("ManageMenuItems.ARApplyButton");
			booMsg1 = mcd.VerifyAlertMessageDisplayed("ManageMenuItems.applyChangeMessage",
					"Please select Ice Selection.", true, AlertPopupButton.OK_BUTTON);
			if ((booMsg1 == true)) {
				actions.reportCreatePASS("Message: 'Please select Ice Selection.' is displayed",
						"Message: 'Please select Ice Selection.' should be displayed",
						"Message: 'Please select Ice Selection.' is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Message: 'Please select Ice Selection.' is displayed",
						"Message: 'Please select Ice Selection.' should be displayed",
						"Message: 'Please select Ice Selection.' is not displayed", "Fail");
			}

			// reset all the fields
			actions.setValue("MasterMenuItemList.ABSCupsizeEnable", "Select");
			actions.setValue("MasterMenuItemList.ABSFlavorEnable", "Select");
			actions.setValue("MasterMenuItemList.ABSLidoptionEnable", "Select");
			actions.setValue("MasterMenuItemList.ABSIceSelectionEnable", "Select");

			// check for alert for lid option present
			actions.smartWait(10);
			actions.setValue("MasterMenuItemList.ABSCupsizeEnable", "Child");
			actions.setValue("MasterMenuItemList.ABSFlavorEnable", flavour);
			actions.setValue("MasterMenuItemList.ABSIceSelectionEnable", "Full Ice Drink");

			actions.keyboardEnter("ManageMenuItems.ARApplyButton");
			booMsg1 = mcd.VerifyAlertMessageDisplayed("ManageMenuItems.applyChangeMessage", "Please select lid Option.",
					true, AlertPopupButton.OK_BUTTON);
			if ((booMsg1 == true)) {
				actions.reportCreatePASS("Message: 'Please select lid Option.' is displayed",
						"Message: 'Please select lid Option.' should be displayed",
						"Message: 'Please select lid Option.' is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Message: 'Please select lid Option.' is displayed",
						"Message: 'Please select lid Option.' should be displayed",
						"Message: 'Please select lid Option.' is not displayed", "Fail");
			}
			// ---------------------------------------------------------------------------------------
			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}

	}
}
