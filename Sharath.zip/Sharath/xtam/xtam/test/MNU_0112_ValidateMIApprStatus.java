package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.MasterMenuItem;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0112_ValidateMIApprStatus {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private MasterMenuItem mi;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo, strPageTitle, mainwindow, menuItem, popupwin, strmsgs, expmsg[], popwin1, menu_name,
			status;
	private String strermsg, ermsg[], strnum, strparam;

	// TODO: Declare test-data variables for other data-parameters

	public MNU_0112_ValidateMIApprStatus(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		mi = new MasterMenuItem(driver, actions, uiActions, inputData, mcd, rfm);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strPageTitle = mcd.GetTestData("DT_PageTitle");
		strmsgs = mcd.GetTestData("DT_MSG");
		strermsg = mcd.GetTestData("DT_ERMSG");
		strnum = mcd.GetTestData("DT_RANGE");
		strparam = mcd.GetTestData("DT_PARAM");
		strermsg = mcd.GetTestData("DT_ERMSG");

		expmsg = strmsgs.split("#");
		ermsg = strermsg.split("#");

		// TODO: GetTestData for other data-parameters
	}

	@Test
	public void test_MNU_0112_ValidateMIApprStatus() throws InterruptedException {
		String strPageTitle = "Master Menu Item List";// TODO: Exact page-title
		String description = "Change approval status-for Menu Item which is present as a component in one or more Choice/ Choice EVM menu items";

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			// setting the description now
			actions.setTestcaseDescription(description);

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			actions.waitForPageToLoad(180);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			String app_date = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow

			// creating Menu Item with CHoice Category
			actions.WaitForElementPresent("MasterMenuItemList.srch_text", 180);
			int menu_num = mi.RFM_MI_CreateMenuItem_updated(strnum, "CHOICE", strermsg, strparam);

			// filtering the active records from the table
			actions.setValue("MasterMenuItemList.srch_text", menu_num);
			actions.keyboardEnter("MasterMenuItemList.Searchbtn");

			// waiting for the page to load
			actions.smartWait(180);

			// selecting the first record from the data-table..
			WebElement rec_sel = mcd.GetTableCellElement("MasterMenuItemList.datatable", 1, "Number", "a");
			actions.click(rec_sel);

			// waiting for the page to load
			mcd.SwitchToWindow("#Title");

			// waiting for the page to load
			actions.smartWait(180);

			// Getting the Name or number of the Menu Item
			menu_name = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.prodname")))
					.getAttribute("value");

			// --- Opening the Component Tab
			actions.click("ManageMenuItem.Component_act");

			// ===Component tab flow

			// waiting for the page to load
			actions.smartWait(180);

			// adding component now
			menuItem = AddRemove_Comp("Available");

			actions.click("CurrentMenuItemDetails.Apply");

			// switching back to main window
			mcd.SwitchToWindow("Apply Changes Details");
			// --//
			actions.waitForPageToLoad(4);

			// Selecting the future date
			actions.click("ApplyChangesDetails.futuredaterbtn");
			actions.click("ApplyChangesDetails.FutureDatecalender");
			actions.smartWait(10);
			mcd.Get_future_date(3, "Close", app_date);
			actions.click("ApplyChangesDetails.Save");

			// switching back to main window
			mcd.SwitchToWindow("Manage Menu Items");

			// waiting for page to load
			actions.smartWait(180);

			//// =======Verification of message
			actions.verifyTextPresence("Your changes have been saved.", true);
			// Clicking on the cancel button
			actions.click("CurrentMenuItemDetails.Cancel");

			// waiting for page to load
			actions.smartWait(180);

			// ==searching for the added Menu item
			actions.clear("MasterMenuItemList.Searchfield");
			actions.setValue("MasterMenuItemList.Searchfield", menuItem);
			Thread.sleep(1789);
			actions.keyboardEnter("SetAssignmentReport.SearchButton");

			// waiting for page to load
			actions.smartWait(180);

			rec_sel = mcd.GetTableCellElement("MasterMenuItemList.datatable", 1, 1, "a");
			Thread.sleep(1890);
			actions.keyboardEnter(rec_sel);

			// waiting for page to load
			actions.smartWait(180);

			// getting the menu item status
			status = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.prodstatus")))
					.getAttribute("value");

			/// =======Changing the approval status now
			actions.click("ManageMenuItem.ApprovalStatus");

			// swtiching to pop up window
			if (mcd.GetGlobalData("Instance").equalsIgnoreCase("AP")) {
				mcd.SwitchToWindow("Status Changes");
				// --//
				actions.waitForPageToLoad(14);
				Thread.sleep(1890);
				actions.click("StatusChanges.AddStatus");
			} else {
				mcd.waitAndSwitch("Approval Status Changes");
				// --//
				actions.waitForPageToLoad(14);
				Thread.sleep(2000);
				actions.click("StatusChanges.AddStatusButton");
			}
			actions.WaitForElementPresent("StatusChanges.datepicker");
			Thread.sleep(4000);
			actions.click("StatusChanges.datepicker");

			/// date selection
			mcd.select_date("15", "next", "StatusChanges.datepicker");
			Thread.sleep(2000);

			// Saving the future date now
			if (mcd.GetGlobalData("Instance").equalsIgnoreCase("AP")) {
				driver.findElement(By.xpath(actions.getLocator("StatusChanges.Save"))).click();
				Thread.sleep(1500);
				// driver.findElement(By.xpath(actions.getLocator("StatusChanges.CancelBtn"))).click();
			} else if(input.get("_rowId").toString().toUpperCase().contains("US")) {
				driver.findElement(By.xpath(actions.getLocator("ApprovalStatusChanges.SaveBtn"))).click();
				int try_cnt = 0;
				actions.smartWait(25);
				// switching to new window
				mcd.SwitchToWindow("@Title");
				// Checking the confirmation message
				if (driver.getPageSource().contains((expmsg[0].trim()))
						|| driver.getPageSource().contains((expmsg[1].trim()))
						|| driver.getPageSource().contains((expmsg[2].trim()))) {
					actions.reportCreatePASS("Validation Message are displayed as Expected.",
							"Validation Message are displayed as Expected.",
							"Validation Message are displayed as Expected.", "PASS");

				} else {

					actions.reportCreateFAIL("Validation Message displayed are not displayed as Expected",
							"Validation Message displayed are not displayed as Expected",
							"Validation Message displayed are not displayed as Expected", "FAIL");
				}
				// clicking on the cancel button now
				actions.keyboardEnter("MenuItemList.CancelButton");
				mcd.waitAndSwitch("$Approval Status Changes");
				
			}

			
			
			//actions.isTextPresence("Your changes have been saved.", true);

			/*// Checking the confirmation message
			if (driver.getPageSource().contains((expmsg[0].trim()))
					|| driver.getPageSource().contains((expmsg[1].trim()))
					|| driver.getPageSource().contains((expmsg[2].trim()))) {
				actions.reportCreatePASS("Validation Message are displayed as Expected.",
						"Validation Message are displayed as Expected.",
						"Validation Message are displayed as Expected.", "PASS");

			} else {

				actions.reportCreateFAIL("Validation Message displayed are not displayed as Expected",
						"Validation Message displayed are not displayed as Expected",
						"Validation Message displayed are not displayed as Expected", "FAIL");
			}*/

			// clicking on the cancel button now
			actions.keyboardEnter("MenuItemList.CancelButton");

			/*// swtiching to pop up window
			if (mcd.GetGlobalData("Instance").equalsIgnoreCase("AP")) {
				mcd.SwitchToWindow("$Status Changes");
			} else {
				mcd.waitAndSwitch("$Approval Status Changes");
			}

			actions.smartWait(20);
			actions.keyboardEnter("StatusChanges.cancelbtn");*/

			// accepting the alert now
			try {
				driver.switchTo().alert().accept();
			} catch (Exception e) {
			}

			// switching back to main window
			mcd.SwitchToWindow("$Manage Menu Items");
			actions.smartWait(30);
			// Checking the Status of the Menu Item
			String nstatus = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.prodstatus")))
					.getAttribute("value");

			if (nstatus.equals(status)) {
				actions.reportCreatePASS("Status remains same as:" + status, "Status remains same as:" + status,
						"Status remains same as:" + status, "PASS");
			} else {
				actions.reportCreateFAIL("Status expected as:" + status + " Actual :" + nstatus,
						"Status expected as:" + status + " Actual :" + nstatus,
						"Status expected as:" + status + " Actual :" + nstatus, "FAIL");
			}
			Thread.sleep(1890);
			//// ============== Resetting data
			actions.click("RFM.Cancelbtn");

			// waiting for the page to load
			actions.smartWait(180);

			// filtering the active records from the table
			actions.clear("MasterMenuItemList.srch_text");
			actions.setValue("MasterMenuItemList.srch_text", menu_num);
			actions.keyboardEnter("MasterMenuItemList.Searchbtn");

			// waiting for the page to load
			actions.smartWait(180);

			// selecting the first record from the data-table..
			rec_sel = mcd.GetTableCellElement("MasterMenuItemList.datatable", 1, "Future Settings", "a");
			actions.click(rec_sel);

			// waiting for the page to load
			mcd.SwitchToWindow("#Title");

			// waiting for the page to load
			actions.smartWait(180);

			actions.click("ManageMenuItems.RemoveAll");

			driver.switchTo().alert().accept();

			// waiting for page to load
			actions.smartWait(180);
			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			actions.catchException(e);
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}

	public String AddRemove_Comp(String straction) {
		String Item_name = null;
		try {
			// clicking on the add remove button
			actions.click("ManageMenuItems.AddRemove");

			// swtiching to new window
			mcd.SwitchToWindow("Common Menu Item Selector");

			// selecting the view full list
			actions.click("SetAssignmentReport.SearchButton");

			// waiting for the page to load
			actions.smartWait(125);

			// setting the available in the search list
			actions.setValue("AddRemoveMenu.Availability", straction);

			// waiting for the page to load
			actions.smartWait(125);

			// getting the webElement from the table

			try {

				// getting the element name
				Item_name = mcd.GetTableCellValue("AddRemoveComponent.webtable", 1, "Name", "", "");

				// getting the check box webelement and selecting it
				WebElement AddCheck_box = mcd.GetTableCellElement("AddRemoveComponent.webtable", 1, "Add", "input");
				AddCheck_box.sendKeys(Keys.SPACE);

				actions.reportCreatePASS("Verify selecting the Available menu Item",
						"Should select the available menu Item", "Selected menu item '" + Item_name + "successfuly",
						"Pass");
			} catch (Exception e) {

				actions.reportCreateFAIL("Verify selecting the Available menu Item",
						"Should select the available menu Item", "Not able to selected menu item", "Fail");
			}

			actions.click("CommonMenuSelector.Continue");

			// switching back to main window
			mcd.SwitchToWindow("$Manage Menu Items");
		} catch (Exception err1) {
			System.out.println(err1.getMessage());
		}
		return Item_name;
	}

}
