package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.MasterMenuItem;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0086_VerifySmartRouting {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();
	private MasterMenuItem mmi;
	private lib_MCD mcd;
	private lib_RFM2 rfm;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo, MIrange, pro_type, strmsg, strmenutype;
	private String strmenuname, proname, strmsgs, MainWindow_MenuItem, strNavigateTo1;
	private String strOperation, StrActivity, StrLevel, StrLevedetails, strDBName, strUserID;
	boolean flag = false, temp = false;
	/* private String strmarkets; */

	public MNU_0086_VerifySmartRouting(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		mmi = new MasterMenuItem(nodeDriver, actions, uiActions, inputData, mcd, rfm);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strNavigateTo1 = mcd.GetTestData("DT_NAVIGATE_TO1");
		// TODO: GetTestData for other data-parameters
		strmenuname = mcd.GetTestData("DT_MENUNAME");
		strmsgs = mcd.GetTestData("DT_MSG");
		MIrange = mcd.GetTestData("DT_MIRANGE");
		pro_type = mcd.GetTestData("DT_MENUITEMCLASS");
		strmsg = mcd.GetTestData("DT_ERR_MSG");
		strmenutype = mcd.GetTestData("DT_MIPARAM");
		StrLevel = mcd.GetTestData("DT_LEVEL");
		StrLevedetails = mcd.GetTestData("DT_LevelDetails");
		StrActivity = mcd.GetTestData("DT_ACTIVITY");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strDBName = mcd.GetTestData("DT_DBNAME");
		strUserID = mcd.GetTestData("DT_USER_NAME");
	}

	@Test
	public void test_MNU_0086_VerifySmartRouting() throws InterruptedException {

		String msg[] = strmsgs.split("#");

		actions.setTestcaseDescription(
				"Verify all the fields under smart routing tab while updating a menu item of menu item class of 'Product/Comment' and also verify the audit log.");

		try {
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);
			Thread.sleep(3000);
			actions.waitForPageToLoad(15000);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
			Thread.sleep(3000);
			actions.waitForPageToLoad(15000);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo1);
			actions.select_menu("RFMHome.Navigation", strNavigateTo1);
			Thread.sleep(6000);
			actions.waitForPageToLoad(15000);
			mcd.SwitchToWindow("#Title");

			// ------------------------------------------------------------------------
			// Actions specific to test-flow

			// Create New Menu Item with Menu item Class as Product.
			String[] strparam = strmenutype.split("#");
			int MenuNumber = mmi.RFM_MI_CreateMenuItem_updated(MIrange, pro_type, strmsg, strmenutype);
			String strMenuNumber = Integer.toString(MenuNumber);
			System.out.println("> > > >" + strMenuNumber);

			/** Navigate to Menu Item */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(6000);
			actions.waitForPageToLoad(15000);
			mcd.SwitchToWindow("#Title");

			// Click on any Menu item set.
			String menuitemset = driver.findElement(By.xpath("//*[@id='Sess1']/tbody/tr[1]/td[1]")).getText();
			System.out.println(menuitemset);

			WebElement MI_Setname = mcd.GetTableCellElement("RestaurantProfile.RestaurantProfileTable", 1, "Name", "a");
			actions.keyboardEnter(MI_Setname);
			actions.smartWait(50);

			/*
			 * String MI_Setname = ""; int Row =
			 * mcd.GetTableRowCount("AdminHelp.Table"); for (int i = 1; i <=
			 * Row; i++) { String ele =
			 * driver.findElement(By.xpath("//*[@id='Sess1']/tbody/tr[" + i +
			 * "]/td[3]")).getText(); if (ele.equalsIgnoreCase(strMarket)) {
			 * WebElement ele2 =
			 * driver.findElement(By.xpath("//*[@id='Sess1']/tbody/tr[" + i +
			 * "]/td[1]/a")); MI_Setname = ele2.getText();
			 * actions.javaScriptClick(ele2); actions.smartWait(20); break; } }
			 */
			// Created Menu Item Add to Menu Item Set
			mcd.SwitchToWindow("#Title");
			actions.keyboardEnter("AddRemoveMenu.AddRemove");
			actions.waitForPageToLoad(20000);
			actions.smartWait(20);
			actions.setValue("CommonMenuItemSelector.SearchTextBox", strMenuNumber);
			actions.click("CopyComponents.SearchExactMatch");
			actions.keyboardEnter("AddRemoveMenu.Searchbtn2");
			actions.smartWait(20);
			Thread.sleep(5000);
			driver.findElement(By.xpath(".//input[@type = 'checkbox'][contains(@onclick, 'addMenuItem')]"))
					.sendKeys(Keys.SPACE);
			actions.keyboardEnter("AddRemoveMenu.Savebtn");
			Thread.sleep(12000);
			actions.waitForPageToLoad(10000);
			actions.verifyTextPresence(msg[1], true);

			// Search for Menu item number & Click on Menu item Number
			// Hyperlink.
			actions.setValue("ManageMenuItems.SearchText", strMenuNumber);
			actions.click("MenuItemSets.SearchButton");
			actions.smartWait(20);
			actions.waitForPageToLoad(10000);
			actions.keyboardEnter("MasterMenuItemList.NumberLink");
			actions.smartWait(20);
			actions.waitForPageToLoad(10000);

			// Click on Smart routing tab.
			actions.keyboardEnter("MasterMenuItemList.SmartRouting");
			actions.smartWait(15);
			actions.WaitForElementPresent("ManageMenuItems.OrderIngredientGroup");

			// Verify Fields in Smart Routing Tab
			// Verify the SmartRouting tab Fields
			String getValue3 = new Select(driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.CYTItem"))))
					.getFirstSelectedOption().getText();
			if (getValue3.contains("Select")) {
				actions.reportCreatePASS("Verify the CYT Item DropDown",
						"The CYT Item DropDown text should be default value Select",
						"The CYT Item text DropDown is default value Select", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the CYT Item DropDown",
						"The CYT Item text DropDown should be default value not Select",
						"The CYT Item text DropDown is default value not Select", "FAIL");
			}

			String getValue4 = new Select(
					driver.findElement(By.xpath(actions.getLocator("MasterMenuItemList.CYTIngType_R"))))
							.getFirstSelectedOption().getText();
			if (getValue4.contains("Select")) {
				actions.reportCreatePASS("Verify the CYT Ingredient Type DropDown",
						"The CYT Ingredient Type DropDown should be default value Select",
						"The CYT Ingredient Type DropDown is default value Select", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the CYT Ingredient Type DropDown",
						"The CYT Ingredient Type DropDown should be default value not Select",
						"The CYT Ingredient Type DropDown is default value not Select", "FAIL");
			}

			String getValue5 = new Select(
					driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.DeliveryEarly"))))
							.getFirstSelectedOption().getText();
			if (getValue5.contains("False")) {
				actions.reportCreatePASS("Verify the Delivery Early DropDown",
						"The Delivery Early DropDown should be default value FAIL",
						"The Delivery Early DropDown is default value FAIL", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the Delivery Early DropDown",
						"The Delivery Early DropDown should be default value FAIL",
						"The Delivery Early DropDown is not default value FAIL", "FAIL");
			}
			if (!actions.isElementEnabled("ManageMenuItems.SRIngredientGroup")) {
				actions.reportCreatePASS("Verify the Ingredient Group DropDown",
						"The Ingredient Group DropDown should be disabled", "The Ingredient Group DropDown is disabled",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify the Ingredient Group DropDown",
						"The Ingredient Group DropDown should be Enabled", "The Ingredient Group DropDown is enabled",
						"FAIL");
			}
			String getValue1 = driver.findElement(By.xpath(actions.getLocator("ManageMenuItems.OrderIngredientGroup")))
					.getAttribute("class");

			if (getValue1.contains("disableButton")) {
				actions.reportCreatePASS("Verify the OrderIngredientGroups button",
						"The OrderIngredientGroups button should be disabled",
						"The OrderIngredientGroups button is disabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the OrderIngredientGroups button",
						"The OrderIngredientGroups button should be Enabled",
						"The OrderIngredientGroups button is enabled", "FAIL");
			}

			String getValue2 = driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.AddTask")))
					.getAttribute("class");
			if (getValue2.contains("disableButton")) {
				actions.reportCreatePASS("Verify the Add Task button", "The Add Task button should be disabled",
						"The Add Task button is disabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the Add Task button", "The Add Task button should be Enabled",
						"The Add Task button is enabled", "FAIL");
			}

			if (!actions.isElementEnabled("MenuItemSets.CookTime")) {
				actions.reportCreatePASS("Verify the Ingredient Group DropDown",
						"The Ingredient Group DropDown should be disabled", "The Ingredient Group DropDown is disabled",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify the Ingredient Group DropDown",
						"The Ingredient Group DropDown should be Enabled", "The Ingredient Group DropDown is enabled",
						"FAIL");
			}
			if (!actions.isElementEnabled("MenuItemSets.PrepTime")) {
				actions.reportCreatePASS("Verify the Ingredient Group DropDown",
						"The Ingredient Group DropDown should be disabled", "The Ingredient Group DropDown is disabled",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify the Ingredient Group DropDown",
						"The Ingredient Group DropDown should be Enabled", "The Ingredient Group DropDown is enabled",
						"FAIL");
			}
			verifyTablecolumnsPresent("ManageMenuItem.SmartRoutingTaskTable", "Message Key");
			verifyTablecolumnsPresent("ManageMenuItem.SmartRoutingTaskTable", "Task Time\n(seconds)");
			verifyTablecolumnsPresent("ManageMenuItem.SmartRoutingTaskTable", "Display Time\n(seconds)");
			verifyTablecolumnsPresent("ManageMenuItem.SmartRoutingTaskTable", "Monitor");
			verifyTablecolumnsPresent("ManageMenuItem.SmartRoutingTaskTable", "Associate Ingredients");

			// Select "Customized Settings" option on right top corner
			rfm.SelectCustOrResetButton(msg[0], "MenuItemSets.Custbtn", "MenuItemSets.Resetbtn");
			actions.waitForPageToLoad(10000);
			actions.WaitForElementPresent("MenuItemSets.CookTime");

			// Enter Cook time & Dress/Prep Time as any value between 1 and
			// 9999.
			actions.setValue("MenuItemSets.CookTime", mcd.fn_GetRndNumInRange(01, 9999));
			actions.setValue("MenuItemSets.PrepTime", mcd.fn_GetRndNumInRange(01, 9999));

			// Click on Apply Button & Click on Now Radio Button
			actions.keyboardEnter("MenuItemSets.Savebtn");
			mcd.SwitchToWindow("Apply Changes Details");
			actions.waitForPageToLoad(10000);
			actions.keyboardEnter("MenuItemSets.ApplyChangeSave");
			Thread.sleep(2000);
			actions.waitForPageToLoad(20000);
			mcd.SwitchToWindow("@Manage Menu Items");
			actions.smartWait(20);
			actions.verifyTextPresence(msg[1], true);
			actions.smartWait(20);

			// Navigate to Home Page & Verify audit log for update
			boolean blnAudit_Update = rfm.VerifyAuditLog_Entry(strOperation, StrActivity, StrLevel);
			if (blnAudit_Update) {
				actions.reportCreatePASS("Verify Audit Log Entry for Update Menu Item List .",
						"Audit log should be generated for Menu Item List .",
						"Audit log generated for Update Menu Item List succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Entry for Update Menu Item List.",
						"Audit log should be generated for Update Menu Item List.",
						"Audit log not generated for Update Menu Item List succesfully", "FAIL");
			}

			String AuditDesc = "Menu Item " + strMenuNumber + " of Menu Item Set " + menuitemset + " has been updated.";
			// Verify audit login Details for Updated Manage Menu Item Set
			boolean blnAudit = RFM_VerifyAuditLog_Details(strDBName, strUserID, strOperation, StrActivity, StrLevel,
					StrLevedetails, AuditDesc);
			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Details for Update Master Menu Item List.",
						"Audit log details should be generated for Update Master Menu Item List.",
						"Audit log details generated for UpdateMaster Menu Item List succesfully", "PASS");
			} else {

				actions.reportCreateFAIL("Verify Audit Log Details for  Update Master Menu Item List .",
						"Audit log details should be generated for  Update Master Menu Item List..",
						"Audit log details not generated for  Update Master Menu Item List itemsuccesfully", "FAIL");
			}

			/*// Click on audit login report
			mcd.GetTableCellElement("RFMHomePage.AuditLog", "Operations", "Menu Item Sets", "", "", "Id", "a")
					.sendKeys(Keys.ENTER);
			mcd.waitAndSwitch("Manage Audit Log");

			actions.smartWait(120);
			actions.keyboardEnter("RFMHomePage.AuditLogDetailsOKButton");
			Thread.sleep(200);
			actions.smartWait(180);
			mcd.SwitchToWindow("RFM - Home");*/

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			// Reporter.log("Test Failed :: " + e.getCause() + " - " +
			// e.getMessage());
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}

	// Verify Table Header Fields
	public void verifyTablecolumnsPresent(String tableLocator, String colName) {

		boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

		if (iscolPresent) {
			actions.reportCreatePASS("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is present in table", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is NOT present in table",
					"Fail");
		}
	}

	public boolean RFM_VerifyAuditLog_Details(String strDBName, String strUserID, String strOperation,
			String strActivity, String strLevel, String strNodeName, String strDescription) throws Exception {
		boolean blnReturn = true;
		try {

			/**
			 * commenting the code for navigation as it has already on the home
			 * page & to get the audit log we no longer need to navigate again
			 */
			/*
			 * // Navigate to Home page
			 * actions.select_menu("RFMHomePage.MainMenu", "HOME");
			 * Thread.sleep(5000);
			 * actions.WaitForElementPresent("RFMHomePage.AuditLogDuration",
			 * 120); actions.waitForPageToLoad(130);
			 * 
			 * // Verify Page displayed mcd.VerifyPageTitle("RFM - Home");
			 */
			// Open Audit-Log details
			String AuditLogID = GetAuditLogID(strOperation);
			actions.keyboardEnter(
					mcd.GetTableCellElement("RFMHomePage.AuditLog", "Operations", strOperation, "", "", "Id", "a"));
			Thread.sleep(1000);
			mcd.waitAndSwitch("Manage Audit Log");

			/** Verify log details */
			blnReturn = blnReturn && mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#1", "Id :", "", "",
					"#2", AuditLogID, "", "", true);

			blnReturn = blnReturn && mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#1", "DB Name :", "",
					"", "#2", strDBName, "", "", true);

			blnReturn = blnReturn && mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#3", "User :", "", "",
					"#4", strUserID, "", "", false);

			blnReturn = blnReturn && mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#1", "Operation :", "",
					"", "#2", strOperation, "", "", true);

			blnReturn = blnReturn && mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#3", "Activity :", "",
					"", "#4", strActivity, "", "", true);

			blnReturn = blnReturn && mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#1", "Level :", "", "",
					"#2", strLevel, "", "", true);

			blnReturn = blnReturn && mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#3", "Level Details :",
					"", "", "#4", strNodeName, "", "", false);

			blnReturn = blnReturn && mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#1", "Description :",
					"", "", "#2", strDescription, "", "", true);

			// Verify Print &Save As CSV File Button is Present
			if (actions.isElementPresent("RFM.PrintBtn")) {
				actions.reportCreatePASS("Verify Print Button is Present", "Print Button should be Present",
						"Print Button is Present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Print Button is Present", "Print Button should not be Present",
						"Print Button is not Present", "FAIL");
			}
			if (actions.isElementPresent("RFM.SaveAsCSVBtn")) {
				actions.reportCreatePASS("Verify Save AS CSV File Button is Present",
						"Save AS CSV File Button should be Present", "Save AS CSV File Button is Present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Save AS CSV File Button is Present",
						"Save AS CSV File Button should not be Present", "Save AS CSV File Button is not Present",
						"FAIL");
			}
			
			/** Close Audit-Log window */
			actions.keyboardEnter("RFMHomePage.AuditLogDetailsOKButton");
			Thread.sleep(1000);
			// actions.windowSwitch(winHndManageAuditLog, "RFM - Home");
			mcd.SwitchToWindow("RFM - Home");

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return blnReturn;

	}

	public String GetAuditLogID(String strOperation) throws Exception {
		String strAuditLogID = "";
		try {
			/*
			 * // Navigate to Home page
			 * actions.select_menu("RFMHome.Navigation", "HOME");
			 * 
			 * //Selecting the Audit Log duration
			 * actions.WaitForElementPresent("RFMHomePage.AuditLogDuration",
			 * 120);
			 * 
			 * // Verify Page displayed mcd.VerifyPageTitle("RFM - Home");
			 * 
			 * //Selecting the Audit Log duration WebElement Element =
			 * driver.findElement(By.xpath(actions.getLocator(
			 * "RFMHomePage.AuditLogDuration"))); Select select = new
			 * Select(Element); select.selectByVisibleText("Today");
			 * 
			 * 
			 * 
			 * actions.setValue("RFMHomePage.AuditLogDuration", "Today");
			 * actions.WaitForElementPresent("RFMAuditLog.PPFirstRecord", 180);
			 */
			// Read Audit Log ID
			strAuditLogID = mcd.GetTableCellValue("RFMHomePage.AuditLog", "Operations", strOperation, "", "", "Id", "a",
					"");

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return strAuditLogID;
	}
}
