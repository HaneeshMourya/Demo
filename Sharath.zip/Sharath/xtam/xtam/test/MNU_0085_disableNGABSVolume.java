package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0085_disableNGABSVolume {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String tcDesc, strMenuItemName;

	public MNU_0085_disableNGABSVolume(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		tcDesc = mcd.GetTestData("DT_Description");
		strMenuItemName = mcd.GetTestData("DT_MenuItemName");
	}

	@Test
	public void MNU_0085_disableNGABSVolume() throws InterruptedException {
		String str = "Are you sure you want to Reset the Default values to the Menu Item?";

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(
					"Verify that ABS specific four fields enabled for either Regular Drink or Breakfast Drink family group");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			actions.smartWait(15);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			// Selecting menu item set and click on menu item set link
			String menuitemset_Name = driver.findElement(By.xpath("//*[@id='menuItemSetData']/tr[2]/td[1]/a"))
					.getText();

			// Verifying New Menu Item Set button
			if (actions.isElementPresent("MenuItemSet.NewMISbutton")) {
				actions.reportCreatePASS("Verify New Menu Item Set button", "New Menu Item Set button should present",
						"New Menu Item Set button is present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify New Menu Item Set button", "New Menu Item Set button should present",
						"New Menu Item Set button is NOT  present", "FAIL");
			}

			// Verifying filter list of Market
			if (!actions.isElementEnabled("MenuItemSets.Marketdrp")) {
				actions.reportCreatePASS("Verify Filter Market dropdown", "Filter Market dropdown should disable",
						"Filter Market dropdown is disable", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Filter Market dropdown", "Filter Market dropdown should disable",
						"Filter Market dropdown is NOT disable", "FAIL");
			}

			// Verifying Country drop down
			if (actions.isElementEnabled("ScreenSet.FilterListRegionDD")) {
				actions.reportCreatePASS("Verify Country drop down", "Country drop down should enable",
						"Country drop down is enable", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Country drop down", "Country drop down should enable",
						"Country drop down is not enable", "FAIL");
			}

			/*
			 * if(strMarket.equals("US Country Office")) {
			 * actions.isElementEnabled(sElement) actions.reportCreatePASS(
			 * "Verify Filter button", "Filter button should enable",
			 * "Filter button is enable", "PASS"); }else{
			 * actions.reportCreatePASS("Verify Filter button",
			 * "Filter button should enable", "Filter button is enable",
			 * "PASS"); }
			 * 
			 * 
			 * i
			 */

			// Verify table columns
			verifyTablecolumnsPresent("FieldPermissions.Table", "Name");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Node");
			
			actions.clear("MenuItemSets.SearchSetName");
			actions.setValue("MenuItemSets.SearchSetName", menuitemset_Name);
			List<WebElement> ele1 = driver.findElements(By.xpath("//*[@id='menuItemSetSearchForm_']"));
			actions.click(ele1.get(0));
			actions.smartWait(50);

			// Clicking on menu item set link
			WebElement Element = mcd.GetTableCellElement("MenuItemSets.Table", 1, "Name", "a");
			actions.keyboardEnter(Element);
			actions.smartWait(15);
			mcd.SwitchToWindow("#Title");

			// Select BREAKFAST_DRINK from family group drop down
			actions.setValue("MenuItemSets.FamilyFltr", "BREAKFAST_DRINK");
			actions.smartWait(50);
			Element = mcd.GetTableCellElement("MenuItemSets.Table", 1, "Number", "a");
			actions.keyboardEnter(Element);
			actions.smartWait(15);
			mcd.SwitchToWindow("#Title");

			
			//Click on ABS SEttings tab and verify all fields are disable
			actions.keyboardEnter("MenuItemSets.NavABStab");
			actions.smartWait(185);

			boolean flag;

			// Verify cup size field is disable
			if (!actions.isElementEnabled("MenuItemSets.BTABSCupsize")) {
				actions.reportCreatePASS("Verify the ABS Cup Size",
						"ABS Cup size should be disable as expected for family group breakfast drink",
						"ABS Cup size is disable as expected for family group breakfast drink", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the ABS Cup Size",
						"ABS Cup size should be disable as expected for family group breakfast drink",
						"ABS Cup size is not disable as expected for family group breakfast drink", "FAIL");

			}

			// Verify Flavor field is disable
			if (!actions.isElementEnabled("MenuItemSets.BTABSFlavor")) {
				actions.reportCreatePASS("Verify the Flavor",
						"flavor should be disable as expected for family group breakfast drink",
						"flavor is disable as expected for family group breakfast drink", "PASS");

			} else {

				actions.reportCreateFAIL("Verify the Flavor",
						"flavor should be disable as expected for family group breakfast drink",
						"flavor is not disable as expected for family group breakfast drink", "FAIL");
			}

			// Verify Ice Selection field is disable
			if (!actions.isElementEnabled("MenuItemSets.BTABSIceSelection")) {
				actions.reportCreatePASS("Verify the Ice Selection ",
						"IceSelection should be disable as expected for family group breakfast drink",
						"Ice Selection is disable as expected for family group breakfast drink", "PASS");
			} else {
				Reporter.log("'Fail'-IceSelection is disabled for family group breakfast drink");
				actions.reportCreateFAIL("Verify the Ice Selection ",
						"IceSelection should be disable as expected for family group breakfast drink",
						"Ice Selection is  not disable as expected for family group breakfast drink", "FAIL");
			}

			// Verify lid option field is disable
			if (!actions.isElementEnabled("MenuItemSets.BTABSLidoption")) {

				actions.reportCreatePASS("Verify the lid option",
						"Lid option should be disable as expected for family group breakfast drink",
						"Lid option is disable as expected for family group breakfast drink", "PASS");
			} else {

				actions.reportCreateFAIL("Verify the lid option",
						"Lid option should be disable as expected for family group breakfast drink",
						"Lid option is not disable as expected for family group breakfast drink", "FAIL");
			}

			
			// Verify NGABSVolume field is disable
			if (!actions.isElementEnabled("MenuItemSets.BTNGABSVolume")) {
				actions.reportCreatePASS("Verify the NGABSVolume",
						"NGABSVolume field should be disabled as expected at menu item set level",
						"NGABSVolume field is disabled as expected at menu item set level", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the NGABSVolume",
						"NGABSVolume field should be disabled as expected at menu item set level",
						"NGABSVolume field is not disabled as expected at menu item set level", "FAIL");
			}

			
			
			//Verifying Ice Product Definition field is disable
			if (!actions.isElementEnabled("ManageMenuItems.IceProduct")) {
				actions.reportCreatePASS("Verify the Ice Product Definition",
						"Ice Product Definition field should be disabled as expected at menu item set level",
						"Ice Product Definition field is disabled as expected at menu item set level", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the Ice Product Definition",
						"Ice Product Definition field should be disabled as expected at menu item set level",
						"Ice Product Definition field is not disabled as expected at menu item set level", "FAIL");
			}
			
			
			//if Reset to default button is there click on reset button or click on customize button 
			
			if (mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.Custbtn")) {

				actions.reportCreatePASS("Verify the customize setting button",
						"customize setting button should be displayed", "customize setting button is displayed",
						"PASS");
			} else {

				if (mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.Resetbtn")) {

					actions.javaScriptClick("MenuItemSets.Resetbtn");
					Thread.sleep(5000);
					mcd.VerifyAlertMessageDisplayed("Warning Message", str, true, AlertPopupButton.OK_BUTTON);
					Thread.sleep(2000);

					if (mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.Custbtn")) {
						actions.reportCreatePASS("Verify the customize setting button",
								"customize setting button should be displayed", "customize setting button is displayed",
								"PASS");
					} else {
						actions.reportCreateFAIL("Verify the customize setting button",
								"customize setting button should be displayed",
								"customize setting button is not displayed", "FAIL");
					}

				} else {
					actions.reportCreateFAIL("Verify the customize setting button",
							"customize setting button should be displayed", "customize setting button is not displayed",
							"FAIL");
				}
			}

			Thread.sleep(6000);
			actions.javaScriptClick("MenuItemSets.Custbtn");
			Thread.sleep(2000);

			
			//Verify Flavor, Cup Size, Lid Option, and Ice Selection attributes should be enabled.
			boolean flag1;

			// Verify cup size field is enable
			if (actions.isElementEnabled("MenuItemSets.BTABSCupsize")) {
				actions.reportCreatePASS("Verify the ABS Cup Size",
						"ABS Cup size should be enabled as expected for family group breakfast drink",
						"ABS Cup size is enabled as expected for family group breakfast drink", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the ABS Cup Size",
						"ABS Cup size should be enabled as expected for family group breakfast drink",
						"ABS Cup size is not enabled as expected for family group breakfast drink", "FAIL");

			}

			// Verify Flavor field is enable
			flag = driver.findElement(By.xpath(actions.getLocator("MenuItemSets.BTABSFlavor"))).isEnabled();
			if (flag) {
				actions.reportCreatePASS("Verify the Flavor",
						"flavor should be enabled as expected for family group breakfast drink",
						"flavor is enabled as expected for family group breakfast drink", "PASS");

			} else {

				actions.reportCreateFAIL("Verify the Flavor",
						"flavor should be enabled as expected for family group breakfast drink",
						"flavor is not enabled as expected for family group breakfast drink", "FAIL");
			}

			// Verify Ice Selection field is enable
			flag = driver.findElement(By.xpath(actions.getLocator("MenuItemSets.BTABSIceSelection"))).isEnabled();
			if (flag) {
				actions.reportCreatePASS("Verify the Ice Selection ",
						"IceSelection should be enabled as expected for family group breakfast drink",
						"Ice Selection is enabled as expected for family group breakfast drink", "PASS");
			} else {
				Reporter.log("'Fail'-IceSelection is disabled for family group breakfast drink");
				actions.reportCreateFAIL("Verify the Ice Selection ",
						"IceSelection should be enabled as expected for family group breakfast drink",
						"Ice Selection is  not enabled as expected for family group breakfast drink", "FAIL");
			}

			// Verify lid option field is enable
			flag = driver.findElement(By.xpath(actions.getLocator("MenuItemSets.BTABSLidoption"))).isEnabled();
			if (flag) {

				actions.reportCreatePASS("Verify the lid option",
						"Lid option should be enabled as expected for family group breakfast drink",
						"Lid option is enabled as expected for family group breakfast drink", "PASS");
			} else {

				actions.reportCreateFAIL("Verify the lid option",
						"Lid option should be enabled as expected for family group breakfast drink",
						"Lid option is not enabled as expected for family group breakfast drink", "FAIL");
			}

			
			// Verify NGABSVolume field is disabled
			if (!actions.isElementEnabled("MenuItemSets.BTNGABSVolume")) {
				actions.reportCreatePASS("Verify the NGABSVolume",
						"NGABSVolume field should be disabled as expected at menu item set level",
						"NGABSVolume field is disabled as expected at menu item set level", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the NGABSVolume",
						"NGABSVolume field should be disabled as expected at menu item set level",
						"NGABSVolume field is not disabled as expected at menu item set level", "FAIL");
			}

			
			//Verifying Ice Product Definition field is disable
			if (!actions.isElementEnabled("ManageMenuItems.IceProduct")) {
				actions.reportCreatePASS("Verify the Ice Product Definition",
						"Ice Product Definition field should be disabled as expected at menu item set level",
						"Ice Product Definition field is disabled as expected at menu item set level", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the Ice Product Definition",
						"Ice Product Definition field should be disabled as expected at menu item set level",
						"Ice Product Definition field is not disabled as expected at menu item set level", "FAIL");
			}
			
			actions.click("MenuItemSets.CompCancelbtn");
			actions.smartWait(15);
			
			
			
			//SELECTING REGULAT DRINK FROM FAMILY GROUP DROP DOWN
			
			// Select REGULAT DRINK from family group drop down
						actions.setValue("MenuItemSets.FamilyFltr", "REGULAR_DRINK");
						actions.smartWait(180);
						Element = mcd.GetTableCellElement("MenuItemSets.Table", 1, "Number", "a");
						actions.keyboardEnter(Element);
						actions.smartWait(15);
						mcd.SwitchToWindow("#Title");

						
						//Click on ABS SEttings tab and verify all fields are disable
						actions.keyboardEnter("MenuItemSets.NavABStab");
						actions.smartWait(185);

					//	boolean flag;

						// Verify cup size field is disable
						if (!actions.isElementEnabled("MenuItemSets.BTABSCupsize")) {
							actions.reportCreatePASS("Verify the ABS Cup Size",
									"ABS Cup size should be disable as expected for family group regular drink",
									"ABS Cup size is disable as expected for family group regular drink", "PASS");
						} else {
							actions.reportCreateFAIL("Verify the ABS Cup Size",
									"ABS Cup size should be disable as expected for family group regular drink",
									"ABS Cup size is not disable as expected for family group regular drink", "FAIL");

						}

						// Verify Flavor field is disable
						if (!actions.isElementEnabled("MenuItemSets.BTABSFlavor")) {
							actions.reportCreatePASS("Verify the Flavor",
									"flavor should be disable as expected for family group regular drink",
									"flavor is disable as expected for family group regular drink", "PASS");

						} else {

							actions.reportCreateFAIL("Verify the Flavor",
									"flavor should be disable as expected for family group regular drink",
									"flavor is not disable as expected for family group regular drink", "FAIL");
						}

						// Verify Ice Selection field is disable
					if (!actions.isElementEnabled("MenuItemSets.BTABSIceSelection")) {
							actions.reportCreatePASS("Verify the Ice Selection ",
									"IceSelection should be disable as expected for family group regular drink",
									"Ice Selection is disable as expected for family group regular drink", "PASS");
						} else {
							
							actions.reportCreateFAIL("Verify the Ice Selection ",
									"IceSelection should be disable as expected for family group regular drink",
									"Ice Selection is  not disable as expected for family group regular drink", "FAIL");
						}

						// Verify lid option field is disable
					if (!actions.isElementEnabled("MenuItemSets.BTABSLidoption")) {
							actions.reportCreatePASS("Verify the lid option",
									"Lid option should be disable as expected for family group regular drink",
									"Lid option is disable as expected for family group regular drink", "PASS");
						} else {

							actions.reportCreateFAIL("Verify the lid option",
									"Lid option should be disable as expected for family group regular drink",
									"Lid option is not disable as expected for family group regular drink", "FAIL");
						}

						
						// Verify NGABSVolume field is disable
						if (!actions.isElementEnabled("MenuItemSets.BTNGABSVolume")) {
							actions.reportCreatePASS("Verify the NGABSVolume",
									"NGABSVolume field should be disabled as expected at menu item set level",
									"NGABSVolume field is disabled as expected at menu item set level", "PASS");
						} else {
							actions.reportCreateFAIL("Verify the NGABSVolume",
									"NGABSVolume field should be disabled as expected at menu item set level",
									"NGABSVolume field is not disabled as expected at menu item set level", "FAIL");
						}

						
						
						//Verifying Ice Product Definition field is disable
						if (!actions.isElementEnabled("ManageMenuItems.IceProduct")) {
							actions.reportCreatePASS("Verify the Ice Product Definition",
									"Ice Product Definition field should be disabled as expected at menu item set level",
									"Ice Product Definition field is disabled as expected at menu item set level", "PASS");
						} else {
							actions.reportCreateFAIL("Verify the Ice Product Definition",
									"Ice Product Definition field should be disabled as expected at menu item set level",
									"Ice Product Definition field is not disabled as expected at menu item set level", "FAIL");
						}
						
						
						//if Reset to default button is there click on reset button or click on customize button 
						
						if (mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.Custbtn")) {

							actions.reportCreatePASS("Verify the customize setting button",
									"customize setting button should be displayed", "customize setting button is displayed",
									"PASS");
						} else {

							if (mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.Resetbtn")) {

								actions.javaScriptClick("MenuItemSets.Resetbtn");
								Thread.sleep(5000);
								mcd.VerifyAlertMessageDisplayed("Warning Message", str, true, AlertPopupButton.OK_BUTTON);
								Thread.sleep(2000);

								if (mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.Custbtn")) {
									actions.reportCreatePASS("Verify the customize setting button",
											"customize setting button should be displayed", "customize setting button is displayed",
											"PASS");
								} else {
									actions.reportCreateFAIL("Verify the customize setting button",
											"customize setting button should be displayed",
											"customize setting button is not displayed", "FAIL");
								}

							} else {
								actions.reportCreateFAIL("Verify the customize setting button",
										"customize setting button should be displayed", "customize setting button is not displayed",
										"FAIL");
							}
						}

						Thread.sleep(6000);
						actions.javaScriptClick("MenuItemSets.Custbtn");
						Thread.sleep(2000);

						
						//Verify Flavor, Cup Size, Lid Option, and Ice Selection attributes should be enabled.
						// Verify cup size field is enable
						if (actions.isElementEnabled("MenuItemSets.BTABSCupsize")) {
							actions.reportCreatePASS("Verify the ABS Cup Size",
									"ABS Cup size should be enabled as expected for family group regular drink",
									"ABS Cup size is enabled as expected for family group regular drink", "PASS");
						} else {
							actions.reportCreateFAIL("Verify the ABS Cup Size",
									"ABS Cup size should be enabled as expected for family group regular drink",
									"ABS Cup size is not enabled as expected for family group regular drink", "FAIL");

						}

						// Verify Flavor field is enable
						flag = driver.findElement(By.xpath(actions.getLocator("MenuItemSets.BTABSFlavor"))).isEnabled();
						if (flag) {
							actions.reportCreatePASS("Verify the Flavor",
									"flavor should be enabled as expected for family group regular drink",
									"flavor is enabled as expected for family group regular drink", "PASS");

						} else {

							actions.reportCreateFAIL("Verify the Flavor",
									"flavor should be enabled as expected for family group regular drink",
									"flavor is not enabled as expected for family group regular drink", "FAIL");
						}

						// Verify Ice Selection field is enable
						flag = driver.findElement(By.xpath(actions.getLocator("MenuItemSets.BTABSIceSelection"))).isEnabled();
						if (flag) {
							actions.reportCreatePASS("Verify the Ice Selection ",
									"IceSelection should be enabled as expected for family group regular drink",
									"Ice Selection is enabled as expected for family group regular drink", "PASS");
						} else {
							
							actions.reportCreateFAIL("Verify the Ice Selection ",
									"IceSelection should be enabled as expected for family group regular drink",
									"Ice Selection is  not enabled as expected for family group regular drink", "FAIL");
						}

						// Verify lid option field is enable
						flag = driver.findElement(By.xpath(actions.getLocator("MenuItemSets.BTABSLidoption"))).isEnabled();
						if (flag) {

							actions.reportCreatePASS("Verify the lid option",
									"Lid option should be enabled as expected for family group regular drink",
									"Lid option is enabled as expected for family group regular drink", "PASS");
						} else {

							actions.reportCreateFAIL("Verify the lid option",
									"Lid option should be enabled as expected for family group regular drink",
									"Lid option is not enabled as expected for family group regular drink", "FAIL");
						}

						// MNU_0085-Verify that NGABSVolume is not customized at Menu Item
						// Set level.

						// Verify NGABSVolume field is disabled
						if (!actions.isElementEnabled("MenuItemSets.BTNGABSVolume")) {
							actions.reportCreatePASS("Verify the NGABSVolume",
									"NGABSVolume field should be disabled as expected at menu item set level",
									"NGABSVolume field is disabled as expected at menu item set level", "PASS");
						} else {
							actions.reportCreateFAIL("Verify the NGABSVolume",
									"NGABSVolume field should be disabled as expected at menu item set level",
									"NGABSVolume field is not disabled as expected at menu item set level", "FAIL");
						}

						
						//Verifying Ice Product Definition field is disable
						if (!actions.isElementEnabled("ManageMenuItems.IceProduct")) {
							actions.reportCreatePASS("Verify the Ice Product Definition",
									"Ice Product Definition field should be disabled as expected at menu item set level",
									"Ice Product Definition field is disabled as expected at menu item set level", "PASS");
						} else {
							actions.reportCreateFAIL("Verify the Ice Product Definition",
									"Ice Product Definition field should be disabled as expected at menu item set level",
									"Ice Product Definition field is not disabled as expected at menu item set level", "FAIL");
						}
						
						actions.click("MenuItemSets.CompCancelbtn");
						actions.smartWait(15);
			
			
						
		//SELECT OPTION OTHER THAN  BREAKFAST DRINK AND REGULAR DRINK IN FAMILY GROUP DDL		
		
						// Select REGULAT DRINK from family group drop down
						actions.setValue("MenuItemSets.FamilyFltr", "FRIES");
						actions.smartWait(15);
						Element = mcd.GetTableCellElement("MenuItemSets.Table", 1, "Number", "a");
						actions.keyboardEnter(Element);
						actions.smartWait(15);
						mcd.SwitchToWindow("#Title");
						
						//Verifying General setting,component,Pos/KVS  setting ,Presentation ,component,parameter,Abc tabs  should display
						
						//General setting 
						if(actions.isElementPresent("ManageMenuItemCurrentMenuItemDetails.GeneralSettings"))
						{
							actions.reportCreatePASS("Verify General setting tab ",
									"General setting tab  should be present",
									"General setting  tab is displayed", "PASS");
							
						}else{
							actions.reportCreateFAIL("Verify General setting tab ",
									"General setting tab  should be present",
									"General setting  tab is not displayed", "FAIL");
						}
						
						//POS/KVS Settings
						if(actions.isElementPresent("RestMIList.POSKVStab"))
						{
							actions.reportCreatePASS("Verify POS/KVS Settings tab ",
									"POS/KVS Settings tab  should be present",
									"POS/KVS Settings  tab is displayed", "PASS");
							
						}else{
							actions.reportCreateFAIL("Verify POS/KVS Settings tab ",
									"POS/KVS Settings tab  should be present",
									"POS/KVS Settings  tab is not displayed", "FAIL");
						}
						
						//Presentation Settings
						if(actions.isElementPresent("RestMIList.PresentationTab"))
						{
							actions.reportCreatePASS("Verify Presentation Settings tab ",
									"Presentation Settings tab  should be present",
									"Presentation Settings  tab is displayed", "PASS");
							
						}else{
							actions.reportCreateFAIL("Verify Presentation Settings tab ",
									"Presentation Settings tab  should be present",
									"Presentation Settings  tab is not displayed", "FAIL");
						}
						

						//Components
						if(actions.isElementPresent("RFMMMIL.ComponentTab"))
						{
							actions.reportCreatePASS("Verify Components tab ",
									"Components tab  should be present",
									"Components  tab is displayed", "PASS");
							
						}else{
							actions.reportCreateFAIL("Verify Components tab ",
									"Components tab  should be present",
									"Components  tab is not displayed", "FAIL");
						}
						
						//	Parameters 
						if(actions.isElementPresent("ManageMenuItems.Parameters"))
						{
							actions.reportCreatePASS("Verify Parameters tab ",
									"Parameters tab  should be present",
									"Parameters  tab is displayed", "PASS");
							
						}else{
							actions.reportCreateFAIL("Verify Parameters tab ",
									"Parameters tab  should be present",
									"Parameters  tab is not displayed", "FAIL");
						}
						
						String apply_bn=driver.findElement(By.xpath(actions.getLocator("RFMMMIL.Applybtn"))).getAttribute("class");
						if(apply_bn.contains("disabled"))
						{
							actions.reportCreatePASS("Verify Apply button", "Apply button should displye", "Apply button is disable", "PASS");
						}else{
							actions.reportCreateFAIL("Verify Apply button", "Apply button should displye", "Apply button is not  disable", "FAIL");
						}
						//Click on ABS SEttings tab and verify all fields are disable
						actions.keyboardEnter("MenuItemSets.NavABStab");
						actions.smartWait(185);

					//	boolean flag;

						// Verify cup size field is disable
						if (!actions.isElementEnabled("MenuItemSets.BTABSCupsize")) {
							actions.reportCreatePASS("Verify the ABS Cup Size",
									"ABS Cup size should be disable as expected for family group fries",
									"ABS Cup size is disable as expected for family group fries", "PASS");
						} else {
							actions.reportCreateFAIL("Verify the ABS Cup Size",
									"ABS Cup size should be disable as expected for family group fries",
									"ABS Cup size is not disable as expected for family group fries", "FAIL");

						}

						// Verify Flavor field is disable
						if (!actions.isElementEnabled("MenuItemSets.BTABSFlavor")) {
							actions.reportCreatePASS("Verify the Flavor",
									"flavor should be disable as expected for family group fries",
									"flavor is disable as expected for family group fries", "PASS");

						} else {

							actions.reportCreateFAIL("Verify the Flavor",
									"flavor should be disable as expected for family group fries",
									"flavor is not disable as expected for family group fries", "FAIL");
						}

						// Verify Ice Selection field is disable
					if (!actions.isElementEnabled("MenuItemSets.BTABSIceSelection")) {
							actions.reportCreatePASS("Verify the Ice Selection ",
									"IceSelection should be disable as expected for family group fries",
									"Ice Selection is disable as expected for family group fries", "PASS");
						} else {
							Reporter.log("'Fail'-IceSelection is disabled for family group breakfast drink");
							actions.reportCreateFAIL("Verify the Ice Selection ",
									"IceSelection should be disable as expected for family group fries",
									"Ice Selection is  not disable as expected for family group fries", "FAIL");
						}

						// Verify lid option field is disable
						if (!actions.isElementEnabled("MenuItemSets.BTABSLidoption")) {
							actions.reportCreatePASS("Verify the lid option",
									"Lid option should be disable as expected for family group fries",
									"Lid option is disable as expected for family group fries", "PASS");
						} else {

							actions.reportCreateFAIL("Verify the lid option",
									"Lid option should be disable as expected for family group fries",
									"Lid option is not disable as expected for family group fries", "FAIL");
						}

						

						// Verify NGABSVolume field is disable
						if (!actions.isElementEnabled("MenuItemSets.BTNGABSVolume")) {
							actions.reportCreatePASS("Verify the NGABSVolume",
									"NGABSVolume field should be disabled as expected at menu item set level",
									"NGABSVolume field is disabled as expected at menu item set level", "PASS");
						} else {
							actions.reportCreateFAIL("Verify the NGABSVolume",
									"NGABSVolume field should be disabled as expected at menu item set level",
									"NGABSVolume field is not disabled as expected at menu item set level", "FAIL");
						}

						
						
						//Verifying Ice Product Definition field is disable
						if (!actions.isElementEnabled("ManageMenuItems.IceProduct")) {
							actions.reportCreatePASS("Verify the Ice Product Definition",
									"Ice Product Definition field should be disabled as expected at menu item set level",
									"Ice Product Definition field is disabled as expected at menu item set level", "PASS");
						} else {
							actions.reportCreateFAIL("Verify the Ice Product Definition",
									"Ice Product Definition field should be disabled as expected at menu item set level",
									"Ice Product Definition field is not disabled as expected at menu item set level", "FAIL");
						}
						
						
						
						
					/*	
						
						//if Reset to default button is there click on reset button or click on customize button 
						
						if (mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.Custbtn")) {

							actions.reportCreatePASS("Verify the customize setting button",
									"customize setting button should be displayed", "customize setting button is displayed",
									"PASS");
						} else {

							if (mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.Resetbtn")) {

								actions.javaScriptClick("MenuItemSets.Resetbtn");
								Thread.sleep(5000);
								mcd.VerifyAlertMessageDisplayed("Warning Message", str, true, AlertPopupButton.OK_BUTTON);
								Thread.sleep(2000);

								if (mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.Custbtn")) {
									actions.reportCreatePASS("Verify the customize setting button",
											"customize setting button should be displayed", "customize setting button is displayed",
											"PASS");
								} else {
									actions.reportCreateFAIL("Verify the customize setting button",
											"customize setting button should be displayed",
											"customize setting button is not displayed", "FAIL");
								}

							} else {
								actions.reportCreateFAIL("Verify the customize setting button",
										"customize setting button should be displayed", "customize setting button is not displayed",
										"FAIL");
							}
						}

						Thread.sleep(6000);
						actions.javaScriptClick("MenuItemSets.Custbtn");
						Thread.sleep(2000);

						
						//Verify Flavor, Cup Size, Lid Option, and Ice Selection attributes should be enabled.
					//	boolean flag1;

						// Verify cup size field is enable
						if (actions.isElementEnabled("MenuItemSets.BTABSCupsize")) {
							actions.reportCreatePASS("Verify the ABS Cup Size",
									"ABS Cup size should be enabled as expected for family group breakfast drink",
									"ABS Cup size is enabled as expected for family group breakfast drink", "PASS");
						} else {
							actions.reportCreateFAIL("Verify the ABS Cup Size",
									"ABS Cup size should be enabled as expected for family group breakfast drink",
									"ABS Cup size is not enabled as expected for family group breakfast drink", "FAIL");

						}

						// Verify Flavor field is enable
						flag = driver.findElement(By.xpath(actions.getLocator("MenuItemSets.BTABSFlavor"))).isEnabled();
						if (flag) {
							actions.reportCreatePASS("Verify the Flavor",
									"flavor should be enabled as expected for family group breakfast drink",
									"flavor is enabled as expected for family group breakfast drink", "PASS");

						} else {

							actions.reportCreateFAIL("Verify the Flavor",
									"flavor should be enabled as expected for family group breakfast drink",
									"flavor is not enabled as expected for family group breakfast drink", "FAIL");
						}

						// Verify Ice Selection field is enable
						flag = driver.findElement(By.xpath(actions.getLocator("MenuItemSets.BTABSIceSelection"))).isEnabled();
						if (flag) {
							actions.reportCreatePASS("Verify the Ice Selection ",
									"IceSelection should be enabled as expected for family group breakfast drink",
									"Ice Selection is enabled as expected for family group breakfast drink", "PASS");
						} else {
							Reporter.log("'Fail'-IceSelection is disabled for family group breakfast drink");
							actions.reportCreateFAIL("Verify the Ice Selection ",
									"IceSelection should be enabled as expected for family group breakfast drink",
									"Ice Selection is  not enabled as expected for family group breakfast drink", "FAIL");
						}

						// Verify lid option field is enable
						flag = driver.findElement(By.xpath(actions.getLocator("MenuItemSets.BTABSLidoption"))).isEnabled();
						if (flag) {

							actions.reportCreatePASS("Verify the lid option",
									"Lid option should be enabled as expected for family group breakfast drink",
									"Lid option is enabled as expected for family group breakfast drink", "PASS");
						} else {

							actions.reportCreateFAIL("Verify the lid option",
									"Lid option should be enabled as expected for family group breakfast drink",
									"Lid option is not enabled as expected for family group breakfast drink", "FAIL");
						}

						// MNU_0085-Verify that NGABSVolume is not customized at Menu Item
						// Set level.

						// Verify NGABSVolume field is disabled
						if (!actions.isElementEnabled("MenuItemSets.BTNGABSVolume")) {
							actions.reportCreatePASS("Verify the NGABSVolume",
									"NGABSVolume field should be disabled as expected at menu item set level",
									"NGABSVolume field is disabled as expected at menu item set level", "PASS");
						} else {
							actions.reportCreateFAIL("Verify the NGABSVolume",
									"NGABSVolume field should be disabled as expected at menu item set level",
									"NGABSVolume field is not disabled as expected at menu item set level", "FAIL");
						}

						
						//Verifying Ice Product Definition field is disable
						if (!actions.isElementEnabled("ManageMenuItems.IceProduct")) {
							actions.reportCreatePASS("Verify the Ice Product Definition",
									"Ice Product Definition field should be disabled as expected at menu item set level",
									"Ice Product Definition field is disabled as expected at menu item set level", "PASS");
						} else {
							actions.reportCreateFAIL("Verify the Ice Product Definition",
									"Ice Product Definition field should be disabled as expected at menu item set level",
									"Ice Product Definition field is not disabled as expected at menu item set level", "FAIL");
						}				*/
						

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}

	// VERIFYING TABLE COLUMS CODE
	public void verifyTablecolumnsPresent(String tableLocator, String colName) {

		boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

		if (iscolPresent) {
			actions.reportCreatePASS("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is present in table", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is NOT present in table",
					"Fail");
		}
	}
}
