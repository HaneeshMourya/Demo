package xtam.test;

import java.util.Map;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.CSVValidations;

public class MNU_20499_UpdateRestPro {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private CSVValidations csv;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;

	private String strNavigateToReport, strNavigateToView, strNavigateToAdmin, strNavigateToHOME, strNavigateToQM;
	private String strDBName, strUserID, strOperation, strActivity, strLevel, strNodeName, strDescription,
			strSuccessMsg;
	boolean AuditEntry;
	String AuditDesc;
	boolean AuditDetail;

	private String strWM1;

	public MNU_20499_UpdateRestPro(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		csv = new CSVValidations();

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");

		strDBName = mcd.GetTestData("DT_DB_NAME");
		strUserID = mcd.GetTestData("DT_USER_ID");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strActivity = mcd.GetTestData("DT_ACTIVITY");
		strLevel = mcd.GetTestData("DT_LEVEL");
		strNodeName = mcd.GetTestData("DT_NODE_NAME");

		strWM1 = mcd.GetTestData("WarningMessage1");

	}

	@Test
	public void test_MNU_20499_UpdateRestPro() throws InterruptedException {
		String strPageTitle = "Restaurant Profile";
		String strPageSubHeading = "Restaurant Profile";

		try {
			System.out
					.println("********************************************************************** Test execution starts");

			actions.setTestcaseDescription("Update smart reminder set in restaurant profile and Verify the audit log");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
			actions.waitForPageToLoad(180);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);

			Thread.sleep(4000);
			actions.waitForPageToLoad(120);
			/** Verify Page Header */
			System.out.println("> Verify Page Heading");
			mcd.VerifyPageTitle(strPageTitle);

			/** Update title of new Page */
			mcd.waitAndSwitch("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow

			// actions.WaitForElementPresent("RFMHome.ViewFullList", 100);

			/** Click on View Full List */
			// actions.keyboardEnter("RFMHome.ViewFullList");
			// actions.smartWait(100);

			// Restaurant full list is displayed by default hence commmented above code.
			/** Get the Table First Value */
			String strRandName = driver.findElement(By.xpath(actions.getLocator("RestaurantProfile.TableFirstData")))
					.getText();
			System.out.println(strRandName);

			/** Click on Table First Data */
			actions.click("RestaurantProfile.TableFirstData");
			actions.smartWait(100);

			actions.WaitForElementPresent("RestaurantProfile.OperationalDetails", 100);

			/** Click on Operational Details */
			actions.keyboardEnter("RestaurantProfile.OperationalDetails");
			actions.smartWait(1000);
			actions.waitForPageToLoad(2000);

			/** Select Value from Smart Reminder Dropdown */
			Select dropdown = new Select(driver.findElement(By.xpath(actions
					.getLocator("RestaurantProfile.SmartReminderDDL"))));

			dropdown.selectByIndex(1);
			actions.smartWait(10000);
			actions.waitForPageToLoad(2000);

			/** Click on Smart Reminder View/Edit */
			actions.click("RestaurantProfile.SmartReminderViewEdit");

			/** Switch Window */
			mcd.SwitchToWindow("Smart Reminder");

			actions.WaitForElementPresent("RestaurantProfile.SmartReminderCustBtn", 100);

			/** Click on Smart Reminder Customer Button */
			actions.keyboardEnter("RestaurantProfile.SmartReminderCustBtn");

			try {
				mcd.VerifyAlertMessageDisplayed("Warning Message", strWM1, true, AlertPopupButton.OK_BUTTON);

				actions.smartWait(100);

				actions.keyboardEnter("RestaurantProfile.SmartReminderCustBtn");
			} catch (Exception err) {
			}

			/** Get Smart Reminder First Data Question Value */
			String strValue = driver.findElement(
					By.xpath(actions.getLocator("RestaurantProfile.SmartReminderFirstDataQuestion"))).getAttribute(
					"value");
			System.out.println(strValue);

			strValue = strValue + 1;

			System.out.println(strValue);

			/** Clear Smart Reminder First Data Question */
			actions.clear("RestaurantProfile.SmartReminderFirstDataQuestion");

			/** Set Value in Smart Reminder First Data Question */
			actions.setValue("RestaurantProfile.SmartReminderFirstDataQuestion", strValue);

			/** Click on Apply */
			actions.keyboardEnter("RestaurantProfile.Apply");

			try {
				mcd.VerifyAlertMessageDisplayed("Confirmation",
						"Are you sure you want to save changes to the current settings?", true,
						AlertPopupButton.OK_BUTTON);
			} catch (Exception e) {
			}
			Thread.sleep(5000);
			/** Switch Window */

			try {
				boolean applyChangeSwitch = mcd.SwitchToWindow("Apply Changes Details");
				if (applyChangeSwitch) {
					actions.keyboardEnter("RFMHome.Save");
					actions.waitForPageToLoad(1000);
					mcd.SwitchToWindow("Smart Reminder");
					Thread.sleep(5000);
				}

			} catch (Exception err) {
				System.out.println(err);
				Thread.sleep(5000);
				if (driver.switchTo().window(driver.getWindowHandle()).getTitle()
						.equalsIgnoreCase("Restaurant Profile")) {
					driver.switchTo().window(driver.getWindowHandle());
					System.out.println(driver.switchTo().window(driver.getWindowHandle()).getTitle());
					for (String winHandle : driver.getWindowHandles()) {
						driver.switchTo().window(winHandle);
						System.out.println(driver.switchTo().window(driver.getWindowHandle()).getTitle());
					}
				}

			}

			/** Click on Save */

			/** Switch Window */

			/** Click on Cancel */
			actions.keyboardEnter("RFMHome.Cancel");
			try {
				mcd.VerifyAlertMessageDisplayed("Confirmation",
						"Are you sure you want to save changes to the current settings?", true,
						AlertPopupButton.OK_BUTTON);
			} catch (Exception e) {
			}
			Thread.sleep(5000);
			actions.waitForPageToLoad(1000);
			/** Switch Window */
			mcd.SwitchToWindow("Restaurant Profile");

			Thread.sleep(3000);

			// Navigate to Home page
			actions.select_menu("RFMHome.Navigation", "HOME");

			actions.smartWait(180);
			actions.waitForPageToLoad(1000);
			Thread.sleep(8000);
			/** Audit Log */
			AuditEntry = VerifyAuditLog_Entry(strOperation, strActivity, strLevel);
			System.out.println(AuditEntry);
			AuditDesc = "Queue Side [" + strRandName + "] has been created.";
			AuditDetail = RFM_VerifyAuditLog_Details(strDBName, strUserID, strOperation, strActivity, strLevel,
					strNodeName, AuditDesc);
			System.out.println(AuditDetail);

			// Verify Audit Log ID in CSV file for Create operation
			String AuditLogIdD = rfm.GetAuditLogID(strOperation);
			mcd.GetTableCellElement("RFMHomePage.AuditLog", "Operations", strOperation, "", "", "Id", "a").sendKeys(
					Keys.ENTER);
			Thread.sleep(1000);
			mcd.waitAndSwitch("Manage Audit Log");
			VerifyAuditLogPrint();
			VerifyAuditLogCSV(AuditLogIdD, "Create");

			// ------------------------------------------------------------------------

			/** Logout the application */
			driver.switchTo().window("");
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}

	}

	public boolean RFM_VerifyAuditLog_Details(String strDBName, String strUserID, String strOperation,
			String strActivity, String strLevel, String strNodeName, String strDescription) throws Exception {
		boolean blnReturn = true;
		try {

			/**
			 * commenting the code for navigation as it has already on the home
			 * page & to get the audit log we no longer need to navigate again
			 */
			/*
			 * // Navigate to Home page
			 * actions.select_menu("RFMHomePage.MainMenu", "HOME");
			 * Thread.sleep(5000);
			 * actions.WaitForElementPresent("RFMHomePage.AuditLogDuration",
			 * 120); actions.waitForPageToLoad(130);
			 * 
			 * // Verify Page displayed mcd.VerifyPageTitle("RFM - Home");
			 */
			// Open Audit-Log details
			String AuditLogID = rfm.GetAuditLogID(strOperation);
			mcd.GetTableCellElement("RFMHomePage.AuditLog", "Operations", strOperation, "", "", "Id", "a").click();
			/*
			 * WebElement auditData=
			 * mcd.GetTableCellElement("RFMHomePage.AuditLog", "Operations",
			 * strOperation, "", "", "Id", "a"); auditData.click();
			 */
			Thread.sleep(1000);
			mcd.waitAndSwitch("Manage Audit Log");

			/** Verify log details */
			blnReturn = blnReturn
					&& mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#1", "Id :", "", "", "#2",
							AuditLogID, "", "", true);

			blnReturn = blnReturn
					&& mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#1", "DB Name :", "", "", "#2",
							strDBName, "", "", true);

			blnReturn = blnReturn
					&& mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#3", "User :", "", "", "#4",
							strUserID, "", "", false);

			blnReturn = blnReturn
					&& mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#1", "Operation :", "", "", "#2",
							strOperation, "", "", true);

			blnReturn = blnReturn
					&& mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#3", "Activity :", "", "", "#4",
							strActivity, "", "", true);

			blnReturn = blnReturn
					&& mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#1", "Level :", "", "", "#2",
							strLevel, "", "", true);

			blnReturn = blnReturn
					&& mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#3", "Level Details :", "", "",
							"#4", strNodeName, "", "", false);

			blnReturn = blnReturn
					&& mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#1", "Description :", "", "", "#2",
							strDescription, "", "", true);

			/** Close Audit-Log window */
			actions.keyboardEnter("RFMHomePage.AuditLogDetailsOKButton");
			Thread.sleep(1000);
			// actions.windowSwitch(winHndManageAuditLog, "RFM - Home");
			mcd.SwitchToWindow("RFM - Home");

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return blnReturn;

	}

	public boolean VerifyAuditLog_Entry(String strOperation, String strExptActivityValue, String strExptLevelValue)
			throws Exception {
		boolean blnReturn = false;
		try {

			// Navigate to Home page
			actions.select_menu("RFMHome.Navigation", "HOME");
			actions.WaitForElementPresent("RFMHomePage.AuditLogDuration", 120);
			actions.waitForPageToLoad(120);

			Thread.sleep(5000);
			// Verify Page displayed
			mcd.VerifyPageTitle("RFM - Home");
			// Selecting the Audit Log duration

			actions.setValue("RFMHomePage.AuditLogDuration", "Today");

			actions.WaitForElementPresent("RFMAuditLog.PPFirstRecord", 180);

			// Verify values
			blnReturn = mcd.VerifyTableColumnValues("RFMHomePage.AuditLog", "Operations", strOperation, "", "",
					"Activities|Level", strExptActivityValue + "|" + strExptLevelValue, "|", "|", false);

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return blnReturn;
	}

	// Functions to Verify Audit log functionality for Print and Save as CSV
	// File

	public void VerifyAuditLogPrint() {

		// Click print button, Print popup should be displayed
		try {

			WebElement printBtn = driver.findElement(By.xpath("//a[contains(text(),'Print')]"));
			actions.keyboardEnter(printBtn);
			Thread.sleep(5000);
			Alert myAlert = driver.switchTo().alert();
			Thread.sleep(2000);
			actions.reportCreatePASS("Click Print button", "Print Window should be displayed.",
					"Print Window is displayed.", "PASS");
			myAlert.dismiss();

		} catch (Exception error1) {
			System.out.println("Print Alert is not displayed");
		}

	}

	public void VerifyAuditLogCSV(String AuditLogId, String strOperation) {

		// Click Save as CSV file button and verify that Audit log Id is
		// displayed in CSV
		try {
			WebElement SaveCSVBtn = driver.findElement(By.xpath("//a[contains(text(),'Save as CSV File')]"));
			actions.javaScriptClick(SaveCSVBtn);
			Thread.sleep(3000);

			// actions.ieDownload();
			// Thread.sleep(3000);

			WebElement OKBtn = driver.findElement(By.xpath("//a[contains(text(),'OK')]"));
			actions.javaScriptClick(OKBtn);

			String targetData = "{\"Id\":\"" + AuditLogId + "\"}";

			boolean csvFlag = csv.validateColumnsData("AuditLogDetail.CSV", "Id", AuditLogId, targetData, false, true);

			System.out.println("CSV field validation = " + csvFlag);

			if (csvFlag)
				actions.reportCreatePASS("Verify AuditLogDetail.CSV file for " + strOperation + " operation.",
						"Auditlog Id should be displayed in CSV file.", "Auditlog Id is displayed in CSV file.", "PASS");
			else
				actions.reportCreateFAIL("Verify AuditLogDetail.CSV file for " + strOperation + " operation.",
						"Auditlog Id should be displayed in CSV file.", "Auditlog Id is not displayed in CSV file.",
						"FALSE");

			mcd.waitAndSwitch("@RFM - Home");
		} catch (Exception error2) {
			System.out.println("Failed to verify CSV file...");
		}

	}

}
