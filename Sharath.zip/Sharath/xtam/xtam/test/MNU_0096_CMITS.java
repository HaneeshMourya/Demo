package xtam.test;

import java.util.Map;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import crossbrowser.library.Keywords;
import crossbrowser.library.PackageValidation;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.Keywords.DialogType;
import crossbrowser.library.XMLValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0096_CMITS {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private XMLValidations xmlValidation;
	private PackageValidation pkg;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strprotype, pro_type[], strMIrange, strmsg, strmenutype;
	// TODO: Declare test-data variables for other data-parameters

	public MNU_0096_CMITS(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		pkg = new PackageValidation(driver, actions, uiActions, inputData, mcd, rfm);
		xmlValidation = new XMLValidations();

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strprotype = mcd.GetTestData("DT_MENUITEMCLASS");
		strMIrange = mcd.GetTestData("DT_MIRANGE");
		strmsg = mcd.GetTestData("DT_ERR_MSG");
		strmenutype = mcd.GetTestData("DT_MIPARAM");
		// TODO: GetTestData for other data-parameters
		pro_type = strprotype.split("#");
	}

	@Test
	public void test_MNU_0096_CMITS() throws InterruptedException {
		String strPageTitle = ""; // TODO: Exact page-title
		String strPageSubHeading = ""; // TODO: Page Heading

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// calling the create Menu item function
			int RAWITEM = RFM_MI_CreateMenuItem_updated(strMIrange, pro_type[0], strmsg, strmenutype);
			actions.reportCreatePASS("Verify that Menu item is created or not",
					"Menu Item number-" + RAWITEM + " of Class-" + pro_type[0] + " should get created ",
					"Menu Item number-" + RAWITEM + " of Class-" + pro_type[0] + " created succesfully", "Pass");
			// Create menu item  product 
			int Product = RFM_MI_CreateProductMenuItem_updated(strMIrange, pro_type[1], strmsg, strmenutype);
			actions.reportCreatePASS("Verify that Menu item is created or not",
					"Menu Item number-" + Product + " of Class-" + pro_type[1] + " should get created ",
					"Menu Item number-" + Product + " of Class-" + pro_type[1] + " created succesfully", "Pass");
			// create menu item check category
			int Check = RFM_MI_CreateProductMenuItem_updated(strMIrange, pro_type[2], strmsg, strmenutype);
			actions.reportCreatePASS("Verify that Menu item is created or not",
					"Menu Item number-" + Check + " of Class-" + pro_type[2] + " should get created ",
					"Menu Item number-" + Check + " of Class-" + pro_type[2] + " created succesfully", "Pass");

			// calling the create Menu item function
			int menuitem = RFM_MI_CreatecopyexistingMenuItem_updated(strMIrange, pro_type[2], strmsg, strmenutype);
			actions.reportCreatePASS("Verify that Menu item is created or not",
					"Menu Item number-" + menuitem + " of Class-" + pro_type[2] + " should get created ",
					"Menu Item number-" + menuitem + " of Class-" + pro_type[2]
							+ " created with copy settings from existing  succesfully",
					"Pass");

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	public int RFM_MI_CreateMenuItem_updated(String MIrange, String pro_type, String strmsg, String strmenutype) {
		boolean blnflag = false;
		String[] strparam = strmenutype.split("#");
		String[] strrange = MIrange.split("#");
		String strerrmsg[] = strmsg.split("#");
		String s = "";
		int mi_num = 0, mi_start = 0, mi_end = 0;
		try {
			boolean flag = false;

			System.out.println(
					"********************************************************************** Start Test-Steps executions");

			// String MainWindow_NewMenuItem = driver.getWindowHandle();
			WebElement ws = driver.findElement(By.xpath("//*[@class='button button'][contains(text(),'Add New')]"));
			actions.click(ws);

			// actions.windowSwitch(MainWindow_NewMenuItem,"Add New Menu Item");
			mcd.SwitchToWindow("Add New Menu Item");

			switch (pro_type) {
			case "CONTAINER_VALUE_MEAL":
				s = "Auto_CVM_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "PRODUCT":
				s = "Auto_Pro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "VALUE_MEAL":
				s = "Auto_VM_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "CHOICE":
				s = "Auto_Choice_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[0]);
				mi_end = Integer.parseInt(strrange[1]);
				break;
			case "CHOICE_EVM":
				s = mcd.fn_GetRndName("Auto_ChoiceEVM");
				mi_start = Integer.parseInt(strrange[0]);
				mi_end = Integer.parseInt(strrange[1]);
				break;
			case "CHECK CATEGORY":
				s = "Auto_Check_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[2]);
				mi_end = Integer.parseInt(strrange[3]);
				break;
			case "NON_FOOD_PRODUCT":
				s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "RAW_ITEM":
				s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "EVM":
				s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "COMMENT":
				s = "Auto_CMNT_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[6]);
				mi_end = Integer.parseInt(strrange[7]);
				break;
			default:
				break;
			}

			System.out.println("product name:" + s);
			actions.setValue("AddNewMI.MenuItemName", s);

			do {
				mi_num = mcd.fn_GetRndNumInRange(mi_start, mi_end);
				actions.clear("AddNewMI.MenuItemNumber");
				actions.setValue("AddNewMI.MenuItemNumber", mi_num);
				actions.keyboardEnter("AddNewMI.Next");
				Thread.sleep(3000);
				actions.waitForPageToLoad(180);
				boolean blnWindow = false;

				try {
					blnWindow = mcd.SwitchToWindow("@Manage Menu Items");
					if (blnWindow) {
						System.out.println("Menu Name and Number is accepted successfully");
						blnflag = false;
					} else {
						mcd.SwitchToWindow("Add New Menu Item");
						if (actions.isTextPresence(strerrmsg[0], true)) {
							blnflag = true;
							System.out.println("Entered  number " + mi_num + " is already exist.");
							System.out.println(blnflag);
						}
					}

				} catch (Exception err) {
					if (actions.isTextPresence(strerrmsg[0], true)) {
						blnflag = true;
						System.out.println("Entered  number " + mi_num + " is already exist.");
						System.out.println(blnflag);
					}
				}

			} while (blnflag == true);

			// SETTING THE VALUE OF THE MANDATORY FIELDS
			String instance = mcd.GetGlobalData("Instance");
			if (instance.equalsIgnoreCase("AP") || instance.equalsIgnoreCase("QMAP")
					|| instance.equalsIgnoreCase("EU")) {
				actions.setValue("ManageMenuItemCurrentMenuItemDetails.MenuItemType", "SMI");
			}
			actions.setValue("ManageMenuItem.ProductClass", pro_type);
			actions.setValue("ManageMenuItem.ProductCategory", strparam[0]);
			actions.setValue("ManageMenuItem.FamilyGroup", strparam[1]);
			actions.setValue("ManageMenuItem.DayPartCode","BREAKFAST_MENU");
			/*Select select = new Select(driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.DayPartCode"))));
			select.selectByVisibleText("BREAKFAST_MENU");*/
			actions.setValue("ManageMenuItem.ProductLName", s + "LN");
			actions.setValue("ManageMenuItem.ProductSName", s + "SN");
			actions.setValue("ManageMenuItem.ProductDTName", s + "DN");
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("ManageMenuItem.ApplySavebtn");
			Thread.sleep(4000);

			if (pro_type.equals("CHOICE") || pro_type.equals("CHOICE_EVM") || pro_type.equals("CHECK CATEGORY")) {
				mcd.VerifyAlertMessageDisplayed(strerrmsg[4], strerrmsg[4], true, AlertPopupButton.OK_BUTTON);
				flag = true;
			}
			// actions.verifyTextPresence(strerrmsg[2], true);
			// Verify the on-screen message
			flag = mcd.VerifyOnscreenMessage("ManageMenuItem.InfoMes", "Menu Item created successfully.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Menu Item created successfully.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Menu Item created successfully.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Navigate to �POS/KVS Settings� tab
			actions.keyboardEnter("ManageMenuItem.POSKVS_tab");
			actions.smartWait(50);

			// Verify the field mutually exclusive
			if (pro_type.equals("CHOICE") || pro_type.equals("CHECK CATEGORY")) {
				if ((actions.isElementEnabled("Current Menu Item Details.mutuallyexclusive"))) {
					actions.reportCreatePASS("verify the 'Mutually Exclusive DropDown' is Enabled",
							"Add check box is disable", "Mutually Exclusive DropDown should be Enabled", "Pass");

				} else {

					actions.reportCreateFAIL("verify the 'Mutually Exclusive DropDown' is Enabled",
							"Mutually Exclusive DropDown is Enabled",
							"Mutually Exclusive DropDown should not be Enabled", "Fail");
				}
				flag = true;
			}

			// Set the limit in promo per item quantity limit
			actions.clear("ManageMenuItem.PromoPerItemQuantLmt");
			actions.setValue("ManageMenuItem.PromoPerItemQuantLmt", "1");

			// Click on Apply Button
			actions.keyboardEnter("CurrentMenuItemDetails.Apply");
			mcd.waitAndSwitch("Apply Changes Details");
			actions.keyboardEnter("ApplyChangesDetails.RPSaveButton");
			mcd.SwitchToWindow("Manage Menu Items");

			// Navigate to 'Presentation settings' tab
			actions.smartWait(10);
			actions.WaitForElementPresent("ManageMenuItem.PresentationSettings", 10);
			actions.click("ManageMenuItem.PresentationSettings");
			actions.smartWait(20);
			actions.click("ManageMenuItemCurrentMenuItemDetails.apply");
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			mcd.VerifyAlertMessageDisplayed("Warning", "No changes have been made.", true, AlertPopupButton.OK_BUTTON);
			actions.smartWait(10);

			// Verifying presence of 'Components' Button
			Boolean Nextbutton;
			Nextbutton = actions.isElementPresent("ManageMenuItem.Components");
			reporting_Pass_Fail("Verify whether 'Components' Button is present",
					"'Components' Button should be present", "'Components' Button is present",
					"'Components' Button is not present", Nextbutton);

			/*
			 * // Click on <Add/Remove>button
			 * actions.click("ManageMenuItems.AddRemove"); mcd.waitAndSwitch(
			 * "Common Menu Item Selector");
			 * 
			 * // Add the menu item
			 * actions.click("MasterMenuItemList.Searchbtn");
			 * actions.smartWait(20); WebElement elem_checkbox =
			 * mcd.GetTableCellElement("AddRemoveComponent.webtable", 1, "Add",
			 * "input[1]"); actions.javaScriptClick(elem_checkbox); WebElement
			 * elem_checkbox1 =
			 * mcd.GetTableCellElement("AddRemoveComponent.webtable", 2, "Add",
			 * "input[1]"); actions.javaScriptClick(elem_checkbox1);
			 * actions.click("ManageMenuItem.SaveasCSVbtn");
			 * mcd.SwitchToWindow("@Title");
			 * actions.keyboardEnter("ManageMenuItem.ApplySavebtn");
			 * actions.smartWait(100);
			 */

			// CLICKING CANCEL BUTTON TO NAVIGATE TO MAIN PAGE
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.click("ManageMenuItem.Cancelbtn1");
			Thread.sleep(2000);
			mcd.VerifyAlertMessageDisplayed("Warning", "Unsaved data will be lost. Are you sure you want to proceed?",
					true, AlertPopupButton.OK_BUTTON);
			actions.smartWait(180);

		} catch (Exception e) {
			actions.reportCreateFAIL("Verify creation of Menu Item",
					"Menu Item of '" + pro_type + "' should be created",
					"Menu Item of '" + pro_type + "' is not created", "Fail");

		}
		return mi_num;
	}

	// Function for Reporting Pass/Fail
	public void reporting_Pass_Fail(String Desc, String ExpRes, String ActRes_Pass, String ActRes_Fail,
			Boolean status) {
		if (status) {
			actions.reportCreatePASS(Desc, ExpRes, ActRes_Pass, "PASS");
		}

		if (!status) {
			actions.reportCreateFAIL(Desc, ExpRes, ActRes_Fail, "FAIL");
		}
	}

	public int RFM_MI_CreateProductMenuItem_updated(String MIrange, String pro_type, String strmsg,
			String strmenutype) {
		boolean blnflag = false;
		String[] strparam = strmenutype.split("#");
		String[] strrange = MIrange.split("#");
		String strerrmsg[] = strmsg.split("#");
		String s = "";
		int mi_num = 0, mi_start = 0, mi_end = 0;
		try {
			boolean flag = false;

			System.out.println(
					"********************************************************************** Start Test-Steps executions");

			// String MainWindow_NewMenuItem = driver.getWindowHandle();
			WebElement ws = driver.findElement(By.xpath("//*[@class='button button'][contains(text(),'Add New')]"));
			actions.click(ws);

			// actions.windowSwitch(MainWindow_NewMenuItem,"Add New Menu Item");
			mcd.SwitchToWindow("Add New Menu Item");

			switch (pro_type) {
			case "CONTAINER_VALUE_MEAL":
				s = "Auto_CVM_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "PRODUCT":
				s = "Auto_Pro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "VALUE_MEAL":
				s = "Auto_VM_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "CHOICE":
				s = "Auto_Choice_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[0]);
				mi_end = Integer.parseInt(strrange[1]);
				break;
			case "CHOICE_EVM":
				s = mcd.fn_GetRndName("Auto_ChoiceEVM");
				mi_start = Integer.parseInt(strrange[0]);
				mi_end = Integer.parseInt(strrange[1]);
				break;
			case "CHECK CATEGORY":
				s = "Auto_Check_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[2]);
				mi_end = Integer.parseInt(strrange[3]);
				break;
			case "NON_FOOD_PRODUCT":
				s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "RAW_ITEM":
				s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "EVM":
				s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "COMMENT":
				s = "Auto_CMNT_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[6]);
				mi_end = Integer.parseInt(strrange[7]);
				break;
			default:
				break;
			}

			System.out.println("product name:" + s);
			actions.setValue("AddNewMI.MenuItemName", s);

			do {
				mi_num = mcd.fn_GetRndNumInRange(mi_start, mi_end);
				actions.clear("AddNewMI.MenuItemNumber");
				actions.setValue("AddNewMI.MenuItemNumber", mi_num);
				actions.keyboardEnter("AddNewMI.Next");
				Thread.sleep(3000);
				actions.waitForPageToLoad(180);
				boolean blnWindow = false;

				try {
					blnWindow = mcd.SwitchToWindow("@Manage Menu Items");
					if (blnWindow) {
						System.out.println("Menu Name and Number is accepted successfully");
						blnflag = false;
					} else {
						mcd.SwitchToWindow("Add New Menu Item");
						if (actions.isTextPresence(strerrmsg[0], true)) {
							blnflag = true;
							System.out.println("Entered  number " + mi_num + " is already exist.");
							System.out.println(blnflag);
						}
					}

				} catch (Exception err) {
					if (actions.isTextPresence(strerrmsg[0], true)) {
						blnflag = true;
						System.out.println("Entered  number " + mi_num + " is already exist.");
						System.out.println(blnflag);
					}
				}

			} while (blnflag == true);

			// SETTING THE VALUE OF THE MANDATORY FIELDS
			String instance = mcd.GetGlobalData("Instance");
			if (instance.equalsIgnoreCase("AP") || instance.equalsIgnoreCase("QMAP")
					|| instance.equalsIgnoreCase("EU")) {
				actions.setValue("ManageMenuItemCurrentMenuItemDetails.MenuItemType", "SMI");
			}
			actions.setValue("ManageMenuItem.ProductClass", pro_type);
			actions.setValue("ManageMenuItem.ProductCategory", strparam[0]);
			actions.setValue("ManageMenuItem.FamilyGroup", strparam[1]);
			actions.setValue("ManageMenuItem.DayPartCode","BREAKFAST_MENU");
			/*Select select = new Select(driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.DayPartCode"))));
			select.selectByVisibleText("BREAKFAST_MENU");*/
			actions.setValue("ManageMenuItem.ProductLName", s + "LN");
			actions.setValue("ManageMenuItem.ProductSName", s + "SN");
			actions.setValue("ManageMenuItem.ProductDTName", s + "DN");
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("ManageMenuItem.ApplySavebtn");
			Thread.sleep(2000);

			if (pro_type.equals("CHOICE") || pro_type.equals("CHOICE_EVM") || pro_type.equals("CHECK CATEGORY")) {
				mcd.VerifyAlertMessageDisplayed(strerrmsg[4], strerrmsg[4], true, AlertPopupButton.OK_BUTTON);
				flag = true;
			}
			// actions.verifyTextPresence(strerrmsg[2], true);
			// Verify the on-screen message
			flag = mcd.VerifyOnscreenMessage("ManageMenuItem.InfoMes", "Menu Item created successfully.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Menu Item created successfully.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Menu Item created successfully.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Navigate to �POS/KVS Settings� tab
			actions.keyboardEnter("ManageMenuItem.POSKVS_tab");
			actions.smartWait(50);

			// Verify the field mutually exclusive
			if (pro_type.equals("CHOICE") || pro_type.equals("CHECK CATEGORY")) {
				if ((actions.isElementEnabled("Current Menu Item Details.mutuallyexclusive"))) {
					actions.reportCreatePASS("verify the 'Mutually Exclusive DropDown' is Enabled",
							"Add check box is disable", "Mutually Exclusive DropDown should be Enabled", "Pass");

				} else {

					actions.reportCreateFAIL("verify the 'Mutually Exclusive DropDown' is Enabled",
							"Mutually Exclusive DropDown is Enabled",
							"Mutually Exclusive DropDown should not be Enabled", "Fail");
				}
				flag = true;
			}

			// Set the limit in promo per item quantity limit
			actions.clear("ManageMenuItem.PromoPerItemQuantLmt");
			actions.setValue("ManageMenuItem.PromoPerItemQuantLmt", "1");

			// Click on Apply Button
			actions.keyboardEnter("CurrentMenuItemDetails.Apply");
			mcd.waitAndSwitch("Apply Changes Details");
			actions.click("ApplyChangesDetails.FutureDateRadioButton");
			actions.click("ApplyChangesDetails.CalendarIcon");
			actions.smartWait(10);
			mcd.Get_future_date(3, "Close", strApplicationDate);
			actions.keyboardEnter("ApplyChangesDetails.RPSaveButton");
			mcd.SwitchToWindow("Manage Menu Items");

			// Navigate to 'Presentation settings' tab
			actions.smartWait(10);
			actions.WaitForElementPresent("ManageMenuItem.PresentationSettings", 10);
			actions.click("ManageMenuItem.PresentationSettings");
			actions.smartWait(20);
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.click("ManageMenuItemCurrentMenuItemDetails.apply");
			mcd.VerifyAlertMessageDisplayed("Warning", "No changes have been made.", true, AlertPopupButton.OK_BUTTON);
			actions.smartWait(10);

			// Navigate to 'Components' tab
			actions.click("ManageMenuItem.Components");
			actions.smartWait(20);

			// Click on <Add/Remove>button
			actions.click("ManageMenuItems.AddRemove");
			mcd.waitAndSwitch("Common Menu Item Selector");

			// Add the menu item
			actions.click("MasterMenuItemList.Searchbtn");
			actions.smartWait(20);
			WebElement elem_checkbox = mcd.GetTableCellElement("AddRemoveComponent.webtable", 1, "Add", "input[1]");
			actions.javaScriptClick(elem_checkbox);
			WebElement elem_checkbox1 = mcd.GetTableCellElement("AddRemoveComponent.webtable", 2, "Add", "input[1]");
			actions.javaScriptClick(elem_checkbox1);
			actions.click("ManageMenuItem.SaveasCSVbtn");
			mcd.SwitchToWindow("@Title");
			actions.keyboardEnter("ManageMenuItem.ApplySavebtn");
			actions.smartWait(100);

			// CLICKING CANCEL BUTTON TO NAVIGATE TO MAIN PAGE
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.click("ManageMenuItem.Cancelbtn1");
			mcd.VerifyAlertMessageDisplayed("Warning", "Unsaved data will be lost. Are you sure you want to proceed?",
					true, AlertPopupButton.OK_BUTTON);
			actions.smartWait(180);

		} catch (Exception e) {
			actions.reportCreateFAIL("Verify creation of Menu Item",
					"Menu Item of '" + pro_type + "' should be created",
					"Menu Item of '" + pro_type + "' is not created", "Fail");

		}
		return mi_num;
	}

	public int RFM_MI_CreatecopyexistingMenuItem_updated(String MIrange, String pro_type, String strmsg,
			String strmenutype) {
		boolean blnflag = false;
		String[] strparam = strmenutype.split("#");
		String[] strrange = MIrange.split("#");
		String strerrmsg[] = strmsg.split("#");
		String s = "";
		int mi_num = 0, mi_start = 0, mi_end = 0;
		try {
			boolean flag = false;

			System.out.println(
					"********************************************************************** Start Test-Steps executions");

			// String MainWindow_NewMenuItem = driver.getWindowHandle();
			WebElement ws = driver.findElement(By.xpath("//*[@class='button button'][contains(text(),'Add New')]"));
			actions.click(ws);

			// actions.windowSwitch(MainWindow_NewMenuItem,"Add New Menu Item");
			mcd.SwitchToWindow("Add New Menu Item");

			switch (pro_type) {
			case "CONTAINER_VALUE_MEAL":
				s = "Auto_CVM_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "PRODUCT":
				s = "Auto_Pro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "VALUE_MEAL":
				s = "Auto_VM_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "CHOICE":
				s = "Auto_Choice_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[0]);
				mi_end = Integer.parseInt(strrange[1]);
				break;
			case "CHOICE_EVM":
				s = mcd.fn_GetRndName("Auto_ChoiceEVM");
				mi_start = Integer.parseInt(strrange[0]);
				mi_end = Integer.parseInt(strrange[1]);
				break;
			case "CHECK CATEGORY":
				s = "Auto_Check_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[2]);
				mi_end = Integer.parseInt(strrange[3]);
				break;
			case "NON_FOOD_PRODUCT":
				s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "RAW_ITEM":
				s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "EVM":
				s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "COMMENT":
				s = "Auto_CMNT_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[6]);
				mi_end = Integer.parseInt(strrange[7]);
				break;
			default:
				break;
			}

			System.out.println("product name:" + s);
			actions.setValue("AddNewMI.MenuItemName", s);
			actions.javaScriptClick("MMILAddNewMenuItem.yrdbtn");
			actions.keyboardEnter("RFMHome.Select");
			mcd.waitAndSwitch("Copy Settings From Existing Menu Item : Find Menu Item");
			actions.keyboardEnter("MasterMenuItemList.Searchbtn");
			actions.smartWait(120);
			WebElement record = mcd.GetTableCellElement("ScreenSet.Table", 1, "Number", "a");
			actions.keyboardEnter(record);
			mcd.SwitchToWindow("Add New Menu Item");

			do {
				mi_num = mcd.fn_GetRndNumInRange(mi_start, mi_end);
				actions.clear("AddNewMI.MenuItemNumber");
				actions.setValue("AddNewMI.MenuItemNumber", mi_num);
				actions.keyboardEnter("AddNewMI.Next");
				Thread.sleep(3000);
				actions.waitForPageToLoad(180);
				boolean blnWindow = false;

				try {
					blnWindow = mcd.SwitchToWindow("@Manage Menu Items");
					if (blnWindow) {
						System.out.println("Menu Name and Number is accepted successfully");
						blnflag = false;
					} else {
						mcd.SwitchToWindow("Add New Menu Item");
						if (actions.isTextPresence(strerrmsg[0], true)) {
							blnflag = true;
							System.out.println("Entered  number " + mi_num + " is already exist.");
							System.out.println(blnflag);
						}
					}

				} catch (Exception err) {
					if (actions.isTextPresence(strerrmsg[0], true)) {
						blnflag = true;
						System.out.println("Entered  number " + mi_num + " is already exist.");
						System.out.println(blnflag);
					}
				}

			} while (blnflag == true);

			// Navigate to general settings
			/*actions.keyboardEnter("ManageMenuItem.GeneralSettings");
			actions.smartWait(10);
			actions.setValue("ManageMenuItem.ProductClass", "CHECK CATEGORY");
			actions.setValue("ManageMenuItem.ProductCategory", "CUP TYPE");
			actions.setValue("ManageMenuItem.FamilyGroup", "FRIES");
			actions.setValue("ManageMenuItems.DayPartCode", "DAY_MENU");*/
			actions.click("ManageMenuItem.ApplySavebtn");
			actions.smartWait(10);

			// Navigate to �POS/KVS Settings� tab
			actions.smartWait(10);
			actions.keyboardEnter("ManageMenuItem.POSKVS_tab");
			// Verify the CSO should be enabled
			/*if ((actions.isElementEnabled("ManageMenuItems.CSO"))) {
				actions.reportCreatePASS("verify the 'CSO check box' is Enabled", "CSO check box is Enabled",
						"CSO check box should be Enabled", "Pass");

			} else {

				actions.reportCreateFAIL("verify the 'CSO check box' is Enabled", "CSO check box is Enabled",
						"CSO check box should not be Enabled", "Fail");
			}*/

			/*// Navigate to 'Components' tab
			actions.click("ManageMenuItem.Components");
			actions.smartWait(20);

			// Click on <Add/Remove>button
			actions.click("ManageMenuItems.AddRemove");
			mcd.waitAndSwitch("Common Menu Item Selector");

			// Add the menu item
			actions.click("MasterMenuItemList.Searchbtn");
			actions.smartWait(20);
			WebElement elem_checkbox = mcd.GetTableCellElement("AddRemoveComponent.webtable", 1, "Add", "input[1]");
			actions.javaScriptClick(elem_checkbox);
			WebElement elem_checkbox1 = mcd.GetTableCellElement("AddRemoveComponent.webtable", 2, "Add", "input[1]");
			actions.javaScriptClick(elem_checkbox1);
			actions.click("ManageMenuItem.SaveasCSVbtn");
			mcd.SwitchToWindow("@Title");

			// Click on Apply Button
			actions.keyboardEnter("CurrentMenuItemDetails.Apply");
			mcd.waitAndSwitch("Apply Changes Details");
			actions.click("ApplyChangesDetails.FutureDateRadioButton");
			actions.click("ApplyChangesDetails.CalendarIcon");
			actions.smartWait(10);
			mcd.Get_future_date(3, "Close", strApplicationDate);
			actions.keyboardEnter("ApplyChangesDetails.RPSaveButton");
			mcd.SwitchToWindow("Manage Menu Items");
			actions.smartWait(10)*/;

		} catch (Exception e) {

		}
		return mi_num;
	}

}
