package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20421_Vrf_DG_SlctdMstbeUniq {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String dgName;
	private boolean flag;
	private String miName_1;
	private String miName_2;

	public MNU_20421_Vrf_DG_SlctdMstbeUniq(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");

		// TODO: GetTestData for other data-parameters
	}

	@Test
	public void test_MNU_20421_Vrf_DG_SlctdMstbeUniq() throws InterruptedException {
		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription("Verify that The dimension name selected must be unique within the group");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			actions.smartWait(15);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// Verifying Search Full List by Dimension Group Name text box
			String textbox = driver.findElement(By.xpath(actions.getLocator("ProductionRouting.SearchTextField")))
					.getAttribute("type");
			if (textbox.equals("text")) {
				actions.reportCreatePASS("Verifying Search Full List by Dimension Group Name text box",
						"Verifying Search Full List by Dimension Group Name text box should display",
						"Verifying Search Full List by Dimension Group Name text box is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Search Full List by Dimension Group Name text box",
						"Verifying Search Full List by Dimension Group Name text box should display",
						"Verifying Search Full List by Dimension Group Name text box is NOT displayed", "FAIL");

			}

			// Verifying Search within Status DDL
			if (actions.isElementEnabled("ManageDimensionGroup.STSearchWithInStatus")) {
				actions.reportCreatePASS("Verifying Search within Status DDL", "Search within Status DDL should enable",
						"Search within Status DDL is enable", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Search within Status DDL", "Search within Status DDL should enable",
						"Search within Status DDL is not enable", "FAIL");

			}

			// Verifying search button
			if (actions.isElementPresent("SetAssignmentReport.SearchButton")) {
				actions.reportCreatePASS("Verify Search button", "Search button should display",
						"Search button is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Search button", "Search button should display",
						"Search button is not displayed", "FAIL");
			}

			// Verifying New dimension group button
			if (actions.isElementPresent("DimensionGroup.NewDimensionGroupButton")) {
				actions.reportCreatePASS("Verify New Dimension Group button",
						"New Dimension Group button should display", "New Dimension Group button is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify New Dimension Group button",
						"New Dimension Group button should display", "New Dimension Group button is not displayed",
						"FAIL");
			}

			// Verifying save button
			if (actions.isElementPresent("RFMQueueRoutingPopupPage.SaveButton")) {
				actions.reportCreatePASS("Verify Save button", "Save button should display", "Save button is displayed",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Save button", "Save button should display",
						"Save button is not displayed", "FAIL");
			}

			// Verifying CANCEL button
			if (actions.isElementPresent("RFMQueueManagementPage.CancelButton")) {
				actions.reportCreatePASS("Verify Cancel button", "Cancel button should display",
						"Cancel button is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Cancel button", "Cancel button should display",
						"Cancel button is not displayed", "FAIL");
			}

			// Verifying columns code,description,size order and delete
			verifyTablecolumnsPresent("UpdateTaxType.TaxBreakTable", "Group Name");
			verifyTablecolumnsPresent("UpdateTaxType.TaxBreakTable", "Status");
			verifyTablecolumnsPresent("UpdateTaxType.TaxBreakTable", "Delete");

			// Creating dimension group with inactive
			actions.click("DimensionGroup.NewDimensionGroupButton");
			actions.smartWait(15);
			mcd.SwitchToWindow("#Title");
			actions.setValue("DimensionGroups.StatusDDL", "Inactive");
			do {

				dgName = mcd.fn_GetRndName("Auto_DG");
				actions.clear("DimensionGroup.DimensionGroupName");
				actions.setValue("DimensionGroup.DimensionGroupName", dgName);
				actions.click("DimensionGroup.SaveButton");
				flag = mcd.VerifyOnscreenMessage("DimensionGroup.InfoMessage", "Your changes have been saved.", true);

			} while (!(flag));

			// Verify save changes message
			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}

			// UpdateTaxType.TaxBreakTable

			// Adding menu items to dimension group
			actions.click("DimensionGroup.AddMenuItemButton");
			actions.smartWait(5);
			mcd.SwitchToWindow("Common Menu Item Selector");
			actions.smartWait(15);

			List<WebElement> ele1 = driver
					.findElements(By.xpath(actions.getLocator("SetAssignmentReport.SearchButton")));
			actions.click(ele1.get(0));
			actions.smartWait(15);
			WebElement Element = mcd.GetTableCellElement("CommonMenuItemSelector.Table", 1, "Add", "input");
			Element.sendKeys(Keys.SPACE);
			miName_1 = mcd.GetTableCellValue("CommonMenuItemSelector.Table", 1, "Name", "", "");
			Element = mcd.GetTableCellElement("CommonMenuItemSelector.Table", 2, "Add", "input");
			Element.sendKeys(Keys.SPACE);
			miName_2 = mcd.GetTableCellValue("CommonMenuItemSelector.Table", 2, "Name", "", "");
			actions.click("CommonMenuItemSelector.ContinueButton");
			mcd.SwitchToWindow("Dimension Groups");

			// Selecting dimension DDL values
			String Default;
			Element = mcd.GetTableCellElement("DimensionGroups.Table", 1, "Dimension", "select");
			Default = Element.getText();

			Select selectOption = new Select(Element);
			List<WebElement> values = Element.findElements(By.xpath(".//option"));
			if (Default.equals((values.get(0).getText()))) {
				selectOption.selectByVisibleText(values.get(1).getText().toString());
			} else {
				selectOption.selectByVisibleText(values.get(2).getText().toString());
			}

			Element = mcd.GetTableCellElement("DimensionGroups.Table", 2, "Dimension", "select");
			Default = Element.getText();
			selectOption = new Select(Element);
			List<WebElement> values_1 = Element.findElements(By.xpath(".//option"));
			if (Default.equals((values_1.get(0).getText()))) {
				selectOption.selectByVisibleText(values_1.get(1).getText().toString());
			} else {
				selectOption.selectByVisibleText(values_1.get(2).getText().toString());
			}

			// Verify alert message is displayed
			actions.click("DimensionGroups.ApplyButton");
			flag = mcd.VerifyAlertMessageDisplayed("Warning Message",
					"Dimension should be unique within the Dimension Group", true, AlertPopupButton.OK_BUTTON);
			if (flag) {
				actions.reportCreatePASS("Verify the Dimension Name for Menu Items",
						"Message 'Dimension should be unique within the Dimension Group' should be displayed",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the Dimension Name for Menu Items",
						"Message 'Dimension should be unique within the Dimension Group' should be displayed",
						"Expected Message is not displayed", "FAIL");
			}

			selectOption.selectByVisibleText(values_1.get(3).getText().toString());
			actions.click("DimensionGroups.ApplyButton");
			actions.smartWait(15);

			// Verify save changes messages on screen
			flag = false;
			flag = mcd.VerifyOnscreenMessage("DimensionGroup.InfoMessage", "Your changes have been saved.", true);
			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	public void verifyTablecolumnsPresent(String tableLocator, String colName) {

		boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

		if (iscolPresent) {
			actions.reportCreatePASS("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is present in table", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is NOT present in table",
					"Fail");
		}
	}
}
