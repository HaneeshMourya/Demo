package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20428_VrfDGNmeExstinDiffMKT {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strMarket2;
	// TODO: Declare test-data variables for other data-parameters
	private String dgName, strMsg1;
	private boolean flag;
	private String strActivity;

	public MNU_20428_VrfDGNmeExstinDiffMKT(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");

		// TODO: GetTestData for other data-parameters
		strActivity = mcd.GetTestData("DT_Activity");
		strMarket2 = mcd.GetTestData("DT_MARKET2");
		strMsg1 = mcd.GetTestData("DT_MSG1");
	}

	@Test
	public void test_MNU_20428_VrfDGNmeExstinDiffMKT() throws InterruptedException {
		// String strPageTitle = ""; // TODO: Exact page-title
		String strPageSubHeading = ""; // TODO: Page Heading

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(
					"Verify that if Dimension group with same name exists in multiple markets, and if a Dimension group from one market is deleted, it doesn�t get deleted from other market.");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			actions.smartWait(15);

			/** Verify Page Header */
			System.out.println("> Verify Page Heading");
			strPageSubHeading = mcd.GetTestData("DT_PAGE_TITLE");
			mcd.VerifyPageHeading(strPageSubHeading, "SubHeading");

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// Verifying Search within status drop down
			Boolean resultStatus;
			Select selObj = new Select(
					driver.findElement(By.xpath(actions.getLocator("ManageDimensionGroup.STSearchWithInStatus"))));
			resultStatus = selObj.getFirstSelectedOption().getText().trim().equalsIgnoreCase("Active/Inactive");
			reporting_Pass_Fail("Verify whether Status Active/Inactive is selected by default for Status DDL",
					"Status Active/Inactive should be selected by default",
					"Status Active/Inactive is selected by default",
					"Status Active/Inactive is not selected by default", resultStatus);

			// Verifying status drop down
			Boolean resultStatus1;
			Select selObj1 = new Select(driver.findElement(By.xpath(actions.getLocator("PricingSets.StatusFilter"))));
			resultStatus1 = selObj1.getFirstSelectedOption().getText().trim().equalsIgnoreCase("Active/Inactive");
			reporting_Pass_Fail("Verify whether Status Active/Inactive is selected by default for Status DDL",
					"Status Active/Inactive should be selected by default",
					"Status Active/Inactive is selected by default",
					"Status Active/Inactive is not selected by default", resultStatus1);

			// Verifying Manage dimension groups columns

			verifyTablecolumnsPresent("UpdateTaxType.TaxBreakTable", "Status");
			verifyTablecolumnsPresent("UpdateTaxType.TaxBreakTable", "Group Name");
			verifyTablecolumnsPresent("UpdateTaxType.TaxBreakTable", "Delete");

			// Verifying Save button
			if (actions.isElementPresent("RFMQueueRoutingPopupPage.SaveButton")) {
				actions.reportCreatePASS("Verifying Save button ", "Save button should display",
						"Save button is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Save button ", "Save button should display",
						"Save button is not displayed", "FAIL");
			}

			// Verifying Cancel button
			if (actions.isElementPresent("RFMQueueManagementPage.CancelButton")) {
				actions.reportCreatePASS("Verifying Cancel button ", "Cancel button should display",
						"Cancel button is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Cancel button ", "Cancel button should display",
						"Cancel button is not displayed", "FAIL");
			}

			// Click on New dimension group button
			actions.keyboardEnter("DimensionGroup.NewDimensionGroupButton");
			mcd.SwitchToWindow("#Title");

			// Verifying Status drop down
			Boolean resultStatus2;
			Select selObj2 = new Select(driver.findElement(By.xpath(actions.getLocator("DimensionGroups.StatusDDL"))));
			resultStatus2 = selObj2.getFirstSelectedOption().getText().trim().equalsIgnoreCase("Active");
			reporting_Pass_Fail("Verify whether Status Active is selected by default for Status DDL",
					"Status Active should be selected by default", "Status Active is selected by default",
					"Status Active is not selected by default", resultStatus2);

			// Verifying column name of dimension group
			verifyTablecolumnsPresent("FieldPermissions.Table", "Menu Item Code");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Menu Item Name");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Menu Item Status");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Dimension");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Delete");

			// Verifying Add menu item button
			if (actions.isElementPresent("RestaurantUpdt.addbtn")) {
				actions.reportCreatePASS("Verifying Add menu item button", "Add menu item button should display",
						"Add menu item button is dispayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Add menu item button", "Add menu item button should display",
						"Add menu item button is dispayed", "FAIL");
			}

			// Creating dimension group in Australasia market
			do {

				dgName = mcd.fn_GetRndName("Auto_DG");
				actions.clear("DimensionGroup.DimensionGroupName");
				actions.setValue("DimensionGroup.DimensionGroupName", dgName);
				actions.click("DimensionGroup.SaveButton");

				flag = mcd.VerifyOnscreenMessage("DimensionGroup.InfoMessage", "Your changes have been saved.", true);

			} while (!(flag));

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}
			actions.smartWait(180);
			actions.keyboardEnter("DimensionGroup.CancelButton");
			actions.smartWait(180);
			mcd.SwitchToWindow("#Title");

			// Navigate to Home page & Changing to Market2
			actions.select_menu("RFMHomePage.MainMenu", "HOME");
			mcd.SwitchToWindow("#Title");
			actions.keyboardEnter("RFMHome.ChangeMarket");
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket2);

			// Navigate to dimension group
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			actions.smartWait(15);

			// Click on New Dimension group button
			actions.click("DimensionGroup.NewDimensionGroupButton");
			actions.smartWait(15);
			actions.setValue("DimensionGroups.StatusDDL", "Inactive");

			// Creating dimension group in market2
			do {

				actions.clear("DimensionGroup.DimensionGroupName");
				actions.setValue("DimensionGroup.DimensionGroupName", dgName);
				actions.click("DimensionGroup.SaveButton");

				flag = mcd.VerifyOnscreenMessage("DimensionGroup.InfoMessage", "Your changes have been saved.", true);

			} while (!(flag));

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}
			actions.smartWait(180);
			actions.keyboardEnter("DimensionGroup.CancelButton");
			actions.smartWait(180);
			mcd.SwitchToWindow("#Title");

			// Click on Search button
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			actions.smartWait(180);

			// Verifying Group name arrow
			String arrow = driver.findElement(By.xpath(actions.getLocator("MenuItemCustomParam.sortImg")))
					.getAttribute("src");
			if (arrow.contains("up")) {
				actions.reportCreatePASS("Verifying Group name UP arrow",
						"Group name UP arrow should display with ascending order",
						"Group name UP arrow is displayed with ascending order", "PASS");
			} else {
				actions.reportCreateFAIL("VerifyingGroup name UP arrow",
						"Group name UP arrow should display with ascending order",
						"Group name UP arrow is displayed with ascending order", "FAIL");
			}

			// Checking pagination
			if (actions.isElementPresent("ManageDimensionGroups.Pagination")) {
				actions.reportCreatePASS("Verifying Pagination", "Pagination should disaply", "Pagination is displayed",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verifying Pagination", "Pagination should disaply",
						"Pagination is not displayed", "FAIL");
			}

			// Verifying Status drop down

			if (actions.isElementEnabled("PricingSets.StatusFilter")) {
				actions.reportCreatePASS("Verifying Status drop down", "Status drop down should enable",
						"Status drop down is enable", "PASS");
			} else {
				actions.reportCreatePASS("Verifying Status drop down", "Status drop down should enable",
						"Status drop down is not enable", "PASS");
			}

			// Search for market2 dimension group name
			actions.setValue("PricingSets.StatusFilter", "Inactive");
			actions.smartWait(180);
			actions.setValue("PermissionReportbyRole.SearchTextbox", dgName);
			actions.click("ManageDimensionGroup.SearchButton");
			actions.smartWait(180);

			// Clicking on delete button and verify pop up message and click
			// cancel button
			WebElement Element = mcd.GetTableCellElement("ManageDimensionGroup.Table", 1, "Delete", "a");
			actions.click(Element);
			boolean flag = mcd.VerifyAlertMessageDisplayed("Warning Message", strMsg1, true,
					AlertPopupButton.CANCEL_BUTTON);
			if (flag) {
				actions.reportCreatePASS("Verifying Alert message", "Alert message should display",
						"Alert message is displayed as expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Alert message", "Alert message should display",
						"Alert message is not displayed as expected", "FAIL");
			}

			// Clicking on delete button and verify pop up message and click ok
			// button
			actions.click(Element);
			boolean flag7 = mcd.VerifyAlertMessageDisplayed("Warning", strMsg1, true, AlertPopupButton.OK_BUTTON);
			if (flag7) {
				actions.reportCreatePASS("Verifying Alert message", "Alert message should display",
						"Alert message is displayed as expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Alert message", "Alert message should display",
						"Alert message is not displayed as expected", "FAIL");
			}

			// Verify deleted message
			actions.verifyTextPresence("Delete has been successfully completed.", true);

			// Navigate to market1
			actions.select_menu("RFMHomePage.MainMenu", "HOME");
			mcd.SwitchToWindow("#Title");
			actions.keyboardEnter("RFMHome.ChangeMarket");
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			// Navigate to dimension group
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			actions.smartWait(15);

			// Search with market1 dimension group
			actions.setValue("PermissionReportbyRole.SearchTextbox", dgName);
			actions.click("ManageDimensionGroup.SearchButton");
			actions.smartWait(180);

			// Verifying created dimension group is present in another market
			String dim_Name = driver.findElement(By.xpath(actions.getLocator("ProductionRouting.TableFIrstData")))
					.getText();
			if (dim_Name.equals(dgName)) {
				actions.reportCreatePASS("Verifying Dimension group", "Dimension group should display",
						"Dimension group is displayed ", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Dimension group", "Dimension group should display",
						"Dimension group is not displayed ", "FAIL");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	/////// METHOD WE HAVE TO USE FOR THIS
	public void reporting_Pass_Fail(String Desc, String ExpRes, String ActRes_Pass, String ActRes_Fail,
			Boolean status) {
		if (status) {
			actions.reportCreatePASS(Desc, ExpRes, ActRes_Pass, "PASS");
		}

		if (!status) {
			actions.reportCreateFAIL(Desc, ExpRes, ActRes_Fail, "FAIL");
		}
	}

	// VERIFYING TABLE COLUMS CODE
	public void verifyTablecolumnsPresent(String tableLocator, String colName) {

		boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

		if (iscolPresent) {
			actions.reportCreatePASS("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is present in table", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is NOT present in table",
					"Fail");
		}
	}
}
