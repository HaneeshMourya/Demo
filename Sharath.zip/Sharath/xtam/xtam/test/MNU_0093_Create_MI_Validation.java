package xtam.test;

import java.util.Map;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Keywords.DialogType;
import crossbrowser.library.MasterMenuItem;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0093_Create_MI_Validation {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private MasterMenuItem mmi;
	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket, strApplicationDate, strExpectActivity[], strdeleiconwm;
	private String strOperation, StrActivity, StrLevel, StrLevedetails, strDBName, strUserID;
	private boolean flag;
	private String AuditDes;
	
	// TODO: Declare test-data variables for other data-parameters
	private String strNavigateTo, strprotype, pro_type[], strMIrange, strmsg, strmenutype;

	public MNU_0093_Create_MI_Validation(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		mmi = new MasterMenuItem(driver, actions, uiActions, inputData, mcd, rfm);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strprotype = mcd.GetTestData("DT_MENUITEMCLASS");
		strMIrange = mcd.GetTestData("DT_MIRANGE");
		strmsg = mcd.GetTestData("DT_ERR_MSG");
		strmenutype = mcd.GetTestData("DT_MIPARAM");
		StrLevel = mcd.GetTestData("DT_LEVEL");
		StrLevedetails = mcd.GetTestData("DT_LevelDetails");
		StrActivity = mcd.GetTestData("DT_ACTIVITY");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strDBName = mcd.GetTestData("DT_DBNAME");
		strUserID = mcd.GetTestData("DT_USER_NAME");
		strdeleiconwm = mcd.GetTestData("DT_DeletIcon");
		pro_type = strprotype.split("#");
		strExpectActivity = StrActivity.split("#");
		// TODO: GetTestData for other data-parameters
	}

	@Test
	public void test_MNU_0093_Create_MI_Validation() throws InterruptedException {

		try {
			Reporter.log(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(" Create a new menu Item list (Class Choice)");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------

			// calling the create Menu item function
			int strmenu = RFM_MI_CreateMenuItem_updated(strMIrange, pro_type[0], strmsg, strmenutype);
			actions.reportCreatePASS("Verify that Menu item is created or not",
					"Menu Item number-" + strmenu + " of Class-" + pro_type[0] + " should get created ",
					"Menu Item number-" + strmenu + " of Class-" + pro_type[0] + " created succesfully", "Pass");

			// calling the create Menu item function
			int strmenuitem = RFM_MI_CreateMenuItem_updated(strMIrange, pro_type[1], strmsg, strmenutype);
			actions.reportCreatePASS("Verify that Menu item is created or not",
					"Menu Item number-" + strmenuitem + " of Class-" + pro_type[1] + " should get created ",
					"Menu Item number-" + strmenuitem + " of Class-" + pro_type[1] + " created succesfully", "Pass");

			// Verify the Audit log Details
			boolean AuditlogCorrectValuesDisplayed1 = rfm.VerifyAuditLog_Entry(strOperation, strExpectActivity[1],
					StrLevel);

			if (AuditlogCorrectValuesDisplayed1) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "strExpectActivity[1],Level",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation," + "ActivityValue,Level",
						"Correct values are not displayed", "Fail");
			}

			String AuditDescc = "Future Setting for Menu Item " + strmenuitem + " has been updated.";

			boolean isAuditlogCorrectValuesDisplayed1 = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID,
					strOperation, strExpectActivity[1], StrLevel, StrLevedetails, AuditDescc);

			if (isAuditlogCorrectValuesDisplayed1) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are not displayed", "Fail");
			}

			// Navigate Master Menu Item List
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#title");

			// calling the create Menu item function
			int menuitem = RFM_MI_CreateChoiceMenuItem_updated(strMIrange, pro_type[1], strmsg, strmenutype);
			actions.reportCreatePASS("Verify that Menu item is created or not",
					"Menu Item number-" + menuitem + " of Class-" + pro_type[1] + " should get created ",
					"Menu Item number-" + menuitem + " of Class-" + pro_type[1] + " created succesfully", "Pass");

			// Verify the Audit log Details
			boolean AuditlogCorrectValuesDisplayed = rfm.VerifyAuditLog_Entry(strOperation, strExpectActivity[0],
					StrLevel);

			if (AuditlogCorrectValuesDisplayed) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "strExpectActivity[1],Level",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation," + "ActivityValue,Level",
						"Correct values are not displayed", "Fail");
			}

			String AuditDesc = "Menu Item " + menuitem + " has been created.";

			boolean isAuditlogCorrectValuesDisplayed = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID,
					strOperation, strExpectActivity[0], StrLevel, StrLevedetails, AuditDesc);

			if (isAuditlogCorrectValuesDisplayed) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are not displayed", "Fail");
			}

			// Navigate Master Menu Item List
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#title");

			// Select the active menu item
			actions.clear("MenuItemSets.SearchTextField_New");
			actions.setValue("MenuItemSets.SearchTextField_New", strmenu);
			actions.keyboardEnter("MasterMenuItemList.SearchButton_New");
			actions.smartWait(20);
			WebElement record = mcd.GetTableCellElement("ScreenSet.Table", 1, "Number", "a");
			actions.click(record);
			actions.smartWait(20);

			// Click on Status change button and select the future date
			actions.keyboardEnter("ManageMenuItems.ChangeStatus");

			if (input.get("_rowId").toString().toUpperCase().contains("US")) {
				mcd.waitAndSwitch("Approval Status Changes");
				Thread.sleep(2000);
				actions.smartWait(10);
				actions.click("StatusChanges.AddStatusButton");
				actions.click("StatusChanges.CalandarWidgetActiveStatus");
				mcd.Get_future_date(3, "Close", strApplicationDate);
				actions.keyboardEnter("GlobalSettingsMenuItemCustomParam.save");
				mcd.waitAndSwitch("Run Menu Item Usage Report");
				actions.keyboardEnter("GlobalSettingsMenuItemCustomParam.cancel");
				mcd.waitAndSwitch("Approval Status Changes");
				actions.smartWait(10);
				AuditDes = "Approval status for Menu Item " + strmenu + " has been deleted.";

			}

			else if (input.get("_rowId").toString().toUpperCase().contains("AP")) {
				mcd.waitAndSwitch("Status Changes");
				actions.click("ApprovalStatusChanges.AddBtn");
				actions.click("StatusChanges.CalandarWidgetActiveStatus");
				mcd.Get_future_date(3, "Close", strApplicationDate);
				actions.keyboardEnter("MenuItemCustomParam.save");
				mcd.waitAndSwitch("Run Menu Item Usage Report");
				actions.keyboardEnter("MenuItemCustomParam.cancel");
				mcd.SwitchToWindow("Status Changes");
				actions.smartWait(10);
				AuditDes = "Status for Menu Item " + strmenu + " has been deleted.";
			}

			// Verify the on-screen message
			flag = mcd.VerifyOnscreenMessage("CommonMenuItemSelector.InfoMessage", "Your changes have been saved.",
					true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Click on the delete icon
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.CANCEL_BUTTON);
			actions.keyboardEnter("ApprovalStatusChanges.Delete");
			mcd.VerifyAlertMessageDisplayed("Warning Message", strdeleiconwm, true, AlertPopupButton.CANCEL_BUTTON);
			actions.smartWait(5);
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("ApprovalStatusChanges.Delete");
			mcd.VerifyAlertMessageDisplayed("Warning Message", strdeleiconwm, true, AlertPopupButton.OK_BUTTON);

			// Verify the on-screen message
			flag = mcd.VerifyOnscreenMessage("MassSetAssignment.OnScreenMessage",
					"Delete has been successfully completed.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message",
						"Message 'Delete has been successfully completed.'", "Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message",
						"Message 'Delete has been successfully completed.'", "Expected Message is not displayed",
						"FAIL");
			}

			// Close the window
			actions.keyboardEnter("MenuItemCustomParam.cancel");
			mcd.SwitchToWindow("@Title");
			actions.keyboardEnter("MenuItemCustomParam.cancel");
			actions.smartWait(10);

			// Verify the Audit log Details
			boolean AuditlogCorrectValuesDisplayedd = rfm.VerifyAuditLog_Entry(strOperation, strExpectActivity[2],
					StrLevel);

			if (AuditlogCorrectValuesDisplayedd) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "strExpectActivity[1],Level",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation," + "ActivityValue,Level",
						"Correct values are not displayed", "Fail");
			}

			boolean isAuditlogCorrectValuesDisplayedd = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID,
					strOperation, strExpectActivity[2], StrLevel, StrLevedetails, AuditDes);

			if (isAuditlogCorrectValuesDisplayedd) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are not displayed", "Fail");
			}

			// ------------------------------------------------------------------------
			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());

		} finally {
			actions.quitBrowser();
			actions.reportCreatePASS("Closing Browser", "Should close the browser.", "Closed the browser.", "Pass");
			actions.verifyTestCase(this.getClass());
		}
	}

	public int RFM_MI_CreateMenuItem_updated(String MIrange, String pro_type, String strmsg, String strmenutype) {
		boolean blnflag = false;
		String[] strparam = strmenutype.split("#");
		String[] strrange = MIrange.split("#");
		String strerrmsg[] = strmsg.split("#");
		String s = "";
		int mi_num = 0, mi_start = 0, mi_end = 0;
		try {
			boolean flag = false;

			System.out.println(
					"********************************************************************** Start Test-Steps executions");

			// String MainWindow_NewMenuItem = driver.getWindowHandle();
			WebElement ws = driver.findElement(By.xpath("//*[@class='button button'][contains(text(),'Add New')]"));
			actions.click(ws);

			// actions.windowSwitch(MainWindow_NewMenuItem,"Add New Menu Item");
			mcd.SwitchToWindow("Add New Menu Item");

			switch (pro_type) {
			case "CONTAINER_VALUE_MEAL":
				s = "Auto_CVM_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);

				break;
			case "PRODUCT":
				s = "Auto_Pro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "VALUE_MEAL":
				s = "Auto_VM_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "CHOICE":
				s = "Auto_Choice_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[0]);
				mi_end = Integer.parseInt(strrange[1]);
				break;
			case "CHOICE_EVM":
				s = mcd.fn_GetRndName("Auto_ChoiceEVM");
				mi_start = Integer.parseInt(strrange[0]);
				mi_end = Integer.parseInt(strrange[1]);
				break;
			case "CHECK CATEGORY":
				s = "Auto_Check_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[2]);
				mi_end = Integer.parseInt(strrange[3]);
				break;
			case "NON_FOOD_PRODUCT":
				s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "RAW_ITEM":
				s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "EVM":
				s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "COMMENT":
				s = "Auto_CMNT_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[6]);
				mi_end = Integer.parseInt(strrange[7]);
				break;
			default:
				break;
			}

			System.out.println("product name:" + s);
			actions.setValue("AddNewMI.MenuItemName", s);

			do {
				mi_num = mcd.fn_GetRndNumInRange(mi_start, mi_end);
				actions.clear("AddNewMI.MenuItemNumber");
				actions.setValue("AddNewMI.MenuItemNumber", mi_num);
				actions.keyboardEnter("AddNewMI.Next");
				Thread.sleep(3000);
				actions.waitForPageToLoad(180);
				boolean blnWindow = false;

				try {
					blnWindow = mcd.SwitchToWindow("@Manage Menu Items");
					if (blnWindow) {
						System.out.println("Menu Name and Number is accepted successfully");
						blnflag = false;
					} else {
						mcd.SwitchToWindow("Add New Menu Item");
						if (actions.isTextPresence(strerrmsg[0], true)) {
							blnflag = true;
							System.out.println("Entered  number " + mi_num + " is already exist.");
							System.out.println(blnflag);
						}
					}

				} catch (Exception err) {
					if (actions.isTextPresence(strerrmsg[0], true)) {
						blnflag = true;
						System.out.println("Entered  number " + mi_num + " is already exist.");
						System.out.println(blnflag);
					}
				}

			} while (blnflag == true);

			// SETTING THE VALUE OF THE MANDATORY FIELDS
			String instance = mcd.GetGlobalData("Instance");
			if (instance.equalsIgnoreCase("AP") || instance.equalsIgnoreCase("QMAP")
					|| instance.equalsIgnoreCase("EU")) {
				actions.setValue("ManageMenuItemCurrentMenuItemDetails.MenuItemType", "SMI");
			}
			actions.setValue("ManageMenuItem.ProductClass", pro_type);
			actions.setValue("ManageMenuItem.ProductCategory", strparam[0]);
			actions.setValue("ManageMenuItem.FamilyGroup", strparam[1]);
			/*Select select = new Select(driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.DayPartCode"))));
			select.selectByVisibleText("BREAKFAST_MENU");*/
			actions.setValue("ManageMenuItem.DayPartCode", "BREAKFAST_MENU");
			actions.setValue("ManageMenuItem.ProductLName", s + "LN");
			actions.setValue("ManageMenuItem.ProductSName", s + "SN");
			actions.setValue("ManageMenuItem.ProductDTName", s + "DN");
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("ManageMenuItem.ApplySavebtn");
			Thread.sleep(4000);

			if (pro_type.equals("CHOICE") || pro_type.equals("CHOICE_EVM") || pro_type.equals("CHECK CATEGORY")) {
				mcd.VerifyAlertMessageDisplayed(strerrmsg[4], strerrmsg[4], true, AlertPopupButton.OK_BUTTON);
				flag = true;
			}
			// actions.verifyTextPresence(strerrmsg[2], true);
			// Verify the on-screen message
			flag = mcd.VerifyOnscreenMessage("ManageMenuItem.InfoMes", "Menu Item created successfully.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Menu Item created successfully.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Menu Item created successfully.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Navigate to �POS/KVS Settings� tab
			actions.keyboardEnter("ManageMenuItem.POSKVS_tab");
			actions.smartWait(50);

			// Verify the field mutually exclusive
			if (pro_type.equals("CHOICE") || pro_type.equals("CHECK CATEGORY")) {
				if ((actions.isElementEnabled("Current Menu Item Details.mutuallyexclusive"))) {
					actions.reportCreatePASS("verify the 'Mutually Exclusive DropDown' is Enabled",
							"Add check box is disable", "Mutually Exclusive DropDown should be Enabled", "Pass");

				} else {

					actions.reportCreateFAIL("verify the 'Mutually Exclusive DropDown' is Enabled",
							"Mutually Exclusive DropDown is Enabled",
							"Mutually Exclusive DropDown should not be Enabled", "Fail");
				}
				flag = true;
			}

			// Set the limit in promo per item quantity limit
			actions.clear("ManageMenuItem.PromoPerItemQuantLmt");
			actions.setValue("ManageMenuItem.PromoPerItemQuantLmt", "1");

			// Click on Apply Button
			actions.keyboardEnter("CurrentMenuItemDetails.Apply");
			mcd.waitAndSwitch("Apply Changes Details");
			actions.click("ApplyChangesDetails.FutureDateRadioButton");
			actions.click("ApplyChangesDetails.CalendarIcon");
			actions.smartWait(10);
			mcd.Get_future_date(3, "Close", strApplicationDate);
			actions.keyboardEnter("ApplyChangesDetails.RPSaveButton");
			mcd.SwitchToWindow("Manage Menu Items");

			// Navigate to 'Presentation settings' tab
			actions.smartWait(10);
			actions.WaitForElementPresent("ManageMenuItem.PresentationSettings", 10);
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.click("ManageMenuItem.PresentationSettings");
			actions.smartWait(20);
			actions.click("ManageMenuItemCurrentMenuItemDetails.apply");
			mcd.VerifyAlertMessageDisplayed("Warning", "No changes have been made.", true, AlertPopupButton.OK_BUTTON);
			actions.smartWait(10);

			// Navigate to 'Components' tab
			actions.click("ManageMenuItem.Components");
			actions.smartWait(20);

			// Click on <Add/Remove>button
			actions.click("ManageMenuItems.AddRemove");
			mcd.waitAndSwitch("Common Menu Item Selector");

			// Add the menu item
			actions.click("MasterMenuItemList.Searchbtn");
			actions.smartWait(20);
			WebElement elem_checkbox = mcd.GetTableCellElement("AddRemoveComponent.webtable", 1, "Add", "input[1]");
			actions.javaScriptClick(elem_checkbox);
			WebElement elem_checkbox1 = mcd.GetTableCellElement("AddRemoveComponent.webtable", 2, "Add", "input[1]");
			actions.javaScriptClick(elem_checkbox1);
			actions.click("ManageMenuItem.SaveasCSVbtn");
			mcd.SwitchToWindow("@Title");
			actions.keyboardEnter("ManageMenuItem.ApplySavebtn");
			actions.smartWait(100);

			// CLICKING CANCEL BUTTON TO NAVIGATE TO MAIN PAGE
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.click("ManageMenuItem.Cancelbtn1");
			mcd.VerifyAlertMessageDisplayed("Warning", "Unsaved data will be lost. Are you sure you want to proceed?",
					true, AlertPopupButton.OK_BUTTON);
			actions.smartWait(180);

		} catch (Exception e) {
			actions.reportCreateFAIL("Verify creation of Menu Item",
					"Menu Item of '" + pro_type + "' should be created",
					"Menu Item of '" + pro_type + "' is not created", "Fail");

		}
		return mi_num;
	}

	//// ====
	///
	// ====
	public void CopyExistingMI(String MIrange, String mi_num, String strmsg, boolean blnflag) throws Exception {

		// splitting the MI range
		String[] strrange = MIrange.split("#");
		String[] ermsg = strmsg.split("#");

		// Copying the menu Item number now
		actions.click("AddNewMI.Yes_rbtn");
		Thread.sleep(2000);
		// clicking on the select button
		actions.click("AddNewMI.selectbtn");
		Thread.sleep(1000);

		// Switching to New Pop up window
		mcd.SwitchToWindow("Copy Settings From Existing Menu Item");

		// Copy Settings From Existing Menu Item : Find Menu Item

		// searching for the specific Menu item
		actions.click("COPYMI.exactrbtn");
		actions.setValue("COPYMI.searchtextbox", mi_num);
		actions.click("COPYMI.searchbtn");
		Thread.sleep(1000);
		actions.waitForPageToLoad(120);

		// Select web table record now
		WebElement record = mcd.GetTableCellElement("COPYMI.datatable", 1, "Number", "a");
		record.click();
		Thread.sleep(2000);

		// switching to back to previous window
		mcd.SwitchToWindow("Add New Menu Item");

		actions.setValue("AddNewMI.MenuItemName", mcd.fn_GetRndName("VM_"));

		do {
			// Entering Name and number in the fields

			int mi_start = Integer.parseInt(strrange[4]); /// Getting the random
															/// number
			int mi_end = Integer.parseInt(strrange[5]); ////

			actions.clear("AddNewMI.MenuItemNumber");
			actions.setValue("AddNewMI.MenuItemNumber", mcd.fn_GetRndNumInRange(mi_start, mi_end));

			// reading value from the text box
			String menu_num = actions.getValue("AddNewMI.MenuItemNumber");
			actions.click("AddNewMI.Next");

			// ===
			mcd.SwitchToWindow("Master Menu Item List");
			try {
				mcd.SwitchToWindow("Add New Menu Item");
				if (actions.isTextPresence(ermsg[0], true)) {
					blnflag = true;
					// Reporter.log("Entered number "+menu_num+" is already
					// exist.");
					System.out.println(blnflag);
				}
			} catch (Exception e) {
				blnflag = false;
				Thread.sleep(3000);
				mcd.SwitchToWindow("#Title");
				// Reporter.log("Menu Name and Number is accepted
				// successfully");
				System.out.println(driver.getWindowHandles());
			}
		} while (blnflag == true);

	}

	// Function for Reporting Pass/Fail
	public void reporting_Pass_Fail(String Desc, String ExpRes, String ActRes_Pass, String ActRes_Fail,
			Boolean status) {
		if (status) {
			actions.reportCreatePASS(Desc, ExpRes, ActRes_Pass, "PASS");
		}

		if (!status) {
			actions.reportCreateFAIL(Desc, ExpRes, ActRes_Fail, "FAIL");
		}
	}

	public int RFM_MI_CreateChoiceMenuItem_updated(String MIrange, String pro_type, String strmsg, String strmenutype) {
		boolean blnflag = false;
		String[] strparam = strmenutype.split("#");
		String[] strrange = MIrange.split("#");
		String strerrmsg[] = strmsg.split("#");
		String s = "";
		int mi_num = 0, mi_start = 0, mi_end = 0;
		try {
			boolean flag = false;

			System.out.println(
					"********************************************************************** Start Test-Steps executions");

			// String MainWindow_NewMenuItem = driver.getWindowHandle();
			WebElement ws = driver.findElement(By.xpath("//*[@class='button button'][contains(text(),'Add New')]"));
			actions.click(ws);

			// actions.windowSwitch(MainWindow_NewMenuItem,"Add New Menu Item");
			mcd.SwitchToWindow("Add New Menu Item");

			switch (pro_type) {
			case "CONTAINER_VALUE_MEAL":
				s = "Auto_CVM_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "PRODUCT":
				s = "Auto_Pro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "VALUE_MEAL":
				s = "Auto_VM_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "CHOICE":
				s = "Auto_Choice_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[0]);
				mi_end = Integer.parseInt(strrange[1]);
				break;
			case "CHOICE_EVM":
				s = mcd.fn_GetRndName("Auto_ChoiceEVM");
				mi_start = Integer.parseInt(strrange[0]);
				mi_end = Integer.parseInt(strrange[1]);
				break;
			case "CHECK CATEGORY":
				s = "Auto_Check_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[2]);
				mi_end = Integer.parseInt(strrange[3]);
				break;
			case "NON_FOOD_PRODUCT":
				s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "RAW_ITEM":
				s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "EVM":
				s = "Auto_NonPro_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[4]);
				mi_end = Integer.parseInt(strrange[5]);
				break;
			case "COMMENT":
				s = "Auto_CMNT_" + RandomStringUtils.randomAlphabetic(6);
				mi_start = Integer.parseInt(strrange[6]);
				mi_end = Integer.parseInt(strrange[7]);
				break;
			default:
				break;
			}

			System.out.println("product name:" + s);
			actions.setValue("AddNewMI.MenuItemName", s);

			do {
				mi_num = mcd.fn_GetRndNumInRange(mi_start, mi_end);
				actions.clear("AddNewMI.MenuItemNumber");
				actions.setValue("AddNewMI.MenuItemNumber", mi_num);
				actions.keyboardEnter("AddNewMI.Next");
				Thread.sleep(3000);
				actions.waitForPageToLoad(180);
				boolean blnWindow = false;

				try {
					blnWindow = mcd.SwitchToWindow("@Manage Menu Items");
					if (blnWindow) {
						System.out.println("Menu Name and Number is accepted successfully");
						blnflag = false;
					} else {
						mcd.SwitchToWindow("Add New Menu Item");
						if (actions.isTextPresence(strerrmsg[0], true)) {
							blnflag = true;
							System.out.println("Entered  number " + mi_num + " is already exist.");
							System.out.println(blnflag);
						}
					}

				} catch (Exception err) {
					if (actions.isTextPresence(strerrmsg[0], true)) {
						blnflag = true;
						System.out.println("Entered  number " + mi_num + " is already exist.");
						System.out.println(blnflag);
					}
				}

			} while (blnflag == true);

			// SETTING THE VALUE OF THE MANDATORY FIELDS
			String instance = mcd.GetGlobalData("Instance");
			if (instance.equalsIgnoreCase("AP") || instance.equalsIgnoreCase("QMAP")
					|| instance.equalsIgnoreCase("EU")) {
				actions.setValue("ManageMenuItemCurrentMenuItemDetails.MenuItemType", "SMI");
			}
			actions.setValue("ManageMenuItem.ProductClass", pro_type);
			actions.setValue("ManageMenuItem.ProductCategory", strparam[0]);
			actions.setValue("ManageMenuItem.FamilyGroup", strparam[1]);
			Select select = new Select(driver.findElement(By.xpath(actions.getLocator("ManageMenuItem.DayPartCode"))));
			select.selectByIndex(1);
			actions.setValue("ManageMenuItem.ProductLName", s + "LN");
			actions.setValue("ManageMenuItem.ProductSName", s + "SN");
			actions.setValue("ManageMenuItem.ProductDTName", s + "DN");
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.click("ManageMenuItem.ApplySavebtn");
			actions.smartWait(180);

			if (pro_type.equals("CHOICE") || pro_type.equals("CHOICE_EVM") || pro_type.equals("CHECK CATEGORY")) {
				mcd.VerifyAlertMessageDisplayed(strerrmsg[4], strerrmsg[4], true, AlertPopupButton.OK_BUTTON);
				flag = true;
			}

			// CLICKING CANCEL BUTTON TO NAVIGATE TO MAIN PAGE
			actions.click("ManageMenuItem.Cancelbtn1");
			actions.smartWait(100);

		} catch (Exception e) {

		}
		return mi_num;
	}

	//// ====
	///
	// ====
	public void CopyExistingMenuI(String MIrange, String mi_num, String strmsg, boolean blnflag) throws Exception {

		// splitting the MI range
		String[] strrange = MIrange.split("#");
		String[] ermsg = strmsg.split("#");

		// Copying the menu Item number now
		actions.click("AddNewMI.Yes_rbtn");
		Thread.sleep(2000);
		// clicking on the select button
		actions.click("AddNewMI.selectbtn");
		Thread.sleep(1000);

		// Switching to New Pop up window
		mcd.SwitchToWindow("Copy Settings From Existing Menu Item");

		// Copy Settings From Existing Menu Item : Find Menu Item

		// searching for the specific Menu item
		actions.click("COPYMI.exactrbtn");
		actions.setValue("COPYMI.searchtextbox", mi_num);
		actions.click("COPYMI.searchbtn");
		Thread.sleep(1000);
		actions.waitForPageToLoad(120);

		// Select web table record now
		WebElement record = mcd.GetTableCellElement("COPYMI.datatable", 1, "Number", "a");
		record.click();
		Thread.sleep(2000);

		// switching to back to previous window
		mcd.SwitchToWindow("Add New Menu Item");

		actions.setValue("AddNewMI.MenuItemName", mcd.fn_GetRndName("VM_"));

		do {
			// Entering Name and number in the fields

			int mi_start = Integer.parseInt(strrange[4]); /// Getting the random
															/// number
			int mi_end = Integer.parseInt(strrange[5]); ////

			actions.clear("AddNewMI.MenuItemNumber");
			actions.setValue("AddNewMI.MenuItemNumber", mcd.fn_GetRndNumInRange(mi_start, mi_end));

			// reading value from the text box
			String menu_num = actions.getValue("AddNewMI.MenuItemNumber");
			actions.click("AddNewMI.Next");

			// ===
			mcd.SwitchToWindow("Master Menu Item List");
			try {
				mcd.SwitchToWindow("Add New Menu Item");
				if (actions.isTextPresence(ermsg[0], true)) {
					blnflag = true;
					// Reporter.log("Entered number "+menu_num+" is already
					// exist.");
					System.out.println(blnflag);
				}
			} catch (Exception e) {
				blnflag = false;
				Thread.sleep(3000);
				mcd.SwitchToWindow("#Title");
				// Reporter.log("Menu Name and Number is accepted
				// successfully");
				System.out.println(driver.getWindowHandles());
			}
		} while (blnflag == true);

	}

}
