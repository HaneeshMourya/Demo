package xtam.test;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0013_UpdateWithFuture {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket, strerr;
	private String strNavigateTo, strApplicationDate, strmessage;
	// TODO: Declare test-data variables for other data-parameters
	private String strPageTitle, strTableElement, strrfmmsg, strmsg[];

	public MNU_0013_UpdateWithFuture(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strPageTitle = mcd.GetTestData("DT_PAGE_TITLE");
		// TODO: GetTestData for other data-parameters
		strTableElement = "MasterMenuItemList.datatable";
		strrfmmsg = mcd.GetTestData("DT_ERR_MSG");
		strmsg = strrfmmsg.split("#");
		strmessage = mcd.GetTestData("DT_MSG");
		strerr = mcd.GetTestData("DT_ERR");
	}

	@Test
	public void test_MNU_0013_UpdateWithFuture() throws InterruptedException {

		try {
			System.out.println("****************************** Test execution starts");

			actions.setTestcaseDescription(
					"Verify Update Menu Item Details (Future with Current Settings) functionality");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(4000);
			mcd.SwitchToWindow("#Title");
			actions.smartWait(180);

			// Get application time
			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// Create new Menu Item Set
			actions.click("MenuItemSet.NewMISbutton");
			mcd.waitAndSwitch("Add New Menu Item Set");
			String strSetName = mcd.fn_GetRndName("Auto");
			actions.setValue("NewMenuItemSet.SetName", strSetName);
			System.out.println("Menu item Set Name:" + strSetName);
			actions.keyboardEnter("NewMenuItemSet.SelectBtn");
			mcd.waitAndSwitch("Select Node");
			mcd.Selectrestnode("SelectNode.Tree", strMarket);
			mcd.SwitchToWindow("Add New Menu Item Set");
			actions.keyboardEnter("NewMenuItemSet.NextBtn");
			mcd.SwitchToWindow("@Manage Menu Item Set : Common Menu Item Selector");
			actions.keyboardEnter("CommonMenuItem.SearchBtn");
			actions.smartWait(50);
			actions.javaScriptClick("CommonMenuItemSelector.AddCheckBox");
			actions.smartWait(50);
			actions.keyboardEnter("CommonMenuItemSelector.SaveBtn");
			actions.smartWait(180);
			actions.verifyTextPresence("Your changes have been saved.", true);

			// Click on Return to menu items set
			actions.keyboardEnter("MenuItemSets.ReturnToSet");
			mcd.SwitchToWindow("#Title");

			// Verifying New Menu Item Set button
			if (actions.isElementPresent("MenuItemSet.NewMISbutton")) {
				actions.reportCreatePASS("Verify New Menu Item Set button", "New Menu Item Set button should present",
						"New Menu Item Set button is present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify New Menu Item Set button", "New Menu Item Set button should present",
						"New Menu Item Set button is NOT  present", "FAIL");
			}

			// Verifying filter list of Market
			if (!actions.isElementEnabled("MenuItemSets.Marketdrp")) {
				actions.reportCreatePASS("Verify Filter Market dropdown", "Filter Market dropdown should disable",
						"Filter Market dropdown is disable", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Filter Market dropdown", "Filter Market dropdown should disable",
						"Filter Market dropdown is NOT disable", "FAIL");
			}

			// Verifying Country drop down
			if (actions.isElementEnabled("ScreenSet.FilterListRegionDD")) {
				actions.reportCreatePASS("Verify Country drop down", "Country drop down should enable",
						"Country drop down is enable", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Country drop down", "Country drop down should enable",
						"Country drop down is not enable", "FAIL");
			}

			/*
			 * if(strMarket.equals("US Country Office")) {
			 * actions.isElementEnabled(sElement) actions.reportCreatePASS(
			 * "Verify Filter button", "Filter button should enable",
			 * "Filter button is enable", "PASS"); }else{
			 * actions.reportCreatePASS("Verify Filter button",
			 * "Filter button should enable", "Filter button is enable",
			 * "PASS"); }
			 * 
			 * 
			 * i
			 */

			// Verify table columns
			verifyTablecolumnsPresent("FieldPermissions.Table", "Name");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Node");

			// Searching for menu item set
			actions.clear("CopyScreenSet.CopySearchTextBox");
			actions.setValue("CopyScreenSet.CopySearchTextBox", strSetName);
			List<WebElement> ele1 = driver.findElements(By.xpath("//*[@id='menuItemSetSearchForm_']"));
			actions.click(ele1.get(0));
			actions.smartWait(180);
			actions.click("MenuItemSets.TableFirstValue");
			actions.smartWait(180);

			// Checking future settings is there or not
			String future_Setting = driver.findElement(By.xpath(actions.getLocator("ManageMenuItemSet.FutureSettings")))
					.getText();
			if (future_Setting.equals("")) {
				actions.click("MasterMenuItemList.MenuItemNumber");
				actions.smartWait(180);
				rfm.SelectCustOrResetButton("Are you sure you want to Reset the Default values to the Menu Item?",
						"MenuItemSets.Custbtn", "MenuItemSets.Resetbtn");
				actions.clear("ManageMenuItems.SummaryMonitorName");
				actions.setValue("ManageMenuItems.SummaryMonitorName", "AA");
				actions.keyboardEnter("RFMMMIL.Applybtn");
				mcd.SwitchToWindow("Apply Changes Details");
				actions.click("FeeSet.FutureRadioBtn");
				actions.click("MenuItemSets.FutureCal");
				mcd.Get_future_date(2, "Close", strApplicationDate);
				actions.keyboardEnter("ApplyChangesDetails.Save");
				mcd.SwitchToWindow("@Manage Menu Items");
				actions.smartWait(180);

			} else {
				actions.click("MasterMenuItemList.MenuItemNumber");
				// actions.click("ManageMenuItemSet.FutureSettings");
				actions.smartWait(180);
			}

			// Click on cancel button
			actions.keyboardEnter("RFM.CancelBtn");
			mcd.SwitchToWindow("@Manage Menu Item Set : Manage Menu Items");
			// actions.click("MasterMenuItemList.MenuItemNumber");
			actions.click("ManageMenuItemSet.FutureSettings");
			actions.smartWait(180);

			// Verifying status change button
			if (actions.isElementEnabled("RestMIList.ChangeStatusBtn")) {
				actions.reportCreatePASS("Verifying Status change button", "Status change button should enable",
						"Status change is enable", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Status change button", "Status change button should enable",
						"Status change is not enable", "FAIL");
			}

			/*
			 * // Verifying Apply button if (actions.isElementPresent(
			 * "Verifying Apply button")) { actions.reportCreatePASS(
			 * "Verifying Apply button", "Apply button should enable",
			 * "Apply button is enable", "PASS"); } else {
			 * actions.reportCreateFAIL("Verifying Apply button",
			 * "Apply button should enable", "Apply button is not enable",
			 * "FAIL"); }
			 */

			if (actions.isElementPresent("MasterMenuItemList.ExtIngTxt")) {

				actions.reportCreatePASS("Verifying Extra Ingredients", "Extra Ingredients should present",
						"Extra Ingredients is present", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Extra Ingredients", "Extra Ingredients should present",
						"Extra Ingredients is not  present", "FAIL");
			}
			// Click on View current settings button
			actions.keyboardEnter("ManageMenuItem.ViewCurrSetting");
			mcd.SwitchToWindow("Manage Menu Items");
			actions.keyboardEnter("ManageMenuItem.OK");
			mcd.SwitchToWindow("@Manage Menu Items");

			// Click on menu item number link
			actions.keyboardEnter("RFM.CancelBtn");
			mcd.SwitchToWindow("@Manage Menu Item Set : Manage Menu Items");
			actions.click("MasterMenuItemList.MenuItemNumber");
			actions.smartWait(180);

			// Click on customize settings button
			actions.keyboardEnter("ManageMenuItems.CustomizeSettings");
			//

			// Clicking on change approved status BUTTON
			actions.WaitForElementPresent("ManageMenuItems.ChangeApprovedStatus");
			actions.click("ManageMenuItems.ChangeApprovedStatus");
			if (strMarket.equals("US Country Office")) {
				mcd.waitAndSwitch("Approval Status Changes");

				// clicking on add approval status and selecting date form
				// calendar and click save
				actions.WaitForElementPresent("ApprovalStatusChanges.AddApprovalStatus");
				actions.click("ApprovalStatusChanges.AddApprovalStatus");
				actions.click("ApprovalStatusChanges.SelectDate");
				mcd.Get_future_date(0, "close", strApplicationDate);
				actions.keyboardEnter("DimensionNames.SaveBtn");
				actions.smartWait(180);
				// mcd.SwitchToWindow("Menu Item List");

				// Verifying message and navigate to back
				actions.verifyTextPresence("Your changes have been saved.", true);
				// driver.findElement(By.xpath(actions.getLocator("ManageMenuItems.Cancel"))).click();
				// mcd.SwitchToWindow("$Approval Status Changes");
				actions.keyboardEnter("ApprovalStatusChanges.CancelBtn");
				mcd.SwitchToWindow("@Manage Menu Items");
			} else {
				mcd.waitAndSwitch("Status Changes");

				// clicking on status change button and selecting date form
				// calendar and click save
				actions.WaitForElementPresent("ApprovalStatusChanges.AddApprovalStatus");
				actions.click("ApprovalStatusChanges.AddApprovalStatus");
				actions.click("ApprovalStatusChanges.SelectDate");
				mcd.Get_future_date(0, "close", strApplicationDate);
				actions.click("RestaurantMenuItemList.ChangeStatus_Save");
				mcd.VerifyAlertMessageDisplayed("Warning Message",
						"Defining a status on todays date will override the existing current status. Are you sure you want to proceed?",
						true, AlertPopupButton.OK_BUTTON);
				actions.smartWait(180);
				actions.verifyTextPresence("Your changes have been saved.", true);
				actions.keyboardEnter("ApprovalStatusChanges.CancelBtn");
				mcd.SwitchToWindow("@Manage Menu Items");
			}

			// Verifying Rest to default button
			if (actions.isElementPresent("RFMMenuItemSets.ResetToDefault")) {
				actions.reportCreatePASS("Verifying Rest to defaul button", "Rest to defaul button should display",
						"Rest to defaul button is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Rest to defaul button", "Rest to defaul button should display",
						"Rest to defaul button is not displayed", "FAIL");
			}

			// Updating short name value
			actions.WaitForElementPresent("ManageMenuItem.ProductSName");
			actions.clear("ManageMenuItem.ProductSName");
			actions.setValue("ManageMenuItem.ProductSName", RandomStringUtils.randomAlphabetic(4) + "SN");

			/** setting the future settings */
			actions.click("ManageMenuItem.ApplySavebtn");

			actions.isAlertPresent(60);
			// verify the alert displayed
			if (mcd.VerifyAlertMessageDisplayed("Confirmation", strmsg[1].trim(), true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS(
						"Verify message is displayed while updating menu item (Current with Future Settings) as -"
								+ strmsg[1],
						"Message as-" + strmsg[1]
								+ " should be displayed while updating menu item (Current with Future setting)",
						"Message-" + strmsg[1]
								+ " is displayed as expected while updating menu item(Current with Future Settings)",
						"Pass");
			} else {
				actions.reportCreateFAIL(
						"Verify message is displayed while updating menu item (Current with Future Settings) as -"
								+ strmsg[1],
						"Message as-" + strmsg[1]
								+ " should be displayed while updating menu item (Current with Future Settings)",
						"Message-" + strmsg[1]
								+ " is displayed as expected while updating menu item(Current with Future Settings)",
						"Fail");
			}
			actions.verifyTextPresence("Your changes have been saved.", true);

			// Click on Rest to default button
			actions.keyboardEnter("RFMMenuItemSets.ResetToDefault");
			mcd.VerifyAlertMessageDisplayed("Warning Message", strmessage, true, AlertPopupButton.OK_BUTTON);
			actions.smartWait(180);

			/*
			 * //Verifying Apply button disable
			 * if(!actions.isElementEnabled("ManageMenuItem.ApplySavebtn")) {
			 * actions.reportCreatePASS("Verifying Apply button",
			 * "Apply button should disable", "Apply button is disable",
			 * "PASS"); } else { actions.reportCreateFAIL(
			 * "Verifying Apply button", "Apply button should disable",
			 * "Apply button is not disable", "FAIL"); }
			 */

			// Click on component tab
			actions.keyboardEnter("RFMMMIL.ComponentTab");
			actions.smartWait(180);

			// Verifying View Type drop down
			if (actions.isElementEnabled("ManagePackagesPackagesReport.viewType"))

			{
				actions.reportCreatePASS("Verifying View Type drop down", "View Type drop down should enable",
						"View Type drop down is enable", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying View Type drop down", "View Type drop down should enable",
						"View Type drop down is NOT  enable", "FAIL");
			}

			// Click on customize settings buttono
			actions.keyboardEnter("ManageMenuItems.CustomizeSettings");
			actions.smartWait(90);

			// Click on Add/Remove button for adding compositions
			actions.click("RFMCommonMenuItemSelector.AddRemoveCompobtn");
			mcd.SwitchToWindow("Common Menu Item Selector");
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			actions.smartWait(180);

			/*
			 * actions.setValue("MenuItemSets.Status", "Approved");
			 * actions.smartWait(180);
			 */
			actions.setValue("CommonMenuItemSelector.Availability", "Available");
			actions.smartWait(180);

			WebElement checkbox = mcd.GetTableCellElement("AddRemoveComponent.webtable", 1, "Add", "input");
			actions.javaScriptClick(checkbox);

			// Click on continue button
			actions.keyboardEnter("RFMQueueRoutingPopupPage.SaveButton");
			mcd.SwitchToWindow("@Manage Menu Items");
			actions.keyboardEnter("RFMMMIL.Applybtn");

			mcd.VerifyAlertMessageDisplayed("Warning Message", strerr, true, AlertPopupButton.CANCEL_BUTTON);
			actions.keyboardEnter("RFMMMIL.Applybtn");
			mcd.VerifyAlertMessageDisplayed("Warning Message", strerr, true, AlertPopupButton.OK_BUTTON);
			actions.smartWait(180);

			// Click on Add/Remove button for adding can adds
			actions.click("RFMCommonMenuItemSelector.AddRemoveCompobtn");
			mcd.SwitchToWindow("Common Menu Item Selector");
			actions.javaScriptClick("CommonMenuItem.CanAdds");
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			actions.smartWait(180);
			actions.setValue("CommonMenuItemSelector.Availability", "Available");
			actions.smartWait(180);
			WebElement checkbox_canadd = mcd.GetTableCellElement("AddRemoveComponent.webtable", 1, "Add", "input");
			actions.javaScriptClick(checkbox_canadd);

			// Click on continue button
			actions.keyboardEnter("RFMQueueRoutingPopupPage.SaveButton");
			mcd.SwitchToWindow("@Manage Menu Items");
			actions.keyboardEnter("RFMMMIL.Applybtn");
			actions.smartWait(180);

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			// Reporter.log("Test Failed :: " + e.getCause() + " - " +
			// e.getMessage());
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}

	public void Wait_verifyTextPresence(Object text, boolean continueExecution) throws InterruptedException {
		int iterator = 0;
		String temp = mcd.GetGlobalData("StepTimeOut");
		int time = Integer.parseInt(temp);
		int val = 3000 / time;
		int tempMin = time / 60;
		boolean ispresent = false;
		do {
			String pageText = driver.getPageSource();

			if (pageText.contains(strmsg[0].trim())) {
				ispresent = true;
				break;
			} else {
				Thread.sleep(3000);
				iterator = iterator + 1;
			}
		} while (ispresent == false & iterator <= val);
		if (ispresent == true) {
			actions.reportCreatePASS("Verify Text Presence '" + text + "'",
					"Page should contains'" + text.toString() + "'", "Page contains '" + text.toString() + "'", "Pass");
		} else {

			actions.reportCreateFAIL("verify Text Presence'" + text + "'",
					"Page should contains'" + text.toString() + "'",
					"Timed out after '" + tempMin + "'min &" + text.toString() + "' is not displayed", "Fail");

			if (!continueExecution) {
				actions.quitBrowser();
				actions.assertTestCase();
			}
		}
	}

	// VERIFYING TABLE COLUMS CODE
	public void verifyTablecolumnsPresent(String tableLocator, String colName) {

		boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

		if (iscolPresent) {
			actions.reportCreatePASS("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is present in table", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is NOT present in table",
					"Fail");
		}
	}
}
