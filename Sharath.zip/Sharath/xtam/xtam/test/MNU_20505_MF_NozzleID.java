package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20505_MF_NozzleID {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strWM1;
	private String strWM2;
	// TODO: Declare test-data variables for other data-parameters

	public MNU_20505_MF_NozzleID(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strWM1 = mcd.GetTestData("WarningMessage1");
		strWM2 = mcd.GetTestData("WarningMessage2");
		// TODO: GetTestData for other data-parameters
	}

	@Test
	public void test_MNU_20505_MF_NozzleID() throws InterruptedException {
		String strPageTitle = ""; // TODO: Exact page-title
		String strPageSubHeading = "Master Flavors"; // TODO: Page Heading

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription("Verify that the field validation of Nozzle Id Field");
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
			actions.smartWait(10);
			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Verify Page Header */
			// System.out.println("> Verify Page Heading");
			// mcd.VerifyPageHeading(strPageSubHeading, "SubHeading");

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow
			// waiting for element to be present
			actions.WaitForElementPresent("MasterFlavors.NewFlavor", 100);
			// click on new flavor button
			actions.keyboardEnter("MasterFlavors.NewFlavor");
			// getting the row count
			int rw_cnt = mcd.GetTableRowCount("RFMHome.Table");
			System.out.println(rw_cnt);
			// generating random name
			String strRandName = mcd.fn_GetRndName("Auto");
			// setting table value
			mcd.SetTableCellValue("RFMHome.Table", rw_cnt, "Flavor Name", strRandName, "input", "value");
			mcd.SetTableCellValue("RFMHome.Table", rw_cnt, "Nozzle Id", "Aa", "input", "value");
			// click on save button
			actions.click("MasterFlavors.SaveButton");
			
			// verifying warning message for alphabet input in nozzle id
			boolean booVerify1 = mcd.VerifyAlertMessageDisplayed("Warning Message", strWM2, true,
					AlertPopupButton.OK_BUTTON);
			System.out.println(booVerify1);
			if (booVerify1 == true) {
				System.out.println("Displayed");
				actions.reportCreatePASS("Warning Message is Displayed for Alphabet Input in Nozzle ID",
						"Warning Message should Displayed for Alphabet Input in Nozzle ID",
						"Warning Message is Displayed for Alphabet Input in Nozzle ID", "Pass");
			} else {
				actions.reportCreateFAIL("Warning Message is Displayed for Alphabet Input in Nozzle ID",
						"Warning Message should Displayed for Alphabet Input in Nozzle ID",
						"Warning Message is not Displayed for Alphabet Input in Nozzle ID", "Fail");
			}

			mcd.SetTableCellValue("RFMHome.Table", rw_cnt, "Nozzle Id", "$$", "input", "value");
			// click on save button
			actions.click("MasterFlavors.SaveButton");
			
			// verifying warning message for special character in nozzle id
			boolean booVerify2 = mcd.VerifyAlertMessageDisplayed("Warning Message", strWM2, true,
					AlertPopupButton.OK_BUTTON);
			System.out.println(booVerify2);
			if (booVerify2 == true) {
				System.out.println("Displayed");
				actions.reportCreatePASS("Warning Message is Displayed for Special Character Input in Nozzle ID",
						"Warning Message should Displayed for Special Character Input in Nozzle ID",
						"Warning Message is Displayed for Special Character Input in Nozzle ID", "Pass");
			} else {
				actions.reportCreateFAIL("Warning Message is Displayed for Special Character Input in Nozzle ID",
						"Warning Message should Displayed for Special Character Input in Nozzle ID",
						"Warning Message is not Displayed for Special Character Input in Nozzle ID", "Fail");
			}

			mcd.SetTableCellValue("RFMHome.Table", rw_cnt, "Nozzle Id", "-1", "input", "value");
			// click on save button
			actions.click("MasterFlavors.SaveButton");
			Thread.sleep(5000);
			
			// verifying warning message for negative value in nozzle id
			boolean booVerify3 = mcd.VerifyAlertMessageDisplayed("Warning Message", strWM2, true,
					AlertPopupButton.OK_BUTTON);
			System.out.println(booVerify3);
			if (booVerify3 == true) {
				System.out.println("Displayed");
				actions.reportCreatePASS("Warning Message is Displayed for Negative Integer Input in Nozzle ID",
						"Warning Message should Displayed for Negative Integer Input in Nozzle ID",
						"Warning Message is Displayed for Negative Integer Input in Nozzle ID", "Pass");
			} else {
				actions.reportCreateFAIL("Warning Message is Displayed for Negative Integer Input in Nozzle ID",
						"Warning Message should Displayed for Negative Integer Input in Nozzle ID",
						"Warning Message is not Displayed for Negative Integer Input in Nozzle ID", "Fail");
			}
			
			// inputting the correct values
			boolean flag1;
			do {
				flag1 = false;
				int randomNum = mcd.fn_GetRndNumInRange(0, 99);
				System.out.println(randomNum);
				String strI = "" + randomNum;
				System.out.println(strI);

				mcd.SetTableCellValue("RFMHome.Table", rw_cnt, "Nozzle Id", strI, "input", "value");
				// click on save button
				actions.click("MasterFlavors.SaveButton");
				Thread.sleep(5000);
				actions.smartWait(60);

				try {
					System.out.println("> Click on OK button of Alert Box");
					if (mcd.VerifyAlertMessageDisplayed("Warning Message", strWM1, true, AlertPopupButton.OK_BUTTON)) {
						flag1 = true;
					}
					if (mcd.SwitchToWindow("Warning!")) {
						// click on ok button---- 25/08/2016 -to handle other
						// pop which appears when nozzle id is 99, 88 etc.
						Thread.sleep(1500);
						driver.findElement(By.xpath("//*[@id='masterFlavor_deleteWarningMessage_']")).click();
						flag1 = true;
						mcd.waitAndSwitch("Master Flavor");
					}
				} catch (Exception err) {
				}

			} while (flag1 == true);
			// verifying your changes have been saved
			boolean booMsg = mcd.VerifyOnscreenMessage("ManageMenuItems.SaveMessage", "Your changes have been saved.",
					true);
			System.out.println(booMsg);

			if (booMsg == true) {
				actions.reportCreatePASS("Message: 'Your changes have been saved.' is Displayed",
						"Message: 'Your changes have been saved.' should Displayed",
						"Message: 'Your changes have been saved.' is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Message: 'Your changes have been saved.' is Displayed",
						"Message: 'Your changes have been saved.' should Displayed",
						"Message: 'Your changes have been saved.' is not Displayed", "Fail");
			}
			

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}
