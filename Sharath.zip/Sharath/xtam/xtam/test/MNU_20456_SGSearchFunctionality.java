package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_20456_SGSearchFunctionality {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private boolean flag;
	private String strInvalid;
	private String sgName_Vfl, sgName_Active, sgName_Inactive;

	public MNU_20456_SGSearchFunctionality(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		strInvalid = mcd.GetTestData("DT_Invalid");
	}

	@Test
	public void test_MNU_20456_SGSearchFunctionality() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription("Verify the search functionality of Substitution Groups with Status");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			actions.smartWait(180);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// Verifying Manage Substitution Groups columns
			verifyTablecolumnsPresent("UpdateTaxType.TaxBreakTable", "Group Name");
			verifyTablecolumnsPresent("UpdateTaxType.TaxBreakTable", "Status");
			verifyTablecolumnsPresent("UpdateTaxType.TaxBreakTable", "Delete");

			// Verify Save button
			if (actions.isElementPresent("RFMQueueRoutingPopupPage.SaveButton")) {
				actions.reportCreatePASS("Verify Save button", "Save button should display", "Save page is displayed",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Save button", "Save button should display",
						"Save page is  not displayed", "FAIL");
			}

			// Verify Cancel button
			if (actions.isElementPresent("RFMQueueManagementPage.CancelButton")) {
				actions.reportCreatePASS("Verify Cancel button", "Cancel button should display",
						"Cancel button is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Cancel button", "Cancel button should display",
						"Cancel button is  not displayed", "FAIL");
			}

			// Without entering data in search text box click on search button
			actions.clear("ProductionRouting.SearchTextField");
			actions.click("SubstitutionGroups.SearchButton");
			String sub_Group_Name = driver.findElement(By.xpath(actions.getLocator("ProductionRouting.TableFIrstData")))
					.getText();
			int subgrououp_rc = mcd.GetTableRowCount("SubstitutionGroups.Table");
			if (subgrououp_rc > 0) {
				actions.reportCreatePASS("Verifying Substitution group records",
						"Substitution group records should display", "Substitution group records are disaplyed",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verifying Substitution group records",
						"Substitution group records should display", "Substitution group records are NOT disaplyed",
						"FAIL");
			}

			// Enter invalid data in search text and click on search button and
			// verify error message

			actions.clear("SubstitutionGroups.SearchBox");
			actions.setValue("SubstitutionGroups.SearchBox", strInvalid);
			actions.click("SubstitutionGroups.SearchButton");
			actions.smartWait(100);

			actions.verifyTextPresence("Search returned no matching results.", true);

			flag = mcd.VerifyOnscreenMessage("SubstitutionGroups.InfoMessage", "Search returned no matching results.",
					true);

			if (flag) {
				actions.reportCreatePASS("Verify the alert message", "Message 'Search returned no matching results.' ",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the alert message", "Message 'Search returned no matching results.' ",
						"Expected Message is not displayed", "FAIL");
			}

			// Enter Valid data in search text and click on search button
			actions.clear("SubstitutionGroups.SearchBox");
			actions.setValue("SubstitutionGroups.SearchBox", sub_Group_Name);
			actions.click("SubstitutionGroups.SearchButton");
			actions.smartWait(100);

			// Verifying substitution grop is displayed or not
			int subgrououp_rc2 = mcd.GetTableRowCount("SubstitutionGroups.Table");
			if (subgrououp_rc2 > 0) {
				actions.reportCreatePASS("Verifying Substitution group record",
						"Substitution group record should display", "Substitution group record is disaplyed", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Substitution group record",
						"Substitution group record should display", "Substitution group record is NOT disaplyed",
						"FAIL");
			}

			// Taking active and inactive substitution group name
			actions.clear("SubstitutionGroups.SearchBox");
			actions.click("SubstitutionGroups.SearchButton");
			actions.smartWait(180);
			actions.setValue("PricingSets.StatusFilter", "Active");
			actions.smartWait(180);
			String active_sub_Group_Name = driver
					.findElement(By.xpath(actions.getLocator("ProductionRouting.TableFIrstData"))).getText();

			actions.setValue("PricingSets.StatusFilter", "Inactive");
			actions.smartWait(180);
			String inactive_sub_Group_Name = driver
					.findElement(By.xpath(actions.getLocator("ProductionRouting.TableFIrstData"))).getText();

			// Enter �Active� substitution Group name and select inactive from
			// search within status
			actions.clear("SubstitutionGroups.SearchBox");
			actions.click("SubstitutionGroups.SearchButton");
			actions.smartWait(180);
			actions.setValue("SubstitutionGroups.SearchBox", active_sub_Group_Name);
			actions.setValue("SubstitutionGroups.SearchWithinStatus", "Inactive");
			actions.click("SubstitutionGroups.SearchButton");
			actions.smartWait(180);
			actions.verifyTextPresence("Search returned no matching results.", true);

			// Enter �inactive� substitution Group name and select Active from
			// search within status
			actions.clear("SubstitutionGroups.SearchBox");
			actions.click("SubstitutionGroups.SearchButton");
			actions.smartWait(180);
			actions.setValue("SubstitutionGroups.SearchBox", inactive_sub_Group_Name);
			actions.setValue("SubstitutionGroups.SearchWithinStatus", "Active");
			actions.click("SubstitutionGroups.SearchButton");
			actions.smartWait(180);
			actions.verifyTextPresence("Search returned no matching results.", true);

			// Enter �Active� substitution Group name and select Active/Inactive
			// from search within status
			actions.clear("SubstitutionGroups.SearchBox");
			actions.click("SubstitutionGroups.SearchButton");
			actions.smartWait(180);
			actions.setValue("SubstitutionGroups.SearchBox", active_sub_Group_Name);
			actions.setValue("SubstitutionGroups.SearchWithinStatus", "Active/Inactive");
			actions.click("SubstitutionGroups.SearchButton");
			actions.smartWait(180);

			// Verifying substitution grop is displayed or not
			int subgrououp_rc3 = mcd.GetTableRowCount("SubstitutionGroups.Table");
			if (subgrououp_rc3 > 0) {
				actions.reportCreatePASS("Verifying Substitution group record",
						"Substitution group record should display", "Substitution group record is disaplyed", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Substitution group record",
						"Substitution group record should display", "Substitution group record is NOT disaplyed",
						"FAIL");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	// VERIFYING TABLE COLUMS CODE
	public void verifyTablecolumnsPresent(String tableLocator, String colName) {

		boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

		if (iscolPresent) {
			actions.reportCreatePASS("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is present in table", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is NOT present in table",
					"Fail");
		}
	}
}
